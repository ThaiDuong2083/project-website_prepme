INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,2400,'LISTENING',false,'IELTS Simulation Set 3 Listening test 1',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,2400,'LISTENING',true,'IELTS Simulation Set 3 Listening test 2',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,2400,'LISTENING',true,'IELTS Simulation Set 3 Listening test 3',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'READING',false,'IELTS Simulation Set 3 Reading test 1',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'READING',true,'IELTS Simulation Set 3 Reading test 2',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'READING',true,'IELTS Simulation Set 3 Reading test 3',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking 3 test 3',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'WRITING',true,'IELTS Practice Set 3 Writing 3 test 2',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking 3 test 2',NULL),
	 ('2026-05-30 17:31:40','',false,NULL,'','',3600,'WRITING',false,'IELTS Practice Set 3 Writing test 4',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-05-30 17:31:40','',false,NULL,'','',3600,'WRITING',false,'IELTS Practice Set 3 Writing test 5',NULL),
	 ('2026-05-30 17:31:40','',false,NULL,'','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 6',NULL),
	 ('2026-05-30 17:31:40','',false,NULL,'','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 7',NULL),
	 ('2026-05-30 17:31:40','',false,NULL,'','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 8',NULL),
	 ('2026-06-06 23:50:39.391185','user_56659',false,'2026-06-06 23:50:39.391185','user_56659',NULL,3600,'WRITING',false,'IELTS Practice Set 10 writing test 1',NULL),
	 ('2026-06-07 00:24:33.300056','user_56659',false,'2026-06-07 00:24:33.300056','user_56659',NULL,3600,'WRITING',false,'IELTS Practice Set 11 writing test 1',NULL),
	 ('2026-06-07 00:29:41.088076','user_56659',false,'2026-06-07 00:29:41.088076','user_56659',NULL,3600,'WRITING',false,'IELTS Practice Set 12 writing test 1 ',NULL),
	 ('2026-06-07 10:21:44.85036','user_56659',false,'2026-06-07 10:21:44.85036','user_56659',NULL,900,'SPEAKING',false,'IELTS Practice Set 3 Speaking test 4',NULL),
	 ('2026-06-07 10:52:22.951994','user_56659',false,'2026-06-07 10:52:22.951994','user_56659',NULL,900,'SPEAKING',false,'IELTS Practice Set 3 Speaking test 8',NULL),
	 ('2026-06-07 10:56:01.68929','user_56659',false,'2026-06-07 10:56:01.68929','user_56659',NULL,900,'SPEAKING',false,'IELTS Practice Set 11 speaking test 1',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-07 10:58:05.921977','user_56659',false,'2026-06-07 10:58:05.921977','user_56659',NULL,900,'SPEAKING',false,'IELTS Practice Set 12 speaking test 1',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking 3 test  1',NULL),
	 ('2026-06-07 10:44:13.73424','user_56659',false,'2026-06-07 10:44:13.73424','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 5',NULL),
	 ('2026-06-07 10:47:35.515203','user_56659',false,'2026-06-07 10:47:35.515203','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 6',NULL),
	 ('2026-06-07 10:49:38.030278','user_56659',false,'2026-06-07 10:49:38.030278','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 7',NULL),
	 ('2026-06-07 10:54:05.511224','user_56659',false,'2026-06-07 10:54:05.511224','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 10 speaking test 1',NULL),
	 ('2026-06-07 11:00:43.582328','user_56659',false,'2026-06-07 11:00:43.582328','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 13 speaking test 1',NULL),
	 ('2026-06-07 11:03:51.648411','user_56659',false,'2026-06-07 11:03:51.648411','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 14 speaking test 1',NULL),
	 ('2026-06-07 11:05:40.646484','user_56659',false,'2026-06-07 11:05:40.646484','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 15 speaking test 1',NULL),
	 ('2026-06-07 11:07:00.268813','user_56659',false,'2026-06-07 11:07:00.268813','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 16 speaking test 1',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-07 11:08:23.447469','user_56659',false,'2026-06-07 11:08:23.447469','user_56659',NULL,900,'SPEAKING',true,'IELTS Practice Set 17 speaking test 1',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'WRITING',true,'IELTS Practice Set 3 Writing 3 test 3',NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,NULL,3600,'WRITING',true,'IELTS Practice Set 3 Writing 3 test 1',NULL),
	 ('2026-06-07 00:32:33.141359','user_56659',false,'2026-06-07 00:32:33.141359','user_56659',NULL,3600,'WRITING',true,'IELTS Practice Set 13 writing test 1',NULL),
	 ('2026-06-07 00:38:04.300962','user_56659',false,'2026-06-07 00:38:04.301555','user_56659',NULL,3600,'WRITING',true,'IELTS Practice Set 14 writing test 1',NULL),
	 ('2026-06-07 00:39:28.891321','user_56659',false,'2026-06-07 00:39:28.891321','user_56659',NULL,3600,'WRITING',true,'IELTS Practice Set 15 writing test 1',NULL),
	 ('2026-06-07 00:41:18.935856','user_56659',false,'2026-06-07 00:41:18.935856','user_56659',NULL,3600,'WRITING',true,'IELTS Practice Set 16 writing test 1',NULL),
	 ('2026-06-07 00:42:48.159934','user_56659',false,'2026-06-07 00:42:48.159934','user_56659',NULL,3600,'WRITING',true,'IELTS Practice Set 17 writing test 1',NULL),
	 ('2026-06-07 13:30:19.955758','user_56659',false,'2026-06-07 13:30:19.955758','user_56659',NULL,3600,'READING',false,'IELTS Practice Set 3 Reading test 1',NULL),
	 ('2026-06-07 14:40:23.60344','user_56659',false,'2026-06-07 14:40:23.60344','user_56659',NULL,3600,'READING',false,'IELTS Practice Set 3 Reading test 2',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-07 16:21:28','user_05335',false,'2026-06-07 16:21:28','user_05335','',3600,'READING',false,'IELTS Practice Set 3 Reading test 7',NULL),
	 ('2026-06-07 16:21:28','user_05335',false,'2026-06-07 16:21:28','user_05335','',3600,'READING',false,'IELTS Practice Set 3 Reading test 8',NULL),
	 ('2026-06-07 19:01:47','user_05335',false,'2026-06-07 19:01:47','user_05335','',3600,'READING',true,'IELTS Practice Set 11 reading test 3',NULL),
	 ('2026-06-07 19:24:21','user_05335',false,'2026-06-07 19:24:21','user_05335','',3600,'READING',true,'IELTS Practice Set 12 reading test 3',NULL),
	 ('2026-06-07 14:40:40.203927','user_56659',false,'2026-06-07 14:40:40.203927','user_56659',NULL,3600,'READING',true,'IELTS Practice Set 3 Reading test 3',NULL),
	 ('2026-06-07 14:40:56.293296','user_56659',false,'2026-06-07 14:40:56.293296','user_56659',NULL,3600,'READING',true,'IELTS Practice Set 3 Reading test 4',NULL),
	 ('2026-06-07 18:22:57.827195','user_56659',false,'2026-06-07 18:22:57.827195','user_56659',NULL,3600,'READING',true,'IELTS Practice Set 14 reading test 1',NULL),
	 ('2026-06-07 16:21:28','user_05335',false,'2026-06-07 16:21:28','user_05335','',3600,'READING',true,'IELTS Practice Set 3 Reading test 5',NULL),
	 ('2026-06-07 16:21:28','user_05335',false,'2026-06-07 16:21:28','user_05335','',3600,'READING',true,'IELTS Practice Set 3 Reading test 6',NULL),
	 ('2026-06-07 19:26:26.121837','user_56659',false,'2026-06-07 19:26:26.121837','user_56659',NULL,3600,'READING',true,'IELTS Practice Set 7 reading test 1 ',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-07 18:38:00','user_05335',false,'2026-06-07 18:38:00','user_05335','',3600,'READING',true,'IELTS Practice Set 10 reading test 3',NULL),
	 ('2026-05-30 17:31:40','truongdx18vtit',false,'2026-05-30 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 4',NULL),
	 ('2026-05-31 17:31:40','truongdx18vtit',false,'2026-05-31 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 5',NULL),
	 ('2026-06-01 17:31:40','truongdx18vtit',false,'2026-06-01 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 6',NULL),
	 ('2026-06-02 17:31:40','truongdx18vtit',false,'2026-06-02 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 7',NULL),
	 ('2026-06-03 17:31:40','truongdx18vtit',false,'2026-06-03 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 14 listening test 1 ',NULL),
	 ('2026-06-04 17:31:40','truongdx18vtit',false,'2026-06-04 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 15 listening test 1',NULL),
	 ('2026-06-05 17:31:40','truongdx18vtit',false,'2026-06-05 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 13 listening test 1',NULL),
	 ('2026-06-06 17:31:40','truongdx18vtit',false,'2026-06-06 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 16 listening test 1',NULL),
	 ('2026-06-07 17:31:40','truongdx18vtit',false,'2026-06-07 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 17 listening test 1',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-08 17:31:40','truongdx18vtit',false,'2026-06-08 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 18 listening test 1',NULL);
