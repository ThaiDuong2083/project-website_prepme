INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SYLVIA',NULL,NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ENGLAND',NULL,NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'26 JULY',NULL,NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'2',NULL,NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'HOLIDAY',NULL,NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'APARTMENT',NULL,NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SECURE',NULL,NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MOTORWAY ACCESS',NULL,NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PALM BEACH',NULL,NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',1,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'1500',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',1,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A BIRTHDAY PARTY',NULL,NULL,NULL,15,'What special event will the Sea Life Centre arrange for you?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A QUIZ',NULL,NULL,NULL,17,'What can you use to test what you have learnt?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WORLD OF WATER',NULL,NULL,NULL,11,'What was the Sea Life Centre previously called?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE GOVERNMENT',NULL,NULL,NULL,16,'
Where will the petition for animal conservation be sent to?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,'[
    "A. 12.",
    "B. 20.",
    "C. 200."
  ]',13,'The original number of founding members was about','MULTIPLE_CHOICE',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,'[
  "A. at the front counter.",
  "B. in the lobby.",
  "C. at the back of the hall."
]',11,'Refreshments will be served','MULTIPLE_CHOICE',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,'[
    "A. males up to 75.",
    "B. females with young children.",
    "C. males and females of any age."
  ]',14,'
The club provides activities primarily for reasonably fit','MULTIPLE_CHOICE',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,'[
    "A. on the radio.",
    "B. on a billboard.",
    "C. in the newspaper."
  ]',12,'Nick Noble advertised','MULTIPLE_CHOICE',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TRAMPING',NULL,NULL,NULL,15,NULL,'FILL_IN_THE_BLANK',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WALKING',NULL,NULL,NULL,16,NULL,'FILL_IN_THE_BLANK',2,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ORGANIZER',NULL,NULL,NULL,17,NULL,'FILL_IN_THE_BLANK',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VARIABLE',NULL,NULL,NULL,18,NULL,'FILL_IN_THE_BLANK',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MYSTERY',NULL,NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CHAIRMAN',NULL,NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',2,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ED 995',NULL,NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DOCUMENT',NULL,NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ECONOMIC STRUCTURES',NULL,NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'IMPACT',NULL,NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WRITTEN REVIEW',NULL,NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SEMINAR',NULL,NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',3,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TOWER',NULL,NULL,NULL,27,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'2008',NULL,NULL,NULL,28,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BROWN',NULL,NULL,NULL,29,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'KNOWLEDGE POLICY',NULL,NULL,NULL,30,NULL,'FILL_IN_THE_BLANK',3,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ATTACKS',NULL,NULL,NULL,31,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DISEASE',NULL,NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ACTIVE',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DEFENCE',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BLOOD',NULL,NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'INFECTED COWS',NULL,NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',4,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'EXPERIMENT',NULL,NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'F',NULL,NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',4,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'3000 WORDS',NULL,NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SURPRISE',NULL,NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'16',NULL,NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'AUGUST',NULL,NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'COMP4SS',NULL,NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'POST',NULL,NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',5,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FAMOUS AUTHORS',NULL,NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ONLINE',NULL,NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PUBLIC',NULL,NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SPAIN',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',5,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SPLASH RIDE',NULL,NULL,NULL,12,'What is the newest attraction called?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'12 O''CLOCK',NULL,NULL,NULL,13,'When is the main feeding time?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FEED SHARKS',NULL,NULL,NULL,14,'What can you do with a VIP ticket?','FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,18,NULL,'FILL_IN_THE_BLANK',6,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',6,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,'[
    "A. the topic",
    "B. the length",
    "C. the deadline"
  ]',29,NULL,'MULTIPLE_CHOICE',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,'[
    "A. in a hall of residence",
    "B. in a flat on his own",
    "C. with a host family"
  ]',30,NULL,'MULTIPLE_CHOICE',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'D',NULL,NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,'[
    "A. sociable",
    "B. intelligent",
    "C. energetic"
  ]',27,NULL,'MULTIPLE_CHOICE',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MATHEMATICS',NULL,NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'JET ENGINES',NULL,NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SEMINARS',NULL,NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,'[
    "A. lose his shyness",
    "B. settle into university",
    "C. get to know his subject better"
  ]',28,NULL,'MULTIPLE_CHOICE',7,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THEORY',NULL,NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',7,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WEAK VERBS',NULL,NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PREDICTING',NULL,NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CONSISTENT',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A SILENCE ',NULL,NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PAY ATTENTION',NULL,NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'GRAPHICS',NULL,NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'REPEAT IT',NULL,NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TONE',NULL,NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NEXT STEPS',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',8,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SUPPORTIVE',NULL,NULL,NULL,31,NULL,'FILL_IN_THE_BLANK',8,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SYMONDS',NULL,NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'1996',NULL,NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FULL TIME',NULL,NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SWIMMING',NULL,NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MONTHLY',NULL,NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'GO JOGGING',NULL,NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BAD ANKLE',NULL,NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FITNESS LEVEL',NULL,NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CHARITY WORKER',NULL,NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',9,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ON THE RADIO',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',9,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,'[
    "A. 7.15",
    "B. 7.30",
    "C. 7.45"
  ]',13,'Guests will start arriving at','MULTIPLE_CHOICE',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,'[
    "A. live band",
    "B. comedian",
    "C. magician"
  ]',14,'The entertainment will be a','MULTIPLE_CHOICE',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,'[
    "A. trade fair",
    "B. wedding",
    "C. party"
  ]',11,'
The next event at the hotel will be
','MULTIPLE_CHOICE',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,'[
    "A. less than 50",
    "B. from 50 to 100",
    "C. more than 100"
  ]',12,'The number of guests will be','MULTIPLE_CHOICE',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,16,NULL,'FILL_IN_THE_BLANK',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SPEAKERS',NULL,NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,15,NULL,'FILL_IN_THE_BLANK',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,17,NULL,'FILL_IN_THE_BLANK',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'LOUNGE',NULL,NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',10,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'RING A BELL',NULL,NULL,NULL,18,NULL,'FILL_IN_THE_BLANK',10,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FIRST DRAFT',NULL,NULL,NULL,29,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE COUNCIL',NULL,NULL,NULL,27,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WATER',NULL,NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PINE FORESTS',NULL,NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SOME DATA',NULL,NULL,NULL,28,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SORT',NULL,NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'REMOVE INK',NULL,NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE INTRODUCTION',NULL,NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PRINT',NULL,NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',11,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE TUTOR',NULL,NULL,NULL,30,NULL,'FILL_IN_THE_BLANK',11,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PRODUCTS',NULL,NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SKIN',NULL,NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PROTECTION',NULL,NULL,NULL,31,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'OIL',NULL,NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CAP',NULL,NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FLEXIBLE',NULL,NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'100000',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BLUE BERRIES',NULL,NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ELEPHANTS',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',12,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ACTIVE',NULL,NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',12,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CONFERENCE',NULL,NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,36,'
He highlighted the limitations and deceptions of the camera.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT GIVEN',NULL,NULL,NULL,9,NULL,'TRUE_FALSE_NOT_GIVEN',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'LAUNCH',NULL,NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,37,'He highlighted the limitations and deceptions of the camera.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,40,'He felt photography was part of the trend towards greater mechanisation.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'G',NULL,NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'D',NULL,NULL,'[
    "A. an example of poor talent",
    "B. a message that cannot be trusted",
    "C. an advertisement for something new",
    "D. a signal that something bad will happen"
  ]',29,'
What does the writer mean in line 59 by ‘the handwriting on the wall’?','MULTIPLE_CHOICE',15,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TRUE',NULL,NULL,NULL,6,NULL,'TRUE_FALSE_NOT_GIVEN',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'COST TIME',NULL,NULL,NULL,13,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'LOCAL',NULL,NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,14,'evidence that a significant number of airports provide meeting facilities','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,15,'a statement regarding the fact that no further developments are possible in some areas of airport trade','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,17,'mention of the impact of budget airlines on airport income','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SECURITY PROCEDURES',NULL,NULL,NULL,19,'The length of time passengers spend shopping at airports has been affected by updated……………………','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ED 995',NULL,NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'5 YEARS',NULL,NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'COMPETITIVE ADVANTAGE',NULL,NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',14,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,39,'He based some of the scenes in his paintings on photographs.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ULTRASOUND SIGNALS',NULL,NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NO',NULL,NULL,NULL,28,'Our ability to deal with a lot of input material has improved over time.','YES_NO_NOT_GIVEN',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,'[
    "A. the most educated worried about its impact on public taste",
    "B. it helped artists appreciate the merits of photography",
    "C. improvements were made in photographic methods",
    "D. it led to a reduction in price of photographs"
  ]',30,'What was the result of the widespread availability of photographs to the middle classes?','MULTIPLE_CHOICE',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,31,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'D',NULL,NULL,NULL,38,'He noted the potential for photography to enrich artistic talent.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,35,'He claimed that photography would make paintings more realistic.','FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PROPOSALS',NULL,NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FLAVOURS',NULL,NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ROAD',NULL,NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',13,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SPATIAL MAP',NULL,NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FALSE',NULL,NULL,NULL,8,NULL,'TRUE_FALSE_NOT_GIVEN',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'EXHIBITION',NULL,NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FALSE',NULL,NULL,NULL,7,NULL,'TRUE_FALSE_NOT_GIVEN',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CHOCOLATE',NULL,NULL,NULL,12,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'APPETITES',NULL,NULL,NULL,13,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MEMORIES',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'6M',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'MOLECULES',NULL,NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FINAL DESTINATION',NULL,NULL,NULL,20,'Airports with a wide range of recreational facilities can become a……………………………for people rather than a means to travel.','FILL_IN_THE_BLANK',14,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'G',NULL,NULL,NULL,16,'reference to the low level of income that meeting facilities produce for airport
        
s','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TOXINS',NULL,NULL,NULL,3,'
The tongue was originally developed to recognise the unpleasant taste of……………………..','FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE HULL SHAPE',NULL,NULL,NULL,12,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,18,'
examples of airport premises that might be used for business purposes','FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FLIGHTS',NULL,NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PADS OF MOSS',NULL,NULL,NULL,11,NULL,'FILL_IN_THE_BLANK',13,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ECONOMIC DOWNTURN',NULL,NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',14,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'D',NULL,NULL,'[
    "A. that only artists could reflect a culture’s true values",
    "B. that only artists were qualified to judge photography",
    "C. that artists could lose work as a result of photography",
    "D. that artistic success raised a country’s international profile"
  ]',28,'What public view about artists was shared by the French and the English?','MULTIPLE_CHOICE',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,'[
    "A. Photography is used for many different purposes",
    "B. Photographers and artists have the same principal aims",
    "C. Photography has not always been a readily accepted art form",
    "D. Photographers today are more creative than those of the past"
  ]',27,'What is the writer’s main point in the first paragraph?','MULTIPLE_CHOICE',15,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SMELL',NULL,NULL,NULL,1,'According to scientists, the term………………………….characterises the most critical factor in appreciating flavour.','FILL_IN_THE_BLANK',16,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'PREY',NULL,NULL,NULL,11,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SOCIAL LIFE',NULL,NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DISCIPLINES',NULL,NULL,NULL,5,'Gordon Shepherd uses the word ‘neurogastronomy’ to draw together a number of…………………………related to the enjoyment of eating.','FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'UMAMI',NULL,NULL,NULL,2,'‘Savoury’ is a better-known word for………………………','FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'INTERNAL SCENTS/SMELLS',NULL,NULL,NULL,4,'Human nasal cavities recognize……………………………much better than external ones.','FILL_IN_THE_BLANK',16,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'IV',NULL,NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'I',NULL,NULL,NULL,18,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VIII',NULL,NULL,NULL,16,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'II',NULL,NULL,NULL,15,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,22,'
It will take considerable time for modern robots to match the ones we have created in films and books','FILL_IN_THE_BLANK',17,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,21,'
We have stopped trying to enable robots to perceive objects as humans do.','FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,20,'An important concern for scientists is to ensure that robots do not seem frightening.','FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'V',NULL,NULL,NULL,14,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VII',NULL,NULL,NULL,17,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'COLUMN',NULL,NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FLOORING',NULL,NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VI',NULL,NULL,NULL,17,'Paragraph D','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CONCRETE',NULL,NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'III',NULL,NULL,NULL,18,'Paragraph E','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FACTORY',NULL,NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',20,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'STRUCTURAL REVOLUTION',NULL,NULL,NULL,23,'Zhang refers to his business as a……………………………','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TRUE',NULL,NULL,NULL,4,'Forager ants are able to react quickly to a dangerous situation.','TRUE_FALSE_NOT_GIVEN',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT_GIVEN',NULL,NULL,NULL,3,'Forager ants tell each other how far away the food source is.','TRUE_FALSE_NOT_GIVEN',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'YES',NULL,NULL,NULL,30,'A legal trial could be significantly affected by change blindness.','YES_NO_NOT_GIVEN',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,8,'Citizens in an annual Vermont meeting','FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT GIVEN',NULL,NULL,NULL,27,'What is the writer’s main point in the first paragraph?','YES_NO_NOT_GIVEN',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,23,'We need to enable robots to move freely before we think about trying to communicate with them.','FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'IDENTIFICATION',NULL,NULL,NULL,35,'He claimed that photography would make paintings more realistic.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'ON BOARD COMPUTER',NULL,NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NO',NULL,NULL,NULL,31,'Scientists have concluded that we try to take in as much detail as possible from our surroundings.','YES_NO_NOT_GIVEN',18,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TOUCH SCREEN',NULL,NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',17,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'THE DOOR',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SCOUTS',NULL,NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FALSE',NULL,NULL,NULL,1,'Commuters are often compared favourably with worker ants','TRUE_FALSE_NOT_GIVEN',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'WAGGLE DANCE',NULL,NULL,NULL,11,NULL,'FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,9,'Some Internet users','FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,7,'Managers working for a Texas gas company','FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT_GIVEN',NULL,NULL,NULL,5,'Termite mounds can be damaged by the wind.','TRUE_FALSE_NOT_GIVEN',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DEMOCRATIC',NULL,NULL,NULL,13,NULL,'FILL_IN_THE_BLANK',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TRUE',NULL,NULL,NULL,6,'Termites repair their mounds without directly communicating with each other.','TRUE_FALSE_NOT_GIVEN',19,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NO',NULL,NULL,NULL,29,'
We tend to know when we have made an error of judgement.','YES_NO_NOT_GIVEN',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'FALSE',NULL,NULL,NULL,2,'Some ants within a colony have leadership roles.','TRUE_FALSE_NOT_GIVEN',19,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SOME VALUABLES',NULL,NULL,NULL,36,'
He highlighted the limitations and deceptions of the camera.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VISUAL DISTURBANCE',NULL,NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'SOME DIRECTIONS',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'B',NULL,NULL,NULL,39,'He based some of the scenes in his paintings on photographs.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'E',NULL,NULL,NULL,40,'He felt photography was part of the trend towards greater mechanisation.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'C',NULL,NULL,NULL,38,'He noted the potential for photography to enrich artistic talent.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'A',NULL,NULL,NULL,37,'He highlighted the limitations and deceptions of the camera.','FILL_IN_THE_BLANK',18,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VOLUME',NULL,NULL,NULL,12,NULL,'FILL_IN_THE_BLANK',19,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'IV',NULL,NULL,NULL,14,'Paragraph A','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'VIII',NULL,NULL,NULL,15,'Paragraph B','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'II',NULL,NULL,NULL,16,'
Paragraph C','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'POWER SHORTAGES',NULL,NULL,NULL,25,'In the late eighties','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CLIMATE CONTROL',NULL,NULL,NULL,26,'
In addition to power and cost benefits, Broad’s AC units improve………………………………','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BOILERS',NULL,NULL,NULL,24,'The first products Broad manufactured were…………………………..','FILL_IN_THE_BLANK',20,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'TURN-TAKING',NULL,NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'REJECTION',NULL,NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT_GIVEN',NULL,NULL,NULL,31,'People who talk less often have clearer ideas than those who talk a lot.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'AGREEMENT',NULL,NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',21,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'YES',NULL,NULL,NULL,28,'
People assess information according to how readily they can understand it.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'INTERRUPTIONS',NULL,NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NO',NULL,NULL,NULL,32,'Delays in online chat fail to have the same negative effect as disruptions that occur in natural conversation.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NOT_GIVEN',NULL,NULL,NULL,30,'Video observations have often been used to assess conversational flow.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'YES',NULL,NULL,NULL,27,'
Conversation occupies much of our time.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BELONG',NULL,NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'BEHAVIOR',NULL,NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'CONTENT',NULL,NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'NO',NULL,NULL,NULL,29,'
A quick response to a question is thought to show a lack of knowledge.','YES_NO_NOT_GIVEN',21,NULL),
	 ('2026-05-30 17:31:40.4',NULL,false,NULL,NULL,'DISTRESS LEVELS',NULL,NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',21,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 13:49:46.977407','user_56659',false,'2026-06-07 13:49:46.977407','user_56659','ROAD','Trích đoạn chứa đáp án:
It was 1992. In England, workmen were building a new road through the heart of Dover, to connect the ancient port and the Channel Tunnel, which, when it opened just two years later, was to be the first land link between Britain and Europe for over 10,000 years.....They had found a prehistoric boat, preserved by the type of sediment in which it was buried. It was then named by Dover Bronze- Age Boat.

Keyword cần chú ý:
construction = building
found = discovered

Giải thích đáp án:
Từ loại cần điền: danh từ
-> cần tìm thông tin về thời điểm năm 1992, chiếc thuyền được phát hiện khi cái gì đang được xây dựng
Trong đoạn đầu tiên của bài, người viết đưa ra bối cảnh vào năm 1992 tại Anh, các công nhân đang xây dựng một con đường mới xuyên qua trung tâm của Dover để kết nối cảng thời cổ và Đường hầm Channel. Và trong lúc đang xây dựng thì họ phát hiện ra một con thuyền của thời tiền sử
-> như vậy, khi đang xây dựng 1 con đường thì chiếc thuyền được phát hiện ra
-> từ cần điền là ''road''',NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 13:51:26.622704','user_56659',false,'2026-06-07 13:51:26.622704','user_56659','CONFERENCE','Trích đoạn chứa đáp án:
In 2002, on the tenth anniversary of the discovery, the Dover Bronze Age Boat Trust hosted a conference, where this meeting of different traditions became apparent. Alongside technical papers about the boat, other speakers explored its social and economic contexts, and the religious perceptions of boats in Bronze Age societies. Many speakers came from overseas, and debate about cultural connections was renewed.

Keyword cần chú ý:
held =hosted
overseas = international

Giải thích đáp án:
Từ loại cần điền: danh từ
-> cần tìm thông tin về thời điểm năm 2002 khi 1 sự kiện gì đấy mang tính chất quốc tế được tổ chức để thu thập các thông tin
Nội dung của đoạn trích:
Vào năm 2002, Dover Age Bronze Boat Trust đã tổ chức 1 hội nghị nhân kỷ niệm 10 năm khám phá ra chiếc thuyền. Trong cuộc hội nghị, bên cạnh những tài liệu nghiên cứu kỹ thuật về con thuyền thì những diễn giả cũng khám phá về bối cảnh xã hội và kinh tế của nó, cũng như nhận thức tôn giáo về những con thuyền trong các xã hội thời đại đồ đồng. Và cũng có nhiều diễn giả đến từ nước ngoài
-> tóm lại, vào năm 2002 hội nghị quốc tế đã được tổ chức (bởi có nhiều diễn giả đến từ nước ngoài) để bàn luận, trao đổi thông tin về con thuyền
-> từ cần điền là ''conference''',NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 13:51:41.567934','user_56659',false,'2026-06-07 13:51:41.567934','user_56659','PROPOSALS','Trích đoạn chứa đáp án:
Detailed proposals to reconstruct the boat were drawn up in 2004.

Keyword cần chú ý:
produced = drawn up

Giải thích đáp án:
Từ loại cần điền: danh từ
-> cần tìm thông tin về thời điểm năm 2004 khi một thứ gì đó cho việc tái xây dựng được đưa ra
Thông tin trong bài:
Các đề xuất chi tiết để tái tạo lại con thuyền đã được đưa ra vào năm 2004.
-> từ cần điền là ''proposals''',NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 13:52:12.961648','user_56659',false,'2026-06-07 13:52:12.961648','user_56659','EXHIBITION','Trích đoạn chứa đáp án:
Meanwhile, the exhibition was being prepared ready for opening in July 2012 at the Castle Museum in Boulognesurmer. Entitled “Beyond the Horizon: Societies of the Channel & North Sea 3,500 years ago”, it brought together for the first time a remarkable collection of Bronze Age objects, including many new discoveries for commercial archaeology and some of the great treasure of the past.

Giải thích đáp án:
Từ loại cần điền: danh từ
-> cần tìm thông tin về thời điểm năm 2012, nói tới 1 sự kiện có liên quan tới thời kỳ đồ đồng trưng bày con thuyền cùng những vật dụng khác
Thông tin trong bài:
Vào tháng 7 năm 2012, 1 cuộc triển lãm được tổ chức tại bảo tàng Castle ở Boulogne-sur-Mer, tập hợp một bộ sưu tập đáng chú ý về các đồ vật thời đại đồ đồng, bao gồm nhiều khám phá mới về khảo cổ học thương mại và một số kho báu lớn trong quá khứ. Và đặc biệt, con thuyền được tái tạo chính là trung tâm của triển lãm.
-> như vậy cuộc triển lãm về thời kỳ đồ đồng trưng bày con thuyền cùng những cổ vật khác
-> từ cần điền là ''exhibition''',NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 13:51:59.90723','user_56659',false,'2026-06-07 13:51:59.90723','user_56659','LAUNCH','Trích đoạn chứa đáp án:
There was much enthusiasm and support, and an official launch of the project was held at an international seminar in France in 2007. Financial support was confirmed in 2008 and the project then named BOAT 1550BC got under way in June 2011.

Giải thích đáp án:
Từ loại cần điền: danh từ
-> cần tìm thông tin về thời điểm năm 2007 nói sự kiện gì đó của BOAT 1550BC diễn ra
Thông tin trong bài:
Nhận được rất nhiều sự nhiệt tình và ủng hộ, lễ ra mắt chính thức của dự án đã được tổ chức tại một hội thảo quốc tế ở Pháp vào năm 2007. Hỗ trợ tài chính đã được xác nhận vào năm 2008 và dự án sau đó có tên là BOAT 1550BC được khởi động vào tháng 6 năm 2011.
-> Lễ ra mắt của dự án có tên BOAT 1550BC diễn ra vào năm 2007
-> từ cần điền là ''launch''',NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 13:54:03.77297','user_56659',false,'2026-06-07 13:54:03.77297','user_56659','TRUE','Trích đoạn chứa đáp án:
The boat was not a wreck, but had been deliberately discarded, dismantled and broken. Perhaps it had been “ritually killed” at the end of its life, like other Bronze Age objects.

Keyword cần chú ý:
damaged = broken
on purpose = deliberately

Giải thích đáp án:
Thông tin trong bài:
Con tàu không bị chìm, mà nó đã bị cố tình vứt bỏ, tháo dỡ và hư hỏng. Và có lẽ con tàu đã bị ''giết theo nghi thức'' cũng như các đồ vật khác ở thời kỳ đồ đồng
-> Con tàu bị “giết", nghĩa là không phải tự nhiên bị hư hỏng mà có ai đó tàn phá nó (bị cố ý làm cho hư hỏng)
Đối chiếu với câu hỏi:
Archaeologists realized that the boat had been damaged on purpose - Các nhà khảo cổ nhận ra rằng con thuyền đã bị làm cho hư hại có chủ đích.
-> khớp với thông tin trong bài
-> TRUE',NULL,NULL,6,'Archaeologists realised that the boat had been damaged on purpose','TRUE_FALSE_NOT_GIVEN',113,NULL),
	 ('2026-06-07 14:02:43.582581','user_56659',false,'2026-06-07 14:02:43.582581','user_56659','FALSE','Trích đoạn chứa đáp án:
With hindsight, it was significant that the boat was found and studied by mainstream archaeologists who naturally focused on its cultural context.

Keyword cần chú ý:
examined = studied

Giải thích đáp án:
Thông tin trong bài:
Điều quan trọng là con thuyền đã được tìm thấy và nghiên cứu bởi các nhà khảo cổ học chính thống, những người nghiên cứu tập trung vào bối cảnh văn hóa của nó.
-> the cultural aspect of the boat was studied.
Đối chiếu với câu hỏi:
Only the technical aspects of the boat were examined - Chỉ các khía cạnh kỹ thuật của con thuyền được nghiên cứu
-> trái với thông tin trong bài
-> FALSE',NULL,NULL,7,'Initially, only the technological aspects of the boat were examined.','TRUE_FALSE_NOT_GIVEN',113,NULL),
	 ('2026-06-07 14:03:04.428728','user_56659',false,'2026-06-07 14:03:04.428728','user_56659','FALSE','Trích đoạn chứa đáp án:
The possibility of returning to Dover to search for a boat’s unexcavated northern end was explored, but practical and financial difficulties were insurmountable and there was no guarantee that the timbers had survived the previous decade in the changed environment.

Keyword cần chú ý:
went back = return

Giải thích đáp án:
Thông tin trong bài:
Khả năng quay trở lại Dover để tìm kiếm đầu phía bắc chưa được khai quật của con tàu đã được bàn tới, nhưng những khó khăn về thực tế và tài chính là 1 chướng ngại vật - và không có gì đảm bảo rằng những tấm gỗ vẫn tồn tại trong thập kỷ trước trong môi trường thay đổi
-> có thể suy luận rằng khả năng quay lại Dover được bàn tới nhưng không được thực hiện
Đối chiếu với câu hỏi:
Archeologists went back to the site to find the boat''s northern end - Các nhà khảo cổ đã quay lại địa điểm này để tìm đầu phía bắc của con thuyền
-> trái với thông tin trong bài
-> FALSE',NULL,NULL,8,'Archaeologists went back to the site to try and find the missing northern end of the boat.
','TRUE_FALSE_NOT_GIVEN',113,NULL),
	 ('2026-06-07 14:03:24.181813','user_56659',false,'2026-06-07 14:03:24.181813','user_56659','FALSE','Trích đoạn chứa đáp án:
Detailed proposals to reconstruct the boat were drawn up in 2004. Archaeological evidence was beginning to suggest a Bronze Age community straddling the Channel, brought together by the sea, rather than separated by it.

Giải thích đáp án:
Trong bài tuy có đề cập tới bằng chứng khảo cổ (Archeological evidence) được tìm thấy về Bronze-Age community nhưng không nói gì tới mục đích sử dụng (use) của Bronze Age boat là để trade (giao dịch) hay gì cả
-> NOT GIVEN',NULL,NULL,9,'
Evidence found in 2004 suggested that the Bronze-Age Boat had been used for trade.','TRUE_FALSE_NOT_GIVEN',113,NULL),
	 ('2026-06-07 14:04:42.046961','user_56659',false,'2026-06-07 14:04:42.046961','user_56659','6/SIX METERS/METRES/M','Trích đoạn chứa đáp án:
At the base of the deep shaft six meters below the modern streets a wooden structure was revealed.

Keyword cần chú ý:
below = under the ground
revealed = found

Giải thích đáp án:
Câu hỏi: Con thuyền được tìm thấy cách mặt đất bao xa?
-> câu trả lời cần 1 con số
Định vị thông tin nằm ở đoạn 2:
Ở chân trục sâu sáu mét bên dưới những con phố hiện đại, một công trình kiến trúc bằng gỗ được tìm thấy.
-> vị trí con thuyền được tìm thấy cách mặt đất 6m
-> đáp án là 6 meters',NULL,NULL,10,'
How far under the ground was the boat found?','FILL_IN_THE_BLANK',113,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 14:06:04.111699','user_56659',false,'2026-06-07 14:06:04.111699','user_56659','(PADS OF) MOSS','Trích đoạn chứa đáp án:
The seams had been made watertight by pads of moss, fixed by wedges and yew stitches.

Keyword cần chú ý:
prevent water entering = watertight

Giải thích đáp án:
Câu hỏi: Vật liệu tự nhiên nào đã được gắn vào thuyền để ngăn nước tràn vào?
-> câu trả lời cần tên 1 vật liệu tự nhiên nào đó
Định vị thông tin nằm ở cuối đoạn 3:
Các đường nối đã được làm kín nước bằng các miếng rêu, được cố định bằng nêm và các mũi khâu thủy tùng.
-> các miếng rêu được gắn vào để ngăn nước tràn vào thuyền
-> đáp án là ''pads of moss''',NULL,NULL,11,'What natural material had been secured to the boat to prevent water entering?','FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 14:06:32.528715','user_56659',false,'2026-06-07 14:06:32.528715','user_56659','(THE) HULL (SHAPE)','Trích đoạn chứa đáp án:
In 2012, however, the hull shape was at the centre of the work, so modern power tools were used to carve the oak planks, before turning to prehistoric tools for finishing.

Keyword cần chú ý:
the center of the work = the focus

Giải thích đáp án:
Câu hỏi: Phần nào của con thuyền là trọng tâm của cuộc tái thiết năm 2012?
-> câu trả lời cần tên 1 bộ phận hoặc 1 mặt nào đó của con tàu
Định vị thông tin nằm ở đoạn 9:
Vào năm 2012, hình dạng thân tàu là trung tâm của tác phẩm, vì vậy các công cụ điện hiện đại đã được sử dụng để chạm khắc các tấm ván gỗ sồi, trước khi chuyển sang các công cụ thời tiền sử để hoàn thiện.
-> Cuộc tái thiết vào năm 2012 tập trung vào phần thân tàu
-> đáp án là the hull',NULL,NULL,12,'What aspect of the boat was the focus of the 2012 reconstruction?','FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 14:07:01.534977','user_56659',false,'2026-06-07 14:07:01.534977','user_56659','COST AND TIME [OR] COST TIME [OR] TIME COST','Trích đoạn chứa đáp án:
It was decided to make the replica half-scale for reasons of cost and time...

Keyword cần chú ý:
the replica = the reconstruction of the boat
half-scale = not... a full-scale

Giải thích đáp án:
Câu hỏi: Hai yếu tố nào ảnh hưởng đến quyết định không tái thiết toàn bộ con thuyền?
Định vị thông tin nằm ở đoạn 9:
Người ta đã quyết định làm bản sao với quy mô một nửa vì lý do chi phí và thời gian...
-> Cost and time are the factors which influence the decision to make the replica half-scale
-> đáp án là cost and time',NULL,NULL,13,'Which two factors influenced the decision not to make a full scale reconstruction of the boat?
','FILL_IN_THE_BLANK',113,NULL),
	 ('2026-06-07 14:11:35.950429','user_56659',false,'2026-06-07 14:11:35.950429','user_56659','FINAL DESTINATION','Trích đoạn chứa đáp án:
At this stage of facilities provision, the airport also has the possibility of taking on the role of the final destination rather than merely a facilitator of access.

Keyword cần chú ý:
can ~ has the posibility of
become = taking on the role of
a means to travel ~ a facilitator of access

Giải thích đáp án:
Xác định từ loại cần điền: danh từ số ít (vì đứng sau mạo từ ''a'')
So sánh giữa bài đọc và câu hỏi:
At this stage of facilities provision, the airport also has the possibility of taking on the role of the final destination rather than merely a facilitator of access.
Airports with a wide range of recreational facilities can become a……………… for people rather than a means to travel.
-> đáp án ''final destination''',NULL,NULL,20,'Airports with a wide range of recreational facilities can become a……………………………for people rather than a means to travel.','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:08:29.519627','user_56659',false,'2026-06-07 14:08:29.519627','user_56659','G','Trích đoạn chứa đáp án:
Average revenue per airport was just $12,959. Meeting facilities are effectively a non aeronautical source of airport revenue. Only 1% of respondents generated more than 20% non aeronautical revenue from their meetings facilities; none generated more than 40%.

Giải thích đáp án:
Keyword của câu hỏi: low level of income, meeting facilities, produce
Dòng 2-5 đoạn G đưa thông tin như sau:
Trong 1 cuộc khảo sát yêu cầu respondents ước tính xem sân bay của họ khi có các trang thiết bị hội họp thì sẽ kiếm được bao nhiêu doanh thu trong năm vừa qua. Doanh thu trung bình trên mỗi sân bay là $ 12,959. Chỉ 1% số respondents tạo ra hơn 20% doanh thu phi hàng không từ các cơ sở hội họp của họ; không ai tạo ra quá 40%.
Ta thấy
''was just $12,959'' và ''none generated more than 40%'' là thông tin cho thấy mức doanh thu thấp mà các cơ sở hội họp mang lại cho các sân bay.
-> đáp án G',NULL,NULL,16,'reference to the low level of income that meeting facilities produce for airports','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:08:13.387568','user_56659',false,'2026-06-07 14:08:13.387568','user_56659','B','Trích đoạn chứa đáp án:
Some of the more obvious solutions to growing commercial revenues, such as extending the merchandising space or expanding the variety of shopping opportunities, have already been tried to their limit at many airports

Giải thích đáp án:
Keyword của câu hỏi: no further development, possible, some areas, airport trade
Phần đầu của đoạn B đưa thông tin như sau:
Một số giải pháp rõ ràng hơn để tăng doanh thu thương mại, chẳng hạn như mở rộng không gian bán hàng hoặc mở rộng nhiều cơ hội mua sắm, thì đã được thử nghiệm ở mức tối đa tại nhiều sân bay.
Ta thấy
merchandising space and variety of shopping opportunities ~ some areas of airport trade
have already been tried to their limit ~ no further developments are possible
-> đáp án B',NULL,NULL,15,'a statement regarding the fact that no further developments are possible in some areas of airport trade','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:07:49.868331','user_56659',false,'2026-06-07 14:07:49.868331','user_56659','E','Trích đoạn chứa đáp án:
In total, there were responses from staff at 154 airports and 68% of these answered ''yes’ to the question: Does your airport own and have meetings facilities available for hire? The existence of meeting facilities therefore seems high at airports.

Keyword cần chú ý:
provide meeting facilities ~ have meetings facilities available

Giải thích đáp án:
Keyword của câu hỏi: evidence, significant number of airports, provide, meeting facilities
Dòng 4-5 đoạn E đưa thông tin như sau:
Tổng cộng, đã có câu trả lời từ nhân viên tại 154 sân bay và 68% trong số này trả lời ''có'' cho câu hỏi: Sân bay của bạn có sở hữu và có sẵn các thiết bị hội họp cho thuê không?
Ta thấy
68% ~ a significant number of airports
answered ''yes'' to the question = evidence that.... airports provide meeting facilities
-> đáp án E',NULL,NULL,14,'Evidence that a significant number of airports provide meeting facilities
','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:11:56.379792','user_56659',false,'2026-06-07 14:11:56.379792','user_56659','AIRLINES','Trích đoạn chứa đáp án:
When an airport location can be promoted as a business venue, this may increase the overall appeal of the airport and help it become more competitive in both attracting and retaining airlines and their passengers.

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (trước và sau ''and'' đều phải cùng loại từ)
Thông tin trong bài:
When an airport location can be promoted as a business venue, this may increase the overall appeal of the airport and help it become more competitive in both attracting and retaining airlines and their passengers.
-> Airports có thể thu hút và giữ chân airlines and passengers = passengers and airlines muốn dùng (dịch vụ) và hình thành sự trung thành đối với airports
Đối chiếu với câu hỏi:
Both passengers …………….. may feel encouraged to use and develop a sense of loyalty towards airports that market their business services.
-> Passengers và ai đó muốn dùng (dịch vụ) và phát triển cảm giác trung thành đối với airports
-> đáp án ''airlines''',NULL,NULL,21,'Both passengers and……………………………may feel encouraged to use and develop a sense of loyalty towards airports that market their business services.','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:10:02.635164','user_56659',false,'2026-06-07 14:10:02.635164','user_56659','SECURITY PROCEDURES','Trích đoạn chứa đáp án:
In recent times developing commercial revenues has become more challenging for airports due to a combination of factors, such as increased competition from Internet shopping, restrictions on certain sales, such as tobacco, and new security procedures that have had an impact on the dwell time of passengers.

Keyword cần chú ý:
have had an impact = has been affected
new = updated

Giải thích đáp án:
Xác định từ loại cần điền: danh từ, nói tới 1 cái gì đó được nâng cấp/cập nhất mà làm ảnh hưởng tới khoảng thời gian mua sắm tại sân bay của hành khách
Thông tin trong bài:
Trong thời gian gần đây, việc phát triển doanh thu thương mại trở nên khó khăn hơn đối với các sân bay do sự kết hợp của nhiều yếu tố, chẳng hạn như cạnh tranh gia tăng từ việc mua sắm trên Internet, các hạn chế đối với một số hoạt động mua bán nhất định, chẳng hạn như thuốc lá và các thủ tục an ninh mới đã ảnh hưởng đến thời gian lưu trú của hành khách.
-> yếu tố ảnh hưởng tới thời gian mua sắm tại sân bay của hành khách là ''new security procedures''
-> đáp án ''security procedures''',NULL,NULL,19,'The length of time passengers spend shopping at airports has been affected by updated……………………','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:09:01.099548','user_56659',false,'2026-06-07 14:09:01.099548','user_56659','C','Trích đoạn chứa đáp án:
At the same time, airports have been developing and expanding the range of services that they provide specifically for the business traveller in the terminal. This includes offering business centres that supply support services, meeting or conference rooms and other space for special events.

Giải thích đáp án:
Keyword của câu hỏi: airport premises, might be used, business purposes
Phần đầu đoạn C đưa thông tin như sau:
Các sân bay đang phát triển và mở rộng phạm vi dịch vụ mà họ cung cấp đặc biệt cho khách đi công tác trong nhà ga. Điều này bao gồm việc cung cấp các trung tâm kinh doanh cung cấp các dịch vụ hỗ trợ, phòng họp hoặc hội nghị và không gian khác cho các sự kiện đặc biệt.
Ta thấy
the terminal = airport premises - cơ sở của sân bay
support services, meeting or conference rooms, space for special events -> chính là những ''business purposes''
-> đáp án C',NULL,NULL,18,'examples of airport premises that might be used for business purposes','FILL_IN_THE_BLANK',111,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 14:08:45.653067','user_56659',false,'2026-06-07 14:08:45.653589','user_56659','A','Trích đoạn chứa đáp án:
Meanwhile, the pressures to control the level of aeronautical revenues are as strong as ever due to the poor financial health of many airlines and the rapid rise of the low cost carrier sector.

Giải thích đáp án:
Keyword của câu hỏi: impact, budget airlines, airport income
Phần cuối đoạn A đưa thông tin như sau:
Áp lực kiểm soát doanh thu hàng không vẫn mạnh mẽ hơn bao giờ hết do tình hình tài chính thiếu ổn định của nhiều hãng hàng không và sự gia tăng nhanh chóng của lĩnh vực hàng không giá rẻ.
-> sự phát triển của ngành hàng không giá rẻ có tác động tới mức doanh thu của ngành hàng không
-> đáp án A',NULL,NULL,17,'mention of the impact of budget airlines on airport income','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 17:07:06.124915','user_56659',false,'2026-06-07 17:07:06.124915','user_56659','IDENTIFICATION','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền đứng sau ''on'')
Thông tin trong bài:
Especially noteworthy is an experiment by Davies and Hine (2007) who studied whether change blindness affects eyewitness identification.
-> Davies and Hine (2007).studied whether change blindness affects eyewitness identification
-> Davies và Hine (2007) đã nghiên cứu xem liệu hiện tượng mù thoáng qua có ảnh hưởng đến việc xác định nhân chứng hay không
Đối chiếu với câu hỏi:
Purpose of experiment: to assess the impact of change blindness on ________________ by eyewitnesses
-> đáp án ''identification''',NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 17:06:49.195762','user_56659',false,'2026-06-07 17:06:49.195762','user_56659','A/THE DOOR','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền đứng sau ''of'' với cấu trúc the noun of noun)
Thông tin trong bài:
During the conversation, two men carrying a door pass between the two of you.
-> Đang nói chuyện mà có two men carrying a door đi chen ngang qua giữa -> tự động chú ý tới door
-> You focus on the movement of the door
Đối chiếu với câu hỏi:
Focus of participants’ attention - the movement of ________
-> đáp án ''the door''',NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2027-01-19 17:31:40','truongdx18vtit',false,'2027-01-19 17:31:40','truongdx18vtit','A',NULL,'','["A. three","B. four","C. five"]',13,'How many lunches are included in the price of the holiday?','MULTIPLE_CHOICE',172,''),
	 ('2027-01-20 17:31:40','truongdx18vtit',false,'2027-01-20 17:31:40','truongdx18vtit','PASS',NULL,'','',18,'','FILL_IN_THE_BLANK',172,''),
	 ('2027-01-21 17:31:40','truongdx18vtit',false,'2027-01-21 17:31:40','truongdx18vtit','STEAM',NULL,'','',19,'','FILL_IN_THE_BLANK',172,''),
	 ('2027-01-22 17:31:40','truongdx18vtit',false,'2027-01-22 17:31:40','truongdx18vtit','A',NULL,'','["A. has been in business for longer than most of its competitors.","B. arranges holidays to more destinations than its competitors.","C. has more customers than its competitors."]',11,'According to the speaker, the company','MULTIPLE_CHOICE',172,''),
	 ('2027-01-23 17:31:40','truongdx18vtit',false,'2027-01-23 17:31:40','truongdx18vtit','C',NULL,'','["A. guaranteeing themselves a larger room.","B. booking at short notice.","C. transferring to another date."]',14,'Customers have to pay extra for','MULTIPLE_CHOICE',172,''),
	 ('2027-01-24 17:31:40','truongdx18vtit',false,'2027-01-24 17:31:40','truongdx18vtit','CAPITAL',NULL,'','',20,'','FILL_IN_THE_BLANK',172,''),
	 ('2027-01-25 17:31:40','truongdx18vtit',false,'2027-01-25 17:31:40','truongdx18vtit','G',NULL,'','',21,'the eldest child','FILL_IN_THE_BLANK',173,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 14:19:21.017739','user_56659',false,'2026-06-07 14:19:21.017739','user_56659','LOCAL (PEOPLE)','Trích đoạn chứa đáp án:
63% of respondents estimated that over 60% of users are from the local area.

Giải thích đáp án:
Chỗ trống cần điền: danh từ/tính từ/động từ (PII hoặc V-ed hoặc V-ing), vì từ cần điền đứng sau động từ ''to be''
So sánh thông tin trong bài và câu hỏi:
Bài đọc: 63% respondents ước tính rằng hơn 60% người dùng đến từ khu vực địa phương.
-> số người sử dụng chủ yếu là người địa phương
Câu hỏi: main users of the facilities are ______
-> đáp án ''local people''',NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:19:07.728878','user_56659',false,'2026-06-07 14:19:07.728878','user_56659','5/FIVE YEARS','Trích đoạn chứa đáp án:
In addition, 28% of respondents that did not have meeting facilities stated that they were likely to invest in them during the next five years.

Giải thích đáp án:
Chỗ trống cần điền: danh từ, vì từ cần điền đứng ngay sau giới từ “within"
So sánh thông tin trong bài và câu hỏi:
28% of respondents that did not have meeting facilities stated that they were likely to invest in them during the next five years.
Just under 30% of the airports surveyed plan to provide these facilities within____ .
-> đáp án ''five years''',NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:26:54.537569','user_56659',false,'2026-06-07 14:26:54.538296','user_56659','D','Trích đoạn chứa đáp án:
Discussion of the role of photography in art was especially spirited in France, where the internal policies of the time had created a large pool of artists, but it was also taken up by important voices in England. In both countries, public interest in this topic was a reflection of the belief that national stature and achievement in the arts were related.

Giải thích đáp án:
Câu hỏi về quan điểm của công chúng về nghệ sĩ mà cả người Anh và người Pháp đều có là gì
Thông tin trong bài:
Những cuộc thảo luận về vai trò của nhiếp ảnh trong nghệ thuật đặc biệt sôi nổi ở Pháp cũng như ở Anh. Ở cả hai quốc gia, sự quan tâm của công chúng đối với chủ đề này phản ánh niềm tin rằng ''national stature'' - tầm vóc quốc gia và achievement in the arts - thành tựu trong nghệ thuật có liên quan với nhau.
-> ta thấy danh tiếng quốc gia và thành công nghệ thuật có liên quan, tức là nếu nghệ thuật thành công thì danh tiếng quốc gia tăng theo
-> đáp án D',NULL,'["A. that only artists could reflect a culture’s true values","B. that only artists were qualified to judge photography","C. that artists could lose work as a result of photography","D. that artistic success raised a country’s international profile"]',28,'What public view about artists was shared by the French and the English?','MULTIPLE_CHOICE',112,NULL),
	 ('2026-06-07 14:24:35.509479','user_56659',false,'2026-06-07 14:24:35.509479','user_56659','C','Trích đoạn chứa đáp án:
This may seem a pointless question today. Surrounded as we are by thousands of photographs, most of us take for granted that, in addition to supplying information and seducing customers, camera images also serve as decoration, afford spiritual enrichment, and provide significant insights into the passing scene. But in the decades following the discovery of photography, this question reflected the search for ways to fit the mechanical medium into the traditional schemes of artistic expression.

Giải thích đáp án:
Câu hỏi về quan điểm của tác giả trong đoạn đầu tiên
Tóm tắt nội dung của đoạn:
Câu 1: Tác giả đưa ra vấn đề ''Is Photography Art?'' là pointless question ở thời hiện tại
Câu 2: Giải thích tại sao là pointless questions: supplying information, seducing customers, decoration, spiritual enrichment,...
Câu 3: Đưa ra 1 luận điểm trái với 2 câu đầu bằng từ ''but'' : vào thời trước thì công cuộc tìm kiếm cách áp dụng nhiếp ảnh vào việc truyền đạt nghệ thuật diễn ra hàng thập kỷ
-> như vậy nhiếp ảnh không phải lúc nào cũng được coi là một dạng nghệ thuật
-> đáp án C',NULL,'["A. Photography is used for many different purposes","B. Photographers and artists have the same principal aims","C. Photography has not always been a readily accepted art form","D. Photographers today are more creative than those of the past"]',27,'What is the writer’s main point in the first paragraph?
','MULTIPLE_CHOICE',112,NULL),
	 ('2026-06-07 17:47:31.755075','user_56659',false,'2026-06-07 17:47:31.755075','user_56659','COLUMN(S)','Keyword cần chú ý:
top and bottom = at each end

Giải thích đáp án:
Xác định từ loại cần điền: danh từ
Thông tin trong bài:
The unique column design has diagonal bracing at each end and tabs that bolt into the floors above and below - Thiết kế cột độc đáo có giằng chéo ở mỗi đầu và các mấu bắt vít vào các tầng trên và dưới
-> diagonal bracing is at each end of the column
Đối chiếu với câu hỏi:
diagonal bracing at top and bottom of….- giằng chéo ở trên và dưới của….
-> đáp án ''column''',NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:47:17.744251','user_56659',false,'2026-06-07 17:47:17.744251','user_56659','FLOORING/FLOOR','Keyword cần chú ý:
customer = client

Giải thích đáp án:
Xác định từ loại cần điền: danh từ
Thông tin trong bài:
The client''s choice of flooring is also preinstalled on top - Sự lựa chọn của khách hàng về sàn cũng được cài đặt sẵn trên đầu trang.
-> The client chooses the flooring
Đối chiếu với câu hỏi:
...... choosen by customer - ...... được chọn bởi khách hàng
-> đáp án ''flooring''',NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:25:37','user_05335',false,'2026-06-07 17:25:37','user_05335','GUIDELINES','Trích đoạn chứa đáp án:
Teachers from all over the nation contributed to a national curriculum that provided guidelines, not prescriptions, for them to refer to.

Keyword cần chú ý:
followed = refer to
created = contributed to

Giải thích đáp án:
Bài đọc: Teachers contributed to a national curriculum. They refer to the guidelines in the national curriculum.
=> Teachers refer to the guidelines contributed by teachers
Câu hỏi: Schools followed _____ that were created partly by teachers.
=> Đáp án: guidelines','','',9,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:25:52','user_05335',false,'2026-06-07 17:25:52','user_05335','LANGUAGE','Trích đoạn chứa đáp án:
Besides Finnish and Swedish (the country’s second official language), children started learning a third language (English Is a favorite) usually beginning at age nine.

Keyword cần chú ý:
Young pupils = children
study an additional language = learning a third language

Giải thích đáp án:
Bài đọc: Besides Finnish and Swedish, children started learning a third language
=> Ngoài Finnish và Swedish, children phải học thêm a third language
Câu hỏi: Young pupils had to study an additional _____
=> Đáp án: language','','',10,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:58:29','user_05335',false,'2026-06-07 17:58:29','user_05335','CONCAVE','Trích đoạn chứa đáp án:
Water surges from the cells on the Inside of the leaf to those on the outside, causing the leaf to rapidly flip in shape from convex to concave, like a soft contact lens.
As the leaves flip, they snap together, trapping the insect in their sharp-toothed jaws.

Giải thích đáp án:
Ý của hai câu này: The leaf changes to concave shape and snaps together.
Câu hỏi: Leaves change so that they have a ______ shape and snap nut
=> Đáp án: concave','','',18,'','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 14:19:38.359056','user_56659',false,'2026-06-07 14:19:38.359056','user_56659','FLIGHTS','Trích đoạn chứa đáp án:
16% of respondents estimated that none of the users of their meeting facilities use flights when travelling to or from them, while 56% estimated that 20% or fewer of the users of their facilities use flights.

Keyword cần chú ý:
their users did not take any flights ~ none of the users use flights

Giải thích đáp án:
Chỗ trống cần điền: danh từ, vì từ cần điền đứng ngay sau “any"
So sánh thông tin trong bài và câu hỏi:
Bài đọc: None of the users of their meeting facilities use flights.
-> The users of their meeting facilities did not use any flights
Câu hỏi: Their users did not take any ____
-> đáp án ''flights''',NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',111,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 14:18:53.814516','user_56659',false,'2026-06-07 14:18:53.814516','user_56659','ECONOMIC DOWNTURN/CLIMATE','Trích đoạn chứa đáp án:
Paragraph A
Moreover, the global economic downturn has caused a reduction in passenger numbers while those that are travelling generally have less money to spend.
Paragraph E
The survey also asked to what extent respondents agreed or disagreed with a number of statements about the meeting facilities at their airport.
49% of respondents agreed that they have put more investment into them during recent years; 41% agreed that they would invest more in the immediate future.
These are fairly high proportions considering the recent economic climate.

Keyword cần chú ý:
a significant percentage of = high proportions

Giải thích đáp án:
Chỗ trống cần điền: danh từ, là yếu tố dẫn tới ''financial constraints'' - hạn chế tài chính
Thông tin được tìm thấy ở cả 2 đoạn A và E trong bài
Paragraph A:
Suy thoái kinh tế toàn cầu đã làm giảm số lượng hành khách trong khi những người đi du lịch nói chung có ít tiền hơn để chi tiêu.
-> Những người đi du lịch chi tiêu ít đi vì kinh tế suy thoái
''those that are travelling generally have less money to spend'' refers to ''financial constraint''
Paragraph E:
1 cuộc khảo sát về cơ sở vật chất cho hội họp ở sân bay cho thấy bất chấp tình hình kinh tế, tỷ lệ sân bay đầu tư vào cơ sở vật chất phục vụ hội họp vẫn cao
Từ nội dung para A và E
Những người đi du lịch chi tiêu ít đi vì suy thoái kinh tế /tình hình kinh tế. Mặc dù vậy, tỷ lệ cao các sân bay vẫn đầu tư vào cơ sở vật chất phục vụ hội họp.
-> đáp án ''economic downturn''',NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:12:20.204207','user_56659',false,'2026-06-07 14:12:20.204207','user_56659','COMPETITIVE ADVANTAGE','Trích đoạn chứa đáp án:
In particular, the presence of meeting facilities could become one of the determining factors taken into consideration when business people are choosing airlines and where they change their planes. This enhanced attractiveness itself may help to improve the airport operator’s financial position and future prospects, but clearly this will be dependent on the competitive advantage that the airport is able to achieve in comparison with other venues.

Giải thích đáp án:
Xác định từ loại cần điền: danh từ số ít (vì đứng sau mạo từ ''a'')
Thông tin trong bài:
Sự hiện diện của các cơ sở hội họp có thể trở thành một trong những yếu tố quyết định được cân nhắc khi các doanh nhân lựa chọn hãng hàng không và nơi họ thay đổi máy bay. Điều này có thể giúp cải thiện tình hình tài chính của sân bay và triển vọng trong tương lai, nhưng rõ ràng điều này sẽ phụ thuộc vào lợi thế cạnh tranh mà sân bay có thể đạt được so với các địa điểm khác.
-> Ngoài việc có meeting facilities, airports còn cần có lợi thế cạnh tranh với venues khác thì mới hút khách doanh nhân được
Đối chiếu với câu hỏi:
Airports that supply meeting facilities may need to develop a _________ over other venues.
-> đáp án ''competitive advantage''',NULL,NULL,22,'Airports that supply meeting facilities may need to develop a…………………………..over other venues.','FILL_IN_THE_BLANK',111,NULL),
	 ('2026-06-07 14:27:32.928676','user_56659',false,'2026-06-07 14:27:32.928676','user_56659','D','Trích đoạn chứa đáp án:
Artists reacted to photography in various ways. Many portrait painters miniaturists in particular who realized that photography represented the ‘handwriting on the wall’ became involved with daguerreotyping or paper photography in an effort to save their careers; some incorporated it with painting, while others renounced painting altogether.

Giải thích đáp án:
Câu hỏi về ngụ ý của tác giả khi viết ''the handwriting on the wall'' ở đoạn 4
Để hiểu được nghĩ của cụm “handwriting on the wall” cần đặt nó vào ngữ cảnh cả câu:
Những portrain painters - người mà đã từng coi photography là ''handwriting on the wall'' thì chuyển hướng sang ''daguerreotyping'' hoặc ''paper photography'' để cứu vãn sự nghiệp
-> nói chung, họ muốn chuyển hướng sang photography để cứu vãn sự nghiệp
-> trước đây họ từng xem photography là mối đe doạ tới sự nghiệp của mình.
-> có thể suy luận “handwriting on the wall" là viễn cảnh đen tối sẽ xảy ra nếu họ tiếp tục với nghề hội họa.
-> “handwriting on the wall" = “a threat"
-> đáp án D',NULL,'["A. an example of poor talent","B. a message that cannot be trusted","C. an advertisement for something new","D. a signal that something bad will happen"]',29,'What does the writer mean in line 59 by ‘the handwriting on the wall’?','MULTIPLE_CHOICE',112,NULL),
	 ('2026-06-07 19:58:18.373733','user_56659',false,'2026-06-07 19:58:18.373733','user_56659','K','Trích đoạn chứa đáp án:
While suggestopedia has gained some notoriety through success in the teaching of modern languages,…

Giải thích đáp án:
Từ cần điền là một tính từ nói về phương pháp của Lozanov.
Bài đọc: Suggestopedia được biết đến nhờ thành công trong giảng dạy ngôn ngữ hiện đại.

Từ "notoriety" trong bài đọc có nghĩa là nổi tiếng, như "fame", nhưng thường là do một điều gì đó không tốt. Tuy nhiên nghĩa ở đây vẫn là "được biết đến"
-> K. well-known',NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',141,NULL),
	 ('2026-06-07 19:57:57.120825','user_56659',false,'2026-06-07 19:57:57.120825','user_56659','H','Trích đoạn chứa đáp án:
Such rituals may be seen as placebos. Lozanov acknowledges that the ritual surrounding suggestion in his own system is also a placebo...

Giải thích đáp án:
Từ cần điền phải là một danh từ đếm được, không bắt đầu bằng một âm nguyên âm.
Bài đọc: Các rituals như ngủ, thôi miên, v.v. có thể được coi là "placebos" (thuốc giả, đánh lạc hướng).
-> H. placebo',NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',141,NULL),
	 ('2027-01-26 17:31:40','truongdx18vtit',false,'2027-01-26 17:31:40','truongdx18vtit','A',NULL,'','',23,'the youngest child','FILL_IN_THE_BLANK',173,''),
	 ('2027-01-27 17:31:40','truongdx18vtit',false,'2027-01-27 17:31:40','truongdx18vtit','F',NULL,'','',22,'a middle child','FILL_IN_THE_BLANK',173,''),
	 ('2027-01-28 17:31:40','truongdx18vtit',false,'2027-01-28 17:31:40','truongdx18vtit','E',NULL,'','',24,'a twin','FILL_IN_THE_BLANK',173,''),
	 ('2027-01-29 17:31:40','truongdx18vtit',false,'2027-01-29 17:31:40','truongdx18vtit','B',NULL,'','',25,'an only child','FILL_IN_THE_BLANK',173,''),
	 ('2026-06-07 14:28:14.094677','user_56659',false,'2026-06-07 14:28:14.094677','user_56659','A','Trích đoạn chứa đáp án:
This appeal to the middle class convinced the elite that photographs would foster a desire for realism instead of idealism, even though some critics recognized that the work of individual photographers might display an uplifting style and substance that was consistent with the defining characteristics of art.

Keyword cần chú ý:
most educated = elite

Giải thích đáp án:
Câu hỏi về kết quả của việc phổ biến rộng rãi các bức ảnh cho các tầng lớp trung lưu là gì?
Thông tin trong bài:
This appeal to the middle class convinced the elite that photographs would foster a desire for realism instead of idealism - Sự hấp dẫn này đối với tầng lớp trung lưu khiến cho giới thượng lưu bị thuyết phục rằng những bức ảnh sẽ thúc đẩy khát vọng về chủ nghĩa hiện thực thay vì chủ nghĩa lý tưởng
-> The elite thinks the appeal of photographs to the middle class would make the public desire realism instead of idealism
-> đáp án A',NULL,'["A. the most educated worried about its impact on public taste","B. it helped artists appreciate the merits of photography","C. improvements were made in photographic methods","D. it led to a reduction in price of photographs"]',30,'What was the result of the widespread availability of photographs to the middle classes?','MULTIPLE_CHOICE',112,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 14:33:16.586941','user_56659',false,'2026-06-07 14:33:16.586941','user_56659','E','Trích đoạn chứa đáp án:
From the maze of conflicting statements and heated articles on the subject, three main positions about the potential of camera art emerged.

Giải thích đáp án:
Thông tin trong bài:
Từ những ý kiến trái chiều cùng những bài báo giật gân về chủ đề này, có 3 luồng ý kiến chính về tiềm năng của camera art được đưa ra
Đối chiếu với câu hỏi:
Opinions on its future were _____, but three clear views emerged - Những ý kiến về tương lai của camera art thì____ nhưng ba quan điểm rõ ràng đã xuất hiện
-> từ cần điền: trái chiều - conflicting
-> Từ đồng nghĩa trong list đáp án: B. mixed (mixed opinions là ý kiến trái chiều, đồng nghĩa conflicting)',NULL,NULL,31,NULL,'FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:33:29.709343','user_56659',false,'2026-06-07 14:33:29.709343','user_56659','G','Trích đoạn chứa đáp án:
The simplest, entertained by many painters and a section of the public, was that photographs should not be considered ‘art’ because they were made with a mechanical device and by physical and chemical phenomena instead of by human hand and spirit

Giải thích đáp án:
Từ cần điền: có thể là danh từ hoặc tính từ
So sánh thông tin câu hỏi và bài đọc:
Bài đọc: photographs should not be considered ‘art’ because they were made with a mechanical device
Bài đọc thể hiện rõ quan điểm của painters và public: Không xem photographs là art vì cách nó được tạo ra
-> Painters và public đánh giá thấp photographs, nghĩ nó không bằng những hình thức nghệ thuật khác
Câu hỏi:
A large number of artists and ordinary people saw photographs as ______ to paintings because of the way they were produced. - Một số lượng lớn các nghệ sĩ và những người bình thường coi ảnh là _____ so với tranh vì cách chúng được tạo ra.
-> từ cần điền: không bằng - inferior
-> Đáp án: G. inferior',NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:33:42.455821','user_56659',false,'2026-06-07 14:33:42.455821','user_56659','A','Trích đoạn chứa đáp án:
The second widely held view, shared by painters, some photographers, and some critics, was that photographs would be useful to art but should not be considered equal in creativeness to drawing and painting.

Giải thích đáp án:
Từ cần điền: tính từ, vì chỗ trống đứng sau từ ''less''
So sánh thông tin câu hỏi và bài đọc:
Bài đọc: photographs would be useful to art but should not be considered equal in creativeness to drawing and painting. - những bức ảnh sẽ hữu ích cho nghệ thuật nhưng không nên được coi là bình đẳng về khả năng sáng tạo như vẽ và hội họa.
-> Ảnh sẽ hữu ích cho nghệ thuật mặc dù ít sáng tạo hơn so với vẽ và hội họa.
Câu hỏi:
photographs could have a role to play in the art world, despite the photographer being less _______ - những bức ảnh có thể đóng một vai trò quan trọng trong thế giới nghệ thuật, mặc dù nhiếp ảnh gia ít _______ hơn
-> từ cần điền ''creative''
-> Từ đồng nghĩa trong list đáp án: A. inventive',NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:33:56.164548','user_56659',false,'2026-06-07 14:33:56.164548','user_56659','C','Trích đoạn chứa đáp án:
Lastly, by assuming that the process was comparable to other techniques such as etching and lithography, a fair number of individuals realized that camera images were or could be as significant as handmade works of art and that they might have a positive influence on the arts and on culture in general.

Giải thích đáp án:
So sánh giữa nội dung bài đọc và câu hỏi:
Bài đọc: They (= camera images) might have a positive influence on the arts and on culture
-> The influence camera images have on the arts and on culture might be positive
Câu hỏi: the impact of photography on art and society could be ________
-> từ cần điền: positive
-> Từ đồng nghĩa trong list đáp án: C. beneficial',NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:35:01.149948','user_56659',false,'2026-06-07 14:35:01.149948','user_56659','B','Trích đoạn chứa đáp án:
The view that photographs might be worthwhile to artists was enunciated in considerable detail by Lacan and Francis Wey. The latter, an art and literary critic, who eventually recognised that camera images could be inspired as well as informative, suggested that they would lead to greater naturalness in the graphic depiction of anatomy, clothing, likeness, expression, and landscape.

Giải thích đáp án:
Thông tin trong bài:
Francis Wey suggested that they (camera images) would lead to greater naturalness in the graphic depiction of anatomy, clothing, likeness, expression, and landscape - Francis Wey gợi ý rằng chúng (hình ảnh máy ảnh) sẽ dẫn đến sự tự nhiên hơn trong mô tả đồ họa về giải phẫu, quần áo, chân dung, biểu cảm và phong cảnh.
Đối chiếu với câu hỏi:
He claimed that photography would make paintings more realistic - ...... cho rằng hình ảnh sẽ làm cho các bức tranh trở nên chân thực hơn.
-> câu phát biểu này của Francis Wey
-> đáp án B',NULL,NULL,35,'He claimed that photography would make paintings more realistic.','FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:35:16.243926','user_56659',false,'2026-06-07 14:35:16.243926','user_56659','E','Trích đoạn chứa đáp án:
The most important statement on this matter was an unsigned article that concluded that while photography had a role to play, it should not be ‘constrained’ into ‘competition’ with art; a more stringent viewpoint led critic Philip Gilbert Hamerton to dismiss camera images as ‘narrow in range, emphatic in assertion, telling one truth for ten falsehoods’.

Giải thích đáp án:
Thông tin trong bài:
A more stringent viewpoint led critic Philip Gilbert Hamerton to dismiss camera images as ‘narrow in range, emphatic in assertion, telling one truth for ten falsehoods
-> Philip Gilbert Hamerton criticise camera images as ‘narrow in range, emphatic in assertion, telling one truth for ten falsehoods’
-> nhà phê bình Philip Gilbert Hamerton nhấn mạnh về mặt hạn chế cũng như đánh lừa thị giác của hình ảnh
Đối chiếu với câu hỏi:
He highlighted the limitations and deceptions of the camera. - ...... nêu bật những hạn chế và sự đánh lừa của máy ảnh.
-> câu phát biểu này của Philip Gilbert Hamerton
-> đáp án E',NULL,NULL,36,'He highlighted the limitations and deceptions of the camera.','FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:35:36.780053','user_56659',false,'2026-06-07 14:35:36.780053','user_56659','A','Trích đoạn chứa đáp án:
Still other painters, the most prominent among them the French painter, Jean Auguste Dominique Ingres, began almost immediately to use photography to make a record of their own output and also to provide themselves with source material for poses and backgrounds, vigorously denying at the same time its influence on their vision or its claims as art.

Giải thích đáp án:
Thông tin trong bài:
Jean Auguste Dominique Ingres use photography to make a record of their own output - Jean Auguste Dominique Ingres sử dụng hình ảnh để ghi lại kết quả đầu ra của riêng mình
-> Jean Auguste Dominique Ingres sử dụng hình ảnh cho công việc của anh ấy
Đối chiếu với câu hỏi:
He documented his production of artwork by photographing his works.- ''He'' ghi lại quá trình sản xuất tác phẩm nghệ thuật của mình bằng cách chụp ảnh các tác phẩm của mình..
-> “He" ở đây là “Jean Auguste Dominique Ingres"
-> đáp án A',NULL,NULL,37,'He documented his production of artwork by photographing his works.','FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:35:54.721375','user_56659',false,'2026-06-07 14:35:54.721375','user_56659','D','Trích đoạn chứa đáp án:
Delacroix’s enthusiasm for the medium can be sensed in a journal entry noting that if photographs were used as they should be, an artist might ‘raise himself to heights that we do not yet know’.

Giải thích đáp án:
Thông tin trong bài:
Delacroix noted that if photographs were used as they should be, an artist might ‘raise himself to heights that we do not yet know’
-> nếu những bức ảnh được sử dụng như bình thường, một nghệ sĩ có thể ''đưa mình lên những tầm cao mà chúng ta chưa biết''
-> như vậy Delacroix cho rằng photography có thể giúp các nghệ sĩ cải thiện tài năng của họ.
Đối chiếu với câu hỏi:
He noted the potential for photography to enrich artistic talent. - ''He'' ghi nhận tiềm năng của nhiếp ảnh để làm giàu tài năng nghệ thuật..
-> ''He'' ở đây chính là Delacroix
-> đáp án D',NULL,NULL,38,'He noted the potential for photography to enrich artistic talent.','FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:36:29.253417','user_56659',false,'2026-06-07 14:36:29.253417','user_56659','C','Trích đoạn chứa đáp án:
Baudelaire regarded photography as ‘a very humble servant of art and science’; a medium largely unable to transcend ‘external reality’. For this critic, photography was linked with ‘the great industrial madness’ of the time, which in his eyes exercised disastrous consequences on the spiritual qualities of life and art.

Giải thích đáp án:
Thông tin trong bài:
Baudelaire regarded photography as ‘a very humble servant of art and science’. For this critic, photography was linked with ‘the great industrial madness’ of the time - Baudelaire coi nhiếp ảnh là "một người phục vụ rất khiêm tốn của nghệ thuật và khoa học". Đối với ông, nhiếp ảnh được liên kết với ''sự điên rồ của công nghiệp vĩ đại'' vào thời điểm đó
-> Baudelaire believed photography was linked with ‘the great industrial madness’ of the time
Đối chiếu với câu hỏi:
He felt photography was part of the trend towards greater mechanisation. - ''He'' cảm thấy nhiếp ảnh là một phần của xu hướng cơ giới hóa mạnh mẽ hơn..
-> ''he'' chính là Baudelaire
-> đáp án C',NULL,NULL,40,'He felt photography was part of the trend towards greater mechanisation.','FILL_IN_THE_BLANK',112,NULL),
	 ('2026-06-07 14:36:11.835053','user_56659',false,'2026-06-07 14:36:11.835053','user_56659','A','Trích đoạn chứa đáp án:
Still other painters, the most prominent among them the French painter, Jean Auguste Dominique Ingres, began almost immediately to use photography to make a record of their own output and also to provide themselves with source material for poses and backgrounds, vigorously denying at the same time its influence on their vision or its claims as art.

Giải thích đáp án:
Thông tin trong bài:
Dominique Ingres use photography to... and also to provide themselves with source material for poses and backgrounds
-> Dominique Ingres sử dụng photography để cung cấp cho mình tài liệu nguồn cho các tư thế và bối cảnh
-> Dominique Ingres sử dụng nhiếp ảnh để cung cấp chất liệu cho nền (trong tranh của anh ấy)
Đối chiếu với câu hỏi:
He based some of the scenes in his paintings on photographs - ''he'' dựa trên một số cảnh trong tranh của mình trên các bức ảnh.
-> ''he'' chính là Dominique Ingres
-> đáp án A',NULL,NULL,39,'He based some of the scenes in his paintings on photographs.','FILL_IN_THE_BLANK',112,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 15:47:05.838249','user_56659',false,'2026-06-07 15:47:05.838249','user_56659','(RETRONASAL) SMELL','Trích đoạn chứa đáp án:
No matter how much we talk about tasting our favorite flavors, relishing them really depends on a combined input from our senses that we experience through mouth, tongue an taste, texture, and feel of food are what we tend to focus on, but most important are the slight puffs of air as we chew our food what scientists call ''retronasal smell''.

Keyword cần chú ý:
what scientists call = according to scientists
important = critical

Giải thích đáp án:
Xác định từ loại cần điền: danh từ hoặc cụm danh từ chỉ tên riêng (vì chỗ trống đứng sau ''the term'' - tên gọi)
Thông tin trong bài:
Hương vị , kết cấu, và cảm nhận những khía cạnh mà chúng ta thường tập trung vào khi thưởng thức 1 món ăn, tuy nhiên yếu tố quan trọng nhất là ''slight puffs of air'' khi nhai thức ăn - và cái này những nhà khoa học thưởng gọi là ''retronasal smell''
-> ''retronasal smell'' là nhân tố quan trọng nhất khi thưởng thức mùi vị
Đối chiếu với câu hỏi:
the term _____ characterises the most critical factor in appreciating flavour -> thuật ngữ gì đặc trưng cho yếu tố quan trọng nhất khi đánh giá hương vị món ăn
-> đáp án ''retronasal smell''',NULL,NULL,1,'According to scientists, the term………………………….characterises the most critical factor in appreciating flavour.','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:39:39.609358','user_56659',false,'2026-06-07 16:39:39.609358','user_56659','UMAMI','Trích đoạn chứa đáp án:
Certainly, our mouths and tongues have taste buds, which are receptors for the five basic flavors: sweet, salty, sour, bitter, and umami, or what is more commonly referred to as savory

Keyword cần chú ý:
more commonly referred to = better-known

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau giới từ ''for'')
Thông tin trong bài:
Miệng và lưỡi của chúng ta có các chồi vị giác, là cơ quan tiếp nhận 5 hương vị cơ bản: ngọt, mặn, chua, đắng và umami, hay còn thường được gọi là vị ngọt dịu.
-> Savory là tên gọi phổ biến của Umami
Đối chiếu với câu hỏi:
‘Savoury’ is a better-known word for ________
-> ‘Savory’ là một từ được biết đến nhiều hơn của cái gì
-> đáp án ''umami''',NULL,NULL,2,'‘Savoury’ is a better-known word for………………………
','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:39:59.9171','user_56659',false,'2026-06-07 16:39:59.9171','user_56659','TOXINS','Trích đoạn chứa đáp án:
They evolved to recognise only a few basic tastes in order to quickly identify toxins, which in nature are often quite bitter or acidly sour.

Keyword cần chú ý:
evolved to ~ orginally developed to
bitter or acidic sour - unpleasant taste

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau ''the unpleasant taste of…'' - cấu trúc ''the noun of noun'')
Thông tin trong bài:
They evolved to recognise only a few basic tastes in order to quickly identify toxins, which in nature are often quite bitter or acidly sour - Lưỡi tiến hóa để chỉ nhận ra một số vị cơ bản nhằm nhanh chóng xác định các chất độc, trong tự nhiên thường khá đắng hoặc chua chua.
-> Lưỡi phát triển để nhận biết vị đắng hoặc chua chua của chất độc
Đối chiếu với câu hỏi:
The tongue was originally developed to recognise the unpleasant taste of _____
-> Ban đầu lưỡi được phát triển để nhận biết mùi vị khó chịu của cái gì?
-> đáp án ''toxins''',NULL,NULL,3,'The tongue was originally developed to recognise the unpleasant taste of…………………….','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:40:17.939522','user_56659',false,'2026-06-07 16:40:17.939522','user_56659','INTERNAL SCENTS/SMELLS','Trích đoạn chứa đáp án:
Unlike a hound''s skull with its extra long nose, which evolved specifically to detect external smells, our noses have evolved to detect internal scent

Keyword cần chú ý:
the back of the nose = human nasal cavities

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau động từ ''recognise'')
Thông tin trong bài:
Unlike a hound’s skull with its extra-long nose, which evolved specifically to detect external smells, our noses have evolved to detect internal scents - Không giống như hộp sọ của chó săn với chiếc mũi cực dài, được phát triển đặc biệt để phát hiện mùi bên ngoài, mũi của chúng ta đã phát triển để nhận biết mùi hương bên trong.
-> our noses have evolved to detect internal scents instead of external smells
Đối chiếu với câu hỏi:
Human nasal cavities recognize ________much better than external ones.
-> Các khoang mũi của con người nhận biết cái gì tốt hơn ở bên ngoài?
-> đáp án ''internal scents''',NULL,NULL,4,'Human nasal cavities recognize……………………………much better than external ones.','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:40:59.87984','user_56659',false,'2026-06-07 16:40:59.87984','user_56659','DISCIPLINES','Trích đoạn chứa đáp án:
Shepherd has come up with the term ''neurogastronomy'' to link the disciplines of food science, neurology, psychology, and with the savory elements of eating, one of the most enjoyed of human experiences.

Keyword cần chú ý:
link = draw together
the savory elements of eating ~ the enjoyment of eating

Giải thích đáp án:
Xác định từ loại cần điền: danh từ số nhiều (vì chỗ trống đứng sau cụm ''a number of'')
Thông tin trong bài:
Shepherd has come up with the term ‘neurogastronomy’ to link the disciplines of food science, neurology, psychology, and anthropology with the savoury elements of eating, one of the most enjoyed of human experiences - Shepherd đã đưa ra thuật ngữ ‘neurogastronomy’ để liên kết các ngành khoa học thực phẩm, thần kinh học, tâm lý học và nhân chủng học với các yếu tố mặn của việc ăn uống, một trong những trải nghiệm thú vị nhất của con người.
-> Shephered sử dụng thuật ngữ “''neurogastronomy'' để liên kết nhiều nguyên tắc với việc thưởng thức ăn uống
Đối chiếu với câu hỏi:
Gordon Shepherd uses the word ‘neurogastronomy’ to draw together a number of ______ related to the enjoyment of eating.
-> Gordon Shepherd sử dụng từ ''neurogastronomy'' để tập hợp cái gì liên quan đến việc thưởng thức ăn uống?
-> đáp án ''disciplines''
Lưu ý: “a number of" không ghi rõ trong bài vì trong bài liệt kê ra luôn những disciplines đó là disciplines nào.',NULL,NULL,5,'Gordon Shepherd uses the word ‘neurogastronomy’ to draw together a number of…………………………related to the enjoyment of eating.','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:41:20.880557','user_56659',false,'2026-06-07 16:41:20.880557','user_56659','SPATIAL MAP','Trích đoạn chứa đáp án:
The visual system detects patterns of light and dark and, building on experience, the brain creates a spatuses

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau mạo từ ''a'')
Thông tin trong bài:
The visual system detects patterns of light and dark and, building on experience, the brain creates a spatial map - Hệ thống thị giác phát hiện các dạng ánh sáng và bóng tối và dựa trên kinh nghiệm, não bộ sẽ tạo ra một bản đồ không gian.
-> The brain creates a spatial map from patterns of light and dark
-> Patterns of light and dark are used to create a spatial map
Đối chiếu với câu hỏi:
Patterns of dark and light are used to put together a …..
-> Các dạng bóng tối và ánh sáng được sử dụng để kết hợp với nhau thành một…..
-> đáp án ''spatial map''',NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:43:32.876766','user_56659',false,'2026-06-07 16:43:32.876766','user_56659','APPETITES','Trích đoạn chứa đáp án:
On the horizon, we have the positive application of neurogastronomy: manipulating flavor to curb our appetites

Keyword cần chú ý:
manipulating flavor = flavor manipulation
curb =control

Giải thích đáp án:
Câu hỏi: Thứ gì có thể được kiểm soát trong tương lai thông qua việc kiểm soát hương vị?
Vì từ để hỏi là ''what'' -> đáp án cần danh từ
Thông tin trong bài:
On the horizon, we have the positive application of neurogastronomy: manipulating flavour to curb our appetites - sắp tới đây, chúng ta có thể có những ứng dụng tích cực của mô học thần kinh: điều khiển hương vị để kiềm chế sự thèm ăn của chúng ta.
-> Trong tương lai, sự thèm ăn có thể được kiểm soát thông qua việc kiểm soát hương vị
-> đáp án ''appetites''',NULL,NULL,13,'What could be controlled in the future through flavour manipulation?','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:41:34.815664','user_56659',false,'2026-06-07 16:41:34.815664','user_56659','SOCIAL LIFE','Trích đoạn chứa đáp án:
This ability to appreciate specific aromas turns out to be central to the pleasure we get from food, much as our ability to recognise individuals is central to the pleasures of social life

Keyword cần chú ý:
central to = key to
pleasures of = enjoyment of

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau giới từ ''of'')
Thông tin trong bài:
This ability to appreciate specific aromas turns out to be central to the pleasure we get from food, much as our ability to recognise individuals is central to the pleasures of social life.
-> Câu trong bài đọc chỉ đơn thuần so sánh hai hiện tượng này giống nhau: ability to appreciate specific aromas ~ our ability to recognise individuals
-> Để trả lời câu hỏi này, ta chỉ cần tập trung vào vế thứ hai của câu: our ability to recognise individuals is central to the pleasures of social life. - khả năng nhận biết những cá nhân xung quanh chúng ta là trung tâm của những thú vui của đời sống xã hội
Đối chiếu với câu hỏi:
Facial recognition is key to our enjoyment of ______ - Nhận dạng khuôn mặt, hay nói cách khác việc nhận biết mọi người xung quanh là chìa khóa để chúng ta tận hưởng ______
-> đáp án ''social life''',NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:42:09.743042','user_56659',false,'2026-06-07 16:42:09.743711','user_56659','(AIR) MOLECULES','Trích đoạn chứa đáp án:
As we eat, specialised receptors in the back of the nose detect the air molecules in our meals.

Keyword cần chú ý:
detect = recognise
meals = food

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau ''the'')
Thông tin trong bài:
As we eat, specialised receptors in the back of the nose detect the air molecules in our meals - Khi chúng ta ăn, các thụ thể chuyên biệt ở phía sau mũi sẽ phát hiện các air molecules trong thức ăn.
Đối chiếu với câu hỏi:
receptors recognize the ….. in food
-> các thụ thể nhận biết..... trong thức ăn
-> đáp án ''air molecules''',NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:42:22.563026','user_56659',false,'2026-06-07 16:42:22.563026','user_56659','FLAVORS/FLAVOURS','Trích đoạn chứa đáp án:
From signals sent by the receptors, the brain understands smells as spatial patterns. Using these, as well as input from the other senses, it constructs the idea of specific flavors.

Keyword cần chú ý:
specific = certain

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống đứng sau tính từ ''certain'')
Thông tin trong bài:
From signals sent by the receptors, the brain understands smells as complex spatial patterns. Using these, as well as input from the other senses, it constructs the idea of specific flavours - Từ các tín hiệu gửi bởi các cơ quan thụ cảm, não bộ hiểu mùi như là các mô hình không gian phức tạp. Hoạt động này kết hợp cùng với các giác quan khác tạo cho não bộ ý tưởng về các hương vị cụ thể
-> the brain can identifies specific flavors.
Đối chiếu với câu hỏi:
The brain identifies certain _____
-> não bộ xác định ..... cụ thể
-> đáp án ''flavours''',NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',114,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:42:42.983095','user_56659',false,'2026-06-07 16:42:42.983095','user_56659','MEMORIES','Trích đoạn chứa đáp án:
Smell stimuli form what Shepherd terms ''odor objects'', stored as memories, and these have a direct link with our emotions.

Giải thích đáp án:
Câu hỏi: Não bộ lưu trữ ''odor objects'' ở dưới hình thức nào?
Vì từ để hỏi là ''what form'' -> đáp án cần danh từ
Thông tin trong bài:
Smell stimuli form what Shepherd terms “odour objects”, stored as memories
-> các tác nhân kích thích khứu giác được gọi là ''odor objetcs'' và được lưu trữ dưới dạng memories
-> Não bộ lưu trữ ''odor objects'' ở dưới dạng thức là: ký ức - memories
-> đáp án ''memories''',NULL,NULL,10,'In what form does the brain store ‘odor objects’?','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:42:58.798565','user_56659',false,'2026-06-07 16:42:58.799106','user_56659','PREY','Trích đoạn chứa đáp án:
Go back in history and this was part of our survival repertoire; like most animals, we drew on our sense of smell, when visual information was scarce to single out prey.

Keyword cần chú ý:
single out = find

Giải thích đáp án:
Câu hỏi: Khi việc nhìn thấy khó khăn, chúng ta đã sử dụng khứu giác để tìm cái gì?
Vì từ để hỏi là ''what'' -> đáp án cần danh từ
Thông tin trong bài:
... we drew on our sense of smell, when visual information was scarce, to single out prey
-> Ở thời xưa, giống như hầu hết các loài động vật, khi việc dựa vào thị giác để săn bắt còn hạn chế, con người dựa vào khứu giác của mình để tìm ra con mồi
-> Khi việc nhìn thấy khó khăn, con người đã sử dụng khứu giác để tìm ra con mồi
-> đáp án ''prey''',NULL,NULL,11,'When seeing was difficult, what did we use our sense of smell to find?','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:43:15.75547','user_56659',false,'2026-06-07 16:43:15.756074','user_56659','CHOCOLATE','Trích đoạn chứa đáp án:
Consider the response to the sharpness of a lemon and compare that with the face that is welcoming the smooth wonder of chocolate.

Giải thích đáp án:
Câu hỏi: Món ăn nào minh họa cho mối liên hệ giữa hương vị và cảm xúc tích cực?
Vì từ để hỏi là ''Which food'' -> đáp án cần danh từ
Thông tin trong bài:
(1) The engagement of our emotions can be readily illustrated when we picture some of the wide ranging facial expressions that are elicited by various foods many of them hardwired at birth - Sự gắn kết cảm xúc của chúng ta có thể dễ dàng được minh họa khi chúng ta hình dung ra một số biểu hiện đa dạng trên khuôn mặt được gợi ra bởi nhiều loại thức ăn khác nhau – nhiều trong số chúng đã đi vào não bộ của chúng ta khi mới sinh ra
-> Các loại thức ăn khác nhau có thể có tác động đến cảm xúc của chúng ta
(2) Consider the response to the sharpness of a lemon and compare that with the face that is welcoming the smooth wonder of chocolate.
-> Câu 2 là ví dụ cho câu 1, thể hiện ảnh hưởng của đồ ăn lên cảm xúc - facial expressions/ emotions
+ Ăn chanh -> thấy chua
+ Ăn chocolate -> gương mặt “Welcome" (Chào mừng") mùi vị “smooth" của chocolate
-> Món ăn mà minh họa cho mối liên hệ giữa hương vị và cảm xúc tích cực là ''chocolate''
-> đáp án ''chocolate''',NULL,NULL,12,'Which food item illustrates how flavour and positive emotion are linked?','FILL_IN_THE_BLANK',114,NULL),
	 ('2026-06-07 16:48:31.219679','user_56659',false,'2026-06-07 16:48:31.219679','user_56659','IV','Trích đoạn chứa đáp án:
Last year, a new Hong Kong restaurant, Robot Kitchen, opened with a couple of sensor-laden humanoid machines directing customers to their seats. Each possesses a touch-screen on which orders can be keyed in

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1 - 3: Giới thiệu về robots làm việc ở nhà hàng
Câu 5 - 8: Giới thiệu robots giúp việc ở Tokyo
Câu 9- 11: Nêu yêu cầu của robots giúp việc: do not scare individuals
-> Ý chính: Những ví dụ của 2 loại robots làm việc
-> đáp án: iv. Examples of robots at work',NULL,NULL,19,'Paragraph F','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:47:06.635109','user_56659',false,'2026-06-07 16:47:06.635109','user_56659','I','Trích đoạn chứa đáp án:
For a long time, researchers tried to get round the problem by attempting to re-create the visual processing that goes on in the human cortex. However, that challenge has proved to be singularly exacting and complex. So scientists have turned to simpler alternatives: ‘We have become far more pragmatic in our work,’ says Nello Cristianini, Professor of Artificial Intelligence at the University of Bristol in England and associate editor of the Journal of Artificial Intelligence Research.

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1 - 2: Cách tiếp cận cũ (recreate visual processing in human) không hiệu quả (complex)
Câu 3 - 8: Cách tiếp cận mới (simpler alternatives)
-> Ý chính: Thay đổi cách tiếp cận vấn đề
-> đáp án: i. Tackling the Issue using a different approach',NULL,NULL,18,'Paragraph E','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:45:54.781193','user_56659',false,'2026-06-07 16:45:54.781701','user_56659','VIII','Trích đoạn chứa đáp án:
‘The robotics industry is developing in much the same way the computer business did 30 years ago,’ he argues

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1 - 2 : Nhấn mạnh sự phát triển của robots (It is a remarkable transition that....)
Câu 3: So sánh sự phát triển của robots với sự phát triển của một phát minh trước đây (computer)
Câu 4: Đưa ví dụ về sự phát triển của robots
Câu 5: Nhấn mạnh lại sự phát triển của robots
-> Ý chính: Sự phát triển của robots giống với sự phát triển một phát minh trước đây (computers)
Có thể thấy nội dung được thể hiện rõ ràng nhất qua trích dẫn phát biểu của Bill Gates ở câu 3: ''The robotics industry is developing in much the same way the computer business did 30 years ago’
Ta thấy:
in much the same way ~ following the pattern
the computer business did 30 years ago ~ earlier development
-> đáp án: viii. Following the pattern of an earlier development',NULL,NULL,16,'Paragraph C','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:45:35.524244','user_56659',false,'2026-06-07 16:45:35.524244','user_56659','II','Trích đoạn chứa đáp án:
Yet only three years earlier, at DARPA’s previous driverless car race, every robot competitor – directed to navigate across a stretch of open desert – either crashed or seized up before getting near the finishing line

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1: Nói về những standards mà máy móc có thể làm được là 1 việc đáng ngạc nhiên - ''startling''
Câu 2: Làm rõ ý cho câu (1) giải thích tại sao việc đó đáng ngạc nhiên (Vì “Driving is a complex task'')
Câu 3: Dù khó nhưng computers được trang bị on-board computers để làm nhiều việc
Câu 4: Thể hiện sự ngạc nhiên về việc computers có thể lái xe tốt (chỉ gây ra 1 tai nạn trong cuộc đua)
Câu 5: Dù cho chỉ ba năm trước thôi mà có rất nhiều tai nạn. (Yet only three years earlier,...)
-> Ý chính: Sự ngạc nhiên về khả năng lái xe và sự tiến bộ của computers so với lần trước.
-> đáp án: ii. A significant improvement on last time',NULL,NULL,15,'Paragraph B','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:44:38.578675','user_56659',false,'2026-06-07 16:44:38.578675','user_56659','V','Trích đoạn chứa đáp án:
Normally drivers get out, gesticulate, exchange insurance details and then drive off. But not on this occasion. No one got out of the cars for the simple reason that they had no humans inside them

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1 - 2: Miêu tả một tai nạn xe: Câu 1 giới thiệu 2 chiếc xe, câu 2 nói về tai nạn xảy ra (there was a crack = có tiếng gãy)
Câu 3: Miêu tả sự việc thường xảy ra khi có tai nạn
Câu 4 - 5: Sự đặc biệt trong vụ tai nạn này: Không hề có humans mà chỉ có computers control cars.
-> Ý chính: Sự khác biệt giữa vụ tai nạn này với vụ tai nạn thông thường
-> sự khác biệt được thể hiện rõ nhất qua cụm ''But not on this occasion'' ~ Not what it seemed to be
-> đáp án: v. Not what it seemed to be',NULL,NULL,14,'Paragraph A','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:50:12.087379','user_56659',false,'2026-06-07 16:50:12.087379','user_56659','ULTRASOUND SIGNALS','Trích đoạn chứa đáp án:
The Trilobite scuttles around homes emitting ultrasound signals to create maps of rooms, which are remembered for future cleaning

Keyword cần chú ý:
a digital map and route plans = maps and plans for route

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (chỗ trống cần điền đứng trước động từ ''sent out'')
Thông tin trong bài:
The Trilobite scuttles around homes emitting ultrasound signals to create maps of rooms, which are remembered for future cleaning - Trilobite di chuyển xung quanh ngôi nhà và phát ra tín hiệu siêu âm để tạo ra bản đồ các phòng, điều này được ghi nhớ cho chức năng lau dọn trong tương lai.
Đối chiếu với câu hỏi:
Electrolux Trilobite builds an image of a room by sending out _____ - Electrolux Trilobite tạo dựng hình ảnh của một căn phòng bằng cách phát ra _____
-> đáp án ''ultrasound signals''',NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:49:46.117125','user_56659',false,'2026-06-07 16:49:46.117708','user_56659','ON(-)BOARD COMPUTER','Trích đoạn chứa đáp án:
Yet here, each car had its on-board computer loaded with a digital map and route plans

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (chỗ trống cần điền đứng trước động từ ''provides'')
Thông tin trong bài:
each car had its onboard computer loaded with a digital map and route plans - mỗi chiếc xe đều có một máy tính gắn liền với một bản đồ kỹ thuật số và các kế hoạch về lộ trình
Đối chiếu với câu hỏi:
____ provides maps and plans for route - ____ cung cấp bản đồ và kế hoạch cho tuyến đường
-> đáp án ''on-board computer''',NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',115,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:49:30.114645','user_56659',false,'2026-06-07 16:49:30.114645','user_56659','C','Trích đoạn chứa đáp án:
Robots first learn basic competence – how to move around a house without bumping into things. Then we can think about teaching them how to interact with humans,’ Chrisley said

Giải thích đáp án:
Thông tin trong bài: (phần cuối đoạn F)
''Robots first learn basic competence how to move around a house without bumping into things. Then we can think about teaching them how to interact with humans - Đầu tiên, rô bốt học kỹ năng cơ bản về cách di chuyển trong nhà mà không va vào đồ vật. Sau đó, chúng ta có thể nghĩ đến việc dạy chúng cách tương tác với con người,
Câu hỏi:
We need to enable robots to move freely before we think about trying to communicate with them - Chúng ta cần cho phép robot di chuyển tự do trước khi nghĩ đến việc cố gắng giao tiếp với chúng
-> đây là phát biểu của Ron Chrisley
-> đáp án C',NULL,NULL,23,'We need to enable robots to move freely before we think about trying to communicate with them.','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:49:15.768917','user_56659',false,'2026-06-07 16:49:15.768917','user_56659','A','Trích đoạn chứa đáp án:
“The fact is we still have a way to go before real robots catch up with their science fiction counterparts”, Gates says

Giải thích đáp án:
Thông tin trong bài: (đoạn D)
The fact is we still have a way to go before real robots catch up with their science fiction counterparts - Thực tế là chúng ta vẫn còn một quãng đường phía trước trước khi các robot thực sự bắt kịp các loại robot khoa học viễn tưởng khác.
-> Chúng ta vẫn còn một con đường để đi trước khi robot thực có thể giống như robot trong khoa học viễn tưởng
Câu hỏi:
It will take considerable time for modern robots to match the ones we have created in films and books. - Sẽ mất nhiều thời gian để rô bốt hiện đại có thể khớp với những rô bốt chúng ta đã tạo ra trong phim và sách
-> đây là phát biểu của Bill Gates
-> đáp án A',NULL,NULL,22,'It will take considerable time for modern robots to match the ones we have created in films and books.','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:49:02.663791','user_56659',false,'2026-06-07 16:49:02.663791','user_56659','B','Trích đoạn chứa đáp án:
‘We are no longer trying to re-create human functions. Instead, we are looking for simpler solutions with basic electronic sensors, for example

Giải thích đáp án:
Thông tin trong bài: (đoạn E)
Nello Cristianini
We are no longer trying to re-create human functions. Instead, we are looking for simpler solutions with basic electronic sensors, for example - Chúng tôi không còn cố gắng tái tạo các chức năng của con người. Thay vào đó, chúng tôi đang tìm kiếm các giải pháp đơn giản hơn với các cảm biến điện tử cơ bản chẳng hạn
Câu hỏi:
We have stopped trying to enable robots to perceive objects as humans do.
- Chúng tôi đã ngừng khiến cho các robot nhận thức các vật thể như con người.
-> đây là phát biểu của Nello Cristianini
-> đáp án B',NULL,NULL,21,'We have stopped trying to enable robots to perceive objects as humans do.','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-10 19:30:51','truongdx18vtit',false,'2026-06-10 19:30:51','truongdx18vtit','PARKING','Trích đoạn chứa đáp án:
FATHER: And will I have any parking problems there?
SARAH: No, there’s always plenty available.

Giải thích đáp án:
10 Plenty of (10) _____ is available.
Đáp án cần điền là một danh từ, cái mà có sẵn (available)
-> parking.','','',10,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:34:04','truongdx18vtit',false,'2026-06-10 19:34:04','truongdx18vtit','I','Trích đoạn chứa đáp án:
Then you’ll need to know where some of the offices are. The human resources department is at the front of this building, so you head to the left along the corridor from reception, and it’s the second room you come to. It looks out onto the main road.

Giải thích đáp án:
Dịch: Human resources department (phòng nhân sự) là phòng thứ 2 phía bên trái hành lang (corridor).
-> I','','',19,'human resources ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:34:58','truongdx18vtit',false,'2026-06-10 19:34:58','truongdx18vtit','B/E','Trích đoạn chứa đáp án:
TOM: ..... I’ve realised the notes from my research are almost all just descriptions, I haven’t actually evaluated anything. So I’ll have to fix that.
JESS: Oh, I didn’t know we had to do that. I’ll have to look at that too

Giải thích đáp án:
23-24 In which TWO ways do both JESS and TOM decide to change their proposals?
TOM kể là mới nhận ra notes từ nghiên cứu của mình chỉ bao gồm mô tả mà chưa có phần đánh giá nên phải sửa lại. Jess cũng nói sẽ làm thêm phần này.
-> E, by making their notes more evaluative','','',23,'','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:34:48','truongdx18vtit',false,'2026-06-10 19:34:48','truongdx18vtit','C/E','Trích đoạn chứa đáp án:
JESS: What a letdown! It poured with rain and we hardly saw a single bird. Much less use than the trip to the Natural History Museum
TOM: Yeah. I liked all the stuff about evolution there.

Giải thích đáp án:
21-22 Which TWO parts of the introductory stage to their art projects do JESS and TOM agree were useful?
Trong script, JESS nói rằng bird tour là chuyến đi Bird Park dính mưa nên ít có ít hơn nhiều so với chuyến đi Natural History Museum.
-> C, the Natural History Museum visit.','','',22,'','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-07 17:05:59.417021','user_56659',false,'2026-06-07 17:05:59.417021','user_56659','NO','Trích đoạn chứa đáp án:
Drawing from change blindness research, scientists have come to the conclusion that we perceive the world in much less detail than previously thought (Johansson, Hall, & Sikstrom, 2008)

Keyword cần chú ý:
conclude = come to the conclusion that
perceive = take in
the world ~ our surroundings

Giải thích đáp án:
Keywords: scientists, concluded, take in, as much detail as possible, our surroundings
Dựa vào keywords -> thông tin cần tìm nằm ở đoạn 5
Thông tin trong bài:
scientists have come to the conclusion that we perceive the world in much less detail - các nhà khoa học đã đi đến kết luận rằng chúng ta nhận thức thế giới ít chi tiết hơn nhiều so với suy nghĩ trước đây
Đối chiếu với câu hỏi:
Scientists have concluded that we try to take in as much detail as possible from our surroundings - Các nhà khoa học đã kết luận rằng chúng ta cố gắng thu nhận càng nhiều chi tiết càng tốt từ thế giới xung quanh chúng ta.
-> trái với thông tin trong bài
-> NO',NULL,NULL,31,'Scientists have concluded that we try to take in as much detail as possible from our surroundings.','YES_NO_NOT_GIVEN',117,NULL),
	 ('2026-06-07 17:04:38.612156','user_56659',false,'2026-06-07 17:04:38.612156','user_56659','YES','Trích đoạn chứa đáp án:
Out of the 80 participants, 49 (61%) did not notice the change of the burglar''s identity, suggesting that change blindness may have serious implications for criminal proceedings.

Keyword cần chú ý:
criminal proceedings = legal trial
serious implications ~ could be significantly affected

Giải thích đáp án:
Keywords: legal trial, be significantly affected, change blindness
Dựa vào keywords -> thông tin cần tìm nằm ở đoạn 3
Ở đây tác giả nhắc tới 1 nghiên cứu của Davies and Hine và đối tượng nghiên cứu là ''burglary video''. Trong nghiên cứu này, 80 người tham gia được xem đoạn burglary video mà trong đó danh tính của tên trộm ban đầu bị thay đổi ở nửa sau của video
Thông tin trong bài:
Out of the 80 participants, 49 (61%) did not notice the change of the burglar''s identity, suggesting that change blindness may have serious implications for criminal proceedings. - Trong số 80 người tham gia, 49 (61%) không nhận thấy sự thay đổi danh tính của tên trộm, cho thấy rằng hiện tượng change blindness có thể có tác động nghiêm trọng đến tố tụng hình sự
-> A lot of people got affected by change blindness during criminal proceedings
Đối chiếu với câu hỏi:
A legal trial could be significantly affected by change blindness - Một phiên tòa pháp lý có thể bị ảnh hưởng đáng kể bởi hiện tượng change blindness
-> khớp với thông tin trong bài
-> YES',NULL,NULL,30,'A legal trial could be significantly affected by change blindness.','YES_NO_NOT_GIVEN',117,NULL),
	 ('2026-06-07 17:04:11.709286','user_56659',false,'2026-06-07 17:04:11.709286','user_56659','NO','Trích đoạn chứa đáp án:
Our sensory and cognitive systems have systematic ways of failing of which we are often, perhaps blissfully, unaware.
Giải thích đáp án:

 

Keywords: Our sensory and cognitive systems = judgement; systematic ways of failing = error; unaware >< tend to know
Thông tin trong bài:
Hệ thống cảm giác và nhận thức của chúng ta có những cách thất bại mang tính hệ thống — mà chúng ta thường, có lẽ một cách “vô tư", không hề nhận ra.
-> trái với thông tin trong bài
-> NO',NULL,NULL,29,'We tend to know when we have made an error of judgement.','YES_NO_NOT_GIVEN',117,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:03:39.580466','user_56659',false,'2026-06-07 17:03:39.580466','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
We are constantly required to process a wide range of information to make decisions. Sometimes, these decisions are trivial, such as what marmalade to buy. At other times, the stakes are higher, such as deciding which symptoms to report to the doctor.

Giải thích đáp án:
Keywords: doctors, make decisions, symptoms, patient describes
Dựa vào keywords -> thông tin cần tìm nằm ở đoạn 1
Thông tin trong bài:
At other times, the stakes are higher, such as deciding which symptoms to report to the doctor - Vào những thời điểm khác, khi rủi ro cao hơn, chẳng hạn như quyết định triệu chứng nào cần báo cho bác sĩ.
-> patients report symptoms to the doctor
Tuy nhiên, bài đọc không hề nhắc tới yếu tố ''doctor make decisions according to the symptoms'' như được đưa ra trong câu hỏi
-> NOT GIVEN',NULL,NULL,27,'Doctors make decisions according to the symptoms that a patient describes.','YES_NO_NOT_GIVEN',117,NULL),
	 ('2026-06-07 17:07:47.778113','user_56659',false,'2026-06-07 17:07:47.778113','user_56659','A/C','Trích đoạn chứa đáp án:
To examine choice blindness, Hall and colleagues (2010) invited supermarket customers to sample two different kinds of jams and teas. After participants had tasted or smelled both samples, they indicated which one they preferred. Subsequently, they were purportedly given another sample of their preferred choice. On half of the trials, however, these were samples of the non-chosen jam or tea.

Giải thích đáp án:
Thông tin trong bài:
After participants had tasted or smelled both samples, they indicated which one they preferred. Subsequently, they were purportedly given another sample of their preferred choice. On half of the trials, however, these were samples of the non-chosen jam or tea. - Sau khi quyết định loại mứt/ trà yêu thích, người tham gia được nhận sản phẩm cùng loại; tuy nhiên, trong một nửa trường hợp, người làm thí nghiệm lại đưa cho họ sản phẩm loại mà họ không chọn
-> Các mẫu samples trong 1 nửa số lần trials (thử nghiệm) là non-chosen, tức không phải cái customers đã chọn
-> Một số lựa chọn của khách đã bị thay đổi.
-> đáp án C',NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 16:50:31.029896','user_56659',false,'2026-06-07 16:50:31.030573','user_56659','TOUCH(-)SCREEN','Trích đoạn chứa đáp án:
Last year, a new Hong Kong restaurant, Robot Kitchen, opened with a couple of sensor-laden humanoid machines directing customers to their seats. Each possesses a touch-screen on which orders can be keyed in

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (chỗ trống cần điền đứng sau mạo từ ''a'')
Thông tin trong bài:
Each possesses a touchscreen on which orders can be keyed in.
(each = Robot Kitchen)
-> Mỗi con rô=bốt sở hữu một màn hình cảm ứng để có thể nhập đơn hàng.
Đối chiếu với câu hỏi:
Robot Kitchen humanoids have a _____ to take orders - Robot Kitchen humanoids có _____ để nhận đơn đặt hàng
-> đáp án ''touchscreen ''',NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:48:46.377978','user_56659',false,'2026-06-07 16:48:46.377978','user_56659','C','Trích đoạn chứa đáp án:
Machines such as these take researchers into the field of socialised robotics: how to make robots act in a way that does not scare or offend individuals. ‘We need to study how robots should approach people, how they should appear. That is going to be a key area for future research,’ adds Chrisles

Giải thích đáp án:
Thông tin trong bài: (phần cuối đoạn F)
Machines such as these take researchers into the field of socialised robotics: how to make robots act in a way that does not scare or offend individuals. - Những máy móc như thế này đưa các nhà nghiên cứu vào lĩnh vực rô bốt xã hội hóa: làm thế nào để rô bốt hoạt động theo cách không gây sợ hãi hoặc xúc phạm các cá nhân.
-> Các nhà nghiên cứu muốn chế tạo robot hoạt động theo cách không khiến các cá nhân sợ hãi
Câu hỏi:
An important concern for scientists is to ensure that robots do not seem frightening - Một mối quan tâm đối với các nhà khoa học là đảm bảo rằng robot không có vẻ đáng sợ
-> đây là phát biểu của Ron Chrisley
-> đáp án C',NULL,NULL,20,'An important concern for scientists is to ensure that robots do not seem frightening.','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 16:46:51.45088','user_56659',false,'2026-06-07 16:46:51.45088','user_56659','VII','Trích đoạn chứa đáp án:
Humans orient themselves with other objects in a room very easily. Robots find the task almost impossible. ‘Even something as simple as telling the difference between an open door and a window can be tricky for a robot,’ says Gates

Giải thích đáp án:
Tóm tắt sơ lược nội dung toàn đoạn:
Câu 1 - 2: Robot có tiềm năng nhưng cần có thời gian đáng kể để đạt được tiềm năng này
Câu 3-8: Nói tới những khó khăn của robots: getting robots to know their place
''Humans orient themselves with other objects in a room very easily. Robots find the task almost impossible. ‘Even something as simple as telling the difference between an open door and a window can be tricky for a robot''
Câu 9: Hệ quả: reduce robots to static (= not moving) roles
''This has, until recently, reduced robots to fairly static and cumbersome roles.''
-> Tác giả nêu ra 1 khó khăn chính đó là làm cho robot biết vị trí của chúng -> điều này thì gần như bất khả thi với robot (giải thích vì sao lại như vậy) -> đưa ra hậu quả: static roles = rarely move
-> có thể thấy tác giả đưa ra lý do tại sao robot hiếm khi di chuyển
-> đáp án: vii. The reason why robots rarely move',NULL,NULL,17,'Paragraph D','FILL_IN_THE_BLANK',115,NULL),
	 ('2026-06-07 17:08:16.053909','user_56659',false,'2026-06-07 17:08:16.053909','user_56659','B/E','Trích đoạn chứa đáp án:
Merckelbach, Jelicic, and Pieters (2011) investigated choice blindness for intensity ratings of one''s own psychological symptoms. Their participants had to rate the frequency with which they experienced 90 common symptoms (e.g. anxiety, lack of concentration, stress, headaches etc.) on a 5 point scale.

Giải thích đáp án:
Thông tin trong bài:
Merckelbach, Jelicic, and Pieters investigated choice blindness for intensity ratings of one''s own psychological symptoms. Their participants had to rate the frequency with which they experienced 90 common symptoms on a 5 point scale.
-> Merckelbach, Jelicic và Pieters đã nghiên cứu về hiện tượng choice blindness để đánh giá cường độ của các triệu chứng tâm lý của chính một người. Những người tham gia phải đánh giá tần suất mà họ đã trải qua trong số 90 triệu chứng phổ biến trên thang điểm 5.
Ta thấy:
intensity ratings = strength of the symptoms (cường độ của triệu chứng)
rate the frequency = rate the regulariy of the symmtoms (đánh giá tần syaats của triệu chứng)
-> đáp án là B và E',NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 17:07:59.97094','user_56659',false,'2026-06-07 17:07:59.97094','user_56659','A/C','Trích đoạn chứa đáp án:
Recently, the phenomenon has also been replicated for choices involving auditory stimuli (Sauerland, Sagana, & Otgaar, 2012). Specifically, participants had to listen to three pairs of voices and decide for each pair which voice they found more sympathetic or more criminal.

Giải thích đáp án:
Thông tin trong bài:
the phenomenon has also been replicated for choices involving auditory stimuli ...Specifically, participants had to listen to three pairs of voices and decide for each pair which voice they found more sympathetic or more criminal.
-> hiện tượng ''choice blindness'' cũng đã được nhân rộng cho các lựa chọn liên quan đến kích thích thính giác. Cụ thể, những người tham gia phải nghe ba cặp giọng nói và quyết định cho mỗi cặp giọng nói mà họ cảm thấy có tính đồng cảm hơn hoặc mang tính phạm tôi hơn
-> khảo sát tập trung vào thính giác (listen to voices) và voices = non-visual material
-> đáp án A',NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 19:38:18','user_05335',false,'2026-06-07 19:38:18','user_05335','G','Trích đoạn chứa đáp án:
In both developed and developing nations there is often a very large discrepancy between the options available to people in different social
classes, incomebrackets, and levels of education

Keyword cần chú ý:
option ~ access

Giải thích đáp án:
Lí do có sự khác biệt giữa mọi người trong một nước trong việc tiếp cận với hệ thống y tế => Đáp án G','','',17,'reasons why the level of access to healthcare can vary within a country','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 19:37:52','user_05335',false,'2026-06-07 19:37:52','user_05335','F','Trích đoạn chứa đáp án:
Researchers.....work to create a clear way of categorising
illnesses, diseases and epidemics into local and global scales.

Keyword cần chú ý:
catergorise ~ classify

Giải thích đáp án:
Các nhà nghiên cứu phân loại (categorise) các bệnh dịch theo độ lan rộng
của chúng => Đáp án F','','',16,'a reference to classifying diseases on the basis of how far they extend geographically','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 17:08:29.561029','user_56659',false,'2026-06-07 17:08:29.561029','user_56659','B/E','Trích đoạn chứa đáp án:
Merckelbach, Jelicic, and Pieters (2011) investigated choice blindness for intensity ratings of one''s own psychological symptoms. Their participants had to rate the frequency with which they experienced 90 common symptoms (e.g. anxiety, lack of concentration, stress, headaches etc.) on a 5 point scale.

Giải thích đáp án:
Thông tin trong bài:
Merckelbach, Jelicic, and Pieters investigated choice blindness for intensity ratings of one''s own psychological symptoms. Their participants had to rate the frequency with which they experienced 90 common symptoms on a 5 point scale.
-> Merckelbach, Jelicic và Pieters đã nghiên cứu về hiện tượng choice blindness để đánh giá cường độ của các triệu chứng tâm lý của chính một người. Những người tham gia phải đánh giá tần suất mà họ đã trải qua trong số 90 triệu chứng phổ biến trên thang điểm 5.
Ta thấy:
intensity ratings = strength of the symptoms (cường độ của triệu chứng)
rate the frequency = rate the regulariy of the symmtoms (đánh giá tần suất của triệu chứng)
-> đáp án là B và E',NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',117,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:07:21.36888','user_56659',false,'2026-06-07 17:07:21.36888','user_56659','(THE/SOME) VALUABLES','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền đứng sau ''of'' với cấu trúc the noun of noun)
Thông tin trong bài:
In the video, a man entered a house, walking through the different rooms and putting valuables into a knapsack. - Trong video, một người đàn ông bước vào một ngôi nhà, đi qua các phòng khác nhau và bỏ những thứ có giá trị vào một chiếc ba lô.
-> participants được cho coi 1 video về a man entered a house and putting valuables into a knapsack
-> Participants watched a man collecting valuables.
Đối chiếu với câu hỏi:
Focus of participants’ attention - The collection of _________
-> đáp án ''valuables''',NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 17:06:35.249329','user_56659',false,'2026-06-07 17:06:35.249329','user_56659','(SOME) DIRECTIONS','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền đứng sau động từ ''giving'')
Thông tin trong bài:
...you are taking a walk in your local city park when a tourist approaches you asking for directions.
-> A tourist ask you to give him/her directions
Đối chiếu với câu hỏi:
Giving _____________ to a stranger
a stranger ~ a tourist
-> đáp án ''directions''',NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 17:06:17.120366','user_56659',false,'2026-06-07 17:06:17.120366','user_56659','VISUAL DISTURBANCE','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền đứng sau mạo từ ''a'')
Thông tin trong bài:
This phenomenon has been termed ''change blindness'' and refers to the difficulty that observers have in noticing changes to visual scenes (e.g. the person swap), when the changes are accompanied by some other visual disturbance (e.g. the passing of the door).
-> change blindess refers to the difficulty that observers have in noticing changes when the changes are accompanied by visual disturbance
-> When there are changes that are accompanied by visual disturbance, change blindness happens.
-> Khi có những thay đổi đi kèm với rối loạn thị giác, hiện tượng ''mù thoáng qua'' sẽ xảy ra.
-> change blindess is caused by visual disturbance
Đối chiếu với câu hỏi:
To illustrate change blindness caused by a________, such as an object.
-> đáp án ''visual disturbance''',NULL,NULL,32,NULL,'FILL_IN_THE_BLANK',117,NULL),
	 ('2026-06-07 17:03:55.44976','user_56659',false,'2026-06-07 17:03:55.44976','user_56659','NO','Trích đoạn chứa đáp án:
However, the fact that we are accustomed to processing large amounts of information does not mean that we are better at it (Chabris & Simons, 2009).

Keyword cần chú ý:
deal with a lot of input material ~ processing large amounts of information

Giải thích đáp án:
Keywords: ability, deal with, lot of input material, improved, over time
Dựa vào keywords -> thông tin cần tìm nằm ở đoạn 1
Thông tin trong bài:
the fact that we are accustomed to processing large amounts of information does not mean that we are better at it - sự thực là việc chúng ta đã quen với việc xử lý một lượng lớn thông tin không có nghĩa là chúng ta giỏi hơn
-> We are able to process a lot of information, but we don''t get better at processing a lot of information.
Đối chiếu với câu hỏi:
Our ability to deal with a lot of input material has improved over time. - Khả năng xử lý nhiều dữ liệu đầu vào của chúng ta đã được cải thiện theo thời gian.
-> trái với thông tin trong bài
-> NO',NULL,NULL,28,'Our ability to deal with a lot of input material has improved over time.','YES_NO_NOT_GIVEN',117,NULL),
	 ('2026-06-07 17:39:18.025176','user_56659',false,'2026-06-07 17:39:18.025176','user_56659','FALSE','Trích đoạn chứa đáp án:
The way they swarm or flock together does not usually get good press coverage either: marching like worker ants might be a common simile for city commuters, but it’s a damning, not positive, image.

Giải thích đáp án:
Dịch thông tin trong bài:
Cách những loài côn trùng, chim hay cá đi theo bầy đàn với nhau thường không mang lại hình ảnh tốt, chẳng hạn như diễu hành như kiến thợ có thể là cách ví von phổ biến đối với những người đi làm trong thành phố, nhưng đó là một hình ảnh không tích cực.
-> có thể suy luận: City commuters are compared in a not positive way with worker ants
Đối chiếu với câu hỏi:
Commuters are often compared favourably with worker ants
-> favourably là trạng từ mang sự tích cực
-> Câu hỏi nói rằng commuters được so sánh với loài kiến thợ theo hướng tích cực là trái với thông tin trong bài (not positive >< favourably)
-> FALSE',NULL,NULL,1,'Commuters are often compared favourably with worker ants.','TRUE_FALSE_NOT_GIVEN',118,NULL),
	 ('2026-06-07 17:40:42.908407','user_56659',false,'2026-06-07 17:40:42.908407','user_56659','FALSE','Trích đoạn chứa đáp án:
Yet as a colony, they make wise decisions. And as Gordon discovered during her research, there’s no one ant making decisions or giving orders.

Giải thích đáp án:
Dịch thông tin trong bài:
Và như Gordon đã phát hiện ra trong quá trình nghiên cứu của cô ấy, không có một con kiến nào đưa ra quyết định hoặc ra lệnh. (...there’s no one ant making decisions or giving orders)
-> có thể suy luận: There’s no ant having leadership roles
Đối chiếu với câu hỏi:
Some ants within a colony have leadership roles - Một số loài kiến ​​trong một đàn có vai trò lãnh đạo.
-> trái với thông tin trong bài
-> FALSE',NULL,NULL,2,'Some ants within a colony have leadership roles.','TRUE_FALSE_NOT_GIVEN',118,NULL),
	 ('2026-06-07 17:42:32.456859','user_56659',false,'2026-06-07 17:42:32.456859','user_56659','NOT GIVEN',NULL,NULL,NULL,3,'Forager ants tell each other how far away the food source is.','TRUE_FALSE_NOT_GIVEN',118,NULL),
	 ('2026-06-07 17:42:55.829723','user_56659',false,'2026-06-07 17:42:55.829723','user_56659','TRUE','Trích đoạn chứa đáp án:
And if something goes wrong – a hungry lizard prowling around for an ant snack, for instance – then a rush of ants returning without food sends waiting reserves a ‘Don’t go out’ signal.
 
Giải thích đáp án:
Dịch thông tin trong bài:
Nếu có điều gì đó không ổn – chẳng hạn như một con thằn lằn đói đang rình mồi để kiếm đồ ăn vặt – thì một đợt kiến quay trở lại mà không có thức ăn sẽ gửi tín hiệu “Đừng đi ra ngoài”.
-> Nếu kiến ​​nhìn thấy thằn lằn đói, chúng sẽ lao về tổ mà không có thức ăn.
-> Kiến phản ứng rất nhanh khi thấy hungry lizard
Đối chiếu với câu hỏi:
Forager ants are able to react quickly to a dangerous situation. - Kiến kiếm ăn có khả năng phản ứng nhanh trước tình huống nguy hiểm
Tình huống nguy hiểm ở đây chính là khi chúng gặp hungry lizard
-> khớp với thông tin trong bài
-> TRUE',NULL,NULL,4,'Forager ants are able to react quickly to a dangerous situation.','TRUE_FALSE_NOT_GIVEN',118,NULL),
	 ('2026-06-07 17:43:13.723239','user_56659',false,'2026-06-07 17:43:13.723239','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
They simply sense changes in their environment, as for example when the mound’s wall has been damaged, altering the circulation of air.

Giải thích đáp án:
Dịch thông tin trong bài:
Chúng chỉ đơn giản là cảm nhận được những thay đổi trong môi trường, chẳng hạn như khi bức tường của gò đất bị hư hại, làm thay đổi sự lưu thông của không khí.
-> Bức tường của gò đất bị hư hại dẫn tới sự thay đổi lưu thông không khí
Đối chiếu với câu hỏi:
Termite mounds can be damaged by the wind - Những gò đất có thể bị phá hủy bởi gió
-> Trong hề chỉ nói hệ quả của việc mounds bị phá huỷ chứ không nói gì về nguyên nhân gây ra nó là do gió hay không.
-> NOT GIVEN',NULL,NULL,5,'Termite mounds can be damaged by the wind.','TRUE_FALSE_NOT_GIVEN',118,NULL),
	 ('2026-06-07 17:43:29.272569','user_56659',false,'2026-06-07 17:43:29.272569','user_56659','TRUE','Trích đoạn chứa đáp án:
Slowly, without any kind of direct decision making, a new wall is built.

Giải thích đáp án:
Dịch thông tin trong bài:
Một bức tường mới được xây dựng mà không có bất kỳ loại quyết định trực tiếp nào
-> có thể suy luận: Termites built a new wall without any kind of direct decision-making
Đối chiếu với câu hỏi:
Termites repair their mounds without directly communicating with each other - Mối sửa chữa các gò của chúng mà không cần giao tiếp trực tiếp với nhau.
-> khớp với thông tin trong bài
-> TRUE',NULL,NULL,6,'Termites repair their mounds without directly communicating with each other.','TRUE_FALSE_NOT_GIVEN',118,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:43:50.45428','user_56659',false,'2026-06-07 17:43:50.45428','user_56659','C','Trích đoạn chứa đáp án:
Miller visited a Texas gas company that has successfully applied formulas based on ant colony behaviour to ‘optimise its factories and route its trucks’.

Giải thích đáp án:
Dịch thông tin trong bài:
Miller đã đến một công ty khí đốt ở Texas mà đã áp dụng thành công công thức dựa trên hành vi của đàn kiến ​​để ‘tối ưu hóa các nhà máy và định tuyến xe tải của mình’.
Ta thấy:
applied formulas based on ant colony behavior ~ use decision-making strategies based on insect communities
‘optimise its factories and route its trucks’ ~ improve their service
-> đáp án C',NULL,NULL,7,'Managers working for a Texas gas company','FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:44:09.21204','user_56659',false,'2026-06-07 17:44:09.21204','user_56659','A','Trích đoạn chứa đáp án:
Citizens in Vermont control their municipal affairs by putting forward proposals, or backing up others’ suggestions, until a consensus is reached through a vote.

Keyword cần chú ý:
back up = provide support for

Giải thích đáp án:
Dịch thông tin trong bài:
Công dân ở Vermont kiểm soát các công việc của thành phố bằng cách đưa ra các đề xuất hoặc ủng hộ đề xuất của người khác, cho đến khi đạt được sự đồng thuận thông qua một cuộc bỏ phiếu.
-> Các công dân trong cuộc họp thường niên ở Vermont ủng hộ cho các ý tưởng của nhau để đạt được kết quả tốt nhất
-> đáp án A',NULL,NULL,8,'Citizens in an annual Vermont meeting','FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:44:26.121107','user_56659',false,'2026-06-07 17:44:26.121107','user_56659','E','Trích đoạn chứa đáp án:
Rather than meeting up and talking about what we want to post online, we just add to what someone maybe a stranger on the other side of the world already wrote.

Keyword cần chú ý:
others they do not know ~ a stranger
contribute = add

Giải thích đáp án:
Dịch thông tin trong bài:
Thay vì gặp gỡ và nói về những gì chúng ta muốn đăng trực tuyến, chúng ta chỉ thêm vào những gì ai đó đã viết, chẳng hạn đó có thể là một người lạ ở đất nước khác.
-> Mọi người có thể đóng góp ý tưởng trong bài đăng của 1 người lạ trên trực tuyến
-> đáp án E',NULL,NULL,9,'Some Internet users','FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:44:38.535293','user_56659',false,'2026-06-07 17:44:38.535293','user_56659','SCOUTS','Trích đoạn chứa đáp án:
The honeybees choose as a group which new nest to move to. First, scouts fly off to investigate multiple sites.

Keyword cần chú ý:
explore = investigate

Giải thích đáp án:
Xác định từ loại cần điền: danh từ
Vì chỗ trống cần điền đứng ngay trước động từ chính của câu ''explore''
-> từ cần điền có vai trò là chủ ngữ. Tuy nhiên, câu đã có một danh từ “Honeybee" đứng làm chủ ngữ
-> Có thể sẽ điền một danh từ nữa để tạo thành danh từ ghép
Thông tin trong bài:
First, scouts fly off to investigate multiple sites (~ explore possible nest sites)
-> đối tượng khám phá net sites là ''scouts''
-> từ cần điền ''scouts''',NULL,NULL,10,NULL,'FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:44:52.952616','user_56659',false,'2026-06-07 17:44:52.952616','user_56659','WAGGLE DANCE','Trích đoạn chứa đáp án:
When they return they do a ‘waggle dance’ for their spot, and other scouts will then fly off and investigate it.

Giải thích đáp án:
Xác định từ loại cần điền: danh từ riêng (Vì chỗ trống cần điền đứng sau cụm ''known as'' - có tên gọi là)
Thông tin trong bài:
When they return (~ on the return) they do a ‘waggle dance’ for their spot, and other scouts will then fly off and investigate it
-> They do a ‘waggle dance'' when they return
Đối chiếu với câu hỏi: They perform what is known as …. on their return
-> từ cần điền ''waggle dance''',NULL,NULL,11,NULL,'FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:26:06','user_05335',false,'2026-06-07 17:26:06','user_05335','EQUIPMENT [OR] (TEACHING) RESOURCES','Trích đoạn chứa đáp án:
The equal distribution of equipment was next, meaning that all teachers had their fair share of teaching resources to aid learning.

Keyword cần chú ý:
given the same equipment = equal distribution of equipment

Giải thích đáp án:
Bài đọc: The equal distribution of equipment was next, meaning that all teachers had their fair share of teaching resources to aid learning.
=> All teachers receive the same equipment.
Câu hỏi: All teachers were given the same ______ to use.
=> Đáp án: equipment','','',11,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:45:03.007281','user_56659',false,'2026-06-07 17:45:03.007281','user_56659','VOLUME','Trích đoạn chứa đáp án:
The more they liked their nest, the more vigorous and lengthy their waggle dance and the more bees will choose to visit it. Gradually the volume of bees builds up towards one site; it’s a system that ensures that support for the best site snowballs and the decision is made in the most democratic way.

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống cần điền nằm ngay trước động từ chính, lại được kết nối với “enthusiasm" bằng chữ “and")
Thông tin trong bài:
The more they liked their nest (~ enthusiasm), the more vigorous and lengthy their waggle dance and the more bees will choose to visit it. Gradually the volume of bees builds up towards one site (~ increase for one particular site). -
-> Loài ong càng thích tổ của mình thì waggle dance của chúng càng mạnh mẽ và kéo dài và càng có nhiều ong chọn đến thăm tổ. Dần dần số lượng đàn ong tăng dần về một địa điểm
Sự mạnh mẽ và độ dài của waggle dance cho thấy enthusiasm (sự hăng hái)
Đối chiếu với câu hỏi: Enthusiasm and …. increase for one particular site
-> từ cần điền ''volume''',NULL,NULL,12,NULL,'FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:45:14.000777','user_56659',false,'2026-06-07 17:45:14.000777','user_56659','DEMOCRATIC','Trích đoạn chứa đáp án:
Gradually the volume of bees builds up towards one site; it’s a system that ensures that support for the best site snowballs and the decision is made in the most democratic way.

Giải thích đáp án:
Xác định từ loại cần điền: tính từ (Vì chỗ trống cần điền đứng trước danh từ ''process'')
Thông tin trong bài:
Gradually the volume of bees builds up towards one site; it’s a system that ensures that support for the best site snowballs and the decision is made (~ a final choice is reached) in the most democratic way.
-> Số lượng ong đổ dồn về 1 tổ thể hiện chúng yêu thích vị trí đó -> quyết định chọn tổ của loài ong được thực hiện 1 cách dân chủ -democratic way
Đối chiếu với câu hỏi: A final choice is reached during a _____ process.
-> từ cần điền ''democratic''',NULL,NULL,13,NULL,'FILL_IN_THE_BLANK',118,NULL),
	 ('2026-06-07 17:46:30.73542','user_56659',false,'2026-06-07 17:46:30.73542','user_56659','VI','Keyword cần chú ý:
to change his course ~ a change of direction

Giải thích đáp án:
Ở dòng đầu của đoạn D, tác giả đã chỉ ra rằng:
''For two decades, Zhang’s AC business boomed. But a couple of events conspired to change his course'' - Trong hai thập kỷ, công việc kinh doanh AC của Zhang phát triển vượt bậc. Nhưng một vài sự kiện đã ngầm thay đổi hướng đi của anh ấy
-> Đáp án: vi. A change of direction',NULL,NULL,17,'Paragraph D','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:46:08.460357','user_56659',false,'2026-06-07 17:46:08.460357','user_56659','II','Giải thích đáp án:
Đoạn C mở đầu bằng việc nói tới những thành tựu mà Zhang có được là nhờ sự sáng tạo và quan điểm của ông về công nghệ.
Dòng 3-4 của đoạn chỉ ra rằng:
''The company started out as a maker of non-pressurized boilers. His senior vice president, Juliet Jiang, says, ''He made his fortune on boilers. He could have kept doing this business, but ... he saw the need for nonelectric air conditioning....Broad has units operating in more than 70 countries, in some of the largest buildings and airports on the planet.''
-> Ngoài các tòa nhà lắp ghép, Broad còn có các thành tựu kỹ thuật khác là “non-pressurized boilers” và “nonelectric air-conditioning”
Ta thấy:
''non-pressurized boilers'' & ''nonelectric air-conditioning'' ~ other engineering achievements
-> Đáp án: ii. Other engineering achievements',NULL,NULL,16,'Paragraph C','FILL_IN_THE_BLANK',119,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:45:53.171761','user_56659',false,'2026-06-07 17:45:53.171761','user_56659','VIII','Giải thích đáp án:
Ở đoạn B, tác giả miêu tả những công đoạn được tiến hành từ factory đến building sites như sau:
''...The floors and ceilings of the skyscrapers are built in sections, each measuring 15.6 by 3.9 meters with a depth of 45 centimeters. Pipes and ducts for electricity, water and waste are threaded through each floor module while it is still in the factory. The client''s choice of flooring is also preinstalled on top. Standardized truckloads carry two modules each to the site with the necessary columns, bolts and tools to connect them stacked on top of each other. Once they arrive at the location, each section is lifted by crane directly to the top of the building, which is assembled like toy Lego bricks...''
-> Qua 2 cụm trạng từ chỉ thời gian, địa điểm ''in the factory'' và ''nce they arrive at the location'' -> Đoạn văn miêu tả các công đoạn chuẩn bị trong nhà máy đến quá trình xây dựng ở công trường.
-> Đáp án: viii. From factory to building site',NULL,NULL,15,'Paragraph B','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:45:38.508356','user_56659',false,'2026-06-07 17:45:38.508356','user_56659','IV','Giải thích đáp án:
Tác giả miêu ra sự độc đáo của tòa nhà được xây bởi ''Broad'' trong đoạn A như sau: ''What it is selling is the world’s first standardized skyscraper...'' - Những gì họ đang bán là tòa nhà chọc trời được tiêu chuẩn hóa đầu tiên trên thế giới
Ta thấy:
the world’s first standardized skyscraper ~ ~ a building like no other
-> đáp án iv. A building like no other',NULL,NULL,14,'Paragraph A','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:48:38.03408','user_56659',false,'2026-06-07 17:48:38.03408','user_56659','POWER SHORTAGES','Keyword cần chú ý:
becoming a serious obstacle = holding back
growth = industrial progress

Giải thích đáp án:
Xác định từ loại cần điền: danh từ số nhiều (vì đứng ngay trước động từ chính ''were'')
Thông tin trong bài:
Power shortages were becoming a serious obstacle to growth - Tình trạng thiếu điện đang trở thành một trở ngại nghiêm trọng đối với tăng trưởng
Đối chiếu với câu hỏi:
In the late eighties, _______ were holding back industrial progress in China
-> đáp án ''power shortages''',NULL,NULL,25,'In the late eighties,…………………………….were holding back industrial progress in China.','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:50:27.901795','user_56659',false,'2026-06-07 17:50:27.901795','user_56659','NOT GIVEN','Giải thích đáp án:
Thông tin trong bài:
...people who do not talk very easily may be incorrectly understood as being less agreeable than those who have no difficulty keeping up a conversation - những người không nói chuyện rất dễ bị hiểu sai là khó gần hơn những người không gặp khó khăn trong việc bắt chuyện.
Đối chiếu với câu hỏi:
People who talk less often have clearer ideas than those who talk a lot. - Những người nói ít thường có ý tưởng rõ ràng hơn những người nói nhiều.
-> => Hai mặt so sánh trong bài đọc và câu hỏi chẳng liên quan gì nhau.
-> NOT GIVEN',NULL,NULL,31,'People who talk less often have clearer ideas than those who talk a lot.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 17:50:12.699159','user_56659',false,'2026-06-07 17:50:12.699159','user_56659','NOT GIVEN','Giải thích đáp án:
Trong bài đúng là có đề cập tới việc “test” idea về conversational flow sử dụng video observations nhưng lại không nói gì về tần suất làm việc này là “often" hay không=> Thông tin trong bài đọc không đủ để trả lời câu hỏi
-> NOT GIVEN',NULL,NULL,30,'Video observations have often been used to assess conversational flow.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 17:49:58.568835','user_56659',false,'2026-06-07 17:49:58.568835','user_56659','NO','Keyword cần chú ý:
A quick response ~ answer questions instantly

Giải thích đáp án:
Thông tin trong bài:
Research indicates that a speaker is judged to be more knowledgeable when they answer questions instantly - Nghiên cứu chỉ ra rằng một diễn giả được đánh giá là hiểu biết hơn khi họ trả lời các câu hỏi ngay lập tức
Đối chiếu với câu hỏi:
A quick response to a question is thought to show a lack of knowledge. - Việc trả lời nhanh một câu hỏi được cho là thể hiện sự thiếu hiểu biết.
-> trái với thông tin trong bài
-> NO',NULL,NULL,29,'A quick response to a question is thought to show a lack of knowledge.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 17:49:41.63043','user_56659',false,'2026-06-07 17:49:41.63043','user_56659','YES','Giải thích đáp án:
Thông tin trong bài:
For instance, people feel that when something is easily processed, it is more true or accurate. - mọi người cảm thấy rằng khi một cái gì đó được xử lý dễ dàng thì nó đúng hơn hoặc chính xác hơn.
Đối chiếu với câu hỏi:
People assess information according to how readily they can understand it - Mọi người đánh giá thông tin dựa trên mức độ mà họ có thể hiểu được
-> khớp với thông tin trong bài
-> YES',NULL,NULL,28,'People assess information according to how readily they can understand it.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 17:49:25.542736','user_56659',false,'2026-06-07 17:49:25.542736','user_56659','YES','Keyword cần chú ý:
conversation = talking
occupies much of our time = spend a large part of our daily life

Giải thích đáp án:
Thông tin trong bài:
We spend a large part of our daily life talking with other people - Chúng ta dành một phần lớn cuộc sống hàng ngày của mình để nói chuyện với người khác.
Đối chiếu với câu hỏi:
Conversation occupies much of our time - Việc trò chuyện chiếm nhiều thời gian của chúng ta
-> khớp với thông tin trong bài
-> YES',NULL,NULL,27,'Conversation occupies much of our time.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 18:21:58','user_05335',false,'2026-06-07 18:21:58','user_05335','TRUE','Trích đoạn chứa đáp án:
The camera now had to be encased in a big, clumsy, unmoveable soundproof box. In addition, actors struggled, having to direct their speech to awkwardly-hidden microphones in huge plants, telephones or even costumes.

Giải thích đáp án:
Bài đọc: Camera bị đóng hộp để thu âm và diễn viên gặp khó khăn vì phải hướng về micro khi diễn.
Câu hỏi: Có nhiều bất lợi đối với việc ghi âm giọng diễn viên trong giai đoạn 1930s.
-> TRUE','','',21,'There were some drawbacks to recording movie actors’ voices in the early 1930s.','TRUE_FALSE_NOT_GIVEN',137,NULL),
	 ('2026-06-07 18:21:02','user_05335',false,'2026-06-07 18:21:02','user_05335','V','Trích đoạn chứa đáp án:
Studio heads realized that they couldn’t make virtually the same film over and over again with the same cast of stars and still expect to keep turning a profit. They also had to create product differentiation.

Keyword cần chú ý:
distinguishing themselves from the rest of the market = create product differentiation

Giải thích đáp án:
Paragraph E nói về việc người đứng đầu các xưởng phim nhận ra họ phải tạo ra khác biệt.
-> v. Distinguishing themselves from the rest of the market','','',18,'Paragraph E','FILL_IN_THE_BLANK',137,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:23:12','user_05335',false,'2026-06-07 18:23:12','user_05335','MOVIE MOGULS','Trích đoạn chứa đáp án:
During the Golden Age, the studios were remarkably consistent and stable enterprises, due in large part to long-term management heads – the infamous ‘movie moguls’ who ruled their kingdoms with iron fists. At MGM, Warner Bros, and Columbia, the same men ran their studios for decades.

Giải thích đáp án:
Những người đứng đầu, có quyền lực ở các xưởng phim là quản lý lâu năm, cũng được gọi là "movie moguls".
-> Đáp án là "movie moguls"','','',25,'','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:20:04','user_05335',false,'2026-06-07 18:20:04','user_05335','II','Trích đoạn chứa đáp án:
The shift of the industry away from ‘silent’ films began during the late 1920s. [...] the financial investment this kind of filmmaking would require, from new camera equipment to new projection facilities, made the studios hesitant to invest at first.

Giải thích đáp án:
Paragraph _x0008_B nói về việc industry thay đổi từ "silent films" với:
1. the use of sound in film
2. full integration of sound into movies
-> ii. The movie industry adapts to innovation','','',15,'Paragraph B','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-07-17 17:31:40','truongdx18vtit',false,'2026-07-17 17:31:40','truongdx18vtit','NEGATIVE',NULL,'','',29,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-18 17:31:40','truongdx18vtit',false,'2026-07-18 17:31:40','truongdx18vtit','GUIDANCE',NULL,'','',30,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-19 17:31:40','truongdx18vtit',false,'2026-07-19 17:31:40','truongdx18vtit','EASTERN ATLANTIC',NULL,'','',31,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-20 17:31:40','truongdx18vtit',false,'2026-07-20 17:31:40','truongdx18vtit','POLITICAL',NULL,'','',32,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-21 17:31:40','truongdx18vtit',false,'2026-07-21 17:31:40','truongdx18vtit','IRELAND',NULL,'','',33,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-22 17:31:40','truongdx18vtit',false,'2026-07-22 17:31:40','truongdx18vtit','EIRE',NULL,'','',34,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-06-07 17:54:25.523386','user_56659',false,'2026-06-07 17:54:25.523386','user_56659','REJECTION','Keyword cần chú ý:
of elementary importance ~ a basic need

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau cụm từ ''a sense of'')
Thông tin trong bài:
Group membership is of elementary importance to our wellbeing and because humans are very sensitive to signals of exclusion, a silence is generally taken as a sign of rejection.
-> Tư cách thành viên nhóm có tầm quan trọng cơ bản đối với sức khỏe của chúng ta và bởi vì con người rất nhạy cảm với các tín hiệu ám chỉ sự loại trừ, và một sự im lặng thường được coi là dấu hiệu của sự từ chối.
Đối chiếu với câu hỏi:
Humans have a basic need to be part of a group, and they experience a sense of ________ If silences exclude them - Con người có nhu cầu cơ bản là trở thành một phần của nhóm và họ có cảm giác ________ nếu sự im lặng loại trừ họ
-> đáp án ''rejection''',NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:54:11.138851','user_56659',false,'2026-06-07 17:54:11.138851','user_56659','DISTRESS LEVELS','Keyword cần chú ý:
a sharp rise ~ increase
even short disruptions in conversational flow ~ even if silences are brief

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau tính từ sở hữu ''our'')
Thông tin trong bài:
We all know that silences can be pretty awkward, and research shows that even short disruptions in conversational flow can lead to a sharp rise in distress levels.
-> Chúng ta đều biết rằng sự im lặng có thể khá khó xử và nghiên cứu cho thấy rằng ngay cả những gián đoạn ngắn trong luồng trò chuyện cũng có thể dẫn đến mức độ căng thẳng tăng lên.
Đối chiếu với câu hỏi:
According to research, our _______ increase even if silences are brief - Theo nghiên cứu, _______ của chúng ta tăng ngay cả khi 1 khoảng lặng chỉ diễn ra ngắn ngủi
-> đáp án ''distress levels''',NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',120,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:53:58.141533','user_56659',false,'2026-06-07 17:53:58.141533','user_56659','BELONG','Keyword cần chú ý:
the need to ~ our desire to
one of the most basic ~ an important element

Giải thích đáp án:
Xác định từ loại cần điền: động từ (Vị trí chỗ trống nằm ngay sau giới từ ''to'')
Thông tin trong bài:
The need to belong has been identified as one of the most basic of human motivations and plays a role in many human behaviors. - Nhu cầu được chấp nhận thuộc về một nhóm đã được xác định là một trong những động cơ cơ bản nhất của con người và đóng một vai trò trong nhiều hành vi của con người.
Đối chiếu với câu hỏi:
Our desire to _______ is also an important element of conversation flow. - Mong muốn của chúng ta về _______ cũng là một yếu tố quan trọng của cuộc hội thoại.
-> đáp án ''belong''',NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:53:46.966372','user_56659',false,'2026-06-07 17:53:46.966372','user_56659','INTERRUPTIONS','Keyword cần chú ý:
simultaneous speech ~ people talk at the same time

Giải thích đáp án:
Xác định từ loại cần điền: danh từ số nhiều (Vị trí chỗ trống nằm ngay sau động từ ''are'')
Thông tin trong bài:
A lack of flow is characterized by interruptions, simultaneous speech or mutual silences.
-> Sự thiếu trôi chảy được thể hiện bởi sự gián đoạn, cả 2 bên cùng nói hoặc cùng im lặng
Đối chiếu với câu hỏi:
only tiny pauses take place when a conversation flows; when it doesn’t, there are ........and silences, or people talk at the same time - khi cuộc trò chuyện trôi chảy thì chỉ xuất hiện 1 vài khoảng dừng ngắn; ngược lại, khi cuộc nói chuyện không trôi chảy sẽ có ........ và sự im lặng, hoặc mọi người nói chuyện cùng một lúc.
-> đáp án ''interruptions''',NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:51:13.480517','user_56659',false,'2026-06-07 17:51:13.480517','user_56659','TURN-TAKING','Keyword cần chú ý:
adjust = alter
duration of their utterances ~ speed of speech
speech rate ~ extent of speech

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau động từ ''facilitate'')
Thông tin trong bài:
In conversations, interpersonal coordination is found when people adjust the duration of their utterances and their speech rate to one another so that they can enable turn-taking to occur - Trong các cuộc trò chuyện, sự phối hợp giữa các cá nhân được tìm thấy khi mọi người điều chỉnh đồ dài của lời nói và tốc độ nói của họ cho phù hợp với nhau để cả 2 có thể thay phiên nhau nói chuyện.
Đối chiếu với câu hỏi:
This co-ordination can be seen in conversations when speakers alter the speed and extent of their speech in order to facilitate _______ - Sự phối hợp này có thể được nhìn thấy trong các cuộc trò chuyện khi người nói thay đổi tốc độ và mức độ bài nói của họ để tạo điều kiện cho _______
-> đáp án ''turn-taking''',NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:51:00.35932','user_56659',false,'2026-06-07 17:51:00.35932','user_56659','(THEIR) BEHAVIO(U)R/ACTIVITIES','Keyword cần chú ý:
attempt to synchronize with ~ in an effort to be ‘in harmony’
desire = need

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau động từ ''co-ordinate'')
Thông tin trong bài:
One of the social needs addressed by conversational flow is the human need for ‘synchrony’ to be ‘in sync’ or in harmony with one another....Many studies have shown how people attempt to synchronize with their partners by coordinating their behavior.
-> People have a need to coordinate their behaviour to be in harmony with their partners
-> Con người luôn có nhu cầu điều phối hành vi của họ để đồng bộ hóa với đối tác của mình.
Đối chiếu với câu hỏi:
There is a human desire to co-ordinate _______ in an effort to be ‘in harmony’ - Con người có 1 mong muốn là điều phối _______ trong nỗ lực để được "hòa hợp"
-> đáp án ''behaviour''',NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:48:55.76464','user_56659',false,'2026-06-07 17:48:55.76464','user_56659','CLIMATE CONTROL','Keyword cần chú ý:
improve climate control ~ enjoy more reliable climate control
cost benefits ~ reduce overheads

Giải thích đáp án:
Xác định từ loại cần điền: danh từ(vì đứng ngay sau động từ ''improve'')
Thông tin trong bài:
Large airconditioning (AC) units fueled by natural gas could help companies ease their electricity load, reduce overheads, and enjoy more reliable climate control into the bargain. - Các thiết bị điều hòa không khí lớn (AC) chạy bằng khí đốt tự nhiên có thể giúp các công ty giảm tải điện, giảm chi phí đầu vào và có khả năng kiểm soát khí hậu đáng tin cậy hơn.
-> Ngoài việc giảm tải điện và giảm chi phí, thiết bị điều hòa AC còn cải thiện kiểm soát khí hậu
Đối chiếu với câu hỏi:
In addition to power and cost benefits, Broad''s AC units improve ______
-> đáp án ''climate control ''',NULL,NULL,26,'In addition to power and cost benefits, Broad’s AC units improve………………………………','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:48:20.363475','user_56659',false,'2026-06-07 17:48:20.363475','user_56659','(NON-PRESSURIZED) BOILERS [OR] (NON-PRESSURISED) BOILERS','Giải thích đáp án:
Xác định từ loại cần điền: danh từ hoặc động từ (vì đứng sau động từ to be)
Thông tin trong bài:
The company started out as a maker of nonpressurized boilers - Công ty khởi đầu là một nhà sản xuất nồi hơi không áp suất
-> sản phẩm đầu tay của công ty chính là nồi hơi không áp suất
Đối chiếu với câu hỏi:
The first products (that) Broad manufactured were ….
-> đáp án ''nonpressurized boilers''',NULL,NULL,24,'The first products Broad manufactured were…………………………..','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:48:03.294283','user_56659',false,'2026-06-07 17:48:03.294283','user_56659','STRUCTURAL REVOLUTION','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (cấu trúc: refer to Noun 1 as Noun 2 = gọi Noun 1 là Noun 2)
Thông tin trong bài:
Zhang replies, ‘It’s not a construction company. It’s a structural revolution.’ - Zhang trả lời, "Đó không phải là một công ty xây dựng. Đó là một cuộc cách mạng về cấu trúc. "
-> Zhang gọi công ty của mình như một cuộc cách mạng về cấu trúc
Đối chiếu với câu hỏi:
Zhang refers to his business as a ….
-> đáp án ''structural revolution''',NULL,NULL,23,'Zhang refers to his business as a……………………………','FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:47:47.607967','user_56659',false,'2026-06-07 17:47:47.607967','user_56659','CONCRETE','Keyword cần chú ý:
conventional buildings ~ traditional methods
contain less concrete ~ used less concrete

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống nằm sau động từ “contain")
Trong đoạn đề cập tới “Zhang had given up on traditional methods” và “the structure had to be different"
-> Zhang không dùng “traditional methods" mà dùng “different structure"
Thông tin trong bài:
To reduce the overall weight of the building, it used less concrete in the floors - Để giảm trọng lượng tổng thể của tòa nhà, phương pháp này đã sử dụng ít bê tông hơn ở các tầng;
-> phương pháp này khác với ''traditional method'' là sử dụng ít bê tông hơn
(less concrete)
Đối chiếu với câu hỏi:
section contains less .......than traditional methods - các tầng chứa ít.... hơn các phương pháp truyền thống
-> đáp án ''concrete''',NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:47:06.330951','user_56659',false,'2026-06-07 17:47:06.330951','user_56659','FACTORY','Keyword cần chú ý:
installed = are threaded

Giải thích đáp án:
Xác định từ loại cần điền: danh từ chỉ địa điểm
Thông tin trong bài:
Pipes and ducts for electricity, water and waste are threaded through each floor module while it is still in the factory. - Các đường ống dẫn điện, nước và chất thải được luồn qua mỗi mô-đun tầng khi nó vẫn còn trong nhà máy.
-> Pipe and ducts are threaded while in the factory
Đối chiếu với câu hỏi:
Pipes and ducts are installed while in….- Các đường ống và ống dẫn được lắp đặt khi ở….
-> đáp án ''factory''',NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',119,NULL),
	 ('2026-06-07 17:46:46.460276','user_56659',false,'2026-06-07 17:46:46.460276','user_56659','III','Giải thích đáp án:
Thông tin trong bài: (đoạn E)
''For Zhang, the environmental savings alone justify the effort… The building process is also less dangerous… ''
-> Đối với Zhang, việc tiết kiệm nguyên liệu cho môi trường thôi cũng đủ chứng minh cho những nỗ lực… Quá trình xây dựng cũng ít nguy hiểm hơn…
''According to Zhang, his buildings will help solve the many problems of the construction industry and what’s more, they will be quicker and cheaper to build''
-> Theo Zhang, các tòa nhà của anh ấy sẽ giúp giải quyết nhiều vấn đề của ngành xây dựng và hơn thế nữa, chúng sẽ được xây dựng nhanh hơn và rẻ hơn
-> Ta thấy tác giả đã đề cập tới những lợi ích về môi trường - Environmental benefits; lợi ích về an toàn - Safety benefits cũng như những lượi ích khác (solve problems of consruction industry, quicker, cheaper)
-> tất cả những điều kể trên chính là ''overall benefits''
-> đoạn E nói về những lợi ích của việc sử dụng phương pháp xây nhà của Broad
-> Đáp án: iii. Examining the overall benefits',NULL,NULL,18,'
Paragraph E','FILL_IN_THE_BLANK',119,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:54:56.922685','user_56659',false,'2026-06-07 17:54:56.922685','user_56659','CONTENT','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau ''the'')
Thông tin trong bài:
It appears that the subjective feeling of being out of sync informs people of possible disagreements, regardless of the content of the conversation. - Dường như cảm giác không đồng bộ chủ quan thông báo cho mọi người về những bất đồng có thể xảy ra, bất kể nội dung của cuộc trò chuyện là gì.
Đối chiếu với câu hỏi:
the _______ of the speakers’ discussion was less important than the perceived synchrony of the speakers.
-> đáp án ''content''',NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:54:44.05606','user_56659',false,'2026-06-07 17:54:44.056657','user_56659','AGREEMENT','Giải thích đáp án:
Xác định từ loại cần điền: danh từ (Vị trí chỗ trống nằm ngay sau tính từ ''overall'')
Thông tin trong bài:
This idea was tested by researchers using video observations. Participants imagined being one out of three people in a video clip who had either a fluent conversation or a conversation in which flow was disrupted by a brief silence. Except for the silence, the videos were identical. After watching the video, participants were asked to what extent the people in the video agreed with each other.
-> những người tham gia - participants được xem 2 đoạn video: 1 đoạn fluent, một đoạn hơi bị disrupted và sau đó participants đánh giá agreement giữa participants
Đối chiếu với câu hỏi:
In an experiment, participants’ judgement of the overall _______ among speakers was tested using videos of a fluent and a slightly disrupted conversation. - Trong một thử nghiệm, đánh giá của những người tham gia về ______ giữa những người nói trong video được kiểm tra bằng cách sử dụng các video về cuộc trò chuyện trôi chảy và hơi bị gián đoạn.
-> đáp án ''agreement''',NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',120,NULL),
	 ('2026-06-07 17:50:45.543219','user_56659',false,'2026-06-07 17:50:45.543219','user_56659','NO','Keyword cần chú ý:
online chat = online conversations

Giải thích đáp án:
Thông tin trong bài:
Because people are generally so well trained in having smooth conversations, any disruption of this flow indicates that something is wrong, either interpersonally or within the group as a whole.
-> Bởi vì mọi người thường chuẩn bị rất tốt để các cuộc trò chuyện được trôi chảy, bất kỳ sự gián đoạn nào của dòng chảy này đều cho thấy rằng có điều gì đó không ổn, giữa các cá nhân hoặc trong toàn bộ nhóm.
In a similar sense, the ever increasing number of online conversations may be disrupted by misinterpretations and anxiety that are produced by insuperable delays in the Internet connection
-> Cũng như vậy, số lượng những cuộc trò chuyện trực tuyến bị gián đoạn ngày càng tăng là do hiểu sai và sự lo lắng gây ra bởi sự chậm trễ khi kết nối Internet
-> qua cụm từ ''in a similar sense'' -> Cả disruption of smooth conversation và delay of online conversation đều có tác động tiêu cực
Đối chiếu với câu hỏi:
Delays in online chat fail to have the same negative effect as disruptions that occur in natural conversation. - Sự chậm trễ trong cuộc trò chuyện trực tuyến không có tác động tiêu cực giống như sự gián đoạn xảy ra trong cuộc trò chuyện tự nhiên.
-> trái với thông tin trong bài
-> NO',NULL,NULL,32,'Delays in online chat fail to have the same negative effect as disruptions that occur in natural conversation.','YES_NO_NOT_GIVEN',120,NULL),
	 ('2026-06-07 17:58:46.907064','user_56659',false,'2026-06-07 17:58:46.907064','user_56659','FALSE','Trích đoạn chứa đáp án:
On 17 January, Robert Scott and the men of the British Antarctic expedition had arrived at the pole to find they had been beaten to it. Just then, a third man arrived; Japanese explorer Nobu Shirase. However, his part in one of the greatest adventure stories of the 20th century is hardly known outside his own country, even by fellow explorers.

Keyword cần chú ý:
other explorers ~ fellow explorers

Giải thích đáp án:
Thông tin trong bài:
However, his part in one of the greatest adventure stories of the 20th century is hardly known outside his own country, even by fellow explorers
-> Hành trình của Shinrase đến south pole hầu như không được biết đến ngoài đất nước của anh ấy, và ngay cả những nhà thám hiểm đồng nghiệp khác cũng không biết đến
-> Shirase’s trip to the South Pole is hardly known outside his country, even by fellow explorers
Đối chiếu với câu hỏi:
Shirase’s trip to the South Pole is well-known to other explorers - Chuyến đi của Shirase đến Nam Cực đã được các nhà thám hiểm khác biết đến.
-> trái với thông tin trong bài
-> FALSE',NULL,NULL,1,'Shirase’s trip to the South Pole is well-known to other explorers.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 17:59:08.81575','user_56659',false,'2026-06-07 17:59:08.81575','user_56659','FALSE','Trích đoạn chứa đáp án:
Yet, as Scott was nearing the pole and with the rest of the world still unaware of Amundsen’s triumph, Shirase and his team sailed into Antarctica’s Bay of Whales in the smallest ship ever to try its luck in these dangerous waters

Giải thích đáp án:
Thông tin trong bài:
Shirase and his team sailed into Antarctica’s Bay of Whales in the smallest ship ever to try its luck in these dangerous waters
-> Shirase và nhóm của anh ấy đã đi thuyền vào Vịnh Cá voi ở Nam Cực trên con tàu nhỏ nhất từng có để thử vận ​​may ở những vùng nước nguy hiểm này
-> Shinrase''s ship was the smallest to sail into Antarctica’s Bay of Whales
Đối chiếu với câu hỏi:
Since Shirase arrived in Antarctica, ships smaller than his have also made the journey - Kể từ khi Shirase đến Nam Cực, những con tàu nhỏ hơn tàu của anh ấy cũng đã thực hiện cuộc hành trình.
-> trái với thông tin trong bài
-> FALSE',NULL,NULL,2,'Since Shirase arrived in Antarctica, smaller ships have also made the journey.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 17:59:28.608655','user_56659',false,'2026-06-07 17:59:28.609208','user_56659','TRUE','Trích đoạn chứa đáp án:
Since boyhood Shirase had dreamed of becoming a polar explorer. Like Amundsen, he initially set his sights on the North Pole

Keyword cần chú ý:
original ambition ~ initially set his sights on

Giải thích đáp án:
Thông tin trong bài:
Since boyhood Shirase had dreamed of becoming a polar explorer. Like Amundsen, he initially set his sights on the North Pole.
->Từ khi còn bé, Shirase đã mơ ước trở thành một nhà thám hiểm địa cực. Giống như Amundsen, ban đầu anh ấy đặt mục tiêu đến Bắc Cực.
-> Ban đầu Shinrase mong muốn đặt chân đến Bắc Cực
Đối chiếu với câu hỏi:
Shirase’s original ambition was to travel to the North Pole - Tham vọng ban đầu của Shirase là đến Bắc Cực.
-> khớp với thông tin trong bài
-> TRUE',NULL,NULL,3,'Shirase’s original ambition was to travel to the North Pole.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 17:59:46.898898','user_56659',false,'2026-06-07 17:59:46.898898','user_56659','TRUE','Trích đoạn chứa đáp án:
In January 1910, Shirase put his plans before Japanese government officials, promising to raise the flag at the South Pole within three years. For many of them, the question wasn’t could he do it but why would it be worth doing?

Keyword cần chú ý:
why would it be worth doing ~ pointless

Giải thích đáp án:
Thông tin trong bài:
In January 1910, Shirase put his plans before Japanese government officials, promising to raise the flag at the South Pole within three years. For many of them, the question wasn’t could he do it but why would it be worth doing?
-> Khi Shinrase trình bày kế hoạch của mình để tới South Pole với Japanese government officials thì có nhiều người trong số họ đặt ra câu hỏi rằng: việc đó có đáng để làm không
-> Japanese officials không hiểu mục đích đáng để Shirase đặt chân tới South Pole.
Đối chiếu với câu hỏi:
Some Japanese officials thought Shirase’s intention to travel to the South Pole was pointless - Một số quan chức Nhật Bản cho rằng ý định tới Nam Cực của Shirase là vô nghĩa.
-> Không hiểu mục đích việc travel to South Pole = xem việc travel to South Pole là vô nghĩa
-> TRUE',NULL,NULL,4,'Some Japanese officials thought Shirase’s intention to travel to the South Pole was pointless.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 17:59:59.346444','user_56659',false,'2026-06-07 17:59:59.346444','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
So, like the British, Shirase presented his expedition as a search for knowledge: he would bring back fossils, make meteorological measurements and explore unknown parts of the continent.

Giải thích đáp án:
Thông tin trong bài:
So, like the British, Shirase presented his expedition as a search for knowledge...
-> nói tới việc cả British và Shinrase có điểm chung là đi thám hiểm để seach for knowledge
Đối chiếu với câu hỏi:
The British team announced their decision to carry out scientific research in Antarctica before Shirase - Nhóm nghiên cứu Anh đã công bố quyết định thực hiện nghiên cứu khoa học ở Nam Cực trước Shirase.
-> trong bài không hề nói rằng ai là người làm điều này trước.
-> NOT GIVEN',NULL,NULL,5,'The British team announced their decision to carry out scientific research in Antarctica before Shirase.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 18:00:15.585725','user_56659',false,'2026-06-07 18:00:15.585725','user_56659','FALSE','Trích đoạn chứa đáp án:
The response from the government was cool, however, and Shirase struggled to raise funds.

Keyword cần chú ý:
raise the money = raise funds

Giải thích đáp án:
Thông tin trong bài:
The response from the government was cool, however, and Shirase struggled to raise funds.
-> Mặc dù nhận được phản hồi tốt từ phía chính phủ nhưng Shinrase phải vật lộn trong công cuộc gây quỹ cho chuyến đi của mình
Đối chiếu với câu hỏi:
Shirase found it easy to raise the money he needed for his trip to the South Pole - Shirase thấy dễ dàng để huy động số tiền cần thiết cho chuyến đi đến Nam Cực
-> trái với thông tin trong bài (found it easy >< struggled)
-> FALSE',NULL,NULL,6,'Shirase found it easy to raise the money he needed for his trip to the South Pole.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 18:00:31.42191','user_56659',false,'2026-06-07 18:00:31.42191','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
Fortunately, a few months later, Japan’s former prime minister Shigenobu Kuma came to Shirase’s rescue. With Kuma’s backing, Shirase got together just enough money to buy and equip a small ship. He eventually acquired a scientist, too, called Terutaro Takeda.

Giải thích đáp án:
Thông tin trong bài:
Japan’s former prime minister Shigenobu Kuma came to Shirase’s rescue. With Kuma’s backing, Shirase got together just enough money to buy and equip a small ship. He eventually acquired a scientist, too, called Terutaro Takeda.
-> đề cập tới việc thủ tưởng nhật bản hỗ trợ cho chuyến đi của Shinrase và có thêm 1 nhà khoa học đi cùng Shinrase trong chuyến thám hiểm
Đối chiếu với câu hỏi:
A previous prime minister of Japan persuaded a scientist to go with Shirase - Một thủ tướng trước đây của Nhật Bản đã thuyết phục một nhà khoa học đi cùng Shirase.
-> không đề cập tới việc ai là người persuade scientist này làm việc với Shirase
-> NOT GIVEN',NULL,NULL,7,'
A previous prime minister of Japan persuaded a scientist to go with Shirase.','TRUE_FALSE_NOT_GIVEN',121,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:00:46.174695','user_56659',false,'2026-06-07 18:00:46.174695','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
Bad weather delayed the expedition and they didn’t reach New Zealand until 8 February

Keyword cần chú ý:
slowed down = delay

Giải thích đáp án:
Thông tin trong bài:
Bad weather delayed the expedition and they didn’t reach New Zealand until 8 February
-> Bài đọc chỉ đề cập việc thời tiết xấu làm trì hoãn hành trình.
Đối chiếu với câu hỏi:
The weather that slowed down Shirase’s progress to New Zealand was unusually bad for the season - Thời tiết xấu bất thường trong mùa làm chậm hành trình của Shirase đến New Zealand
-> Thông tin thời tiết xấu bất thường không được tìm thấy trong bài
-> NOT GIVEN',NULL,NULL,8,'The weather that slowed down Shirase’s progress to New Zealand was unusually bad for the season.','TRUE_FALSE_NOT_GIVEN',121,NULL),
	 ('2026-06-07 18:01:20.620086','user_56659',false,'2026-06-07 18:01:20.620086','user_56659','A','Trích đoạn chứa đáp án:
In New Zealand local reporters were astonished: the ship was half the size of Amundsen’s ship. True, it was reinforced with iron plate and extra wood, but the ship had only the feeblest engine to help force its way through ice. Few doubted Shirase’s courage, but most reckoned the expedition to be ill- prepared as the Japanese had only lightweight sledges for transport across the ice, made of bamboo and wood.

Giải thích đáp án:
Câu hỏi: Khi các phóng viên ở New Zealand gặp Shirase, họ đã...
Thông tin trong bài:
In New Zealand local reporters were astonished: the ship was half the size of Amundsen’s ship. True, it was reinforced with iron plate and extra wood, but the ship had only the feeblest engine to help force its way through ice. Few doubted Shirase’s courage, but most reckoned the expedition to be ill- prepared
-> Điều khiến cho những phóng viên ở New Zealand ngạc nhiên đó là con tàu chỉ ''half the size of Amundsen’s ship'' (nhỏ bằng 1 nửa tàu của Amundsen) và ''had only the feeblest engine'' (sử dụng loại động cơ yếu nhất) -> điều này khiến cho phần lớn phóng viên cho rằng cuộc thám hiểm không được chuẩn bị kỹ lưỡng (ill-prepared)
-> suy luận rằng những phóng viên quan ngại về chất lượng của những dụng cụ trên tàu Shinrase
-> đáp án A',NULL,'["A. concerned about the quality of his equipment.","B. impressed with the design of his ship.","C. certain he was unaware of the dangers ahead.","D. surprised by the bravery he demonstrated."]',9,'When reporters in New Zealand met Shirase, they were','MULTIPLE_CHOICE',121,NULL),
	 ('2026-06-07 18:01:50.153379','user_56659',false,'2026-06-07 18:01:50.153379','user_56659','B','Trích đoạn chứa đáp án:
The ice began to close in, threatening to trap them for the winter, an experience no one was likely to survive. With a remarkable piece of seamanship, the captain steered the ship out of the ice and turned north.

Giải thích đáp án:
Câu hỏi: Trong đoạn 5, chúng ta được cho biết thông tin gì về thuyền trưởng của Kainan Maru?
Thông tin trong bài:
The ice began to close in, threatening to trap them for the winter, an experience no one was likely to survive. With a remarkable piece of seamanship, the captain steered the ship out of the ice and turned north.
-> Băng bắt đầu đóng lại khiến cho con tàu Kainan Maru bị kẹt lại trong mùa đông, một trải nghiệm không ai có thể sống sót vượt qua. Tuy nhiên, với kỹ năng lái thuyền điêu luyện, người thuyền trưởng đã lái con tàu ra khỏi lớp băng và quay về phía bắc.
-> đoạn trích nhấn mạnh về kỹ năng lái tàu của người thuyền trưởng giúp cứu sống thủy thủ đoạn và con tàu
-> đáp án B.',NULL,'["A. He had given Shirase some poor advice.","B. His skill at sailing saved the boat and crew.","C. He refused to listen to the warnings of others.","D. He was originally confident they could reach Antarctica."]',10,'What are we told about the captain of the Kainan Maru in the fifth paragraph?','MULTIPLE_CHOICE',121,NULL),
	 ('2026-06-07 18:02:23.264754','user_56659',false,'2026-06-07 18:02:23.264754','user_56659','C','Trích đoạn chứa đáp án:
A year later than planned, Shirase and six men finally reached Antarctica.
...
Yet Shirase still felt the pull of the pole and eventually decided he would head southward to experience the thrills and hardships of polar exploration he had always dreamed of.
...
On 26 January, Shirase estimated there were enough provisions to continue for two more days. Two days later, he announced it was time to turn back.

Giải thích đáp án:
Câu hỏi: Sau khi Shirase đến Nam Cực, anh ấy nhận ra rằng
Thông tin trong bài:
Catching up with Scott or Amundsen was out of the question… With provisions for 20 days, he and four men would see how far they could get.
-> Bắt kịp Scott và Amundsen (đến cực Nam) là không thể và với lương thực cung cấp trong 20 ngày, ông ấy chỉ muốn thử xem mình có thể đi được xa đến đâu
-> Sỉnase nghĩ rằng ông ấy không thể có đủ lương thực để đến cực Nam.
-> đáp án C',NULL,'["A. he was unsure of the direction he should follow.","B. he would have to give up on fulfilling his personal ambition.","C. he might not have enough food to get to the South Pole.","D. he still wanted to compete in the race against the other teams."]',11,'After Shirase finally reached Antarctica he realised that','MULTIPLE_CHOICE',121,NULL),
	 ('2026-06-07 18:02:55.832747','user_56659',false,'2026-06-07 18:02:55.832747','user_56659','C','Trích đoạn chứa đáp án:
For a week they struggled through one blizzard after another, holing up in their tents during the worst of the weather. The temperature fell to -25°C, and frostbite claimed some of the dogs.

Giải thích đáp án:
Câu hỏi: Tác giả muốn cho người đọc biết điều gì ở?
Thông tin trong bài:
For a week they struggled through one blizzard after another, holing up in their tents during the worst of the weather. The temperature fell to -25°C, and frostbite claimed some of the dogs.
-> Trong một tuần, họ phải vật lộn với hết trận bão tuyết này đến trận bão tuyết khác, chui rúc trong lều của mình trong thời tiết xấu nhất. Nhiệt độ giảm xuống -25 ° C, và một số con chó bị tê cóng.
-> đoạn trích miêu tả cụ thể về tình hình thời tiết của chuyến thám hiểm (blizzard - bão tuyết, frostbite,....)
-> đáp án C',NULL,'["A. criticising a decision concerning scientific research.","B. explaining why a particular mistake had occurred.","C. describing the conditions that the expedition faced.","D. rejecting the idea that Shirase was poorly prepared."]',12,'What is the writer doing in the seventh paragraph?','MULTIPLE_CHOICE',121,NULL),
	 ('2026-06-07 18:03:28.317883','user_56659',false,'2026-06-07 18:03:28.317883','user_56659','A','Trích đoạn chứa đáp án:
On 3 February, all the men were heading home. The ship reached Tokyo in June 1912 – and Shirase was greeted like a hero despite the fact that he never reached the pole. Nor did he contribute much to science – but then nor did Amundsen, whose only interest was in being first to the pole. Yet Shirase’s expedition was heroic. They travelled beyond 80° south, one of only four teams to have gone so far south at the time. Furthermore, they did it all without the advantages of the other teams and with no previous experience.

Giải thích đáp án:
Câu hỏi: Luận điểm người viết đưa ra trong đoạn cuối cùng là gì
Thông tin trong bài:
Yet Shirase’s expedition was heroic. They travelled beyond 80° south, one of only four teams to have gone so far south at the time. Furthermore, they did it all without the advantages of the other teams and with no previous experience.
-> Cuộc thám hiểm của Shirase rất anh dũng. Họ đã đi xa hơn 80° về phía nam, là một trong bốn đội duy nhất đã đi xa về phía nam vào thời điểm đó. Hơn nữa, họ đã làm tất cả mà không có lợi thế của các đội khác và không có kinh nghiệm trước đó.
Ta thấy:
Shirase’s expedition was heroic ~ his achievement was incredible
without the advantages of the other teams and with no previous experience ~ problems Shirase had to deal with (khi không có lợi thế và kinh nghiệ trước đó -> phải đối mặt với nhiều vấn đề trong chuyến đi)
-> đáp án A',NULL,'["A. Considering the problems Shirase had to deal with, his achievement was incredible.","B. In Japan, the reaction to Shirase’s adventure in Antarctica came as a surprise to him.","C. It was obvious that Amundsen would receive more attention as an explorer than Shirase.","D. Shirase had achieved more on the Antarctic expedition than even he had expected."]',13,'What is the writer’s main point in the final paragraph?
','MULTIPLE_CHOICE',121,NULL),
	 ('2026-06-07 18:04:26.32083','user_56659',false,'2026-06-07 18:04:26.32083','user_56659','NO','Trích đoạn chứa đáp án:
On the new model farms of the future, precision will be key. Why dose a whole field with chemicals if you can spray only where they are needed? Each plant could get exactly the right amount of everything, no more or less, an approach that could slash chemical use and improve yields in one move.

Giải thích đáp án:
Thông tin trong bài:
Each plant could get exactly the right amount of everything, no more or less, an approach that could slash chemical use and improve yields in one move.
-> Mỗi loại cây có thể nhận được đúng lượng thuốc cần thiết -> cách tiếp cận này có thể cắt giảm việc sử dụng hóa chất và cải thiện năng suất cùng lúc
Đối chiếu với câu hỏi:
In the future, farmers are likely to increase their dependency on chemicals - Trong tương lai, người nông dân có thể sẽ ngày càng phụ thuộc vào hóa chất.
-> trái với thông tin trong bài (Trong bài nói dùng vừa đủ, trong câu hỏi nói dùng nhiều hơn)
-> NO',NULL,NULL,16,'In the future, farmers are likely to increase their dependency on chemicals.','YES_NO_NOT_GIVEN',122,NULL),
	 ('2026-06-07 18:04:10.998111','user_56659',false,'2026-06-07 18:04:10.998111','user_56659','YES','Trích đoạn chứa đáp án:
Yet while farmers must squeeze more out of the land, they must also address the necessity of reducing their impact on the soil, waterways and atmosphere.

Keyword cần chú ý:
reduce the harm = reduce their impactenvironment ~ the soil, waterways and atmosphere

Giải thích đáp án:
Thông tin trong bài:
Yet while farmers must squeeze more out of the land, they must also address the necessity of reducing their impact on the soil, waterways and atmosphere.
-> trong khi nông dân phải ngày càng vắt kiệt nguồn tài nguyên đất, thì họ cũng phải chú trọng tới việc giảm tác động của mình lên đất, đường nước và bầu khí quyển.
-> farmers need to reduce their impact on the soil, waterways and atmosphere
Đối chiếu với câu hỏi:
Farmers need to reduce the harm they do to the environment - Người nông dân cần giảm tác hại của họ đối với môi trường
-> khớp với thông tin trong bài
-> YES',NULL,NULL,15,'Farmers need to reduce the harm they do to the environment.','YES_NO_NOT_GIVEN',122,NULL),
	 ('2026-06-07 18:03:52.544645','user_56659',false,'2026-06-07 18:03:52.544645','user_56659','NOT GIVEN','Giải thích đáp án:
Không có thông tin nào nêu “chính phủ nên nỗ lực hơn trong việc đảm bảo mọi người đều có khả năng mua thực phẩm”.
-> NOT GIVEN',NULL,NULL,14,'Governments should do more to ensure that food is generally affordable.','YES_NO_NOT_GIVEN',122,NULL),
	 ('2026-06-07 18:10:49.209664','user_56659',false,'2026-06-07 18:10:49.209664','user_56659','C/D','Trích đoạn chứa đáp án:
However, even as they were celebrated as the models to which all literature should aspire, Homer’s masterworks had also long been the source of scholarly unease.

Giải thích đáp án:
Thông tin trong bài:
However, even as they were celebrated as the models to which all literature should aspire, Homer’s masterworks had also long been the source of scholarly unease - ngay cả khi chúng được tôn vinh như những hình mẫu mà tất cả nền văn học phải khao khát, các tác phẩm của Homer cũng từ lâu đã trở thành nguồn gốc của sự bất ổn trong học thuật.
-> chú ý chi tiết ''the models to which all literature should aspire'' ~ ideal examples of writing
-> đáp án D',NULL,NULL,34,NULL,'FILL_IN_THE_BLANK',123,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-07-23 17:31:40','truongdx18vtit',false,'2026-07-23 17:31:40','truongdx18vtit','ENGLAND',NULL,'','',35,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-24 17:31:40','truongdx18vtit',false,'2026-07-24 17:31:40','truongdx18vtit','MAN',NULL,'','',36,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-25 17:31:40','truongdx18vtit',false,'2026-07-25 17:31:40','truongdx18vtit','CONFUSION',NULL,'','',37,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-26 17:31:40','truongdx18vtit',false,'2026-07-26 17:31:40','truongdx18vtit','COUNTY',NULL,'','',38,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-27 17:31:40','truongdx18vtit',false,'2026-07-27 17:31:40','truongdx18vtit','ENGLISH',NULL,'','',39,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-28 17:31:40','truongdx18vtit',false,'2026-07-28 17:31:40','truongdx18vtit','COLONIAL',NULL,'','',40,'','FILL_IN_THE_BLANK',154,''),
	 ('2026-07-29 17:31:40','truongdx18vtit',false,'2026-07-29 17:31:40','truongdx18vtit','238',NULL,'','',1,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-07-30 17:31:40','truongdx18vtit',false,'2026-07-30 17:31:40','truongdx18vtit','3331',NULL,'','',2,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-07-31 17:31:40','truongdx18vtit',false,'2026-07-31 17:31:40','truongdx18vtit','DELUXE',NULL,'','',3,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-06-07 18:05:57.282076','user_56659',false,'2026-06-07 18:05:57.282076','user_56659','COMMUNICATION','Trích đoạn chứa đáp án:
You probably haven’t even noticed, for these robots are disguised as tractors. Many are self-steering, use GPS to cross a field, and can even ‘talk’ to their implements – a plough or sprayer, for example. And the implements can talk back, telling the tractor that it’s going too fast or needs to move to the left. This kind of communication is also being developed in other farm vehicles

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì đứng trước ''between'')
Thông tin trong bài:
Many are self-steering, use GPS to cross a field, and can even ‘talk’ to their implements – a plough or sprayer, for example. And the implements can talk back, telling the tractor that it’s going too fast or needs to move to the left. This kind of communication is also being developed in other farm vehicles
-> Nhiều trong số máy móc là tự lái, sử dụng GPS để băng qua cánh đồng và thậm chí có thể ‘nói chuyện’ với dụng cụ của mình – chẳng hạn như máy cày hoặc máy phun. Và những dụng cụ này có thể nói chuyện ngược lại, nói với máy kéo rằng nó đang chạy quá nhanh hoặc cần phải di chuyển sang trái. Loại giao tiếp này cũng đang được phát triển trên các loại xe nông trại khác.
-> Có sự giao tiếp giữa các loại máy kéo và các dụng cụ nông nghiệp
-> There is communication between tractors and implements
Đối chiếu với câu hỏi:
___________ between machines such as tractors is making farming more efficient.
-> đáp án ''communication''',NULL,NULL,21,'……………………………….between machines such as tractors is making farming more efficient.','FILL_IN_THE_BLANK',122,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:05:41.299094','user_56659',false,'2026-06-07 18:05:41.299094','user_56659','CEREALS','Trích đoạn chứa đáp án:
More than a century of mechanization has already turned farming into an industrial-scale activity in much of the world, with farms that grow cereals being the most heavily automated.

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì đứng sau cụm ''the production of'' -> cấu trúc ''the noun of noun'')
Thông tin trong bài:
More than a century of mechanization has already turned farming into an industrial-scale activity in much of the world, with farms that grow cereals being the most heavily automated.
-> Hơn một thế kỷ cơ giới hóa đã biến nông nghiệp thành một hoạt động quy mô công nghiệp ở hầu hết khắp nơi trên thế giới, với các trang trại trồng ngũ cốc được tự động hóa nhiều nhất.
-> Các trang trại trồng ngũ cốc áp dụng tự động hóa nhiều nhất tức là các trang trại này sử dụng nhiều máy móc tự động nhất
-> Farms that grow cereals use the most machines.
Đối chiếu với câu hỏi:
It is the production of ________ which currently uses most machinery on farms.
-> đáp án ''cereals''',NULL,NULL,20,'It is the production of………………………………which currently uses most machinery on farms.','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:05:22.801552','user_56659',false,'2026-06-07 18:05:22.801552','user_56659','LASERS','Trích đoạn chứa đáp án:
Other machines would distinguish problem weeds from crops and eliminate them with shots from high-power lasers or a microdot of pesticide.

Keyword cần chú ý:
get rid of = eliminate
chemicals ~ pesticide

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì đứng sau từ nồi ''or'' -> cần cùng loại với từ trước ''or'' là ''chemicals'')
Thông tin trong bài:
Other machines would distinguish problem weeds from crops and eliminate them with shots from high-power lasers or a microdot of pesticide
-> Các máy khác sẽ phân biệt cỏ dại có vấn đề với cây trồng và loại bỏ chúng bằng cách bắn tia laser công suất cao hoặc sử dụng một microdot thuốc trừ sâu
-> Thuốc trừ sâu hoặc tia laser sẽ được sử dụng để loại trừ cỏ dại có hại cho cây trồng
-> Other machines use pesticide or lasers to eliminate problem weeds
Đối chiếu với câu hỏi:
Some machines will use chemicals or ________ to get rid of unwanted plants..
-> đáp án ''lasers''',NULL,NULL,19,'Some machines will use chemicals or……………………………..to get rid of unwanted plants.','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:04:59.574383','user_56659',false,'2026-06-07 18:04:59.574383','user_56659','FERTILISER/FERTILIZER','Trích đoạn chứa đáp án:
One day, we might see fields with ‘agribots’ (agricultural robots) that can identify individual seedlings and encourage them along with drops of fertilizer.

Keyword cần chú ý:
young plants = seedlings
provide fertilizer = encourage them along with drops of fertilizer

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì đứng sau động từ ''provide'')
Thông tin trong bài:
One day, we might see fields with ‘agribots’ (agricultural robots) that can identify individual seedlings and encourage them along with drops of fertilizer.
-> Một ngày nào đó, chúng ta có thể thấy những cánh đồng với ‘agribots’ (robot nông nghiệp) có thể xác định từng cây con và khuyến khích chúng phát triển mà chỉ cần tới1 lượng nhở phân bón.
-> Agribots dùng fertilizer (phân bón) để giúp cây con phát triển.
-> Agribots use fertilizer to encourage seedlings to grow
Đối chiếu với câu hỏi:
In the future, agribots will provide _______ to young plants.
-> đáp án ''fertilizer''',NULL,NULL,18,'In the future, agribots will provide………………………….to young plants.','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-08-01 17:31:40','truongdx18vtit',false,'2026-08-01 17:31:40','truongdx18vtit','2 PILLOWS',NULL,'','',4,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-08-02 17:31:40','truongdx18vtit',false,'2026-08-02 17:31:40','truongdx18vtit','THREE NIGHTS',NULL,'','',5,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-08-03 17:31:40','truongdx18vtit',false,'2026-08-03 17:31:40','truongdx18vtit','CAF�',NULL,'','',6,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-06-07 18:07:11.674423','user_56659',false,'2026-06-07 18:07:11.674423','user_56659','A','Trích đoạn chứa đáp án:
Lewis Holloway, who studies agriculture at the University of Hull, UK, says that robotic milking is likely to influence the genetics of dairy herds as farmers opt for ‘robot-friendly’ cows, with udder shape, and even attitudes, suited to automated milking. Similarly, he says, it’s conceivable that agribots could influence what fruit or vegetable varieties get to the shops, since farmers may prefer to grow those with, say, leaf shapes that are easier for their robots to discriminate from weeds.

Keyword cần chú ý:
robotic milking ~ use of automation
influence the genetics of dairy herds ~ impact on the development of particular animal
agribots ~ use of automation
influence what fruit or vegetable varieties get to the shops ~ impact on the development of particular plant

Giải thích đáp án:
Thông tin trong bài:
Lewis Holloway, who studies agriculture at the University of Hull, UK, says that robotic milking is likely to influence the genetics of dairy herds as farmers opt for ‘ robot-friendly ‘ cows, with udder shape, and even attitudes, suited to automated milking. Similarly, he says, it’s conceivable that agribots could influence what fruit or vegetable varieties get to the shops, since farmers may prefer to grow those with, say, leaf shapes that are easier for their robots to discriminate from weeds.
-> Theo Lewis Holloway: vắt sữa bằng robot có khả năng ảnh hưởng đến di truyền của đàn bò sữa và agribots có thể ảnh hưởng đến những loại rau quả hoặc trái cây đến cửa hàng
-> Lewis Holloway believes robots can influence the genetics of animals and fruit or vegetables.
-> đáp án A. The use of automation might impact on the development of particular animal and plant species.',NULL,NULL,25,'Lewis Holloway','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:06:56.718895','user_56659',false,'2026-06-07 18:06:56.718895','user_56659','H','Trích đoạn chứa đáp án:
Calvin and Martin have observed how rising employment costs have led to the adoption of labour-saving farm technology in the past, citing the raisin industry as an example

Keyword cần chú ý:
economic factors ~ rising employent costs
the development of machinery ~ the adoption of labour-saving farm technology

Giải thích đáp án:
Thông tin trong bài:
Calvin and Martin have observed how rising employment costs have led to the adoption of labour-saving farm technology in the past, citing the raisin industry as an example
-> Calvin và Martin đã quan sát xem chi phí nhân công tăng cao đã dẫn đến việc áp dụng công nghệ trang trại tiết kiệm lao động như thế nào trong quá khứ
-> Chi phí việc làm tăng cao dẫn đến việc áp dụng công nghệ trang trại tiết kiệm lao động
-> Rising employment costs led to labour-saving farm technology
-> đáp án H. Economic factors are often the driving force behind the development of machinery.',NULL,NULL,24,'
Linda Calvin and Philip Martin','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:07:47.274404','user_56659',false,'2026-06-07 18:07:47.274404','user_56659','E','Trích đoạn chứa đáp án:
They were, rather, a loose collection of songs transmitted by generations of Greek bards*, and only redacted* in their present form at some later date.

Giải thích đáp án:
Thông tin trong bài:
They (Odyssey and Iliad) were a loose collection of songs, and only redacted in their present form at some later date - Chúng là một bộ sưu tập rời rạc các bài hát được các thế hệ thi sĩ Hy Lạp truyền lại, và chỉ được biên soạn lại ở dạng hiện tại vào một thời gian sau đó.
-> “Present form" (hình thức hiện tại) của tác phẩm này là poems
-> Câu được hiểu là: Odyssey and Iliad là bài hát, sau này (at some later date) chuyển thành poems
Đối chiếu với câu hỏi:
the claim that the Odyssey and Iliad were not poems in their original form.- Hình thức gốc của Odyssey and Iliad không phải là poems
-> Chính xác, vì đoạn E nói rõ rằng tác phẩm này ban đầu là songs
-> Đáp án: E',NULL,NULL,27,'
the claim that the Odyssey and Iliad were not poems in their original form.','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 17:26:27','user_05335',false,'2026-06-07 17:26:27','user_05335','MASTER''S DEGREE [OR] MASTERS DEGREE','Trích đoạn chứa đáp án:
The second critical decision came in 1979, when it was required that every teacher gain a fifth-year Master’s degree, in theory and practice, paid for by the state.

Keyword cần chú ý:
get a Master''s degree = gain a fifth-year Master’s degree
they did not have to pay for this = paid for by the state

Giải thích đáp án:
Bài đọc: The second critical decision came in 1979, when it was required that every teacher gain a fifth-year Master’s degree paid for by the state .
=> Every teacher gained a Master''s degree. The master’s degree was paid for by the state.
Câu hỏi: Teachers had to get a _______ but they did not have to pay for this.
=> Đáp án: Master''s Degree','','',12,'','FILL_IN_THE_BLANK',130,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:26:46','user_05335',false,'2026-06-07 17:26:46','user_05335','RESPECT/STATUS','Trích đoạn chứa đáp án:
Applicants began flooding teaching programs, not because the salaries were so high but because autonomous decision-making and respect made the job desirable.
 
Keyword cần chú ý:
respect/ status = respect
 
Giải thích đáp án:
Câu hỏi: Applicants were attracted to the ______ that teaching received.
=> Đáp án: Vì chỉ được điền <= 2 từ nên chắc chắn không thể điền được cụm “autonomous decision making" => Chỉ có thể điền “respect"
Ngoài ra, thí sinh nào điền “status" cũng được chấp nhận vì hai từ này mang nghĩa như nhau trong bài đọc. Từ status cũng được sử dụng trong bài nên về nguyên tắc là có thể dùng để điền vào chỗ trống.
=> Đáp án: respect/ status','','',13,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 18:26:04','user_05335',false,'2026-06-07 18:26:04','user_05335','LIGHT','Trích đoạn chứa đáp án:
Rogers found that a chicks lateralization depends on whether it is exposed to light before hatching from its egg – if it is kept in the dark during this period, neither hemisphere becomes dominant.

Keyword cần chú ý:
given = exposed to

Giải thích đáp án:
Rogers phát hiện lateralization ở gà con phụ thuộc vào việc nó đã tiếp xúc với "light" trước khi nở hay chưa.
-> Đáp án là "light"','','',32,'','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:09:58.881485','user_56659',false,'2026-06-07 18:09:58.881485','user_56659','B','Trích đoạn chứa đáp án:
Odysseus was always ’clever Odysseus’. Dawn was always ‘rosy-fingered’. Why would someone write that? Sometimes the epithets seemed completely off-key. Why call the murderer of Agamemnon ‘blameless Aegisthos’? Why refer to ‘swift-footed Achilles’ even when he was sitting down? Or to ‘laughing Aphrodite’ even when she was in tears

Giải thích đáp án:
Thông tin trong bài:
Why call the murderer of Agamemnon ‘blameless Aegisthos’? Why refer to ‘swift-footed Achilles’ even when he was sitting down? Or to ‘laughing Aphrodite’ even when she was in tears
-> Tại sao lại gọi kẻ sát hại Agamemnon là ‘Aegisthos vô tội vạ’? Tại sao lại đề cập đến ‘Achilles chân nhanh thoăn thoắt’ ngay cả khi anh ấy đang ngồi? Hay ‘Aphrodite toe toét’ ngay cả khi cô ấy đang khóc?
-> đoạn này cho thấy những thắc mắc của tác giả về sự miêu tả bất hợp lý các nhân vật trong tác phẩm (hành động và tên gọi trái ngược nhau)
Câu hỏi:
doubts regarding Homer’s apparently inappropriate descriptions - nghi ngờ về các mô tả có vẻ không phù hợp của Homer
-> Chọn B.',NULL,NULL,32,'doubts regarding Homer’s apparently inappropriate descriptions','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:09:08.807197','user_56659',false,'2026-06-07 18:09:08.807197','user_56659','A','Trích đoạn chứa đáp án:
In India, an entire class of priests was charged with memorizing the Vedas with perfect fidelity. In pre-lslamic Arabia, people known as Rawis were often attached to poets as official memorizers.

Keyword cần chú ý:
recall = memorize

Giải thích đáp án:
Thông tin trong bài:
In India, an entire class of priests was charged with memorizing the Vedas with perfect fidelity. In pre-lslamic Arabia, people known as Rawis were often attached to poets as official memorizers.
-> Ở Ấn Độ, cả một lớp linh mục được giao trách nhiệm học thuộc các kinh Veda với lòng trung thành tuyệt đối. Ở Ả Rập tiền Hồi giáo, những người được gọi là Rawis thường được gắn với các nhà thơ như những người ghi nhớ chính thức.
-> tóm gọn lại: priests was responsible for memorizing the Vedas. Rawis were official memorizers
Câu hỏi:
examples of the kinds of people employed to recall language (examples chính là priests và Rawis trong đoạn bên trên)

-> Đáp án: A',NULL,NULL,31,'examples of the kinds of people employed to recall language','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:08:29.94746','user_56659',false,'2026-06-07 18:08:29.94746','user_56659','E','Trích đoạn chứa đáp án:
He suggested that the reason Homer’s epics seemed unlike other literature was because they were unlike other literature.
.....
All those stylistic quirks, including the formulaic and recurring plot elements and the bizarrely repetitive epithets – ‘clever Odysseus’ and ‘gray-eyed Athena’ – that had always perplexed readers were actually like thumbprints left by a potter: material evidence of how the poems had been crafted

Giải thích đáp án:
Thông tin trong bài:
''the reason Homer’s epics seemed unlike other literature was because they were unlike other literature''
-> So sánh giữa tác phẩm của Homer và những tác phẩm khác
All those stylistic quirks.....were actually like thumbprints left by a potter: material evidence of how the poems had been crafted.
-> Phân tích điểm đặc biệt về cách mà Homer''s poems được tạo ra (crafted)
-> Tóm lại: Homer''s poems are different from other literature in the way they had been crafted
So với câu hỏi:
a comparison between the construction of Homer’s poems and another art form
-> Đáp án: E',NULL,NULL,30,'a comparison between the construction of Homer’s poems and another art form','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:08:14.303831','user_56659',false,'2026-06-07 18:08:14.303831','user_56659','C','Trích đoạn chứa đáp án:
There were no historical records of Homer, and no trustworthy biography of the man exists beyond a few self-referential hints embedded in the texts themselves.

Keyword cần chú ý:
little is known about Homer’s life ~ There were no historical records of Homer

Giải thích đáp án:
Thông tin trong bài:
There were no historical records of Homer, and no trustworthy biography of the man exists..
-> Không có hồ sơ lịch sử nào về Homer, và không có tiểu sử đáng tin cậy nào về người đàn ông này ..
-> Không có thông tin nào về Homer -> There was no information about Homer.
Câu hỏi:
references to the fact that little is known about Homer’s life - đề cập đến thực tế là ít người biết về cuộc đời của Homer
-> Trùng khớp với thông tin trong đoạn C. No information about Homer đồng nghĩa với việc không có nhiều điều được biết về Homer (little is known about Homer''s life)
-> Đáp án: C',NULL,NULL,29,'references to the fact that little is known about Homer’s life
','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:08:01.8739','user_56659',false,'2026-06-07 18:08:01.8739','user_56659','D','Trích đoạn chứa đáp án:
Jean-Jacques Rousseau was one of the first modern critics to suggest that Homer might not have been an author in the contemporary sense of a single person who sat down and wrote a story and then published it for others to read.

Giải thích đáp án:
Thông tin trong bài:
Homer might not have been an author in the contemporary sense of a single person who sat down and wrote a story and then published it for others to read
-> Homer không phải là một tác giả theo nghĩa đương đại của một người ngồi viết một câu chuyện và sau đó xuất bản nó cho người khác đọc.
-> đoạn trích mang hàm ý cho rằng cần phải hiểu Homer là “author" theo cách hiểu khác
Đối chiếu với câu hỏi:
a theory involving the reinterpretation of the term ‘author’ - Giả thuyết liên quan tới việc hiểu lại cụm từ “author"
-> Phù hợp với thông tin bài đọc, yêu cầu phải hiểu cụm từ “author" theo một cách khác, không phải cách hiểu hiện tại
-> Đáp án: D',NULL,NULL,28,'a theory involving the reinterpretation of the term ‘author’','FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 17:31:55','user_05335',false,'2026-06-07 17:31:55','user_05335','C/E','','','',26,'','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:54:48','user_05335',false,'2026-06-07 17:54:48','user_05335','TRUE','Trích đoạn chứa đáp án:
In an account of his journey across South America, published in 1836 William Smyth thus complained of frequent ‘desertion'' by his helpers: ‘without them it was impossible to get on’.

Giải thích đáp án:
Bài đọc: In an account of his journey across South America, William Smyth complained of frequent desertion (= bỏ rơi) by his helpers: without them it was impossible to get on.
=> Helpers abandoned/ left William Smyth during his journey.
- Câu hỏi: Local helpers refused to accompany William Smyth during parts of his journey.
=> Đáp án: True','','',7,'Local helpers refused to accompany William Smyth during parts of his journey.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 18:22:14','user_05335',false,'2026-06-07 18:22:14','user_05335','NOT GIVEN','Giải thích đáp án:
Câu hỏi: There was intense competition between actors for contracts with the leading studios.
-> Không có thông tin nào nêu “có sự cạnh tranh gay gắt giữa các diễn viên trong việc giành hợp đồng với các studio hàng đầu”.
-> Đáp án: NOT GIVEN','','',22,'There was intense competition between actors for contracts with the leading studios.','TRUE_FALSE_NOT_GIVEN',137,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:12:15.618884','user_56659',false,'2026-06-07 18:12:15.618884','user_56659','ABSTRACT','Trích đoạn chứa đáp án:
Words that rhyme are much more memorable than words that don’t, and concrete nouns are easier to remember than abstract ones.

Keyword cần chú ý:
difficult to remember words that express abstract ideas = concrete nouns are easier to remember than abstract one

Giải thích đáp án:
Xác định từ loại cần điền: tính từ (vì chỗ trống trong câu hỏi nằm ngay trước danh từ ''ideas'')
Thông tin trong bài:
Words that rhyme are much more memorable than words that don’t, and concrete nouns are easier to remember than abstract ones. - Những từ có vần dễ nhớ hơn nhiều so với những từ không có vần và danh từ cụ thể dễ nhớ hơn những từ trừu tượng.
-> Mọi người thấy danh từ cụ thể dễ nhớ hơn danh từ trừu tượng
Hay nói cách khác: Mọi người cảm thấy khó nhớ những danh từ trừu tượng hơn những danh từ cụ thể.
-> People find it more difficult to remember abstract nouns than concrete nouns.
Câu hỏi:
Psychologists now know that when people are trying to remember information, they may find it difficult to remember words that express ______ ideas.
-> Đáp án: abstract',NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:11:36.173481','user_56659',false,'2026-06-07 18:11:36.173481','user_56659','GENERATION','Trích đoạn chứa đáp án:
Until the last tick of history’s clock, cultural transmission meant oral transmission and poetry, passed from mouth to ear, was the principal medium of moving information across space and from one generation to the next.

Keyword cần chú ý:
pass on its knowledge = moving information
means = medium
Spoken poetry ~ oral transmission and poetry

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống trong câu hỏi nằm ngay sau từ “each")
Thông tin trong bài:
...oral transmission and poetry, passed from mouth to ear, was the principal medium of moving information across space and from one generation to the next. - truyền khẩu và thơ ca, được truyền từ miệng sang tai, là phương tiện chính để truyền đạt thông tin xuyên không gian và từ thế hệ này sang thế hệ khác.
-> Oral transmission là phương pháp chính để truyền thông tin từ qua các thế hệ
-> Oral transmission was the main method of moving information from one generation to the next
So với câu hỏi: Spoken poetry was once the means by which each ………of a particular culture or community could pass on its knowledge.
-> Đáp án: generation',NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:11:17.025248','user_56659',false,'2026-06-07 18:11:17.025248','user_56659','B/C','Trích đoạn chứa đáp án:
Parry had discovered what Wood and Wolf had missed: the evidence that the poems had been transmitted orally was right there in the text itself.

Giải thích đáp án:
Thông tin trong bài:
Parry had discovered what Wood and Wolf had missed: the evidence that the poems had been transmitted orally was right there in the text itself. - Parry đã phát hiện ra điều mà Wood và Wolf đã bỏ lỡ: bằng chứng cho thấy những bài thơ đã được truyền miệng nằm ngay trong chính văn bản đó.
-> “The poems" được nhắc tới ở đây chính là tác phẩm Odyssey and Iliad. Bài đọc nói rõ là The poems had been transmitted orally (tác phẩm được truyền miệng)
-> điều này chứng tỏ tác giả không hề viết những tác phẩm này
-> Đáp án: C. Homer created the Odyssey and Iliad without writing them down.',NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:26:28','user_05335',false,'2026-06-07 18:26:28','user_05335','MULTI(-)TASKING','Trích đoạn chứa đáp án:
In 2004, Rogers used this observation to test the advantages of brain bias in chicks faced with the challenge of multitasking.

Giải thích đáp án:
Rogers dùng thí nghiệm này để kiếm tra lợi ích của lateralization cho "multitasking" (đa nhiệm, làm nhiều việc cùng một lúc).
-> Đáp án là "multitasking"','','',33,'','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 17:30:25','user_05335',false,'2026-06-07 17:30:25','user_05335','PERIODIC UNSETTLING','Trích đoạn chứa đáp án:
Grains can be simply thrown in with a batch of milk for ripening to begin.
The mixture then requires a cool, dark place to live and grow, with periodic unsettling to prevent clumping.

Giải thích đáp án:
Bài đọc: The mixture then requires a cool, dark place to live and grow, with periodic unsettling to prevent clumping
= The mixture requires a cool, dark place and it needs to go through periodic unsettling to prevent clumping.
Câu hỏi: What needs to happen to kefir while it is ripening?
= While kefir is wipending, it needs to go through (trải qua) Noun.
(Khi kefir chính, nó phải trải qua việc….)
=> Cần tìm Noun diễn tả một việc, một quá trình nào đó.
=> Đáp án: periodic unsettling','','',22,'What needs to happen to kefir while it is ripening?','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:31:34','user_05335',false,'2026-06-07 17:31:34','user_05335','C/E','Trích đoạn chứa đáp án:
Kefir also accompanies sour cream as one of the main ingredients in cold beetroot soup and can be used in lieu of regular cow’s milk on granola or cereal.
As a way to keep their digestive systems fine-tuned, athletes sometimes combine kefir with yoghurt in protein shakes.

Giải thích đáp án:
Câu hỏi: Which products are NOT mentioned as things which kefir can replace?
= Which products CAN''T kefir replace?
Bài đọc:
(1) Kefir also accompanies sour cream
= Kefir is used together with sour cream (Kefir và sour cream được sử dụng cùng nhau)
=> Kefir không thay thế được sour cream mà chỉ kết hợp dùng chung với nhau thôi
=> Đáp án: C. Sour cream
(2) Athletes combine kefir with yoghurt
= Kefir is used together with yoghurt (Kefir và yoghurt được sử dụng cùng nhau)
=> Kefir không thay thế được yoghurt mà chỉ kết hợp dùng chung với nhau thôi
=> Đáp án: E. Yoghurt
Lí do không chọn đáp án A, B và D
A. Ordinary cow''s milk
Trong bài có câu “Kefir can be used in lieu of (= instead of) regular cow’s milk on granola or cereal.”
= Kefir can replace regular cow''s milk
B. Buttermilk
Bài đọc: “...the tangy flavour also makes kefir an ideal buttermilk substitute in pancakes.”
=> Cấu trúc make Noun 1 Noun 2 (biến Noun 1 thành Noun 2)
=> Biến Kefir thành chất thay thế (substitute) hoàn hảo cho buttermilk
= Kefir can replace buttermilk
D. Starter yeast
Bài đọc: “Many bakers use it instead of starter yeast in the preparation of sourdough”
=> Bakers dùng kefir thay cho starter yeast
= Kefir can replace starter yeast','','',25,'','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:28:58','user_05335',false,'2026-06-07 17:28:58','user_05335','VI','Trích đoạn chứa đáp án:
Although it has prevailed largely as a fermented milk drink, over the years kefir has acquired a number of other uses. Many bakers use it instead of starter yeast in the preparation of sourdough, and the tangy flavour also makes kefir an ideal buttermilk substitute in pancakes. Kefir also accompanies sour cream as one of the main ingredients in cold beetroot soup and can be used in lieu of regular cow’s milk on granola or cereal. As a way to keep their digestive systems fine-tuned, athletes sometimes combine kefir with yoghurt in protein shakes.

Giải thích đáp án:
Phân tích từng câu:
(1) Kefir có nhiều ứng dụng
(2) - (4) Kể ra các ứng dụng của kefir (trong ẩm thực)
=> Main idea: Các ứng dụng của kefir trong ngành ẩm thực, thức ăn
So với list of heading:
Chọn heading vi. Culinary applications
(related to food)','','',18,'Paragraph E','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 18:07:27.714227','user_56659',false,'2026-06-07 18:07:27.714227','user_56659','D','Trích đoạn chứa đáp án:
The real tipping point for robot agriculture will come when farms are being designed with agribots in mind, says Salah Sukkarieh, a robotics researcher at the Australian Center for Field Robotics, Sydney. This could mean a return to smaller fields, with crops planted in grids rather than rows and fruit trees pruned into two-dimensional shapes to make harvesting easier.

Giải thích đáp án:
Thông tin trong bài:
Almost inevitably, these machines will eventually alter the landscape, too. The real tipping point for robot agriculture will come when farms are being designed with agribots in mind, says Salah Sukkarieh, a robotics researcher at the Australian Center for Field Robotics, Sydney.
-> Salah Sukkarieh cho biết các trang trại sẽ được thiết kế để phù hợp với người máy nông nghiệp và điều không thể tránh khỏi là những chiếc máy cuối cùng cũng sẽ làm thay đổi cảnh quan
-> Khi nông trại áp dụng tự động hóa thì cảnh quan xung quan sẽ phải thay đổi
-> đáp án D.As farming becomes more automated the appearance of farmland will change.',NULL,NULL,26,'Salah Sukkarieh','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:06:37.034351','user_56659',false,'2026-06-07 18:06:37.034351','user_56659','F','Trích đoạn chứa đáp án:
There is another reason why automation may be the way forward according to Eldert van Henten, a robotics researcher at Wageningen University in the Netherlands. ‘While the population is growing and needs to be fed, a rapidly shrinking number of people are willing to work in agriculture,’ he points out.

Keyword cần chú ý:
shortage = a rapidly shrinking number
employees in the farming industry ~ people are willing to work in agriculture

Giải thích đáp án:
Thông tin trong bài:
There is another reason why automation may be the way forward according to Eldert Van Henten, a robotics researcher at Wageningen University in the Netherlands. ‘While the population is growing and needs to be fed, a rapidly shrinking number of people are willing to work in agriculture'', he points out.
-> Eldert Van Henten cho rằng trong khi dân số đang tăng và cần được cung cấp thức ăn, thì số lượng người sẵn sàng làm nông nghiệp đang sụt giảm nhanh chóng
-> như vậy là ngày càng có ít người sẵn sàng làm việc trong lĩnh vực nông nghiệp.
-> According to Eldert van Henten, there are fewer people willing to work in agriculture
-> đáp án F. There is a shortage of employees in the farming industry.',NULL,NULL,23,'Eldert van Henten','FILL_IN_THE_BLANK',122,NULL),
	 ('2026-06-07 18:06:17.887075','user_56659',false,'2026-06-07 18:06:17.887075','user_56659','C','Trích đoạn chứa đáp án:
Simon Blackmore, who researches agricultural technology at Harper Adams University College in England believes that fleets of lightweight autonomous robots have the potential to solve this problem and that replacing brute force with precision is key.

Keyword cần chú ý:
exact = precise (-> precision)

Giải thích đáp án:
Thông tin trong bài:
Simon Blackmore, who researches agricultural technology at Harper Adams University College in England believes that fleets of lightweight autonomous robots have the potential to solve this problem and that replacing brute force with precision is key.
-> Simon Blackmore believes that replacing brute force with precision is key - Simon tin rằng thay thế sức mạnh vật lý bằng sự chính xác là chìa khóa -> tức việc thay thế này là quan trọng
-> hay nói cách khác, Simon tin rằng độ chính xác quan trong hơn sức mạnh
-> Simon Blackmore thinks precision is more important than force.
-> đáp án A. We need machines of the future to be exact, not more powerful.',NULL,NULL,22,'Simon Blackmore','FILL_IN_THE_BLANK',122,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:04:40.709998','user_56659',false,'2026-06-07 18:04:40.709998','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
But this is easier said than done; the largest farms in Europe and the U.S. can cover thousands of acres. That’s why automation is key to precision farming.
 
Giải thích đáp án:
 

Thông tin trong bài:
But this is easier said than done; the largest farms in Europe and the U.S. can cover thousands of acres. That’s why automation is key to precision farming.
-> Nhưng điều này nói dễ hơn làm; các trang trại lớn nhất ở Châu Âu và Hoa Kỳ có thể bao phủ hàng nghìn mẫu Anh. Đó là lý do tại sao tự động hóa là chìa khóa để canh tác chính xác.
Đối chiếu với câu hỏi:
Farms in Europe and the US may find it hard to adapt to precision farming. - Các trang trại ở châu Âu và Mỹ nói chung có thể khó thích nghi với việc canh tác chính xác.
-> Trong bài không có thông tin nói chung các farms
-> NOT GIVEN',NULL,NULL,17,'Farms in Europe and the US may find it hard to adapt to precision farming.','YES_NO_NOT_GIVEN',122,NULL),
	 ('2026-06-07 18:12:32.80447','user_56659',false,'2026-06-07 18:12:32.80447','user_56659','MUSIC','Trích đoạn chứa đáp án:
Finding patterns and structure in information is how our brains extract meaning from the world, and putting words to music and rhyme is a way of adding extra levels of pattern and structure to language.

Keyword cần chú ý:
sound similar ~ rhyme
go together with music ~ putting words to

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì chỗ trống trong câu hỏi này đứng ngay sau giới từ “with" )
Thông tin trong bài:
Words that rhyme are much more memorable than words that don’t, and concrete nouns are easier to remember than abstract ones.
-> Câu 1 nói về những loại từ dễ nhớ: từ có vần điệu (words that rhyme) và concrete nouns
Finding patterns and structure in information is how our brains extract meaning from the world, and putting words to music and rhyme is a way of adding extra levels of pattern and structure to language.
-> Câu 2 giải thích lí do dễ nhớ từ có vần điệu và từ có vần hoặc đi kèm với nhạc thì có extra levels of pattern and structure nên dễ nhớ
Câu hỏi:
It is easier to remember words which sound similar or go together with ______
-> Đáp án: music',NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:11:54.052389','user_56659',false,'2026-06-07 18:11:54.052911','user_56659','CITIZEN','Trích đoạn chứa đáp án:
It was, argues the classicist Eric Havelock, a “massive repository of useful knowledge, a sort of encyclopedia of ethics, politics, history and technology which the effective citizen was required to learn as the core of his educational equipment”

Giải thích đáp án:
Xác định từ loại cần điền: danh từ (vì cấu trúc câu hỏi có dạng a Noun 1 of Noun 2)
Thông tin trong bài:
It was a “massive repository of useful knowledge… which the effective citizen was required to learn
-> The effective citizen was required to learn poetry to have useful knowledge such as politics and history
-> it was the requirement for an effective citizen to learn poetry to have useful knowledge such as politics and history
Câu hỏi:
it was the duty of a _______ to know poetry so they would be informed about subjects such as politics and history
-> Đáp án: citizen',NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 19:12:52.575244','user_56659',false,'2026-06-07 19:12:52.575244','user_56659','COMPETITION','Trích đoạn chứa đáp án:
greater competition in academic learning and schools.

Keyword cần chú ý:
increased = greater
in schools = in academic learning and schools

Giải thích đáp án:
Trước đáp án là tính từ “increased” → đáp án là 1 danh từ được “increased” bổ nghĩa.
Từ những keywords được paraphrase → “competition” là đáp án của câu hỏi này.',NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 18:11:03.700475','user_56659',false,'2026-06-07 18:11:03.700475','user_56659','B/C','Trích đoạn chứa đáp án:
In 1795, the German philologist Friedrich August Wolf argued for the first time that not only were Homer’s works not written down by Homer, but they weren’t even by Homer.

Giải thích đáp án:
Thông tin trong bài:
...not only were Homer’s works not written down by Homer, but they weren’t even by Homer.
-> Cấu trúc “Not only… but also" là cấu trúc đảo ngữ dùng để nhấn mạnh
-> Tác phẩm của Homer không chỉ không được viết xuống bới Homer mà chúng thậm chí còn không được sáng tác bởi ông.
-> Homer did not write the works.
Xem xét đáp án:
B. Neither the Odyssey nor the Iliad were written by Homer.
(Neither… nor là cấu trúc phủ định, không phải cái này cũng không phải cái kia)
-> Both Odyssey and Iliad were NOT written by Homer
-> Đáp án: B.',NULL,NULL,35,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-06-07 18:10:22.59655','user_56659',false,'2026-06-07 18:10:22.59655','user_56659','C/D','Trích đoạn chứa đáp án:
The same narrative units – gathering armies, heroic shields, challenges between rivals – pop up again and again, only with different characters and different circumstances.

Giải thích đáp án:
Thông tin trong bài:
The same narrative units – gathering armies, heroic shields, challenges between rivals – pop up again and again, only with different characters and different circumstances
-> Những lời kể chuyện giống nhau – chẳng hạn như tập hợp quân đội, lá chắn anh hùng, thử thách giữa các đối thủ – xuất hiện lặp đi lặp lại, chỉ là các nhân vật khác nhau và hoàn cảnh khác nhau.
Ta thấy:
The same narrative units...pop up again and again : lời tường thuật lặp đi lặp lại cho thấy nội dung là tương tự nhau ~ their content is very similar
-> đáp án C',NULL,NULL,33,NULL,'FILL_IN_THE_BLANK',123,NULL),
	 ('2026-08-04 17:31:40','truongdx18vtit',false,'2026-08-04 17:31:40','truongdx18vtit','MILL',NULL,'','',7,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-08-05 17:31:40','truongdx18vtit',false,'2026-08-05 17:31:40','truongdx18vtit','BOOKSHOP',NULL,'','',8,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-06-07 17:54:29','user_05335',false,'2026-06-07 17:54:29','user_05335','FALSE','Trích đoạn chứa đáp án:
In their published narratives, European explorers rarely portrayed themselves as vulnerable or dependent on others, despite the fact that without this support they were quite literally lost.

Keyword cần chú ý:
publications = published narratives
describe = portrayed
dependence on their helpers = dependent on others

Giải thích đáp án:
In their published narratives , European explorers rarely portrayed themselves as vulnerable or dependent on others, despite the fact that without this support they were quite literally lost .
Câu hỏi: In their publications, European explorers often describe their dependence on their helpers.
rarely # often
=> Đáp án: FALSE','','',6,'In their publications, European explorers often describe their dependence on their helpers.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 16:35:17','user_05335',false,'2026-06-07 16:35:17','user_05335','VI','Trích đoạn chứa đáp án:
Big trees are incredibly important ecologically. For a start, they sustain countless other species. They provide shelter for many animals, and their trunks and branches can become gardens, hung with green ferns, orchids and bromeliads, coated with mosses and draped with vines. With their tall canopies* basking in the sun, they capture vast amounts of energy. This allows them to produce massive crops of fruit, flowers and foliage that sustain much of the animal life in the forest.

Giải thích đáp án:
Phân tích từng câu:
(1) Giới thiệu tầm quan trọng của big trees lên hệ sinh thái
(2) - (5) Làm rõ tầm quan trọng này: support animal species.
=> Main idea: Big trees help support animal species.
So với list of heading:
Chọn heading vi. How wildlife benefits from big tree','','',1,'Paragraph A','FILL_IN_THE_BLANK',127,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-06 17:31:40','truongdx18vtit',false,'2026-08-06 17:31:40','truongdx18vtit','KITCHEN',NULL,'','',9,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-08-07 17:31:40','truongdx18vtit',false,'2026-08-07 17:31:40','truongdx18vtit','KING',NULL,'','',10,'','FILL_IN_THE_BLANK',155,''),
	 ('2026-08-08 17:31:40','truongdx18vtit',false,'2026-08-08 17:31:40','truongdx18vtit','C',NULL,'','["A. non-profit making organisation","B. owned by an international corporation.","C. a collective owned by ordinary people."]',11,'The SIS is','MULTIPLE_CHOICE',156,''),
	 ('2026-08-09 17:31:40','truongdx18vtit',false,'2026-08-09 17:31:40','truongdx18vtit','B',NULL,'','[
  "A. has no fees.",
  "B. has low fees.",
  "C. avoid paying fees."
]',12,'The SIS','MULTIPLE_CHOICE',156,''),
	 ('2026-06-07 16:36:10','user_05335',false,'2026-06-07 16:36:10','user_05335','X','Trích đoạn chứa đáp án:
Only a small number of tree species have the genetic capacity to grow really big. The mightiest are native to North America, but big trees grow all over the globe, from the tropics to the boreal forests of the high latitudes. To achieve giant stature, a tree needs three things: the right place to establish its seedling, good growing conditions and lots of time with low adult mortality*. Disrupt any of these, and you can lose your biggest trees.

Keyword cần chú ý:
capacity = ability
big = giant = mighty

Giải thích đáp án:
Phân tích từng câu:
(1) Genetic rất quan trọng nếu muốn có big trees
(2) Đưa ra vị trí của big trees: all around the globes
(3) Liệt kê các factors để có big trees
(4) Nếu thiếu những factors này sẽ không thể có big trees
=> Main idea: Factors leading to big trees
So với list of heading:
Chọn heading x. Factors that enable trees to grow to significant heights
(grow to significant heights = big) (paraphrase bằng cách định nghĩa)','','',2,'Paragraph B','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:36:40','user_05335',false,'2026-06-07 16:36:40','user_05335','II','Trích đoạn chứa đáp án:
In some parts of the world, populations of big trees are dwindling because their seedlings cannot survive or grow. In southern India, for instance, an aggressive nonnative shrub, Lantana camara, is invading the floor of many forests. Lantana grows so thickly that young trees often fail to take root. With no young trees to replace them, it is only a matter of time before most of the big trees disappear. Across much of northern Australia, gamba grass from Africa is overrunning native savannah woodlands. The grass grows up to four metres tall and burns fiercely, creating super hot fires that cause catastrophic tree mortality.

Giải thích đáp án:
Phân tích từng câu:
(1) The number of big trees is declining.
(2) - (4) Give first example why big trees decline : Lantana grows quickly
(5) - (6) Give second example why big trees decline: gamba grass grows quickly
=> Main idea: The growth of other trees (Lantana, gamba grass…) leads to a decline in the number of big trees.
So với list of heading:
Chọn heading ii. How other plants can cause harm','','',3,'
Paragraph C','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:37:07','user_05335',false,'2026-06-07 16:37:07','user_05335','IX','rích đoạn chứa đáp án:
Without the right growing conditions trees cannot get really big, and there is some evidence to suggest tree growth could slow down in a warmer world, particularly in environments that are already warm. Having worked for decades at La Selva Biological Station in Puerto Viejo de Sarapiqui, Costa Rica, David and Deborah Clark and colleagues have shown that tree growth there declines markedly in warmer years. “During the day, their photosynthesis* shuts down when it gets too warm, and at night they consume more energy because their metabolic rate increases, much as a reptile’s would when it gets warmer,” explains David Clark. With less energy produced in warmer years and more being consumed just to survive, there is even less energy available for growth.

Keyword cần chú ý:
higher temperatures = warmer
slow the rate of tree growth = tree growth decline

Giải thích đáp án:
Phân tích từng câu:
(1) - (2) Trees cannot grow big in warmer climate
(3) - (4) Explain why trees cannot grow big in warmer climate (because they need to use more energy)
=> Main idea: Có thể thấy, tổng quan cả đoạn xoay quanh việc Warmer climate (khí hậu nóng) cản trở the growth of trees
So với list of heading:
Chọn heading ix. How higher temperatures slow the rate of tree growth','','',4,'
Paragraph D','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:37:32','user_05335',false,'2026-06-07 16:37:32','user_05335','IV','Trích đoạn chứa đáp án:
The Clarks’ hypothesis, if correct, means tropical forests would shrink over time. The largest, oldest trees would progressively die off and tend not to be replaced. According to the Clarks, this might trigger a destabilisation of the climate; as older trees die, forests would release some of their stored carbon into the atmosphere, prompting a vicious cycle of further warming, forest shrinkage and carbon emissions.

Keyword cần chú ý:
Environment ~ climate

Giải thích đáp án:
Phân tích từng câu:
(1) - (2) Big trees will die off
(3) How this affects the climate
=> Main idea: The impact of the loss of big trees on the climate
So với list of heading:
Chọn heading iv Impact of big tree loss on the wider environment','','',5,'Paragraph E','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:37:58','user_05335',false,'2026-06-07 16:37:58','user_05335','I','Trích đoạn chứa đáp án:
Big trees face threats from elsewhere. The most serious is increasing mortality, especially of mature trees. Across much of the planet, forests of slow growing ancient trees have been cleared for human use. In western North America, most have been replaced by monocultures of fast growing conifers. Siberia’s forests are being logged at an incredible rate. Logging in tropical forests is selective but the timber cutters usually prioritise the biggest and oldest trees. In the Amazon, my colleagues and I found the mortality rate for the biggest trees had tripled in small patches of rainforest surrounded by pasture land. This happens for two reasons. First, as they grow taller, big trees become thicker and less flexible: when winds blow across the surrounding cleared land, there is nothing to stop their acceleration. When they hit the trees, the impact can snap them in half. Second, rainforest fragments dry out when surrounded by dry, hot pastures and the resulting drought can have devastating consequences: one four-year study has shown that death rates will double for smaller trees but will increase 4.5 times for bigger trees.

Keyword cần chú ý:
Deforestation = destroy forests
Isolated trees = biggest trees

Giải thích đáp án:
Phân tích từng câu:
(1) Big trees are facing threats
(2) The most serious threat is increasing mortality (death rate)
(3) Làm rõ hơn ý câu 2: forests are cleared (destroyed) for human use
(4) + (5) đưa ví dụ cho câu 3
(6) Làm rõ ý câu 3: Chủ yếu là biggest trees are cut off
(7) - (11) Đưa ra ví dụ và giải thích cho điều này
=> Main idea: People mostly cut off biggest trees when they destroy forests
So với list of heading:
Chọn heading i. How deforestation harms isolated trees','','',6,'Paragraph F','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:45:21','user_05335',false,'2026-06-07 16:45:21','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
In 1998, researchers at the Pelagos Cetacean Research Institute, a Greek nonprofit scientific group, linked whale strandings with low frequency sonar tests being carried out by the North Atlantic Treaty Organisation (NATO).

Giải thích đáp án:
Bài đọc: In 1998, researchers at the Pelagos Cetacean Research Institute linked whale strandings with low- frequency sonar tests
=> Bài đọc chỉ nói kết quả mà Pelagos Institute tìm ra được: mối liên hệ giữa whale strandings và sonar, không hề đề cập tới mục đích thí nghiệm (the aim of the research)
Câu hỏi: The aim of the research by the Pelagos Institute in 1998 was to prove that navy sonar was responsible for whale strandings.
=> Đáp án: NOT GIVEN','','',22,'The aim of the research by the Pelagos Institute in 1998 was to prove that navy sonar was responsible for whale strandings.','TRUE_FALSE_NOT_GIVEN',128,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-10 17:31:40','truongdx18vtit',false,'2026-08-10 17:31:40','truongdx18vtit','A',NULL,'','[
  "A. will be charged for setting up automatic payments.",
  "B. attract no service charges.",
  "C. must have a minimum balance"
]',13,'SIS accounts with the same customer number','MULTIPLE_CHOICE',156,''),
	 ('2026-06-07 16:38:22','user_05335',false,'2026-06-07 16:38:22','user_05335','VII','Trích đoạn chứa đáp án:
Particular enemies to large trees are insects and disease. Across vast areas of western North America, increasingly mild winters are causing massive outbreaks of bark beetle. These tiny creatures can kill entire forests as they tunnel their way through the inside of trees. In both North America and Europe, fungus causing diseases such as Dutch elm disease have killed off millions of stately trees that once gave beauty to forests and cities. As a result of human activity, such enemies reach even the remotest corners of the world, threatening to make the ancient giants a thing of the past. Glossary: a canopy: leaves and branches that form a cover high above the ground mortality: the number of deaths within a particular group photosynthesis: a process used by plants to convert the light energy from the sun into chemical energy that can be used as food.

Keyword cần chú ý:
Pests = Insects
infection = disease

Giải thích đáp án:
Phân tích từng câu:
(1) Liệt kê 2 enemies của large trees: insects và diseases
(2) (3) Giải thích cách insects làm hại large trees
(4) Giải thích cách diseases làm hại large trees
(5) Nhấn mạnh lại tác hại của insects và diseases
=> Main idea: Insects and diseases can harm large trees
So với list of heading: Chọn heading vii. Risk from pests and infection','','',7,'Paragraph G','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:38:48','user_05335',false,'2026-06-07 16:38:48','user_05335','NORTH AMERICA','Trích đoạn chứa đáp án:
The mightiest are native to North America, but big trees grow all over the globe, from the tropics to the boreal forests of the high latitudes.

Keyword cần chú ý:
biggest = mightiest

Giải thích đáp án:
Ngay cả khi không hiểu “mightiest" là gì, vẫn có thể đoán được nghĩa từ nếu nhìn connection giữa 2 vế (liên hệ bởi chữ “but")
=> Cây lớn thì có ở khắp nơi trên thế giới, nhưng những cây …. nhất nằm ở North America,
=> Mightiest = Biggest
=> Big trees grow all over the globe, but the biggest are native to North America.
Câu hỏi: The biggest trees in the world can be found in _______ (Hỏi vị trí cây lớn nhất)
=> Đáp án: North America','','',8,'The biggest trees in the world can be found in……………………….','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:39:12','user_05335',false,'2026-06-07 16:39:12','user_05335','(SUPER-HOT) FIRES','Trích đoạn chứa đáp án:
Across much of northern Australia, gamba grass from Africa is overrunning native savannah woodlands.
The grass grows up to four metres tall and burns fiercely, creating super hot fires that cause catastrophic tree mortality.

Keyword cần chú ý:
die (v) ~ tree mortality (n)

Giải thích đáp án:
Bài đọc: The grass creates super-hot fires. Super-hot fires cause tree mortality (tree death)
=> Tree mortality is caused by super-hot fires, which are caused by the grass.
Câu hỏi: Some trees in northern Australia die because of ________ made worse by gamba grass.
=> Đáp án: (super-hot) fires','','',9,'Some trees in northern Australia die because of…………………………made worse by gamba grass.','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:39:46','user_05335',false,'2026-06-07 16:39:46','user_05335','(STORED) CARBON','Trích đoạn chứa đáp án:
According to the Clarks, this might trigger a destabilisation of the climate; as older trees die, forests would release some of their stored carbon into the atmosphere, prompting a vicious cycle of further warming, forest shrinkage and carbon emissions.

Keyword cần chú ý:
release of (stored) carbon = release some of their stored carbon
dead trees = older trees die
death of more trees = a vicious cycle

Giải thích đáp án:
Bài đọc: Older trees die, forests release stored carbon. Stored carbon encourages other trees to die.
Câu hỏi: The Clarks believe that the release of _______ from dead trees could lead to the death of more trees.
=> Đáp án: stored carbon','','',10,'The Clarks believe that the release of………………………….from dead trees could lead to the death of more trees.','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:40:15','user_05335',false,'2026-06-07 16:40:15','user_05335','WINDS','Trích đoạn chứa đáp án:
First, as they grow taller, big trees become thicker and less flexible: when winds blow across the surrounding cleared land, there is nothing to stop their acceleration.
When they hit the trees, the impact can snap them in half.

Keyword cần chú ý:
Strong winds = winds + nothing to stop their acceleration
damaging = snap them in half
tall trees = taller, big trees

Giải thích đáp án:
Bài đọc: Winds become faster and stronger when they blow across cleared land. These strong winds can snap tall, big trees in half.
Câu hỏi: Strong ______ are capable of damaging tall trees in the Amazon.
=> Đáp án: winds','','',11,'Strong…………………………………are capable of damaging tall trees in the Amazon.','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:40:39','user_05335',false,'2026-06-07 16:40:39','user_05335','DROUGHT','Trích đoạn chứa đáp án:
Second, rainforest fragments dry out when surrounded by dry, hot pastures and the resulting drought can have devastating consequences: one fouryear study has shown that death rates will double for smaller trees but will increase 4.5 times for bigger trees.

Keyword cần chú ý:
worse impact ~ devastating consequences
tall = big

Giải thích đáp án:
Bài đọc: Rainforest fragments dry out -> Drought -> Devastating consequences (= Negative impacts ) : double death rates for smaller trees, 4.5 times death rates for bigger trees (tỉ lệ tử vong smaller trees là x2, bigger trees là 4.5)
=> Hậu quả tác động lên bigger trees lớn hơn
=> Drought leads to worse consequences on bigger trees than smaller trees.
Câu hỏi: _______ has a worse impact on tall trees than smaller ones.
=> Đáp án: drought','','',12,'…………………………………..has a worse impact on tall trees than smaller ones.','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:41:06','user_05335',false,'2026-06-07 16:41:06','user_05335','(BARK) BEETLE','Trích đoạn chứa đáp án:
Across vast areas of western North America, increasingly mild winters are causing massive outbreaks of bark beetle.
These tiny creatures can kill entire forests as they tunnel their way through the inside of trees.

Keyword cần chú ý:
a species of beetle = bark beetle + These tiny creatures
destroyed many trees = kill entire forests

Giải thích đáp án:
Bài đọc: These tiny creatures can kill entire forests as they tunnel their way through the inside of trees.
Câu hỏi: In western Northern America, a species of ________ has destroyed many trees.
=> Đáp án: beetle','','',13,'In western Northern America, a species of……………………………….has destroyed many trees.','FILL_IN_THE_BLANK',127,NULL),
	 ('2026-06-07 16:42:33','user_05335',false,'2026-06-07 16:42:33','user_05335','NOISE [OR] NOISE POLLUTION','Trích đoạn chứa đáp án:
It is known that noise pollution from offshore industry, shipping and sonar can impair underwater communication, but can it really drive whales onto our beaches?

Keyword cần chú ý:
harmful to whales ~ impair underwater communication

Giải thích đáp án:
Bài đọc: noise pollution from offshore industry, shipping and sonar can impair underwater communication
-> offshore industry, shipping and sonar cause noise pollution that can impair underwater communication
- Câu hỏi:
some industries and shipping create what that is harmful to whales?
=> Đáp án: noise pollution','','',15,'What do some industries and shipping create that is harmful to whales?','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 16:49:49','user_05335',false,'2026-06-07 16:49:49','user_05335','B','Trích đoạn chứa đáp án:
One of CASIS’s roles is to convince public and private investors that science on the station is worth the spend because judged solely by the number of papers published, the ISS certainly seems poor value: research on the station has generated about 3,100 papers since 1998.The Hubble Space Telescope, meanwhile, has produced more than I 1,300 papers in just over 20 years, yet it cost less than one tenth of the price of the space station.

Giải thích đáp án:
Phân tích từng câu:
(1) Because ISS couldn''t produce many papers (= poor value of papers published), there is a need to convince the public and private investors that ISS is worth the investment.
(2) The Hubble Space Telescope can produce a lot of paper at a cheaper cost.
=> Đưa The Hubble Space Telescope để làm bật lên sự so sánh với ISS => Nhấn mạnh kết quả của ISS nghèo nàn thế nào => Nếu ISS muốn nhận investment thì phải convince the public and private investors=> Đưa The Hubble Space Telescope vào để nhấn mạnh tầm quan trọng của việc khuyến khích đầu tư vào ISS
=> Đáp án: B. highlight the need to promote the ISS in a positive way.
(nhấn mạnh nhu cầu cần quảng bá ISS theo hướng tích cực)','','["A. show why investment in space technology has decreased.","B. highlight the need to promote the ISS in a positive way.","C. explain which kind of projects are more likely to receive funding.","D. justify the time required for a space project to produce results."]',29,'The writer refers to the Hubble Space Telescope in order to','MULTIPLE_CHOICE',129,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:53:22','user_05335',false,'2026-06-07 16:53:22','user_05335','F','Trích đoạn chứa đáp án:
More importantly, scientists are already queuing for seats on these lowgravity spaceflight services so they can collect data during a few minutes of weightlessness. This demand for low-cost space flight could eventually lead to a service running on a more frequent basis

Keyword cần chú ý:
the demand for space flights = This demand for low-cost space flight
more regular = on a more frequent basis

Giải thích đáp án:
Câu hỏi: Another point is that as the demand for space flights increases, there is a chance of them (= space flights) becoming more ____
=> Cần điền “frequent" vào chỗ trống. Trong list đáp án chỉ có F. regular là synonym của frequent.
=> Đáp án: F. regular','','',38,'','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:46:09','user_05335',false,'2026-06-07 16:46:09','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
Another is Rosemary Gales, a leading expert on whale strandings. She says sonar technology cannot always be blamed for mass strandings.

Giải thích đáp án:
Another is Rosemary Gales, a leading expert on whale strandings.
She says sonar technology cannot always be blamed for mass strandings .
=> Bài đọc chỉ nói sonar technology không phải lúc nào cũng gây ra mass strandings, không đề cập gì tới “research techniques" (cách thức nghiên cứu) của Greek scientists.
Câu hỏi: Rosemary Gales has questioned the research techniques used by the Greek scientists.
=> Đáp án: NOT GIVEN','','',24,'Rosemary Gales has questioned the research techniques used by the Greek scientists.','TRUE_FALSE_NOT_GIVEN',128,NULL),
	 ('2026-06-07 16:44:05','user_05335',false,'2026-06-07 16:44:05','user_05335','NUTRIENTS','Trích đoạn chứa đáp án:
To put it more simply, she says, in the years when strong westerly and southerly winds bring cool water rich in nutrients closer to the Australia coast, there is an increase in the number of fish.

Keyword cần chú ý:
Extra nutrients in the water = water rich in nutrients
attracts fish => an increase in the number of fish
South Australian coasts = Australia coast

Giải thích đáp án:
Bài đọc: Nutrients in cool water increase the number of fish and whales to the Australia coast
Câu hỏi: Extra _____ in the water attracts fish and therefore whales to South Australian coasts.
=> Đáp án: nutrients','','',19,'','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 16:44:22','user_05335',false,'2026-06-07 16:44:22','user_05335','MICROBUBBLES','Trích đoạn chứa đáp án:
Larger ones rise quickly to the surface and disappear, whilst smaller ones called microbubbles can last for days. It is these that absorb whale ''clicks! "Rough weather generates more bubbles than usual,” James adds. So, during and after a storm, echolocating whales are essentially swimming blind.

Keyword cần chú ý:
Storms create microbubbles = Rough weather generates more bubble + storm

Giải thích đáp án:
Bài đọc: Microbubbles absorb whale clicks. Storms generate more microbubbles than usual.
=> Storms generate more microbubbles which absorb whale clicks.
Câu hỏi: Storms create _____ which absorbs whales'' clicks.
=> Đáp án: microbubbles','','',20,'','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 16:46:59','user_05335',false,'2026-06-07 16:46:59','user_05335','FALSE','Trích đoạn chứa đáp án:
In 2005, a survey by Klaus Vanselow and Klaus Ricklefs of sperm whale strandings in the North Sea even found a correlation between these and the sunspot cycle, and suggested that changes in the Earth’s magnetic field might be involved. But others are sceptical.

Giải thích đáp án:
Bài đọc: a survey of sperm whale strandings in the North Sea found a correlation between these and the sunspot cycle, and suggested that changes in the Earth’s magnetic field might be involved. But others are sceptical.
= A survey found a connection between sperm whale strandings and the Earth''s magnetic field. But other (scientists) are sceptical (= hoài nghi)
=> Nếu “other scientists are sceptical" thì không thể nói tất cả mọi người đều đồng ý với phát hiện trên
Câu hỏi: There is now agreement amongst scientists that changes in the Earth’s magnetic fields contribute to whale strandings.
Agreement amongst scientist # other scientists are sceptical
=> Đáp án: FALSE','','',26,'There is now agreement amongst scientists that changes in the Earth’s magnetic fields contribute to whale strandings.','TRUE_FALSE_NOT_GIVEN',128,NULL),
	 ('2026-06-07 16:43:24','user_05335',false,'2026-06-07 16:43:24','user_05335','SPERM [OR] SPERM WHALE(S)','Trích đoạn chứa đáp án:
In 2005, a survey by Klaus Vanselow and Klaus Ricklefs of sperm whale strandings in the North Sea even found a correlation between these and the sunspot cycle, and suggested that changes in the Earth’s magnetic field might be involved.

Keyword cần chú ý:
study = survey

Giải thích đáp án:
Bài đọc: a survey by Klaus Vanselow and Klaus Ricklefs of sperm whale strandings in the North Sea found a correlation between these and the sunspot cycle ...
=> The survey by Klaus Vanselow and Klaus Ricklefs in the North Sea was about sperm whale strandings.
Câu hỏi: The subject of a study in the North Sea was which kind of whale?
=> Đáp án: sperm (whale)','','',17,'Which kind of whale was the subject of a study in the North Sea?
','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 16:42:58','user_05335',false,'2026-06-07 16:42:58','user_05335','(AROUND) TASMANIA','Trích đoạn chứa đáp án:
And when 80% of all Australian whale strandings occur around Tasmania, Gales and her team must continue in the search for answers.

Keyword cần chú ý:
most -> 80%
happen = occur

Giải thích đáp án:
Bài đọc: when 80% of all Australian whale strandings occur around Tasmania, Gales and her team must continue in the search for answers.
- Câu hỏi: most whale strandings in Australia happen in which geographical region?
=> Đáp án: (around) Tasmania','','',16,'In which geographical region do most whale strandings in Australia happen?','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 16:46:30','user_05335',false,'2026-06-07 16:46:30','user_05335','TRUE','Trích đoạn chứa đáp án:
"They''re highly social creatures,” says Gales. "When they mass strand it’s complete panic and chaos. If one of the group strands and sounds the alarm, others will try to swim to its aid, and become stuck themselves.”

Keyword cần chú ý:
help = aid
call for help = alarm

Giải thích đáp án:
Bài đọc: “They’re social creatures,” says Gales. “ When they mass strand – it’s complete panic and chaos. If one of the group strands and sounds the alarm, others will try to swim to its aid, and become stuck themselves.”
= If one of the group strands and sounds the alarm, others will try to swim to its aid
=> If one of the group strands, others will try to help it.
Câu hỏi: According to Gales, whales are likely to try to help another whale in trouble.
=> Đáp án: TRUE','','',25,'According to Gales, whales are likely to try to help another whale in trouble.','TRUE_FALSE_NOT_GIVEN',128,NULL),
	 ('2026-06-07 16:45:45','user_05335',false,'2026-06-07 16:45:45','user_05335','TRUE','Trích đoạn chứa đáp án:
Typically they all wash ashore together, but in mass atypical strandings (such as the one in Greece), the whales don''t strand as a group; they are scattered over a larger area.

Keyword cần chú ý:
found at different points = scattered

Giải thích đáp án:
Bài đọc: they all wash ashore together , but in mass atypical strandings (such as the one in Greece), the whales don’t strand as a group; they are scattered over a larger area.
=> Ngay cả khi không hiểu “scatter" là gì thì thí sinh vẫn có thể dựa vào vế trước để đoạn: Whales don''t strand as a group (không bị mắc cạn cùng nhau) => Whales strand lẻ tẻ, rời rạc ở nhiều nơi khác nhau
- Câu hỏi: The whales stranded in Greece were found at different points along the coast.
=> Đáp án: TRUE','','',23,'The whales stranded in Greece were found at different points along the coast.','TRUE_FALSE_NOT_GIVEN',128,NULL),
	 ('2026-06-07 16:44:41','user_05335',false,'2026-06-07 16:44:41','user_05335','BLOOD','Trích đoạn chứa đáp án:
For whales, on the other hand, there is a theory on how sonar can kill. The noise can surprise the animal, causing it to swim too quickly to the surface. The result is decompression sickness, a hazard human divers know all too well. If a diver ascends too quickly from a high pressure underwater environment to a lower pressure one, gases dissolved in blood and tissue expand and form bubbles. The bubbles block the flow of blood to vital organs, and can ultimately lead to death.

Keyword cần chú ý:
supply = flow

Giải thích đáp án:
Câu đầu đề cập rằng “sonar can kill" .
=> Những câu sau giải thích việc này diễn ra như thế nào: Bubbles block the flow of blood to vital organs and can lead to death.
Câu hỏi: Sonar may result in a blocked supply of …. in whale bodies.
=> Đáp án: blood','','',21,'','FILL_IN_THE_BLANK',128,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:42:05','user_05335',false,'2026-06-07 16:42:05','user_05335','SKIN [OR] SKIN SAMPLES','Trích đoạn chứa đáp án:
A team of researchers begins to investigate, collecting skin samples for instance, recording anything that could help them answer the crucial question: why?

Keyword cần chú ý:
take = collecting

Giải thích đáp án:
Bài đọc: researchers begins to investigate, collecting skin samples
- Câu hỏi: researchers often take what from the bodies of whales?
=> Đáp án: skin (samples)','','',14,'What do researchers often take from the bodies of whales?','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 17:01:52','user_05335',false,'2026-06-07 17:01:52','user_05335','SOUND WAVES','Trích đoạn chứa đáp án:
Usually, as they swim, they make clicking noises, and the resulting sound waves are reflected in an echo and travel back to them.
However, these just fade out on shallow beaches, so the whale doesn’t hear an echo and it crashes onto the shore.

Keyword cần chú ý:
sound waves disappear ~ sound waves + these just fade out

Giải thích đáp án:
Bài đọc: Whales dùng sound waves as they swim. Tuy nhiên, sound waves biến mất ở shallow beaches, nên whale không nghe echo => đâm vào (crashes into) bờ biển.
=> Sound waves biến mất ở shallow beaches nên whale không biết được bờ biển ở gần nên đâm vào đó
=> Because sound waves disappear on shallow beaches, the whale doesn''t know the beach is near.
Câu hỏi: Because ….. disappear on shallow beaches, whales don''t realise the beach is near.
=> Đáp án: sound waves','','',18,'','FILL_IN_THE_BLANK',128,NULL),
	 ('2026-06-07 17:22:47','user_05335',false,'2026-06-07 17:22:47','user_05335','VI','Trích đoạn chứa đáp án:
At Kirkkojarvi Comprehensive School in Espoo, a suburb west of Helsinki, Kari Louhivuori, the school’s principal, decided to try something extreme by Finnish standards. One of his sixth-grade students, a recent immigrant, was falling behind, resisting his teacher’s best efforts. So he decided to hold the boy back a year. Standards in the country have vastly improved in reading, math and science literacy over the past decade, in large part because its teachers are trusted to do whatever it takes to turn young lives around. ‘I took Besart on that year as my private student,'' explains Louhivuori. When he was not studying science, geography and math, Besart was seated next to Louhivuori''s desk, taking books from a tall stack, slowly reading one, then another, then devouring them by the dozens. By the end of the year, he had conquered his adopted country’s vowel-rich language and arrived at the realization that he could, in fact, learn.

Giải thích đáp án:
Phân tích đoạn:
(1) The principal tried something extreme
(2) - (6) Giải thích rõ hơn việc principal làm để giúp cậu học sinh đang falling behind (không theo kịp lớp)
(7) Kết quả việc làm này: He conquered (= mastered) the language + He could learn
=> Main idea: A method used by the principal which helped a young learner.
So với list of heading:
Chọn heading vi. An approach that helped a young learner','','',1,'Paragraph A','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:23:11','user_05335',false,'2026-06-07 17:23:11','user_05335','VII','Trích đoạn chứa đáp án:
This tale of a single rescued child hints at some of the reasons for Finland’s amazing record of education success. The transformation of its education system began some 40 years ago but teachers had little idea it had been so successful until 2000. In this year, the first results from the Programme for International Student Assessment (PISA), a standardized test given to 15-year-olds in more than 40 global venues, revealed Finnish youth to be the best at reading in the world. Three years later, they led in math. By 2006, Finland was first out of the 57 nations that participate in science. In the latest PISA scores, the nation came second in science, third in reading and sixth in math among nearly half a million students worldwide.

Giải thích đáp án:
Phân tích đoạn:
(1) Finland''s education system is successful
(2) - (6) Give evidence/data for this success: best at reading, led at math, first in science,...
=> Main idea: Evidence which proves Finland''s education success
So với list of heading:
Chọn heading vii Statistical proof of education success
(Statistic proof là chứng cứ đưa ra về mặt thống kê. Trong bài, chứng cứ này chính là thứ hạng của Finland trong những môn học khác nhau).','','',2,'Paragraph B','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-08-11 17:31:40','truongdx18vtit',false,'2026-08-11 17:31:40','truongdx18vtit','TRANSACTION',NULL,'','',14,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-08-12 17:31:40','truongdx18vtit',false,'2026-08-12 17:31:40','truongdx18vtit','BONUS ',NULL,'','',15,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-06-07 17:23:33','user_05335',false,'2026-06-07 17:23:33','user_05335','I','Trích đoạn chứa đáp án:
In the United States, government officials have attempted to improve standards by introducing marketplace competition into public schools. In recent years, a group of Wall Street financiers and philanthropists such as Bill Gates have put money behind private sector ideas, such as charter schools, which have doubled in number in the past decade. President Obama, too, apparently thought competition was the answer. One policy invited states to compete for federal dollars using tests and other methods to measure teachers, a philosophy that would not be welcome in Finland. ‘I think, in fact, teachers would tear off their shirts,’ said Timo Heikkinen, a Helsinki principal with 24 years of teaching experience. ‘If you only measure the statistics, you miss the human aspect.’

Giải thích đáp án:
Phân tích đoạn:
(1) - (4) The new approach to education: introducing marketplace competition in education
(5) - (6) The result of this approach: Miss the human aspect (không còn giá trị nhân văn)
=> Main idea: Introducing a new approach (marketplace competition) to education can miss the human aspect.
So với list of heading:
Chọn heading i A business-model approach to education
(business-model approach ở đây chính là marketplace competition được đề cập trong đoạn).','','',3,'Paragraph C','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:23:56','user_05335',false,'2026-06-07 17:23:56','user_05335','IV','Trích đoạn chứa đáp án:
There are no compulsory standardized tests in Finland, apart from one exam at the end of students’ senior year in high school. There is no competition between students, schools or regions. Finland’s schools are publicly funded. The people in the government agencies running them, from national officials to local authorities, are educators rather than business people or politicians. Every school has the same national goals and draws from the same pool of university trained educators. The result is that a Finnish child has a good chance of getting the same quality education no matter whether he or she lives in a rural village or a university town.

Giải thích đáp án:
Câu (1) - (4) Miêu tả nền giáo dục ở Finland: no tests, no competition, publicly funded, run by educators… => không hề có yếu tố business như ở paragraph C.
Câu (5) - (6) Nhấn mạnh sự bình đẳng trong nền giáo dục ở Finland: Schools have the same goals and draws from the same pool of educators; children have the same quality education..
=> Main idea: Finland’s education is non-business and promotes equality.
So với list of heading:
Chọn heading iv Ways in which equality is maintained in the Finnish education system
(Note: Có thể thấy, nếu chỉ skim/scan sẽ không chọn được đáp án này vì keyword “equality" trong heading hoàn toàn không được tìm thấy trong bài đọc => Cách duy nhất để chọn được heading đúng là phải thật sự có khả năng đọc hiểu và tóm tắt được nội dung trong đoạn)','','',4,'Paragraph D','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:24:16','user_05335',false,'2026-06-07 17:24:16','user_05335','VIII','Trích đoạn chứa đáp án:
It’s almost unheard of for a child to show up hungry to school. Finland provides three years of maternity leave and subsidized day care to parents, and preschool for all five-year-olds, where the emphasis is on socializing. In addition, the state subsidizes parents, paying them around 150 euros per month for every child until he or she turns 17. Schools provide food, counseling and taxi service if needed. Health care Is even free for students taking degree courses.

Giải thích đáp án:
Phân tích đoạn:
Câu (2) nói về những thứ mà Finland tài trợ (subsidise) cho parents.
Câu (3) nối kết với câu 2 bằng từ nối “In addition" => Hình dung được câu 3 sẽ tiếp tục phát triển tiếp ý câu 2, tiếp tục nói về cách Finland tài trợ cho parents.
Cấu trúc cả đoạn khá đơn giản: Main idea cả đoạn xoay quanh cách Finland hỗ trợ cho parents và students. Toàn đoạn liệt kê những biện pháp hỗ trợ này (three years of maternity leave, the statesubsidizes parents, Schools provide food, counseling ,...)
So với list of heading:
=> Chọn heading viii. Support for families working and living in Finland','','',5,'Paragraph E','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:24:37','user_05335',false,'2026-06-07 17:24:37','user_05335','II','Trích đoạn chứa đáp án:
Finland’s schools were not always a wonder. For the first half of the twentieth century, only the privileged got a quality education. But In 1963, the Finnish Parliament made the bold decision to choose public education as the best means of driving the economy forward and out of recession. Public schools were organized into one system of comprehensive schools for ages 7 through 16. Teachers from all over the nation contributed to a national curriculum that provided guidelines, not prescriptions, for them to refer to. Besides Finnish and Swedish (the country’s second official language), children started learning a third language (English Is a favorite) usually beginning at age nine. The equal distribution of equipment was next, meaning that all teachers had their fair share of teaching resources to aid learning. As the comprehensive schools Improved, so did the upper secondary schools (grades 10 through 12). The second critical decision came In 1979, when it was required that every teacher gain a fifth-year Master’s degree In theory and practice, paid for by the state. From then on, teachers were effectively granted equal status with doctors and lawyers. Applicants began flooding teaching programs, not because the salaries were so high but because autonomous decision-making and respect made the job desirable. And as Louhivuori explains, ‘We have our own motivation to succeed because we love the work.’

Giải thích đáp án:
Phân tích đoạn:
(1) Finland''s schools không phải lúc nào cũng tốt
(2) In the past, only the rich got a good education
(3) In 1963, có sự cải cách (reform) trong nền giáo dục: đầu tư vào public education để cải thiện kinh tế (drive the economy forward)
(4) - (8) Làm rõ hơn cho sự cải cách này, liệt kê những mặt thay đổi
(9) Second reform in education: require teachers to have Master’s degree
(10) - (12) Kết quả sự cải cách này: Teachers love the work
=> Main idea: Liệt kê những cải cách mà Finland làm để cải thiện giáo dục
So với list of heading:
=> Chọn heading ii. The reforms that improved education in Finland','','',6,'Paragraph F','FILL_IN_THE_BLANK',130,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 17:24:56','user_05335',false,'2026-06-07 17:24:56','user_05335','SCIENCE','Trích đoạn chứa đáp án:
In the latest PISA scores, the nation came second in science, third in reading and sixth in math among nearly half a million students worldwide.

Keyword cần chú ý:
PISA tests = PISA scores
Finland’s top subject was science = came second in science, third in reading and sixth in math

Giải thích đáp án:
Bài đọc: In the latest PISA scores, the nation came second in science, third in reading and sixth in math
=> Finland đứng thứ nhì ở science, thứ 3 reading và thứ 6 ở math…
=> Trong số các môn học, Science là môn mà Finland có thứ hạng cao nhất
=> Môn Finland giỏi nhất là Science
Câu hỏi: In the most recent tests, Finland’s top subject was _____
=> Đáp án: science','','',7,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-06-07 17:25:17','user_05335',false,'2026-06-07 17:25:17','user_05335','ECONOMY','Trích đoạn chứa đáp án:
But In 1963, the Finnish Parliament made the bold decision to choose public education as the best means of driving the economy forward and out of recession.

Keyword cần chú ý:
improve Finland’s economy = driving the economy forward

Giải thích đáp án:
Bài đọc: The Finnish Parliament choose public education as the best means of driving the economy forward
=> The Finnish Parliament use public education to drive the economy forward
Câu hỏi: A new school system was needed to improve Finland’s ______
=> Đáp án: economy','','',8,'','FILL_IN_THE_BLANK',130,NULL),
	 ('2026-08-13 17:31:40','truongdx18vtit',false,'2026-08-13 17:31:40','truongdx18vtit','SIMPLE SAVER',NULL,'','',16,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-06-07 17:32:56','user_05335',false,'2026-06-07 17:32:56','user_05335','D','Trích đoạn chứa đáp án:
The story starts with a multinational company which had invented products for keeping homes spotless, and couldn''t come up with better ways to clean floors, so it hired designers to watch how people cleaned. Frustrated after hundreds of hours of observation, they one day noticed a woman do with a paper towel what people do all the time: wipe something up and throw it away. An idea popped into lead designer Harry West''s head: the solution to their problem was a floor mop with a disposable cleaning surface. Mountains of prototypes and years of teamwork later, they unveiled the Swiffer, which quickly became a commercial success.

Giải thích đáp án:
Phân tích từng câu:
(1) A company has a problem: couldn''t think of a way to clean floors
(2) The company observed a cleaning lady
(3) The company came up with an idea
(4) The idea developed into The Swiffer
=> Main idea: By observing a cleaning lady, the company came up with the idea for The Swiffer
=> Chọn D. Its design was inspired by a common housework habit.','','["A. Its designers had little experience working with household objects.","B. Once the idea for it was conceived, it did not take long to develop.","C. It achieved profits beyond the manufacturer’s expectations.","D. Its design was inspired by a common housework habit."]',27,'What are we told about the product called a ‘Swifter’?','MULTIPLE_CHOICE',132,NULL),
	 ('2026-06-07 17:33:48','user_05335',false,'2026-06-07 17:33:48','user_05335','B','Trích đoạn chứa đáp án:
Lehrer, the author of Imagine, a new book that seeks to explain how creativity works, says this study of the imagination started from a desire to understand what happens in the brain at the moment of sudden insight. ''But the book definitely spiraled out of control,'' Lehrer says. ''When you talk to creative people, they''ll tell you about the ''eureka''* moment, but when you press them they also talk about the hard work that comes afterwards, so I realised I needed to write about that, too. And then I realised I couldn''t just look at creativity from the perspective of the brain, because it''s also about the culture and context, about the group and the team and the way we collaborate.''

Giải thích đáp án:
Phân tích từng câu:
(1) The study began by wanting to study the brain during “eureka" moments
(2) The book changed its plans
(3) + (4) The author realised he needed to write more about the hard work, the context and culture instead of just the brain.
=> Main idea: The author changed his plans after starting the books: He wanted to write more than just the brain.
=> Chọn đáp án: B. he ended up revising his plans for the content.','','["A. he had not intended to focus on creativity.","B. he ended up revising his plans for the content.","C. he was working in a highly creative environment.","D. he was driven by his own experience of the ‘eureka’ moment."]',28,'When Jonah Lehrer began writing his book,','MULTIPLE_CHOICE',132,NULL),
	 ('2026-06-07 17:49:45','user_05335',false,'2026-06-07 17:49:45','user_05335','TRUE','Trích đoạn chứa đáp án:
The Hidden Histories of Exploration exhibition at Britain''s Royal Geographical Society in London sets out to present an alternative view, in which exploration is a fundamentally collective experience of work, involving many different people.

Keyword cần chú ý:
aims = sets out
show = present
the wide range of people = many different people
expeditions = exploration

Giải thích đáp án:
Bài đọc: Hidden Histories of Exploration exhibition có mục tiêu trình bày về những người khác nhau tham gia thám hiểm
Câu hỏi: The Hidden Histories of Exploration exhibition aims to show the wide range of people involved in expeditions.
=> Đáp án: TRUE','','',1,'The Hidden Histories of Exploration exhibition aims to show the wide range of people involved in expeditions.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 17:50:06','user_05335',false,'2026-06-07 17:50:06','user_05335','FALSE','Trích đoạn chứa đáp án:
Many of the most famous examples of explorers said to have been ‘lone travellers’- say, Mungo Park or David Livingstone in Africa - were anything but ‘alone’ on their travels. They depended on local support of various kinds - for food, shelter, protection, information, guidance and solace - as well as on other resources from elsewhere.

Giải thích đáp án:
Bài đọc: _x0008_Các nhà thám hiểm như Park và Livingstone được tin là thực hiện các chuyến thám hiểm một mình nhưng họ phụ thuộc nhiều vào những người hỗ trợ ở địa phương.
-> The belief that explorers such as Park and Livingstone travelled alone is false.
Câu hỏi: The common belief about how Park and Livingstone travelled is accurate.
-> Đáp án: FALSE','','',2,'The common belief about how Park and Livingstone travelled is accurate.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 17:50:25','user_05335',false,'2026-06-07 17:50:25','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
The Royal Geographical Society (RGS) seeks to record this story in its Hidden Histories project, using its astonishingly rich collections. The storage of geographical information was one of the main rationales for the foundation of the KGS in 1830, and the society’s collections now contain more than two million individual items, including books, manuscripts, maps, photographs, art-works, artefacts and film - a rich storehouse of material rejecting the widt1 geographical extent of British interest across the globe.

Giải thích đáp án:
Dù có nhắc tới thông tin “RGS" và sự thành lập của nó (foundation) nhưng trong bài lại chẳng nhắc gì tới số lượng exhibitions được tổ chức.
=> Đáp án: NOT GIVEN','','',3,'The RGS has organised a number of exhibitions since it was founded.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 17:50:43','user_05335',false,'2026-06-07 17:50:43','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
For the researcher, this archive can yield many surprises; materials gathered Tor one purpose - say, maps relating to an international boundary dispute or photographs taken an a scientific expedition - may today be put to quite different uses.

Giải thích đáp án:
Bài đọc: This archieve can surprise people because materials can be used for different purposes
=> Không hề so sánh materials hay records nào useful hơn records nào
- Câu hỏi: Some of the records in the RGS archives are more useful than others.
=> Đáp án: NOT GIVEN
','','',4,'Some of the records in the RGS archives are more useful than others.','TRUE_FALSE_NOT_GIVEN',133,NULL),
	 ('2026-06-07 17:51:06','user_05335',false,'2026-06-07 17:51:06','user_05335','TRUE','Trích đoạn chứa đáp án:
For the researcher, this archive can yield many surprises; materials gathered Tor one purpose - say, maps relating to an international boundary dispute or photographs taken an a scientific expedition - may today be put to quite different uses.

Giải thích đáp án:
Bài đọc: Materials can be gathered for one purpose but can be used in other ways.
Câu hỏi: Materials owned by the RGS can be used in ways that were not originally intended.
= Materials can be intended for one purpose but can be used in other ways.
=> Đáp án: TRUE','','',5,'Materials owned by the RGS can be used in ways that were not originally intended.','TRUE_FALSE_NOT_GIVEN',133,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-14 17:31:40','truongdx18vtit',false,'2026-08-14 17:31:40','truongdx18vtit','30TH JUNE ',NULL,'','',17,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-08-15 17:31:40','truongdx18vtit',false,'2026-08-15 17:31:40','truongdx18vtit','SECURE',NULL,'','',18,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-08-16 17:31:40','truongdx18vtit',false,'2026-08-16 17:31:40','truongdx18vtit','BONDS',NULL,'','',19,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-06-07 17:55:13','user_05335',false,'2026-06-07 17:55:13','user_05335','D','Trích đoạn chứa đáp án:
For example, the history of African exploration in the nineteenth century is dominated by the use of Zanzibar as a recruiting station for porters, soldiers and guides who would then travel thousands of miles across the continent.

Giải thích đáp án:
Bài đọc: The history of African exploration is dominated by the use of Zanzibar as a recruiting station for porters, soldiers and guides who would then travel thousands of miles across the continent
=> porters, soldiers and guides chính là những non-European helpers
= non-European helpers travelled thousands of miles across the continent.

- Câu hỏi: reference to the distances that some non-European helpers travelled
=> Distances được đề cập trong đoạn D chính là “thousands of miles"
=> Đáp án là đoạn D','','',8,'reference to the distances that some non-European helpers travelled','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 17:55:32','user_05335',false,'2026-06-07 17:55:32','user_05335','B','Trích đoạn chứa đáp án:
The storage of geographical information was one of the main rationales for the foundation of the KGS in 1830, and the society’s collections now contain more than two million individual items, including books, manuscripts, maps, photographs, art-works, artefacts and film - a rich storehouse of material rejecting the wide geographical extent of British interest across the globe.

Giải thích đáp án:
Bài đọc: The storage of geographical information was one of the main rationales for the foundation of the RGS, and the Society’s collections [ contain more than two million individual items, including... (liệt kê tài liệu)
- Câu hỏi: description of a wide range of different types of documents
=> trùng khớp
=> Đáp án là paragraph B','','',9,'description of a wide range of different types of documents','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 17:55:52','user_05335',false,'2026-06-07 17:55:52','user_05335','G','Trích đoạn chứa đáp án:
These touching portraits encourage us to see them as agents rather than simply colonial subjects or paid employees.

Keyword cần chú ý:
exhibition = these touching portraits

Giải thích đáp án:
- Bài đọc: These touching portraits encourage us to see them as agents rather than colonial subjects or paid employees .
Câu hỏi: belief about the effect of an exhibition on people seeing it
=> Câu hỏi nói chung về ảnh hưởng của triển lãm lên những người theo dõi, bài đọc nói rõ ảnh hưởng này là gì (encourage us to see them as … than… - khuyến khích người theo dõi thay đổi cách nhìn nhận của mình)
=> Đáp án là paragraph G','','',10,'belief about the effect of an exhibition on people seeing it
','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 17:56:11','user_05335',false,'2026-06-07 17:56:11','user_05335','C','Trích đoạn chứa đáp án:
Archival research confirms that Europeans were not merely dependent on the work of porters, soldiers, translators, cooks, pilots, glides, hunters and collectors: they also relied on local expertise. Such assistance was essential in identifying potential dangers -poisonous species, unpredictable rivers, uncharted territories - which could mean the difference between life and death.

Keyword cần chú ý:
risks = dangers

Giải thích đáp án:
Bài đọc: Europeans were not merely dependent on the work of.... : they also relied on local expertise
Such assistance was essential in identifying potential dangers - (liệt kê cụ thể dangers)
= Help from local expertise was important in identifying potential dangers, which could save explores’ lives
= Explores need local help to identify potential dangers
Câu hỏi: examples of risks explorers might have been unaware of without local help
= Explorers might have not known about risks without local help
= Explorers need local help to know about risks
=> Đáp án: đoạn C','','',11,'examples of risks explorers might have been unaware of without local help
','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 17:56:31','user_05335',false,'2026-06-07 17:56:31','user_05335','E','Trích đoạn chứa đáp án:
The information provided by locals and intermediaries was of potential importance to geographical science. How was this evidence judged? The formal procedures of scientific evaluation provided one framework. Alongside these were more common sense'' notions of veracity and reliability, religiously-inspired judgments about the authenticity of testimony, and the routine procedures for cross-checking empirical observations developed in many professions.

Keyword cần chú ý:
assess = judge
data from local helpers = The information provided by locals

Giải thích đáp án:
Thông tin trong bài:
(1) The information provided by locals and intermediaries was of potential importance to geographical science. How was this evidence judged?
(2) The formal procedures of evaluation provided ...
(3) Alongside (= Beside) these were ....
=>
(1) The information provided by locals was judged.
(2) The formal way to judge this information is…
(3) Other than this way, other ways to judge this information is….
=> Main idea: Different ways (= approaches) to judge information provided by locals

Câu hỏi: reference to various approaches to assessing data from local helpers
=> Đáp án là đoạn E','','',12,'reference to various approaches to assessing data from local helpers','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 17:56:50','user_05335',false,'2026-06-07 17:56:50','user_05335','F','Trích đoạn chứa đáp án:
Given explorers'' need for local information and support, it was in their interests to develop effective working partnerships with knowledgeable intermediaries who could act as brokers in their dealings with local inhabitants

Keyword cần chú ý:
local assistance = local information and support

Giải thích đáp án:
Thông tin trong bài: Given explorers’ need for local information and support, it was in their interests to develop working partnerships with intermediaries who could act as brokers in their dealings with local inhabitants .
= Explorers need local information and support, so they develop partnerships with people to help them deal with local inhabitants.
= Explorers need local information and support, so there are people who work to help them with local inhabitants.
- Câu hỏi: reference to people whose long-term occupation was to organise local assistance for European explorers
=> Đáp án là đoạn F','','',13,'reference to people whose long-term occupation was to organise local assistance for European explorers','FILL_IN_THE_BLANK',133,NULL),
	 ('2026-06-07 18:02:06','user_05335',false,'2026-06-07 18:02:06','user_05335','X','Trích đoạn chứa đáp án:
But are these vast networks really that relevant to us on a personal level? Robin Dunbar, an evolutionary anthropologist at the University of Oxford, believes that our primate brains place a cap on the number of genuine social relationships we can actually cope with: roughly 150. According to Dunbar, online social networking appears to be very good for ''servicing'' relationships, but not for establishing them. He argues that our evolutionary roots mean we still depend heavily on physical and face-to-face contact to be able to create ties.

Giải thích đáp án:
Phân tích từng câu:
(1): đặt nghi vấn về lợi ích mà vast network mang lại
(2): ví dụ cụ thể về số lượng social relationship thực tế mà ta có thể lo được
(3), (4): đưa ra lập luận củng cố nghi vấn.
=> Main idea: vast network không thật sự có ích như ta nghĩ.
So với list đáp án, ta có:
x. Doubts about values of online socialising','','',28,'Paragraph C','FILL_IN_THE_BLANK',135,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-17 17:31:40','truongdx18vtit',false,'2026-08-17 17:31:40','truongdx18vtit','INCOME',NULL,'','',20,'','FILL_IN_THE_BLANK',156,''),
	 ('2026-06-07 18:01:45','user_05335',false,'2026-06-07 18:01:45','user_05335','I','Trích đoạn chứa đáp án:
The explosion of weak ties could have profound consequences for our social structures too, according to Judith Donath of the Berkman Genter for Internet and Society at Harvard University. ''We’re already seeing changes, '' she says. For example, many people now turn to their online social networks ahead of sources such as newspapers and television for trusted and relevant news or information. What they hear could well be inaccurate, but the change is happening nonetheless. If these huge ''supernets'' - some of them numbering up to 5, 000 people - continue to thrive and grow, they could fundamentally change the way we share information and transform our notions of relationships.

Giải thích đáp án:
Phân tích từng câu:
Câu 1, 2 giới thiệu hiện tượng: tác động của weak ties lên con người
Câu 3, 4 đưa ví dụ cụ thể về việc weak ties khiến con người thay đổi thói quen tìm information
Câu 5 tác động của weak ties lên hành vi con người trong tương lai
=> Main idea: Tác động của weak ties lên hành vi con người
So với list đáp án, ta có:
=> i. A shift in our fact-finding habits
("shift": sự thay đổi)','','',27,'Paragraph B','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:15:01','user_05335',false,'2026-06-07 18:15:01','user_05335','SEAFARING','Trích đoạn chứa đáp án:
They became the greatest traders of the pre-classical world, and were the first people to establish a large colonial network. Both of these activities were based on seafaring, an ability the Phoenicians developed from the example of their maritime predecessors, the Minoans of Crete.

Giải thích đáp án:
Thông tin về "trade" (thương mại, buôn bán) xuất hiện ở đoạn đầu.
Ở đây, tác giả nói người Phoenix là những "traders" (thương nhân) của thế giới cổ nhờ "seafaring" (kĩ năng đi tàu vượt biển).
-> Đáp án là "seafaring"','','',1,'The Phoenicians’ skill at……………………………….helped them to trade.','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:15:22','user_05335',false,'2026-06-07 18:15:22','user_05335','MERCHANT','Trích đoạn chứa đáp án:
One of the characters is Wereket-El, a Phoenician merchant living at Tanis in Egypt’s Nile delta. As many as 50 ships carry out his business, plying back and forth between the Nile and the Phoenician port of Sidon.

Keyword cần chú ý:
merchant from Phoenicia = Phoenician merchant

Giải thích đáp án:
Từ khoá "50 ships" giúp ta xác định vị trí thông tin ở đoạn 2.
Đoạn này tác giả đang nói đến một "merchant" (thương nhân) ở Egypt và có 50 ships.
-> Đáp án là "merchant"','','',2,'In an ancient story, a…………………………………..from Phoenicia, who lived in Egypt, owned 50 ships.','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:15:42','user_05335',false,'2026-06-07 18:15:42','user_05335','TEMPLE','Trích đoạn chứa đáp án:
Hiram, the king of the Phoenician city of Tyre, was an ally and business partner of Solomon, King of Israel. For Solomon’s temple in Jerusalem, Hiram provided craftsmen with particular skills that were needed for this major construction project. He also supplied materials – particularly timber, including cedar from the forests of Lebanon.

Keyword cần chú ý:
supplies from Phoenicia ~ supplied materials

Giải thích đáp án:
Từ khoá về "king of Israel" và "supplies/supplied" xuất hiện ở đoạn 3.
Tác giả nói Hiram cung cấp "materials" (vật liệu) để xây "Solomon''s temple" (chùa cho Solomon).
-> Đáp án là "temple"','','',3,'A king of Israel built a…………………………………….using supplies from Phoenicia.','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:16:03','user_05335',false,'2026-06-07 18:16:03','user_05335','CRAFTSMEN','Trích đoạn chứa đáp án:
Hiram, the king of the Phoenician city of Tyre, was an ally and business partner of Solomon, King of Israel. For Solomon’s temple in Jerusalem, Hiram provided craftsmen with particular skills that were needed for this major construction project. He also supplied materials – particularly timber, including cedar from the forests of Lebanon.

Keyword cần chú ý:
supplied = provided
skilled craftsmen = craftsmen with skills

Giải thích đáp án:
Trong đoạn về những thứ Hiram giúp xây Solomon''s temple, từ "skills/skilled" dùng để chỉ "craftsmen" (thợ thủ công).
-> Đáp án là "craftsmen"','','',4,'Phoenicia supplied Solomon with skilled…………………………….','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:16:21','user_05335',false,'2026-06-07 18:16:21','user_05335','TIMBER/WOOD/CEDAR','Trích đoạn chứa đáp án:
Hiram, the king of the Phoenician city of Tyre, was an ally and business partner of Solomon, King of Israel. For Solomon’s temple in Jerusalem, Hiram provided craftsmen with particular skills that were needed for this major construction project. He also supplied materials – particularly timber, including cedar from the forests of Lebanon.

Giải thích đáp án:
Trong các materials, vật liệu chính là "timber" (gỗ). Tác giả nói thêm là trong đó có "cedar" (gỗ tùng).
-> Đáp án là "timber/wood/cedar"','','',5,'The main material that Phoenicia sent to Israel was……………………………','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:16:46','user_05335',false,'2026-06-07 18:16:46','user_05335','PARTNERSHIP','Trích đoạn chứa đáp án:
And the two kings went into trade in partnership.

Keyword cần chú ý:
the kings of Phoenicia and Israel ~ the two kings
to carry out trade = trade

Giải thích đáp án:
Bài đọc: Hai vị vua thực hiện trade qua "partnership" (hợp tác).
-> Đáp án là "partnership"','','',6,'
Giải thích chi tiết đá','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:17:05','user_05335',false,'2026-06-07 18:17:05','user_05335','IVORY','Trích đoạn chứa đáp án:
The cedar wood was not only exported as top-quality timber for architecture and shipbuilding. It was also carved by the Phoenicians, and the same skill was adapted to even more precious work in ivory.

Giải thích đáp án:
Từ "carved" (khắc) giúp xác định vị trí thông tin ở đoạn 4, cụ thể là câu về "cedar wood" (gỗ tùng) được khắc và "ivory" (ngà) cũng được khắc.
-> Đáp án là "ivory"','','',7,'Phoenicians carved………………………………………., as well as cedar.','FILL_IN_THE_BLANK',136,NULL),
	 ('2026-06-07 18:17:23','user_05335',false,'2026-06-07 18:17:23','user_05335','COMMISSION','Trích đoạn chứa đáp án:
In addition, as traders and middlemen, they took a commission on a much greater range of precious goods that they transported from elsewhere.

Keyword cần chú ý:
shipping goods = transporting goods

Giải thích đáp án:
Tác giả nói về "goods" ở đoạn 5 và 6.
Trong đoạn 8, tác giả nói về việc người Phoenix nhận "commission" (đặt hàng) vận chuyển các sản phẩm quý từ nơi khác.
-> Đáp án là "commission"','','',8,'The Phoenicians also earned a………………………………………. for shipping goods.','FILL_IN_THE_BLANK',136,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:13:03.467782','user_56659',false,'2026-06-07 19:13:03.467782','user_56659','EVIDENCE','Trích đoạn chứa đáp án:
But what they often lack is the evidence to base policies on.

Keyword cần chú ý:
difficult to find = lack
support new policies = base policies on

Giải thích đáp án:
Đáp án sau động từ “find” → đáp án là 1 danh từ
Câu hỏi: những chính sách quốc tế về sự vui chơi của trẻ em gặp khó khăn trong việc tìm chứng cứ để xác nhận/ủng hộ những chính sách mới này → “evidence” là đáp án của câu hỏi này',NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 18:17:42','user_05335',false,'2026-06-07 18:17:42','user_05335','TRUE','Trích đoạn chứa đáp án:
But the main expansion came from the 8th century BC onwards, when pressure from Assyria to the east disrupted the patterns of trade on the Phoenician coast.

Keyword cần chú ý:
the establishment of a number of Phoenician colonies ~ main expansion
problems with Assyria ~ pressure from Assyria to the east disrupted the patterns of trade on the Phoenician coast

Giải thích đáp án:
Câu hỏi: Các vấn đề với Assyria dẫn đến sự thành lập một số thuộc địa Phoenix.
Từ khoá "Assyria" giúp xác định vị trí thông tin ở đoạn 7.
Bài đọc: Sự mở rộng bắt đầu từ TK 8 TCN khi áp lực từ Assyria ở phía Đông phá vỡ các liên minh thương mại ở bờ biển Phoenix.
-> TRUE','','',9,'Problems with Assyria led to the establishment of a number of Phoenician colonies.','TRUE_FALSE_NOT_GIVEN',136,NULL),
	 ('2026-06-07 18:18:16','user_05335',false,'2026-06-07 18:18:16','user_05335','FALSE','Trích đoạn chứa đáp án:
Carthage was the largest of the towns founded by the Phoenicians on the North African coast, and it rapidly assumed a leading position among the neighbouring colonies.

Giải thích đáp án:
Câu hỏi: Carthage là một thị trấn đối thủ mà người Phoenix đã thắng.
Từ khoá "Carthage" được nói đến ở đoạn 9.
Bài đọc: Carthage là thị trấn lớn nhất được thành lập bởi người Phoenix.
-> FALSE','','',10,'Carthage was an enemy town which the Phoenicians won in battle.','TRUE_FALSE_NOT_GIVEN',136,NULL),
	 ('2026-06-07 18:18:35','user_05335',false,'2026-06-07 18:18:35','user_05335','TRUE','Trích đoạn chứa đáp án:
The subsequent spread and growth of Phoenician colonies in the western Mediterranean, and even out to the Atlantic coasts of Africa and Spain, was as much the achievement of Carthage.

Keyword cần chú ý:
reached the Atlantic Ocean = (spread) out to the Atlantic coasts of Africa and Spain

Giải thích đáp án:
Câu hỏi: Người Phoenix đến tận Đại Tây Dương.
Từ khoá "Atlantic (Ocean)" xuất hiện ở đoạn 10.
Bài đọc: Các thuộc địa của Phoenix mở rộng ở Tây biển Địa Trung Hải, đến tận bờ biển Đại Tây Dương của châu Phi và Tây Ban Nha.
-> TRUE','','',11,'Phoenicians reached the Atlantic ocean.','TRUE_FALSE_NOT_GIVEN',136,NULL),
	 ('2026-06-07 18:18:54','user_05335',false,'2026-06-07 18:18:54','user_05335','TRUE','Trích đoạn chứa đáp án:
From the 8th century BC, many of the coastal cities of Phoenicia came under the control of a succession of imperial powers.

Keyword cần chú ý:
parts of Phoenicia = many of the coastal cities of Phoenicia
conquered by a series of empires = came under the control of a succession of imperial powers

Giải thích đáp án:
Câu hỏi: Một phần Phoenicia bị thôn tính bởi một loạt các đế chế.
Thông tin về Phoenicia bị xâm lược có ở đoạn 11.
Bài đọc: Từ TK 8 TCN, nhiều thành phố giáp biển của Phoenicia chịu sự thống trị của nhiều thế lực đế quốc.
-> TRUE','','',12,'Parts of Phoenicia were conquered by a series of empires.','TRUE_FALSE_NOT_GIVEN',136,NULL),
	 ('2026-06-07 18:19:13','user_05335',false,'2026-06-07 18:19:13','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
In 64 BC, the area of Phoenicia became part of the Roman province of Syria. The Phoenicians as an identifiable people then faded from history, merging into the populations of modern Lebanon and northern Syria.

Giải thích đáp án:
Câu hỏi: Người Phoenix chào đón sự kiểm soát của người La Mã.
Bài đọc: Không có thông tin về phản ứng của người Phoenix khi quân La Mã đến.
-> NOT GIVEN','','',13,'The Phoenicians welcomed Roman control of the area.','TRUE_FALSE_NOT_GIVEN',136,NULL),
	 ('2026-06-07 18:24:42','user_05335',false,'2026-06-07 18:24:42','user_05335','E','Trích đoạn chứa đáp án:
The results showed that the parrots with the strongest foot preferences worked out the puzzle far more quickly than their ambidextrous peers.

Keyword cần chú ý:
the greater an animal’s lateralization = the parrots with the strongest foot preferences
the better it is at problem-solving = worked out the puzzle far more quickly

Giải thích đáp án:
Kết quả nghiên cứu của Magat và Brown là vẹt có đặc tính thuận chân rõ nhất thì giải puzzle nhanh hơn những con dùng cả hai chân như nhau.
-> Con có đặc tính lateralization mạnh hơn thì có khả năng giải đố tốt hơn
-> E. the greater an animal’s lateralization, the better it is at problem-solving.','','',29,'Magat and Brown’s studies show that','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:23:56','user_05335',false,'2026-06-07 18:23:56','user_05335','D','Trích đoạn chứa đáp án:
For example, in the 1970s, Lesley Rogers, now at the University of New England in Australia, was studying memory and learning in chicks. She had been injecting a chemical into chicks’ brains to stop them learning how to spot grains of food among distracting pebbles, and was surprised to observe that the chemical only worked when applied to the left hemisphere of the brain. That strongly suggested that the right side of the chick’s brain played little or no role in the learning of such behaviours. Similar evidence appeared in songbirds and rats around the same time, and since then, researchers have built up an impressive catalogue of animal lateralization.

Giải thích đáp án:
Những năm 1970s, Lesley Rogers làm nghiên cứu và phát hiện ra nhiều loài có lateralization.
-> Lateralization không phải chỉ có ở con người
-> D. lateralization is not confined to human beings.','','',27,'
In the 1970s, Lesley Rogers discovered that','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:25:32','user_05335',false,'2026-06-07 18:25:32','user_05335','ENVIRONMENTAL','Trích đoạn chứa đáp án:
Genetics plays a part in determining lateralization, but environmental factors have an impact too.

Keyword cần chú ý:
influence = impact

Giải thích đáp án:
Nghiên cứu của Rogers năm 2004 là nội dung đoạn D. Đây cũng là vị trí thông tin cho các câu 31-35.
Các yếu tố ảnh hưởng đến hay quyết định lateralization trong bài đọc là "genetics" (di truyền) và "environmental factors" (các yếu tố môi trường).
-> Đáp án là "environmental"','','',31,'','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 17:28:14','user_05335',false,'2026-06-07 17:28:14','user_05335','VII','Trích đoạn chứa đáp án:
The great thing about kefir is that it does not require a manufacturing line in order to be produced. Grains can be simply thrown in with a batch of milk for ripening to begin. The mixture then requires a cool, dark place to live and grow, with periodic unsettling to prevent clumping (Caucasus inhabitants began storing the concoction in animal-skin satchels on the back of doors – every time someone entered the room the mixture would get lightly shaken). After about 24 hours the yeast cultures in the grains have multiplied and devoured most of the milk sugars, and the final product is then ready for human consumption.

Giải thích đáp án:
Phân tích từng câu:
(1) Quy trình sản xuất kefir đơn giản, không cần dây chuyền sản xuất
(2) - (5) Lần lượt liệt kê từng bước của quy trình sản xuất
=> Main idea: Có thể thấy, tổng quan cả đoạn xoay quanh cách sản xuất, tạo ra kefir
So với list of heading:
Chọn heading vii. Making kefir','','',16,'Paragraph C','FILL_IN_THE_BLANK',131,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-18 17:31:40','truongdx18vtit',false,'2026-08-18 17:31:40','truongdx18vtit','17TH CENTURY',NULL,'','',21,'What period of English literature will the conference cover?','FILL_IN_THE_BLANK',157,''),
	 ('2026-06-07 17:29:38','user_05335',false,'2026-06-07 17:29:38','user_05335','II','Trích đoạn chứa đáp án:
Kefir’s rise in popularity has encouraged producers to take short cuts or alter the production process. Some home users have omitted the ripening and culturation process while commercial dealers often add thickeners, stabilisers and sweeteners. But the beauty of kefir is that, at its healthiest and tastiest, it is a remarkably affordable, uncluttered process, as any accidental invention is bound to be. All that is necessary are some grains, milk and a little bit of patience. A return to the unadulterated kefir-making of old is in everyone’s interest.

Giải thích đáp án:
Phân tích từng câu:
(1) Có sự thay đổi trong quá trình sản xuất kefir (change the production process)
(2) Làm rõ sự thay đổi này: Some users… while commercial dealers…
(3) (4) Tương phản câu (1) + (2): Mọi người cố gắng thay đổi cách tạo ra kefir nhưng bản chất cách tạo ra nó rất đơn giản và không mắc tiền (affordable)
(5) Cần trở lại cách cũ để làm ra kefir
=> Main idea: Không cần phải thay đổi quá trình sản xuất kefir, nên trở về với cách làm cũ
=> Heading: ii Getting back to basics
(basics = những điều cơ bản nhất)','','',20,'Paragraph G','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:30:05','user_05335',false,'2026-06-07 17:30:05','user_05335','CAULIFLOWER ROSETTES','Trích đoạn chứa đáp án:
This is because the grains, which are granular to the touch and bear a slight resemblance to cauliflower rosettes, house active cultures that feed on lactose when added to milk.

Keyword cần chú ý:
look like = bear a slight resemblance to

Giải thích đáp án:
Bài đọc: The grains bear a slight resemblance to cauliflower rosettes.
Câu hỏi: Kefir grains looks like [what]?
=> Đáp án: cauliflower rosettes','','',21,'What do kefir grains look like?','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:28:38','user_05335',false,'2026-06-07 17:28:38','user_05335','I','Trích đoạn chứa đáp án:
Nothing compares to a person’s first encounter with kefir. The smooth, uniform consistency rolls over the tongue in a manner akin to liquefied yogurt. The sharp, tart pungency of unsweetened yogurt is there too, but there is also a slight hint of effervescence, something most users will have previously associated only with mineral waters, soda or beer. Kefir also comes with a subtle aroma of yeast, and depending on the type of milk and ripening conditions, ethanol content can reach up to two or three percent – about on par with a decent lager – although you can expect around 0.8 to one per cent for a typical day-old preparation. This can bring out a tiny edge of alcohol in the kefir’s flavour.

Giải thích đáp án:
Phân tích từng câu:
(1) Trải nghiệm khi lần đầu nếm kefir rất đặc biệt, không gì so sánh được
(2) - (5) Giải thích rõ hơn mùi vị của kefir ( smooth, sharp, slight, subtle, có mùi alcohol…)
=> Main idea: Mùi vị đặc biệt của kefir
So với list of heading:
Chọn heading i. A unique sensory experience
(trải nghiệm giác quan đặc biệt)','','',17,'Paragraph D','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:38:24','user_05335',false,'2026-06-07 17:38:24','user_05335','CITIES','Trích đoạn chứa đáp án:
According to theoretical physicist Geoffrey West, when corporate institutions get bigger, they often become less receptive to change. Cities, however, allow our ingenuity to grow by pulling huge numbers of different people together, who then exchange ideas.

Keyword cần chú ý:
creativity = ingenuity

Giải thích đáp án:
Bài đọc: Cities allow our ingenuity to grow .
=> Cities encourage our ingenuity.
Câu hỏi: living in ______ encourages creativity
=> Đáp án: cities','','',39,'','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:27:53','user_05335',false,'2026-06-07 17:27:53','user_05335','III','Trích đoạn chứa đáp án:
Although their exact origin remains a mystery, we do know that yeast-based kefir grains have always been at the root of the kefir phenomenon. These grains are capable of a remarkable feat: in contradistinction to most other items you might find in a grocery store, they actually expand and propagate with use. This is because the grains, which are granular to the touch and bear a slight resemblance to cauliflower rosettes, house active cultures that feed on lactose when added to milk. Consequently, a bigger problem for most kefir drinkers is not where to source new kefir grains, but what to do with the ones they already have!

Giải thích đáp án:
Phân tích từng câu:
(1) Giới thiệu tầm quan trọng của kefir grains
(2) Kefir grains ngày càng có nhiều công dụng
(3) Lí do kefir grains có nhiều công dụng
(4) Vì có nhiều công dụng nên kefir drinkers (người uống kefir) không biết phải làm gì với nó.
=> Main idea: Có thể thấy, tổng quan cả đoạn xoay quanh việc kefir có nhiều công dụng như thế nào, và số lượng công dụng (uses) của nó ngày càng tăng
So với list of heading:
Chọn heading iii. The gift that keeps on giving
(Một món quà không người cho đi, không ngừng cống hiến)','','',15,'Paragraph B','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:27:22','user_05335',false,'2026-06-07 17:27:22','user_05335','VIII','Trích đoạn chứa đáp án:
The shepherds of the North Caucasus region of Europe were only trying to transport milk the best way they knew how – in leather pouches strapped to the side of donkeys – when they made a significant discovery. A fermentation process would sometimes inadvertently occur enroute, and when the pouches were opened up on arrival they would no longer contain milk but rather a pungent, effervescent, low- alcoholic substance instead. This unexpected development was a blessing in disguise. The new drink – which acquired the name kefir – turned out to be health tonic, a naturally-preserved dairy product and a tasty addition to our culinary repertoire.

Giải thích đáp án:
Phân tích đoạn:
(1) + (2) + (3) The shepherds discovered a new substance while transporting milk.
(4) Nói về tầm quan trọng của new substance (=new drink) này
=> Main idea: Shepherds tình cờ phát hiện new drink khi đang vận chuyển milk và phát hiện này rất quan trọng
So với list of heading:
Chọn heading viii. A fortunate accident (Một phát hiện tình cờ may mắn)','','',14,'Paragraph A','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:31:10','user_05335',false,'2026-06-07 17:31:10','user_05335','LIQUEFIED YOG(H)URT','Trích đoạn chứa đáp án:
Nothing compares to a person’s first encounter with kefir.
The smooth, uniform consistency rolls over the tongue in a manner akin to liquefied yogurt.

Keyword cần chú ý:
The texture = The smooth, uniform consistency
in the mouth = over the tongue
similar to = akin to

Giải thích đáp án:
Bài đọc: The smooth, uniform consistency rolls over the tongue in a manner akin to liquefied yogurt .
= The texture (of kefir) rolls over the tongue in a way similar to liquefied yogurt
Câu hỏi: The texture of kefir in the mouth is similar to [what]?
=> Đáp án: liquefied yogurt','','',24,'
The texture of kefir in the mouth is similar to what?','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-08-19 17:31:40','truongdx18vtit',false,'2026-08-19 17:31:40','truongdx18vtit','5',NULL,'','',22,'
How many panel discussions have been arranged?','FILL_IN_THE_BLANK',157,''),
	 ('2026-08-20 17:31:40','truongdx18vtit',false,'2026-08-20 17:31:40','truongdx18vtit','VIEWS',NULL,'','',23,'What is the aim of a panel discussion? To present','FILL_IN_THE_BLANK',157,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-21 17:31:40','truongdx18vtit',false,'2026-08-21 17:31:40','truongdx18vtit','CONFLICT',NULL,'','',24,'','FILL_IN_THE_BLANK',157,''),
	 ('2026-06-07 17:29:18','user_05335',false,'2026-06-07 17:29:18','user_05335','IX','Trích đoạn chứa đáp án:
Associated for centuries with pictures of Slavic babushkas clutching a shawl in one hand and a cup of kefir in the other, the unassuming beverage has become a minor celebrity of the nascent health food movement in the contemporary West. Every day, more studies pour out supporting the benefits of a diet high in probiotics . This trend toward consuming probiotics has engulfed the leisure classes in these countries to the point that it is poised to become, according to some commentators, “the next multivitamin”. These days the word kefir is consequently more likely to bring to mind glamorous, yoga mat-toting women from Los Angeles than austere visions of blustery Eastern Europe.

Giải thích đáp án:
Phân tích từng câu:
(1) Kafir đại diện cho trào lưu thức ăn lành mạnh (health food movement)
(2) Các nghiên cứu chỉ ra lợi ích sức khoẻ của chế độ ăn này
(3) Nhắc lại trào lưu xem trọng lợi ích sức khoẻ của kafir, xem nó như multivitamin
(4) Hình ảnh xuất hiện trong đầu khi nghĩ tới kefir: sang chảnh, lành mạnh (yoga) thay vì hình ảnh Đông Âu (nhắc lại ý Slavic ở câu đầu)
=> Main idea: Kefir thay đổi hình ảnh, không còn gắn với hình ảnh Đông Âu mà gắn liền với hình ảnh chế độ ăn uống lành mạnh
=> Heading: ix. Kefir gets an image makeover
(image makeover = sự thay đổi hình ảnh)','','',19,'Paragraph F','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:30:50','user_05335',false,'2026-06-07 17:30:50','user_05335','MILK SUGARS','Trích đoạn chứa đáp án:
After about 24 hours the yeast cultures in the grains have multiplied and devoured most of the milk sugars, and the final product is then ready for human consumption.

Keyword cần chú ý:
consumed = devoured
kefir = the final product
ready to drink = ready for human consumption

Giải thích đáp án:
Bài đọc: The yeast cultures have devoured the milk sugars, and the final product is then ready for human consumption.
= The yeast cultures have consumed the milk sugars before kefir is ready to drink.
Câu hỏi: The yeast cultures have consumed [what] before kefir is ready to drink
=> Đáp án: milk sugars','','',23,'What will the yeast cultures have consumed before kefir is ready to drink?
','FILL_IN_THE_BLANK',131,NULL),
	 ('2026-06-07 17:36:12','user_05335',false,'2026-06-07 17:36:12','user_05335','D','Trích đoạn chứa đáp án:
Some now have a policy of encouraging staff to take time out during the day and spend time on things that at first glance are unproductive (like playing a PC game), but daydreaming has been shown to be positively correlated with problem-solving.

Keyword cần chú ý:
employees = staff
stop working = take time out
finding answers = problem-solving

Giải thích đáp án:
Bài đọc: Staff are encouraged to take time out to day-dream because it can increase the chance of problem-solving.
So với lựa chọn D: Some companies require their employees to stop working so they can increase the possibility of finding answers.
=> Trùng khớp
=> Đáp án: D','','',33,'Some companies require their employees to stop working','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:37:45','user_05335',false,'2026-06-07 17:37:45','user_05335','CONVERSATIONS','Trích đoạn chứa đáp án:
Lehrer says he has taken all this on board, and despite his inherent shyness, when he''s sitting next to strangers on a plane or at a conference, forces himself to initiate conversations.

Keyword cần chú ý:
start conversations = initiate conversations
new people = strangers

Giải thích đáp án:
Bài đọc: Lehrer forces himself to initiate conversations.
=> Lehrer thinks it is important to initiate conversations (chỉ khi cảm thấy việc đó quan trọng thì mới “ép" bản thân phải làm việc đó)
Câu hỏi: It’s important to start _______ with new people.
=> Đáp án: conversations','','',37,'','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:35:08','user_05335',false,'2026-06-07 17:35:08','user_05335','C','Trích đoạn chứa đáp án:
Instead, the right hemisphere of the brain is assembling connections between past influences and making something entirely new. Neuroscientists have roughly charted this process by mapping the brains of people doing word puzzles solved by making sense of remotely connecting information For instance, subjects are given three words such as ''age'', ''mile'' and ''sand'' and asked to come up with a single word that can precede or follow each of them to form a compound word. (It happens to be ''stone''.) Using brain-imaging equipment, researchers discovered that when people get the answer in an apparent flash of insight, a small fold of tissue called the anterior superior temporal gyrus suddenly lights up just beforehand. This stays silent when the word puzzle is solved through careful analysis. Lehrer says that this area of the brain lights up only after we''ve hit the wall on a problem. Then the brain starts hunting through the ''filing cabinets of the right hemisphere'' to make the connections that produce the right answer.

Keyword cần chú ý:
become active => light up

Giải thích đáp án:
Phân tích từng câu:
(1) + (2) Word puzzles experiment to test out brain processes
(3) MIêu tả experiment này
(4) -> (7) Kết quả thí nghiệm: A part of the brain lights up before people get the answer
=> Main Idea: The results of the word puzzles experiment showed that a part of the brain lights up before people get the answer
=> Đáp án: C One part of the brain only becomes active when a connection is made suddenly.','','["A. Memories are easier to retrieve when they are more meaningful.","B. An analytical approach to problem-solving is not necessarily effective.","C. One part of the brain only becomes active when a connection is made suddenly.","D. Creative people tend to take a more instinctive approach to solving language problems."]',30,'What did neuroscientists discover from the word puzzle experiment?','MULTIPLE_CHOICE',132,NULL),
	 ('2026-06-07 17:35:54','user_05335',false,'2026-06-07 17:35:54','user_05335','C','Trích đoạn chứa đáp án:
In contrast, when we are diligently focused, our attention tends to be towards the details of the problems we are trying to solve.'' In other words, then we are less likely to make those vital associations.

Keyword cần chú ý:
connection = association
concentrate (v) (concentrating) = focus (v) (focused)
the specifics of a problem = the details of the problem

Giải thích đáp án:
Bài đọc: When we focus on the details of the problems, we are less likely to make associations.
(less likely = have a lower chance = có khả năng thấp hơn)
= When we focus on the details of the problems, making associations is harder.
Lựa chọn C: if people are concentrating on the specifics of a problem, Mental connections are much harder to make
=> Đáp án: C','','',32,'Mental connections are much harder to make','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:38:08','user_05335',false,'2026-06-07 17:38:08','user_05335','INTERNET','Trích đoạn chứa đáp án:
As for predictions that the rise of the Internet would make the need for shared working space obsolete, Lehrer says research shows the opposite has occurred; when people meet face to face, the level of creativity increases.

Keyword cần chú ý:
physical contact = meet face to face

Giải thích đáp án:
Bài đọc: People predict that the Internet would reduce the need for working together in the same place. However, it is not true because face-to-face meetings increase creativity.
=> The Internet has not replaced the need for face-to-face meetings.
Câu hỏi: The _______ has not replaced the need for physical contact.
=> Đáp án: Internet','','',38,'','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-08-22 17:31:40','truongdx18vtit',false,'2026-08-22 17:31:40','truongdx18vtit','MODERATOR',NULL,'','',25,'','FILL_IN_THE_BLANK',157,''),
	 ('2026-08-23 17:31:40','truongdx18vtit',false,'2026-08-23 17:31:40','truongdx18vtit','FORMAT',NULL,'','',26,'','FILL_IN_THE_BLANK',157,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-08-24 17:31:40','truongdx18vtit',false,'2026-08-24 17:31:40','truongdx18vtit','BIOGRAPHICAL',NULL,'','',27,'','FILL_IN_THE_BLANK',157,''),
	 ('2026-06-07 17:37:16','user_05335',false,'2026-06-07 17:37:16','user_05335','WORKPLACE','Trích đoạn chứa đáp án:
Lehrer describes how at Pixar Animation, Jobs designed the entire workplace to maximise the chance of strangers bumping into each other, striking up conversations and learning from one another.

Keyword cần chú ý:
made changes to the workplace = designed the entire workplace
encourage interaction = maximise the chance of strangers bumping into each other, striking up conversations

Giải thích đáp án:
Bài đọc: at Pixar Animation , Jobs designed the entire workplace to maximize the chance of strangers bumping into each other, striking up conversations and learning from one another.
=> Jobs designed the workplace to increase conversations between employees at Pixar
Câu hỏi: Steve Jobs: made changes to the ______ to encourage interaction at Pixar.
=> Đáp án: workplace','','',35,'','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:39:06','user_05335',false,'2026-06-07 17:39:06','user_05335','A','Giải thích đáp án:
Để trả lời được câu hỏi Multiple Choice dạng tổng kết cả bài, thí sinh cần có khả năng nhìn được main idea của cả bài đọc và nắm được nội dung chính của từng đoạn.
Main idea và cấu trúc cả bài đọc có thể được tóm tắt như sau:
Paragraph 1: Give example of Swiffer - an unexpected invention
Paragraph 2: It is important to write about the eureka moment as well as the hard work after it
Paragraph 3: Ideas can come unexpectedly and suddenly.
Paragraph 4: Changes in the brain before an idea arrived
Paragraph 5-6: ISS should do more commercial research
Paragraph 7: Factors which encourage creativity (face-to-face contact, living in cities…)
=> Main idea: Nội dung lặp lại xuyên suốt bài là bàn về cội nguồn sáng tạo: sáng tạo tới như thế nào, từ đâu ra, những yếu tố kích thích sự sáng tạo
=> Chọn A Understanding what drives our moments of inspiration
Lí do không chọn những đáp án khác:
B Challenging traditional theories of human creativity
=> Không chọn B vì trong bài không nói gì về việc thay đổi quan điểm “truyền thống" về sự sáng tạo
C Creative solutions for enhancing professional relationships
=> Main idea của bài tập trung vào những phát minh sáng tạo, không phải tập trung vào cải thiện mối quan hệ công việc
D How the future is shaped by innovative ideas and inspired people
=> Không chọn vì bài không bài gì tới tương lai','','["A. Understanding what drives our moments of inspiration","B. Challenging traditional theories of human creativity","C. Creative solutions for enhancing professional relationships","D. How the future is shaped by innovative ideas and inspired people"]',40,'Which of the following is the most suitable title for Reading Passage 3?
','MULTIPLE_CHOICE',132,NULL),
	 ('2026-06-07 17:34:28','user_05335',false,'2026-06-07 17:34:28','user_05335','A','Trích đoạn chứa đáp án:
He writes of how burnt-out American singer Bob Dylan decided to walk away from his musical career in 1965 and escape to a cabin in the woods, only to be overcome by a desire to write. Apparently ''Like a Rolling Stone'' suddenly flowed from his pen. ''It''s like a ghost is writing a song,'' Dylan has reportedly said. ''It gives you the song and it goes away.'' But it''s no ghost, according to Lehrer.

Keyword cần chú ý:
spontaneous = unexpected, suddenly, without planning

Giải thích đáp án:
Phân tích từng câu:(1) Bob Dylan left his musical career but suddenly wanted to write.
(2) He suddenly and unexpectedly wrote the song “Like A Rolling Stone"
(3) + (4) + (5) Nhấn mạnh bài hát được viết nhanh và đột ngột như thế nào, như thể “a ghost is writing a song"
=> Main idea: The idea for the song came to Bob Dylan unexpectedly and suddenly.
=> Đáp án: A illustrate how ideas seem spontaneous.','','["A. illustrate how ideas seem spontaneous.","B. exemplify ways in which we might limit our inventiveness.","C. contrast different approaches to stimulating the imagination.","D. propose particular approaches to regaining lost creativity."]',29,'Lehrer refers to the singer Bob Dylan in order to','MULTIPLE_CHOICE',132,NULL),
	 ('2026-06-07 17:35:32','user_05335',false,'2026-06-07 17:35:32','user_05335','B','Trích đoạn chứa đáp án:
Studies have demonstrated it''s possible to predict a moment of insight up to eight seconds before it arrives. The predictive signal is a steady rhythm of alpha waves emanating from the brain''s right hemisphere, which are closely associated with relaxing activities.

Keyword cần chú ý:
know a moment of insight is coming = predict a moment of insight + The predictive signal
greater activity in the right side of the brain = alpha waves emanating from the brain''s right hemisphere

Giải thích đáp án:
Bài đọc: The predictive signal is a steady rhythm of alpha waves emanating from the brain’s right hemisphere
Lựa chọn B: Scientists know a moment of insight is coming because there is greater activity in the right side of the brain.
=> Trùng khớp
=> Đáp án: B','','',31,'Scientists know a moment of insight is coming','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:36:58','user_05335',false,'2026-06-07 17:36:58','user_05335','A','Trích đoạn chứa đáp án:
However, to be more imaginative, says Lehrer, it''s also crucial to collaborate with people from a wide range of backgrounds because if colleagues are too socially intimate, creativity is stifled.

Keyword cần chú ý:
familiar with one another = socially intimate

Giải thích đáp án:
Bài đọc: It is better to collaborate with people who are not too socially close to each other.
- Lựa chọn A:
A team will function more successfully when people are not too familiar with one another.
=> Trùng khớp
=> Chọn A. when people are not too familiar with one another','','',34,'A team will function more successfully','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 17:37:30','user_05335',false,'2026-06-07 17:37:30','user_05335','ACQUAINTANCES','Giải thích đáp án:
Bài đọc:
1. He also points to a study of 766 business graduates who had gone on to own their own companies.
2. Those with the greatest diversity of acquaintances enjoyed far more success.
Câu hỏi: company owners must have a wide range of ______ to do well.
=> Đáp án: acquaintances','','',36,'','FILL_IN_THE_BLANK',132,NULL),
	 ('2026-06-07 16:53:06','user_05335',false,'2026-06-07 16:53:06','user_05335','D','Trích đoạn chứa đáp án:
They might not come close to the ISS’s orbit, yet Stern believes they will revolutionise the way we, the public, see space.
Soon everyone will be dreaming of interplanetary travel again, he predicts.

Keyword cần chú ý:
space exploration = interplanetary travel
ordinary people = the public

Giải thích đáp án:
Câu hỏi: commercial flights might make the whole idea of space exploration seem ________ to ordinary people
=> Đáp án: D. real','','',37,'','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 17:57:38','user_05335',false,'2026-06-07 17:57:38','user_05335','(ELECTRIC) CHARGE','Trích đoạn chứa đáp án:
When an insect brushes against them, this triggers a tiny electric charge, which travels down tunnels in the leaf.

Keyword cần chú ý:
Small (electric) charge = tiny electric charge
passes through = travels

Giải thích đáp án:
Bài đọc: When an insect brushes against them , this triggers tiny electric charge , which travels down tunnels in the leaf] ....
=> “Which" là vế mở đầu mệnh đề quan hệ, bổ nghĩa cho “electric charge"
=> Tiny electric charge travels down tunnels in the leaf
Câu hỏi:
Small _______ passes through leaf
=> Đáp án: Electric charge','','',15,'','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-08-25 17:31:40','truongdx18vtit',false,'2026-08-25 17:31:40','truongdx18vtit','GESTURE',NULL,'','',28,'','FILL_IN_THE_BLANK',157,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:50:34','user_05335',false,'2026-06-07 16:50:34','user_05335','D','Trích đoạn chứa đáp án:
To get the ISS research back on track, CASIS has examined more than 100 previous microgravity experiments to identify promising research themes. From this, it has opted to focus on life science and medical research, and recently called for proposals for experiments on muscle wasting, osteoporosis and the immune system.

Keyword cần chú ý:
invited researchers to suggest = called for proposals
health-based projects = experiments on muscle wasting, osteoporosis and the immune system

Giải thích đáp án:
It (= CASIS) has opted to focus on life science and medical research , and called for proposals for experiments on muscle wasting, osteoporosis and the immune system.
= CASIS called for proposals for experiments on health.
So với đáp án D: CASIS has invited researchers to suggest certain health-based projects. => trùng khớp
=> Đáp án: D','','["A. rejected certain applications for experiments on the ISS.","B. expressed concern about testing products used for profit.","C. questioned the benefits of some of the projects currently on the ISS.","D. invited researchers to suggest certain health-based projects."]',30,'In the sixth paragraph, we are told that CASIS has','MULTIPLE_CHOICE',129,NULL),
	 ('2026-06-07 16:53:39','user_05335',false,'2026-06-07 16:53:39','user_05335','G','Trích đoạn chứa đáp án:
This demand for low-cost space flight could eventually lead to a service running on a more frequent basis, giving researchers the chance to test their ideas before submitting a proposal for experiments on the ISS. Getting flight experience should help them win a slot on the station, says Stern.

Keyword cần chú ý:
working on a commercial flight = Getting flight experience
an ISS position = a slot on the station

Giải thích đáp án:
Câu hỏi: And by working on a commercial flight first, scientists would be more _______ if an ISS position came up.
=> Trong list các lựa chọn, G. suitable là đáp án phù hợp nhất.
And by working on a commercial flight first, scientists would be more suitable if an ISS position came up (= they can get a slot on the station more easily)
=> Đáp án: G. suitable','','',39,'','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:52:33','user_05335',false,'2026-06-07 16:52:33','user_05335','A','Trích đoạn chứa đáp án:
The only way to test this is in weightlessness, and the only time we have to do that is on the space station,’ says Laurence Young, a space medicine expert at the Massachusetts Institute of Technology.

Keyword cần chú ý:
assess = test
an absence of gravity = weightlessness

Giải thích đáp án:
Câu hỏi: To properly assess new space technology, there has to be an absence of gravity.
=> Đáp án: A. Laurence Young','','',35,'To properly assess new space technology, there has to be an absence of gravity.','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:51:08','user_05335',false,'2026-06-07 16:51:08','user_05335','C','Trích đoạn chứa đáp án:
The organisation also maintains that the ISS should be used to develop products with commercial application and to test those that are either close to or already on the market. Investment from outside organisations is vital, says Uhran, and a balance between academic and commercial research will help attract this.

Keyword cần chú ý:
business-related ventures = develop products with commercial application + commercial research

Giải thích đáp án:
Bài đọc: Investment from outside organisations is vital, says Uhran, and a balance between academic and commercial research will help attract this.
=> Bài đọc nhấn mạnh ý kiến của Uhran: ISS cần phải có cả academic research và research vì mục đích thương mại, lợi nhuận (commercial research)
Câu hỏi: The ISS should be available for business-related ventures. (ISS nên sẵn sàng tham gia vào business-related projects)
=> Trùng khớp
=> Đáp án: C. Mark Uhran','','',31,'The ISS should be available for business-related ventures.','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 17:57:53','user_05335',false,'2026-06-07 17:57:53','user_05335','PORES','Giải thích chi tiết đáp án 

Trích đoạn chứa đáp án:
When an insect brushes against them, this triggers a tiny electric charge, which travels down tunnels in the leaf and opens up pores in the leaf''s cell membranes.

Keyword cần chú ý:
pores in cell membrane = pores in the leaf''s cell membranes
open = opens up

Giải thích đáp án:
[...] this triggers a tiny electric charge, which travels down tunnels in the leaf and opens up pores in the leaf’s cell membranes
=> Tiny electric charge travels in the leaf and opens up pores in the cell membrane

Câu hỏi: _______ in cell membrane open
=> Đáp án: pores','','',16,'','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 16:48:22','user_05335',false,'2026-06-07 16:48:22','user_05335','B','Trích đoạn chứa đáp án:
A premier, world class laboratory in low Earth orbit. That was how the National Aeronautics and Space Administration agency (NASA) sold the International Space Station (ISS) to the US Congress in 2001. Today no one can doubt the agency’s technological ambition. The most complex engineering project ever attempted has created an enormous set of interlinked modules that orbits the planet at more than 27,000 kilometres per hour. It might be travelling fast but, say critics, as a lab it is going nowhere. So far, it has gone through $150 billion.

Giải thích đáp án:
Phân tích từng câu:
Simplify + Read connection:
(1) + (2) NASA gọi ISS là “world-class laboratory" (phòng thí nghiệm chuẩn quốc tế)
(3) + (4) Nhấn mạnh tiếp tục về đẳng cấp của ISS: “technological ambition", “the most complex engineering project"
(5) + (6) Đưa ra thông tin thêm về ISS (tốc độ, tiền tiêu…)
=> Main idea: Highlight the impressiveness/ development of ISS (Nhấn mạnh đẳng cấp và sự ấn tượng của ISS)
=> So với list đáp án, câu thể hiện được sự khen ngợi với ISS:
B. It is a great example of technological achievement','','["A. Its manufacture has remained within the proposed budget.","B. It is a great example of technological achievement.","C. There are doubts about the speed it has attained.","D. NASA should have described its purpose more"]',27,'What does the writer state about the ISS in the first paragraph?','MULTIPLE_CHOICE',129,NULL),
	 ('2026-06-07 16:51:54','user_05335',false,'2026-06-07 16:51:54','user_05335','B','Trích đoạn chứa đáp án:
Lengthy delays like this are one of the key challenges for NASA, according to an April 201 I report from the US National Academy of Sciences. Its authors said they were ‘deeply concerned’ about the state of NASA’s science research, and made a number of recommendations. Besides suggesting that the agency reduces the time between approving experiments and sending them into space, it also recommended setting clearer research priorities.

Keyword cần chú ý:
speeded up = reduces the time

Giải thích đáp án:
Câu 1 đề cập việc authors đưa ra recommendations, câu 2 làm rõ recommendations đó là gì (reduce the time approving experiments…)
Câu hỏi: The process of getting accepted projects onto the ISS should be speeded up.
=> Trùng khớp
=> Đáp án: B. Authors of the US National Academic of Sciences','','',33,'The process of getting accepted projects onto the ISS should be speeded up.','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-08-26 17:31:40','truongdx18vtit',false,'2026-08-26 17:31:40','truongdx18vtit','SUMMARY',NULL,'','',29,'','FILL_IN_THE_BLANK',157,''),
	 ('2026-08-27 17:31:40','truongdx18vtit',false,'2026-08-27 17:31:40','truongdx18vtit','APPLAUSE',NULL,'','',30,'','FILL_IN_THE_BLANK',157,''),
	 ('2026-08-28 17:31:40','truongdx18vtit',false,'2026-08-28 17:31:40','truongdx18vtit','WATER',NULL,'','',31,'','FILL_IN_THE_BLANK',158,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 16:52:51','user_05335',false,'2026-06-07 16:52:51','user_05335','H','Trích đoạn chứa đáp án:
According to Alan Stern, planetary scientist, the biggest public relations boost for the ISS may come from the privately funded space flight industry. Companies like SpaceX could help NASA and its partners when it comes to resupplying the ISS, as it suggests it can reduce launch costs by two-thirds.

Keyword cần chú ý:
private space companies = privately funded space flight industry + Companies like SpaceX
sending food and equipment = resupplying
economical = reduce launch costs by two-thirds

Giải thích đáp án:
Câu hỏi: He believes they could change its image; firstly because sending food and equipment there would be more _______ if a commercial craft were used,
=> Thông tin trong bài cho thấy làm việc này sẽ giúp giảm chi phí , đồng nghĩa với việc tiết kiệm tiền hơn => Trong list đáp án, lựa chọn H. Economical (tiết kiệm) là phù hợp nhất.
=> Đáp án: H. economical','','',36,'','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:51:32','user_05335',false,'2026-06-07 16:51:32','user_05335','D','Trích đoạn chứa đáp án:
Jeanne DiFrancesco at ProOrbis conducted more than 200 interviews with people from organisations with potential interests in low gravity studies. Some were aware of the ISS but they didn’t know what’s going on up there, she says. ‘Others know there’s science, but they don’t know what kind.’

Keyword cần chú ý:
general ignorance => didn’t know what’s going on up there + don’t know what kind

Giải thích đáp án:
Câu hỏi: People from Jeanne DiFrancesco''s interviews did not know what kind of research is done on ISS.
Câu hỏi: There is general ignorance about what kinds of projects are possible on the ISS.
=> Đáp án: D. Jeanne DiFrancesco','','',32,'There is general ignorance about what kinds of projects are possible on the ISS.','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:52:14','user_05335',false,'2026-06-07 16:52:14','user_05335','C','Trích đoạn chứa đáp án:
Yet Mark Uhran, assistant associate administrator for the ISS, refutes the criticism that the station hasn’t done any useful research. He points to progress made on a salmonella vaccine, for example.

Keyword cần chú ý:
achievements = useful research + progress

Giải thích đáp án:
Câu hỏi: Some achievements of the ISS are underrated (Thành tựu của ISS bị đánh giá thấp = ISS có thành tựu và nên được đánh giá cao hơn)
=> Trùng khớp nội dung bài đọc.
=> Chọn C. Mark Uhran','','',34,'Some achievements of the ISS are underrated.','FILL_IN_THE_BLANK',129,NULL),
	 ('2026-06-07 16:54:35','user_05335',false,'2026-06-07 16:54:35','user_05335','B','Giải thích đáp án:
Paragraph 1: Highlight the achievement of ISS
Paragraph 2+3: ISS research about how to keep the body healthy in space.
Paragraph 4: Recommendations for ISS (speed up the process + clearer research priorities)
Paragraph 5 + 6: NASA''s plan to improve ISS and attract more investment in ISS
Paragraph 7 +8: ISS should do more commercial research
Paragraph 9: How private companies can help ISS
=> Main idea: Nội dung lặp lại xuyên suốt bài là đưa ra những cách để cải thiện ISS (recommendations, plan to improve,....)
=> Chọn B. illustrate how the ISS could become more effective','','["A. promote the advantages of space flight in general.","B. illustrate how the ISS could become more effective.","C. criticise the ISS for its narrow-minded attitude.","D. contrast useful and worthless space projects."]',40,'The writer’s purpose in writing this article is to','MULTIPLE_CHOICE',129,NULL),
	 ('2026-06-07 16:49:06','user_05335',false,'2026-06-07 16:49:06','user_05335','A','Trích đoạn chứa đáp án:
This is where Iwase comes in. He leads a team designing a centrifuge for humans. In their preliminary design, an astronaut is strapped into the seat of a machine that resembles an exercise bike.

Giải thích đáp án:
Bài đọc: He = Iwasa leads a team designing a centrifuge for humans .
In their preliminary design, an astronaut is strapped into the seat of a machine that resembles an exercise bike
= Design của Iwasa resemble (giống với) exercise bike.
+ Đáp án A: It (= Iwasa''s experimental machine] is based on conventional exercise equipment.
= Machine của Iwasa is based on (dựa vào) exercise equipment.
=> Trùng khớp
=> Đáp án A. It is based on conventional exercise equipment','','["A. It is based on conventional exercise equipment.","B. It was originally commissioned by NASA.","C. It is designed only to work in low-gravity environments.","D. It has benefits that Iwase did not anticipate."]',28,'What are we told about Satoshi Iwase’s experimental machine?','MULTIPLE_CHOICE',129,NULL),
	 ('2026-06-07 17:59:09','user_05335',false,'2026-06-07 17:59:09','user_05335','D','Trích đoạn chứa đáp án:
Raffles'' pitcher plant, from the jungles of Borneo, produces nectar that both lures insects and forms a slick surface on which they can''t get a grip. Insects that land On the rim of the pitcher slide on the liquid and tumble in.

Keyword cần chú ý:
slippery = can''t get a grip
substance = nectar
fall inside it = tumble in

Giải thích đáp án:
Bài đọc: Raffles’ pitcher plant produces nectar that lures insects and forms a slick surface on which they can’t get a grip .
Insects slide on the liquid and tumble in
=> Raffles’ pitcher plant produces nectar which makes insects fail to get a grip, so insects tumble in.
Câu hỏi: It produces a slippery substance to make insects fall inside it.
=> Đáp án: D. Raffles’ pitcher plant','','',20,'It produces a slippery substance to make insects fall inside it.
','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 17:59:49','user_05335',false,'2026-06-07 17:59:49','user_05335','C','Trích đoạn chứa đáp án:
The Drosera sundew, blood, has a thick, sweet liquid oozing from its leaves, which first attracts insects, then holds them fast before the leaves snap shut.

Keyword cần chú ý:
sticky ~ thick (liquid)

Giải thích đáp án:
Bài đọc: The Drosera sundew has a thick, sweet liquid from its leaves, which first attracts insects, then holds them fast before the leaves snap shut .
= The Drosera sundew produces a thick, sweet liquid. The liquid attracts insects, holds insects, then closes (= snaps shut)
(thu hút côn trùng, giữ côn trùng sau đó đóng lại = nhốt côn trùng lại)
=> The Drosera sundew produces a thick, sweet liquid which traps insects.
Câu hỏi: It produces a sticky substance which traps insects on its surface.
=> Đáp án: C. Drosera sundew','','',22,'It produces a sticky substance which traps insects on its surface.
','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 18:00:46','user_05335',false,'2026-06-07 18:00:46','user_05335','F','Trích đoạn chứa đáp án:
Two kinds of pitcher plants - the tropical genus Nepenthes and the North American Sarracenia - have, surprisingly, evolved from different ancestors, although both grow deep pitcher-shaped leaves and employ the same strategy for capturing prey.

Keyword cần chú ý:
unexpected = surprising

Giải thích đáp án:
Bài đọc: Nepenthes and the North American Sarracenia have, surprisingly, evolved from different ancestors
= Nepenthes and the North American Sarracenia developed from different ancestors. This information is surprising.
=> The information about the ancestors (tổ tiên) of Nepenthes and the North American Sarracenia is surprising.
=> Thông tin về tổ tiên cũng chính là thông tin về nguồn gốc
=> The information about the origins of Nepenthes and the North American Sarracenia is surprising.
Câu hỏi: unexpected information about the origins of certain carnivorous plants
=> Đáp án: F','','',25,'unexpected information about the origins of certain carnivorous plants','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 18:01:06','user_05335',false,'2026-06-07 18:01:06','user_05335','H','Trích đoạn chứa đáp án:
Agricultural run-off and pollution from power plants are adding extra nitrogen to many bogs in North America. Carnivorous plants are so finely tuned to low levels of nitrogen that this extra fertilizer is overloading their systems, and they eventually burn themselves out and die.

Keyword cần chú ý:
environmental changes = extra nitrogen + extra fertilizer
shorten the life cycles = die

Giải thích đáp án:
Bài đọc: Carnivorous plants are so finely tuned to low levels of nitrogen that this extra fertilizer is overloading their systems , and they burn themselves out and die.
= Carnivorous plants are familiar with low levels of nitrogen
=> Extra nitrogen makes carnivorous plants die.
Câu hỏi: an example of environmental changes that shorten the life cycles of carnivorous plants
=> Đáp án: H','','',26,'an example of environmental changes that shorten the life cycles of carnivorous plants','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 17:58:49','user_05335',false,'2026-06-07 17:58:49','user_05335','E','Trích đoạn chứa đáp án:
But the purple pitcher plant, which lives in bogs and infertile sandy soils in North America, enlists other organisms to process its food.

Keyword cần chú ý:
other creatures = other organisms
digest insects = process its food

Giải thích đáp án:
Bài đọc: The purple pitcher plant enlists other organisms to process its food.
(phần mệnh đề quan hệ bổ nghĩa cho purple pitcher plant nên có thể bỏ qua, không cần đọc)
= The purple pitcher plant uses other organisms to process its food.
Câu hỏi: It uses other creatures to help it digest insects.
=> Đáp án: E. purple pitcher plant','','',19,'
It uses other creatures to help it digest insects.','FILL_IN_THE_BLANK',134,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:00:09','user_05335',false,'2026-06-07 18:00:09','user_05335','E','Trích đoạn chứa đáp án:
A pitcher or a flytrap cannot carry out much photosynthesis because, unlike plants with ordinary leaves, they do not have flat solar panels that can grab lots of sunlight.

Keyword cần chú ý:
leaf shape = do not have flat solar panels
carnivorous plants = A pitcher or a flytrap

Giải thích đáp án:
Bài đọc: A pitcher or a flytrap cannot carry out much photosynthesis because, they do not have flat solar panels that can grab lots of sunlight .
= Unlike plants with ordinary leaves, a pitcher or a flytrap do not have flat solar panels to grab sunlight, so they cannot carry out much photosynthesis.
(Khác với cây lá bình thường, pitcher or flytrap không có flat solar panels => không tiếp nhận được sunlight)
- Câu hỏi: a mention of a disadvantage of the leaf shape of some carnivorous plants
=> Disadvantage được đề cập trong bài chính là việc không tiếp nhận được sunlight
=> Đáp án: E','','',23,'a mention of a disadvantage of the leaf shape of some carnivorous plants','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 18:19:39','user_05335',false,'2026-06-07 18:19:39','user_05335','IV','Trích đoạn chứa đáp án:
In addition to its historical interest, inspecting the growth of the studio system may offer clues regarding the kinds of struggles that accompany the growth of any new medium. It might, in fact, be intriguing to examine which changes occurred during the growth of the Hollywood studio, and compare those changes to contemporary struggles in which production companies are trying to define and control emerging industries, such as online film and interactive television.

Giải thích đáp án:
Paragraph A đưa ra những lợi ích của việc nghiên cứu sự phát triển của Hollywood studio system:
1. historical interest
2. offer clues regarding the kinds of struggles that accompany the growth of any new medium
3. examine which changes occurred during the growth of the Hollywood studio, and compare those changes to contemporary struggles
-> iv. The value of studying Hollywood’s Golden Age','','',14,'
Paragraph A','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 17:59:31','user_05335',false,'2026-06-07 17:59:31','user_05335','B','Trích đoạn chứa đáp án:
The bladderwort has an equally sophisticated way of setting its underwater trap. It pumps water out of tiny bag-like bladders, making a vacuum inside. When small creatures swim past, they bend the hairs on the bladder, causing a flap to open. The low pressure sucks water in, carrying the animal along with it.

Keyword cần chú ý:
empty space = vacuum
insects = small creatures + the animal

Giải thích đáp án:
Bài đọc:
(1) The bladderwort has way of setting trap
(2) It pumps water out of tiny bag-like bladders ,
making a vacuum inside .
(3) When small creatures swim past, they bend the hairs on the bladder, causing a flap to open.
(4) The low pressure sucks water in, carrying the animal along with it (= the water) .
=> The bladderwort pumps water out, makes a vacuum inside, sucks water and animal .
Câu hỏi: It creates an empty space into which insects are sucked.
=> Đáp án: B. bladderwort','','',21,'It creates an empty space into which insects are sucked.','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 17:58:13','user_05335',false,'2026-06-07 17:58:13','user_05335','WATER','Trích đoạn chứa đáp án:
Water surges from the cells on the Inside of the leaf to those on the outside, causing the leaf to rapidly flip in shape from convex to concave, like a soft contact lens.

Keyword cần chú ý:
leaves filled with water = Water surges on the Inside of the leaf

Giải thích đáp án:
Bài đọc: Water surges from the cells on the inside of the leaf to those on the outside,...
=> Water moves from the cells on the inside of the leaf to the cells on the outside
=> Nước chuyển từ cells phía trong leaves sang cells phía ngoài leaves => Outside cells of leaves có chứa nước
Câu hỏi: Outside cells of leaves filled with _____
=> Đáp án: Water','','',17,'','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 18:00:28','user_05335',false,'2026-06-07 18:00:28','user_05335','I','Trích đoạn chứa đáp án:
The black market trade in exotic carnivorous plants is so vigorous now that botanists are keeping the location of some rare species a secret.

Giải thích đáp án:
Bài đọc: The black market trade in carnivorous plants is so vigorous that botanists are keeping the location of rare species a secret
=> Cấu trúc “so….Adj….that S + V” nghĩa là “quá… tới nỗi mà…”
=> Thị trường chợ đen buôn bán carnivorous plants quá ..., tới nỗi mà botanists phải giữ bí mật vị trí của rare species.
=> Botanists giữ bí mật vị trí của rare species để bảo vệ chúng không bị buôn bán ở thị trường chợ đen.
Câu hỏi: an example of an effort made to protect carnivorous plants (nỗ lực bảo vệ carnivorous plants)
=> Đáp án: I','','',24,'an example of an effort made to protect carnivorous plants','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-06-07 17:57:19','user_05335',false,'2026-06-07 17:57:19','user_05335','(THE) HAIRS','Trích đoạn chứa đáp án:
The leaves of the Venus flytrap plant are covered in hairs. When an insect brushes against them, ...

Giải thích đáp án:
Bài đọc:
The leaves of the Venus flytrap plant are covered in hairs

When an insect brushes against them ...
=> Insect brushes against leaves which are covered in hair
Câu hỏi: Insect touches ______on leaf of plant
=> Đáp án: hairs','','',14,'','FILL_IN_THE_BLANK',134,NULL),
	 ('2026-08-29 17:31:40','truongdx18vtit',false,'2026-08-29 17:31:40','truongdx18vtit','EFFICIENT',NULL,'','',32,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-08-30 17:31:40','truongdx18vtit',false,'2026-08-30 17:31:40','truongdx18vtit','NOISE',NULL,'','',33,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-08-31 17:31:40','truongdx18vtit',false,'2026-08-31 17:31:40','truongdx18vtit','RELIABLE',NULL,'','',34,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-06-07 18:03:03','user_05335',false,'2026-06-07 18:03:03','user_05335','III','Trích đoạn chứa đáp án:
Henry Holzman, also at MIT, who studies the interface between online social networking and the real world, points out that increased visibility also means our various social spheres - family, work, friends - are merging, and so we will have to prepare for new societal norms. ‘We’ll have to learn how to live a more transparent life, ’ he says. We may have to give up some ability to show very limited glimpses of ourselves to others.’

Giải thích đáp án:
Phân tích từng câu:
(1) Một hệ quả khác nữa từ online networking: cuộc sống cá nhân sẽ bị biết tới nhiều hơn
(2) - (3) những gì chúng ta cần làm để thích nghi với hệ quả đó
=> Main idea: Vì online networking, thông tin cá nhân sẽ bị biết tới nhiều hơn.
=> Đáp án: iii. More personal information being known','','',31,'Paragraph F','FILL_IN_THE_BLANK',135,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:02:24','user_05335',false,'2026-06-07 18:02:24','user_05335','II','Trích đoạn chứa đáp án:
Nonetheless, there is evidence that online networking can transform our daily interactions. In an experiment at Cornell University, psychologist Jeff Hancock asked participants to try to encourage other participants to like them via instant messaging conversation. Beforehand, some members of the trial were allowed to view the Facebook profile of the person they were trying to win over. He found that those with Facebook access asked questions to which they already knew the answers or raised things they had in common, and as result were much more successful in their social relationships. Hancock concluded that people who use these sites to keep updated on the activities of their acquaintances are more likely to be liked in subsequent social interactions.

Giải thích đáp án:
Phân tích từng câu:
(1): nêu quan điểm rằng thật ra online networking vẫn có ích
(2) -(5): đưa ví dụ cụ thể để chứng minh và rút ra kết luận: online networking có ích khi giúp người ta dễ được liked in social interactions
=> Main idea: online networking có ích trong việc giúp người được liked in social interactions
So với list đáp án, ta có:
ii. How to be popular','','',29,'Paragraph D','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:04:23','user_05335',false,'2026-06-07 18:04:23','user_05335','C','Trích đoạn chứa đáp án:
Robin Dunbar, an evolutionary anthropologist at the University of Oxford, believes that our primate brains place a cap on the number of genuine social relationships we can actually cope with: roughly 150

Keyword cần chú ý:
a limit = a cap
meaningful relationships = genuine social relationships
maintain = cope with

Giải thích đáp án:
Bài đọc: Robin Dunbar believes that our brains place a cap on the number of genuine social relationships we can actually cope with: roughly 150
-> không hiểu "place a cap" là gì thì đọc khúc sau: "roughly 150"
-> số relationship ta có thể giữ gìn được là có giới hạn
= According to Robin Dunbar, their is a limit to the number of genuine social relationships that we can maintain.
_x0008_Câu hỏi: There is a limit to how many meaningful relationships we can maintain.
=> Đáp án: C. Robin Dunbar','','',35,'There is a limit to how many meaningful relationships we can maintain.','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:03:45','user_05335',false,'2026-06-07 18:03:45','user_05335','F','Trích đoạn chứa đáp án:
While Kearns warns that the setting was artificial, he says it’s possible that greater persuasive power could lie with well-connected individuals in the everyday online world too.

Keyword cần chú ý:
People who network widely = well-connected individuals
exert pressure on others = greater persuasive power

Giải thích đáp án:
Bài đọc: he (Kearns) says that greater persuasive power could lie with well-connected individuals
= According to Kearns, the more an individual connects well with others, the more he/she can persuade others.
-> persuade được người khác theo ý mình, có thể hiểu là có thể tạo áp lực lên người khác được
= According to Kearns, the more an individual connects well with others, the more he/she can pressure others
- Câu hỏi: People who network widely may be more able to exert pressure on others
=> Đáp án: F. Michael Kearns','','',33,'People who network widely may be more able to exert pressure on others.','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:05:43','user_05335',false,'2026-06-07 18:05:43','user_05335','A','Trích đoạn chứa đáp án:
For example, many people now turn to their online social networks ahead of sources such as newspapers and television for trusted and relevant news or information. What they hear could well be inaccurate, but the change is happening nonetheless.

Keyword cần chú ý:
online social contacts = online social networks
unreliable = inaccurate

Giải thích đáp án:
Bài đọc: people now turn to their online social networks ahead of sources such as newspapers for information.
What they hear could well be inaccurate, but the change is happening nonetheless.
=> information on online social networks could be inaccurate (= wrong)
- So với list đáp án:
=> A. Information from online social contacts may be unreliable.','','',39,'','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:04:44','user_05335',false,'2026-06-07 18:04:44','user_05335','D','Trích đoạn chứa đáp án:
Hancock concluded that people who use these sites to keep updated on the activities of their acquaintances are more likely to be liked in subsequent social interactions.

Keyword cần chú ý:
social advantage = more likely to be liked in subsequent social interactions .
knowing about = keep updated on
the lives = the activities
online contacts = their acquaintances

Giải thích đáp án:
Bài đọc: Hancock concluded that people who use these sites (= online network) to keep updated on the activities of their acquaintances are more likely to be liked in social interactions .
-> "more likely to be liked in social interactions" : được thích hơn khi tương tác xã giao, tức là có lợi thế khi tương tác hơn.
= Hancock concluded that people who use online network to know about the activities of their acquaintances have advantage in social interaction
_x0008_Câu hỏi: There is a social advantage in knowing about the lives of our online contacts.
=> Đáp án: D. Jeff Hancock','','',36,'There is a social advantage in knowing about the lives of our online contacts.','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:04:05','user_05335',false,'2026-06-07 18:04:05','user_05335','E','Trích đoạn chứa đáp án:
Nicole Ellison of Michigan State University found that the frequency of networking site use correlates with greater self- esteem. Support and affirmation from the weak ties could be the explanation, says Ellison. ''Asking your close friends for help or advice is nothing new, but we are seeing a lowering of barriers among acquaintances, '' she says. People are readily sharing personal feelings and experiences to a wider circle than they might once have done.

Keyword cần chú ý:
become more willing = are readily
confide in = sharing
extensive number of people = a wider circle

Giải thích đáp án:
Bài đọc: ''Asking your close friends for help or advice is nothing new, but we are seeing a lowering of barriers among acquaintances,'' she (Nicole Ellison) says.
People are readily sharing personal feelings to a wider circle than they might once have done.
= According to Nicole Ellison, we share our feelings to more people now.
Câu hỏi: We have become more willing to confide in an extensive number of people
=> Đáp án: E. Nicole Ellison','','',34,'We have become more willing to confide in an extensive number of people.','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:02:45','user_05335',false,'2026-06-07 18:02:45','user_05335','VII','Trích đoạn chứa đáp án:
Online social networking may also have tangible effects on our well-being. Nicole Ellison of Michigan State University found that the frequency of networking site use correlates with greater self- esteem. Support and affirmation from the weak ties could be the explanation, says Ellison. ''Asking your close friends for help or advice is nothing new, but we are seeing a lowering of barriers among acquaintances, '' she says. People are readily sharing personal feelings and experiences to a wider circle than they might once have done. Sandy Pentland at the Massachusetts Institute of Technology agrees. The ability to broadcast to our social group means we need never feel alone/ he says. The things that befall us are often due to a lack of social support. There’s more of a safety net now.''

Giải thích đáp án:
Phân tích từng câu:
(1) Online networking còn có lợi ích về well-being (sức khỏe và hạnh phúc)
(2) Cụ thể là lợi ích về self- esteem (lòng tự trọng)
(3) - (9): Giải thích chi tiết tại sao có được lợi ích đó
=> Main idea: Ích lợi về well-being mà online networking đem lại
=> Đáp án: vii. The emotional benefits of online networking','','',30,'
Paragraph E','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:03:26','user_05335',false,'2026-06-07 18:03:26','user_05335','V','Trích đoạn chứa đáp án:
Another way that online networking appears to be changing our social structures is through dominance. In one repeated experiment, Michael Kearns of the University of Pennsylvania asked 30 volunteers to quickly reach consensus in an online game over a choice between two colours. Each person was offered a cash reward if they succeeded in persuading the group to pick one or other colour. All participants could see the colour chosen by some of the other people, but certain participants had an extra advantage: the ability to see more of the participants'' chosen colours than others. Every time Kearns found that those who could see the choices of more participants (in other words, were better connected) persuaded the group to pick their colour, even when they had to persuade the vast majority to give up their financial incentive. While Kearns warns that the setting was artificial, he says it’s possible that greater persuasive power could lie with well-connected individuals in the everyday online world too.

Giải thích đáp án:
Phân tích từng câu:
(1): một ảnh hưởng khác của online networking: dominance (uy thế)
(2)-(4): 1 thí nghiệm chứng minh ảnh hưởng này
(5)-(6): kết luận: những người biết nhiều info của người khác hơn (=well-connected individuals) có thể có khả năng thuyết phục tốt hơn greater persuasive power
=> Main idea: Online networking giúp có thêm info -> tăng sức ảnh hưởng lên người khác
- So với list đáp án, ta có:
v. the link between knowledge and influence','','',32,'Paragraph G','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:05:25','user_05335',false,'2026-06-07 18:05:25','user_05335','B/E','Trích đoạn chứa đáp án:
Nicole Ellison of Michigan State University found that the frequency of networking site use correlates with greater self- esteem. Support and affirmation from the weak ties could be the explanation, says Ellison

Keyword cần chú ý:
reassuring ~ greater self- esteem + Support and affirmation
be part of an online social network = networking site use

Giải thích đáp án:
Bài đọc: Ellison found that the frequency of networking site use correlates with greater self-esteem
-> correlates: tương quan/ liên quan
Support and affirmation from the weak ties could be the explanation, says Ellison
=> Support and affirmation from the weak ties is the explanation to why networking site use helps you have greater self- esteem
=> Networking site use helps you have greater self- esteem because you receive support and affirmation from the weak ties on online social network.
- So với list đáp án, ta có:
E. It can be reassuring to be part of an online social network.','','',38,'','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:05:02','user_05335',false,'2026-06-07 18:05:02','user_05335','B/E','Trích đoạn chứa đáp án:
You couldn’t maintain all of those weak ties on your own, '' says Jennifer Golbeck of the University of Maryland, ''Online sites, such as Facebook, give you a way of cataloguing them.'' The result? It’s now significantly easier for the schoolfriend you haven''t seen in years to pass you a tip that alters your behaviour, from recommendation of a low-cholesterol breakfast cereal to a party invite where you meet your future wife or husband.

Keyword cần chú ý:
Online socialising => Online sites + Facebook
efficient way of keeping in touch = a way of cataloguing
people = weak ties

Giải thích đáp án:
Bài đọc: ''You couldn’t maintain all of those weak ties on your own, '' says Jennifer Golbeck of the University of Maryland, ''Online sites, such as Facebook, give you a way of cataloguing them.''
-> Nếu không hiểu "cataloguing" thì dựa vào mạch ý trước đó. Đầu tiên người ta nêu vấn đề là bạn không thể tự maintain all of those weak ties, nhưng ngay sau đó nói về những online site như Facebook cho bạn cách "cataloguing them"
-> "cataloguing them" chính là maintaining all those weak ties. (Nếu vẫn chưa rõ, có thể đọc thêm ví dụ cụ thể ở câu tiếp theo trong bài)
=> Online sites, such as Facebook, allow you to maintain a lot of weak ties.
- So với list đáp án, ta có:
B. Online socialising is an efficient way of keeping in touch with a lot of people.','','',37,'','FILL_IN_THE_BLANK',135,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:06:14','user_05335',false,'2026-06-07 18:06:14','user_05335','A','Trích đoạn chứa đáp án:
‘We’ll have to learn how to live a more transparent life,’ he says.

Keyword cần chú ý:
lack of privacy = a more transparent life

Giải thích đáp án:
Bài đọc: We’ll have to learn how to live a more transparent life
-> "transparent" là "trong suốt", "rõ ràng". Ở các đoạn trước, ta biết được social online network giúp kết nối và giữ gìn nhiều mối quan hệ + tâm sự, chia sẻ với nhiều người hơn
-> Online network khiến cuộc sống cá nhân của mình "transparent" hơn với người ngoài
-> mất đi privacy
- So với list đáp án, ta có:
E. Using social networking sites may result in a lack of privacy.','','',40,'','FILL_IN_THE_BLANK',135,NULL),
	 ('2026-06-07 18:22:33','user_05335',false,'2026-06-07 18:22:33','user_05335','TRUE','Trích đoạn chứa đáp án:
Studio bosses could also force bad roles on actors, and manipulate every single detail of stars’ images with their mammoth in-house publicity departments.

Giải thích đáp án:
Bài đọc: Sếp ở các xưởng phim có thể bắt diễn viên đóng vai xấu/ác và thay đổi hình ảnh các ngôi sao trong mắt khán giả nhờ bộ phận quảng cáo trực thuộc được đầu tư.
Câu hỏi: Các xưởng phim có toàn quyền kiểm soát cách công chúng nhìn nhận diễn viên.
-> TRUE','','',23,'Studios had total control over how their actors were perceived by the public.','TRUE_FALSE_NOT_GIVEN',137,NULL),
	 ('2026-06-07 19:13:13.396893','user_56659',false,'2026-06-07 19:13:13.396893','user_56659','LIFE','Trích đoạn chứa đáp án:
there is very little data on the impact it has on the child''s later life.

Keyword cần chú ý:
research need to study = very little data on
the rest of = later

Giải thích đáp án:
Đáp án đứng sau sở hữu cách “child’s” → đáp án là 1 danh từ.
Câu hỏi: cần nghiên cứu về ảnh hưởng của việc vui chơi đến phần còn lại của cuộc đời trẻ → “life” là đáp án của câu hỏi này.',NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 18:22:54','user_05335',false,'2026-06-07 18:22:54','user_05335','VERTICAL INTEGRATION','Trích đoạn chứa đáp án:
Vertical integration is the other key component in the rise of the Hollywood studio system. The major studios realized they could increase their profits by handling each stage of a film’s life: production (making the film), distribution (getting the film out to people) and exhibition (owning the theaters in major cities where films were shown first).

Giải thích đáp án:
Hệ thống được nhắc đến có vai trò quan trọng trong sự phát triển của hệ thống xưởng phim Hollywood là "vertical integration" (gộp dọc, hay thâu tóm toàn bộ các quá trình liên quan đến một bộ phim từ khâu sản xuất đến trình chiếu).
-> Đáp án là "vertical integration"','','',24,'','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:21:21','user_05335',false,'2026-06-07 18:21:21','user_05335','VI','Trích đoạn chứa đáp án:
In the United States versus Paramount federal decree of that year, the studios were ordered to give up their theaters in what is commonly referred to as ‘divestiture’ – opening the market to smaller producers. This, coupled with the advent of television in the 1950s, seriously compromised the studio system’s influence and profits.

Giải thích đáp án:
Paragraph F nói về nghị định liên bang "the United States vs. Paramount" và sự xuất hiện của TV làm giảm ảnh hưởng và lợi nhuận của các hệ thống xưởng phim.
-> tầm ảnh hưởng của film studios chịu tác động của hai sự kiện này
-> vi. A double attack on film studios’ power','','',19,'Paragraph F','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:23:29','user_05335',false,'2026-06-07 18:23:29','user_05335','DIVESTITURE','Trích đoạn chứa đáp án:
In the United States versus Paramount federal decree of that year, the studios were ordered to give up their theaters in what is commonly referred to as ‘divestiture’ – opening the market to smaller producers. This, coupled with the advent of television in the 1950s, seriously compromised the studio system’s influence and profits.

Keyword cần chú ý:
a process known as = commonly referred to as

Giải thích đáp án:
Nghị định năm 1948 yêu cầu mở ra thị trường cho các xưởng phim nhỏ hơn là "divestiture".
-> Đáp án là "divestiture"','','',26,'','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:20:43','user_05335',false,'2026-06-07 18:20:43','user_05335','I','Trích đoạn chứa đáp án:
During the Golden Age, the studios were remarkably consistent and stable enterprises, due in large part to long-term management heads – the infamous ‘movie moguls’ who ruled their kingdoms with iron fists. At MGM, Warner Bros, and Columbia, the same men ran their studios for decades.

Keyword cần chú ý:
power within each studio = ruled their kingdoms with iron fists

Giải thích đáp án:
Paragraph D nói rằng sự ổn định của các xưởng phim là nhờ những người quản lý.
-> i. The power within each studio','','',17,'Paragraph D','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:20:24','user_05335',false,'2026-06-07 18:20:24','user_05335','VII','Trích đoạn chứa đáp án:
Together these eight companies operated as a mature oligopoly, essentially running the entire market.

Keyword cần chú ý:
gaining control of the industry = running the entire market

Giải thích đáp án:
Paragraph C nói về cách 8 công ty nắm thị trường và trở thành các thế lực độc quyền trong ngành.
-> vii. Gaining control of the industry','','',16,'
Paragraph C','FILL_IN_THE_BLANK',137,NULL),
	 ('2026-06-07 18:21:40','user_05335',false,'2026-06-07 18:21:40','user_05335','FALSE','Trích đoạn chứa đáp án:
The financial investment this kind of filmmaking would require, from new camera equipment to new projection facilities, made the studios hesitant to invest at first.

Giải thích đáp án:
Bài đọc: Kinh phí đầu tư khiến các xưởng phim ban đầu e ngại và chưa dám đầu tư.
Câu hỏi: Khi The Jazz Singer ra mắt, các studios khác ngay lập tức bắt đầu làm phim với âm thanh đồng bộ.
-> FALSE','','',20,'After The Jazz Singer came out, other studios immediately began making movies with synchronized sound.','TRUE_FALSE_NOT_GIVEN',137,NULL),
	 ('2026-06-07 18:28:14','user_05335',false,'2026-06-07 18:28:14','user_05335','B','Trích đoạn chứa đáp án:
Similar evidence appeared in songbirds and rats around the same time, and since then, researchers have built up an impressive catalogue of animal lateralization.

Giải thích đáp án:
Câu hỏi: Nhắc đến lượng lớn kiến thức đã được thu thập về animal lateralization.
Tác giả nói về quan điểm rằng lateralization chỉ có ở người ở đầu đoạn hai. Quan điểm đó bị phủ nhận _x0008_khi nghiên cứu của Rogers giai đoạn 1970s ghi nhận lateralization ở nhiều loài khác nhau.
-> Đáp án là paragraph B','','',38,'reference to the large amount of knowledge of animal lateralisation that has accumulated','FILL_IN_THE_BLANK',138,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:27:23','user_05335',false,'2026-06-07 18:27:23','user_05335','E','Trích đoạn chứa đáp án:
Similar results probably hold true for many other animals. In 2006, Angelo Bisazza at the University of Padua set out to observe the differences in feeding behaviour between strongly-lateralized and weakly-lateralized fish.

Giải thích đáp án:
Câu hỏi: Mô tả một nghiên cứu ủng hộ phát hiện của một nhà khoa học khác.
Trong bài, nghiên cứu của Angelo Bisazza được nhắc đến nhằm so sánh kết quả với nghiên cứu của Rogers ở đoạn trước đó. Trong đó, nghiên cứu của Bisazza có kết quả tương tự và ủng hộ kết luận của Rogers. Nghiên cứu này được mô tả ở đoạn E.
-> Đáp án là paragraph E','','',36,'description of a study which supports another scientist’s findings','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:26:44','user_05335',false,'2026-06-07 18:26:44','user_05335','FOOD','Trích đoạn chứa đáp án:
As predicted, the birds incubated in the light looked for food mainly with their right eye, while using the other to check out the predator. The weakly-lateralized chicks, meanwhile, had difficulty performing these two activities simultaneously.

Keyword cần chú ý:
as expected = as predicted
locate = look for

Giải thích đáp án:
Như dự đoán, Rogers thấy gà con có lateralization mạnh hơn (được ấp trong môi trường chiếu sáng) vừa tìm "food" vừa trông chừng "predator" (loài ăn thịt).
-> Đáp án là "food"','','',34,'','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:29:02','user_05335',false,'2026-06-07 18:29:02','user_05335','A','Trích đoạn chứa đáp án:
This does, on some occasions, let the animal down: such as when a toad fails to escape from a snake approaching from the right just because its right eye is worse at spotting danger than its left. So why would animals evolve a characteristic that seems to endanger them?

Keyword cần chú ý:
disadvantage ~ let down + endanger

Giải thích đáp án:
Câu hỏi: Ý tưởng là lateralization có vẻ là bất lợi cho động vật.
Đoạn A định nghĩa lateralization và gợi mở cho chủ đề về những lợi ích của lateralization ở các đoạn sau. Trước đó, tác giả đã đặt câu hỏi rằng thoạt nhiên lateralization có vẻ gây bất lợi cho động vật.
-> Đáp án là paragraph A','','',40,'a suggestion that lateralisation would seem to disadvantage animals','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-09-01 17:31:40','truongdx18vtit',false,'2026-09-01 17:31:40','truongdx18vtit','STABILITY',NULL,'','',35,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-06-07 18:28:38','user_05335',false,'2026-06-07 18:28:38','user_05335','B','Trích đoạn chứa đáp án:
For many years it was assumed that lateralization was a uniquely human trait, but this notion rapidly fell apart as researchers started uncovering evidence of lateralization in all sorts of animals.

Giải thích đáp án:
Câu hỏi: Những kết quả nghiên cứu đầu tiên trái ngược với một niềm tin trước đó.
Đoạn thứ hai mở đầu bằng quan niệm rằng lateralization chỉ có ở người và những nghiên cứu đầu tiên của Rogers đưa ra bằng chứng phủ nhận.
-> Đáp án là paragraph B','','',39,'research findings that were among the first to contradict a previous belief','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:27:01','user_05335',false,'2026-06-07 18:27:01','user_05335','PREDATOR','Trích đoạn chứa đáp án:
As predicted, the birds incubated in the light looked for food mainly with their right eye, while using the other to check out the predator. The weakly-lateralized chicks, meanwhile, had difficulty performing these two activities simultaneously.

Keyword cần chú ý:
as expected = as predicted
monitor = check out

Giải thích đáp án:
Như dự đoán, Rogers thấy gà con có lateralization mạnh hơn (được ấp trong môi trường chiếu sáng) vừa tìm "food" vừa trông chừng "predator" (loài ăn thịt).
-> Đáp án là "predator"','','',35,'','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:27:50','user_05335',false,'2026-06-07 18:27:50','user_05335','H','Trích đoạn chứa đáp án:
Whereas most co-operative interactions require participants to react similarly, there are some situations – such as aggressive interactions – where it can benefit an individual to launch an attack from an unexpected quarter.

Giải thích đáp án:
Câu hỏi: Gợi ý rằng một người có lợi thế so với số đông khi có lateralization trái ngược.
Con người thường cần hợp tác, nhưng trong các tình huống bạo lực, có lateralization khác người có lợi vì có thể tấn công từ hướng mà đối thủ không ngờ đến. Nội dung này được nói đến ở đoạn H.
-> Đáp án là paragraph H','','',37,'the suggestion that a person could gain from having an opposing lateralisation to most of the population','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:25:13','user_05335',false,'2026-06-07 18:25:13','user_05335','B','Trích đoạn chứa đáp án:
These have shown that a group of fish is likely to survive a shark attack with the fewest casualties if the majority turn together in one direction while a very small proportion of the group escape in the direction that the predator is not expecting.

Giải thích đáp án:
Nghiên cứu của Vallortigara and Ghirlanda cho thấy đàn cá có khả năng thoát chết cao nhất khi bị cá mập tấn công nếu phần đông di chuyển về cùng một hướng và một nhóm nhỏ thoát đi ở hướng không ngờ tới.
-> Một số khác có lateralization khác số đông thì có lợi cho quần thể
-> B. it benefits a population if some members have a different lateralization than the majority.','','',30,'Vallortigara and Ghirlanda’s research findings suggest that','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 18:24:20','user_05335',false,'2026-06-07 18:24:20','user_05335','C','Trích đoạn chứa đáp án:
Assigning different jobs to different brain halves may be especially advantageous for animals such as birds or fish, whose eyes are placed on the sides of their heads. This enables them to process input from each side separately, with different tasks in mind.

Keyword cần chú ý:
do two things at the same time = process input from each side separately, with different tasks in mind

Giải thích đáp án:
Trong thí nghiệm của Angelo Bisazza, hai bán cầu não có hai nhiệm vụ khác nhau giúp động vật có khả năng xử lý thông tin và thực hiện nhiệm vụ khác nhau.
-> Cho thấy nhờ lateralization mà não làm được hai việc một lúc
-> C. lateralization helps animals do two things at the same time.','','',28,'Angelo Bisazza’s experiments revealed that','FILL_IN_THE_BLANK',138,NULL),
	 ('2026-06-07 19:11:49.900444','user_56659',false,'2026-06-07 19:11:49.900444','user_56659','CREATIVITY','Trích đoạn chứa đáp án:
Although she isn''t aware of it, this fantasy is helping her take her first steps towards her capacity for creativity and so it will have important repercussions in her adult life.

Keyword cần chú ý:
building a ‘magical kingdom’ = this fantasy
develop = take her first steps towards

Giải thích đáp án:
Đáp án đứng sau động từ “develop” → đáp án là 1 danh từ.
Đáp án cần tìm là 1 danh từ chỉ khả năng/kĩ năng mà trẻ em được phát triển khi xây dựng những vương quốc kì diệu.
Từ bài đọc, “her capacity for creativity” là cụm từ cần tìm; tuy nhiên, đáp án là 1 từ → “creativity” là đáp án của câu hỏi này.',NULL,NULL,1,NULL,'FILL_IN_THE_BLANK',124,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:12:07.077567','user_56659',false,'2026-06-07 19:12:07.077567','user_56659','RULES','Trích đoạn chứa đáp án:
Later on, when they tire of this and settle down with a board game, she''s learning about the need to follow rules and take turns with a partner.

Keyword cần chú ý:
turn-taking = take turns

Giải thích đáp án:
Theo cấu trúc song song, sau “and” là danh từ “turn-taking” → đáp án là 1 danh từ.
Đáp án là 1 danh từ chỉ 2 kĩ năng trẻ em 33 được học khi chơi “board games” + đáp án đứng trước “and”.
Từ bài đọc, “follow rules” là cụm từ phù hợp; tuy nhiên, đáp án là danh từ có 1 từ → “rules” là đáp án của câu hỏi này.',NULL,NULL,2,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 19:12:20.783697','user_56659',false,'2026-06-07 19:12:20.783697','user_56659','CITIES','Trích đoạn chứa đáp án:
But we live in changing times, and Whitebread is mindful of a worldwide decline in play, pointing out that over half the people in the world now live in cities.

Keyword cần chú ý:
Recent changes = in changing times
Populations = the people in the world
have grown = over half

Giải thích đáp án:
Đáp án đứng sau giới từ “of” → đáp án là 1 danh từ.
“populations of ...” → đáp án là danh từ chỉ nơi chốn/địa điểm.
Câu hỏi đang hỏi về những thay đổi ảnh hưởng đến sự vui chơi của trẻ em: dân số ở thành thị tăng → “cities” là đáp án của câu hỏi này.',NULL,NULL,3,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 19:12:31.663999','user_56659',false,'2026-06-07 19:12:31.663999','user_56659','TRAFFIC','Trích đoạn chứa đáp án:
Outdoor play is curtailed by
perceptions of risk to do with
traffic

Keyword cần chú ý:
opportunities for free play = outdoor play
limited = curtailed
fear = perceptions of risk

Giải thích đáp án:
Đáp án đứng sau giới từ “of” → đáp án là 1 danh từ.
Đáp là là 1 danh từ chỉ 1 lý do/yếu tố làm cơ hội được vui chơi của trẻ em bị giới hạn → “traffic” là đáp án của câu hỏi này.',NULL,NULL,4,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 19:12:43.350178','user_56659',false,'2026-06-07 19:12:43.350178','user_56659','CRIME','Trích đoạn chứa đáp án:
as well as parents'' increased wish to protect their children from being the victims of crime,

Keyword cần chú ý:
Fear = wish to protect their children from being the victims of crime

Giải thích đáp án:
Tương tự câu 3, đáp án là 1 danh từ.
Nỗi sợ thứ 2: sợ trẻ em trở thành nạn nhân của tội phạm → “crime” là đáp án của câu hỏi này.',NULL,NULL,5,NULL,'FILL_IN_THE_BLANK',124,NULL),
	 ('2026-06-07 19:13:34.560872','user_56659',false,'2026-06-07 19:13:34.560872','user_56659','TRUE','Trích đoạn chứa đáp án:
the ability to self-regulate has been shown to be a key predictor of academic performance.

Keyword cần chú ý:
Children with good self-control = the ability to self-regulate.
are know to be likely = has been shown to be.
to do well = a key predictor.
school = academic performance.

Giải thích đáp án:
Tất cả những keywords trong câu hỏi đều được paraphrase và tìm thấy trong bài (câu trích dẫn)
Dịch: Trẻ em với kĩ năng tự chủ tốt thường học tốt ở trường sau này → TRUE',NULL,NULL,9,'Children with good self-control are known to be likely to do well at school later on.','TRUE_FALSE_NOT_GIVEN',124,NULL),
	 ('2026-06-07 19:14:37.266926','user_56659',false,'2026-06-07 19:14:37.266926','user_56659','TRUE','Trích đoạn chứa đáp án:
Somehow the importance of play has been lost in recent decades.

Keyword cần chú ý:
children’s play = play
significant = inportance
less = has been lost

Giải thích đáp án:
Dịch: Ngày này mọi người xem việc vui chơi của trẻ em ít quan trọng hơn ngày xưa.
Giải thích: câu trong bài “Vì lý do nào đó, tầm quan trọng của việc vui chơi đã biến mất trong những thập kỉ gần đây”, nghĩa là trước đó việc vui chơi được xem là quan trọng.
→ TRUE',NULL,NULL,13,'People nowadays regard children’s play as less significant than they did in the past.','TRUE_FALSE_NOT_GIVEN',124,NULL),
	 ('2026-06-07 19:17:41.711318','user_56659',false,'2026-06-07 19:17:41.711318','user_56659','POLICE','Trích đoạn chứa đáp án:
The police were opposed to Provo''s initiatives and almost as soon as the white bikes were distributed around the city, they removed them.

Keyword cần chú ý:
as quickly as = as soon as
took away = remove
left the bikes around the city = the white bikes were distributed around the city

Giải thích đáp án:
Đáp án sau mạo từ “the” và trước 1 động từ chỉ hành động → Đáp án là danh từ chỉ người.
Đối chiếu giữa keywords trong câu hỏi với những cụm được paraphrase trong baif → “police” là đáp án của câu hỏi này.',NULL,NULL,26,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:17:31.94048','user_56659',false,'2026-06-07 19:17:31.94048','user_56659','LEAFLETS','Trích đoạn chứa đáp án:
They also distributed leaflets describing the dangers of cars and inviting people to use the white bikes.

Keyword cần chú ý:
handed out = distributed
condemned = describing
the use of cars = the dangers of cars

Giải thích đáp án:
Trước đáp án là động từ “handed out” → đáp án là 1 danh từ.
Dịch: Sau khi sơn những chiếc xe màu trắng, họ phân phát ... để chỉ trích việc sử dụng xe hơi → “leaflets” (tờ rơi) là đáp án của câu hỏi này.',NULL,NULL,25,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:16:53.475325','user_56659',false,'2026-06-07 19:16:53.475325','user_56659','D/E','Trích đoạn chứa đáp án:
People who travel on the underground don''t carry their bikes around. But often they need additional transport to reach their final destination.''

Keyword cần chú ý:
residents who use public transport = people who travel on the underground.

Giải thích đáp án:
Dịch: Dự án “bike-sharing” sẽ giúp ích cho những người sử dụng phương tiện công cộng.
Theo câu trích dẫn: Những người đi tàu ngầm không mang theo xe đạp nhưng học vẫn cần 1 phương tiện để đi đến đích đến cuối cùng → những chiếc xe đạp trong “bike-sharing scheme” có thể giúp được.',NULL,NULL,22,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:16:42.329896','user_56659',false,'2026-06-07 19:16:42.329896','user_56659','D/E','Trích đoạn chứa đáp án:
In Amsterdam today, 38% of all trips are made by bike and, along with Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the world -but the city never got another Witte Fietsenplan.

Keyword cần chú ý:
a place that welcome cyclists = two most cycle- friendly capitals.

Giải thích đáp án:
Dịch: Một thành phố nổi mang danh tiếng như 1 nơi chào đón người đi xe đạp (Amsterdam được xem như một trong hai thủ đô thân thiện với xe đạp nhất trên thế giới).',NULL,NULL,21,NULL,'FILL_IN_THE_BLANK',125,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:16:28.377736','user_56659',false,'2026-06-07 19:16:28.377736','user_56659','B/D','Trích đoạn chứa đáp án:
To continue the project we would have needed to set up another system, but the business partner had lost interest.''

Keyword cần chú ý:
withdrew support = has lost interest
partner = business partner

Giải thích đáp án:
Chương trình/dự án “bike-sharing” thất bại là do 1 người đồng hành cùng dự án đã rút hỗ trợ (trong đoạn trích dẫn: “had lost interest” (không còn hứng thú)).',NULL,NULL,20,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:15:40.245485','user_56659',false,'2026-06-07 19:15:40.245485','user_56659','C','Trích đoạn chứa đáp án:
It turned out that a white bicycle - per person, per kilometre -would cost the municipality only 10% of what it contributed to public transport per person per kilometre.'' (C)

Giải thích đáp án:
Đoạn trích dẫn giải thích rõ Schimmelpennink đã tính toán những khoản tiết kiệm tiềm năng khi thực hiện dự án như thế nào: chỉ tốn 10% những gì phải đóng góp cho phương tiện công cộng mỗi người 1km.',NULL,NULL,17,'an explanation of the potential savings a bike-sharing scheme would bring','FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:15:27.913658','user_56659',false,'2026-06-07 19:15:27.913658','user_56659','F','Trích đoạn chứa đáp án:
But financially I didn''t really benefit from it, because I never filed for a patent.'' (F)

Keyword cần chú ý:
unable to profit = financially didn’t benefit
from their work= from it

Giải thích đáp án:
Đoạn F nói về việc Schimmelpennink không thể tạo lợi nhuận từ dự án này vì ông chưa bao giờ nộp đơn xin cấp bằng sáng chế (file for a patent).',NULL,NULL,16,'a reference to a person being unable to profit their work','FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:15:13.177227','user_56659',false,'2026-06-07 19:15:13.177227','user_56659','C','Trích đoạn chứa đáp án:
Nevertheless, the council unanimously rejected the plan. ''They said that the bicycle belongs to the past. They saw a glorious future for the car,'' (C)

Giải thích đáp án:
Bản đề xuất về dự án “bike-sharing scheme” bị bãi bỏ vì Hội đồng đã từ chối kế hoạch: ‘Họ nói xe đạp đã thuộc về quá khứ. Họ nhìn thấy một tương lai huy hoàng đối với xe hơi’',NULL,NULL,15,'an explanation of why a proposed bike-sharing scheme was turned down','FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:13:47.893892','user_56659',false,'2026-06-07 19:13:47.893892','user_56659','TRUE','Trích đoạn chứa đáp án:
Gibson adds: ''Playful behaviour is also an important indicator of healthy social and emotional development. In my previous research, I investigated how observing children at play can give us important clues about their well-being and can even be useful in the diagnosis of neurodevelopmental disorders like autism.''

Keyword cần chú ý:
The way a child play = playful behaviour
provide information = give us important clues
possible medical problems = their well- being; the diagnosis of...

Giải thích đáp án:
Tất cả những keywords trong câu hỏi 37 đều được paraphrase và tìm thấy trong bài (câu trích dẫn).
Dịch: Cách trẻ chơi sẽ cung cấp thông tin về những vẫn đề sức khỏe có thể có (trong bài: sự khỏe mạnh và những triệu chứng về...)
→ TRUE',NULL,NULL,10,'The way a child plays may provide information about possible medical problems.','TRUE_FALSE_NOT_GIVEN',124,NULL),
	 ('2026-06-07 19:13:59.573739','user_56659',false,'2026-06-07 19:13:59.573739','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
Children wrote longer and better-structured stories when they first played with dolls representing characters in the story.

Giải thích đáp án:
Dịch: Chơi với búp bê được phát hiện có ích lợi cho kĩ năng viết của bé gái hơn bé trai.
Giải thích: Trong bài, phần thông tin đề cập đến việc chơi búp bê nói “Trẻ viết những câu chuyện dài với cấu trúc câu tốt hơn khi chúng bắt đầu chơi với búp bê - đại diện cho những nhân vật trong truyện”, hoàn toàn không đề cập đến việc so sánh kĩ năng viết giữa bé trai và bé gái.
→ NOT GIVEN',NULL,NULL,11,'Playing with dolls was found to benefit girls’ writing more than boys’ writing.','TRUE_FALSE_NOT_GIVEN',124,NULL),
	 ('2026-06-07 19:14:19.702582','user_56659',false,'2026-06-07 19:14:19.702582','user_56659','FALSE','Trích đoạn chứa đáp án:
Many teachers commented that they had always previously had children saying they didn''t know what to write about. With the Lego building, however, not a single child said this through the whole year of the project.''
Keyword cần chú ý:

had problems = didn’t know
thinking up ideas/ created the story = know what to write about

Giải thích đáp án:
Dịch: Trẻ gặp khó khăn trong việc nghĩ ra ý tưởng khi chúng bắt đầu tạo dựng câu chuyện với Lego.
Giải thích: Trong bài, giáo viên nói trước kia học sinh thường nói không biết viết gì nhưng với việc dựng Lego, không 1 đứa trẻ nào than phiền về việc này nữa.
→ FALSE',NULL,NULL,12,'Children had problems thinking up ideas when they first created the story with Lego.','TRUE_FALSE_NOT_GIVEN',124,NULL),
	 ('2026-06-07 19:17:06.20766','user_56659',false,'2026-06-07 19:17:06.208219','user_56659','ACTIVISTS','Trích đoạn chứa đáp án:
Provo, the organisation that came up with the idea, was a group of Dutch activists who wanted to change society.

Keyword cần chú ý:
was the idea of = came up with the idea
the Dutch group = a group of Dutch

Giải thích đáp án:
Đáp án sau động từ tobe “were” → đáp án là danh từ hoặc tính từ.
So sánh phần tìm thấy thông tin và câu hỏi → “activists” là đáp án của câu hỏi này.',NULL,NULL,23,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:16:17.076194','user_56659',false,'2026-06-07 19:16:17.076194','user_56659','B/D','Trích đoạn chứa đáp án:
People had become more environmentally conscious, and the Danish experiment had proved that bike-sharing was a real possibility.

Giải thích đáp án:
Dịch: Chương trình/dự án “bike-sharing” trở nên khả thi là nhờ vào sự thay đổi trong thái độ của mọi người (mọi người đã trở nên ý thức hơn về môi trường).',NULL,NULL,19,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:16:02.258922','user_56659',false,'2026-06-07 19:16:02.258922','user_56659','A','Trích đoạn chứa đáp án:
They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism. (A)

Giải thích đáp án:
Vấn đề mà “bike-sharing scheme” dự định sẽ giải quyết: những sự đe dọa đến ô nhiễm không khí và việc bảo vệ quyền lợi người tiêu dùng.',NULL,NULL,18,'a reference to the problems a bike-sharing scheme was intended to solve','FILL_IN_THE_BLANK',125,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:15:01.198865','user_56659',false,'2026-06-07 19:15:01.198865','user_56659','E','Trích đoạn chứa đáp án:
The system, however, was prone to vandalism and theft. ''After every weekend there would always be a couple of bikes missing,'' (E)

Giải thích đáp án:
“The bike-sharing scheme” được tạo ra với mục đích cung cấp xe đạp miễn phí cho những người cần phương tiện đi lại. Tuy nhiên, khi thực hiện dự án, mỗi tuần lại có một vài chiếc xe đạp bị trộm mất → mọi người đã sử dụng sai mục đích của dự án.',NULL,NULL,14,'a description of how people misused a bike-sharing scheme','FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:18:01.672675','user_56659',false,'2026-06-07 19:18:01.672675','user_56659','E','Trích đoạn chứa đáp án:
This implies that it is beneficial for hotel managers to understand what practices are most favorable to increase employee satisfaction and retention

Keyword cần chú ý:
to know = to understand
encourage good staff to remain = increase employee satisfaction and retention

Giải thích đáp án:
Dịch: Quản lý khách sạn cần biết điều gì khuyến khích đội ngũ nhân viên tốt tiếp tục làm việc (tương tự nội dung trích dẫn)
→ Đáp án: E. Enz and Siguaw',NULL,NULL,27,'Hotel managers need to know what would encourage good staff to remain.','FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:20:05.162983','user_56659',false,'2026-06-07 19:20:05.162983','user_56659','RESTAURANTS','Trích đoạn chứa đáp án:
Tews, Michel and Stafford (2013) conducted a study focusing on staff from a chain of themed restaurants in the United States.

Keyword cần chú ý:
carried out = conducted
research = a study
American = the United States

Giải thích đáp án:
Đáp án sau “chain of” → đáp án là 1 danh từ.
Từ những keywords được paraphrase → 50 “restaurants” là đáp án của câu hỏi này.
Dịch: Tews, Michel and Stafford tiến hành 1 cuộc nghiên cứu về đội ngũ nhân viên trong chuỗi nhà hàng ở Mĩ.',NULL,NULL,36,NULL,'FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:19:53.625975','user_56659',false,'2026-06-07 19:19:53.625975','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
Those particularly appropriate to the hospitality industry include allowing adequate breaks during the working day, staff functions that involve families, and providing health and well-being opportunities.

Keyword cần chú ý:
take breaks = allowing adequate breaks

Giải thích đáp án:
Dịch: Nhân viên nên được phép chọn thời điểm nghỉ ngơi trong ngày làm việc (trong bài chỉ nhắc đến việc cho phép nhân viên có 1 thời gian nghỉ tương thích, không đề cập đến việc nhân viên được phép tự chọn hay không)
→ Not given',NULL,NULL,35,'Staff should be allowed to choose when they take breaks during the working day.','YES_NO_NOT_GIVEN',126,NULL),
	 ('2026-06-07 19:19:39.574876','user_56659',false,'2026-06-07 19:19:39.574876','user_56659','NO','Trích đoạn chứa đáp án:
Significantly, though, just fulfilling these needs does not result in satisfaction, but only in the reduction of dissatisfaction (Maroudas et al., 2008).

Keyword cần chú ý:
improvement in working conditions and job security
just fulfilling these needs

Giải thích đáp án:
Dịch: Sự cải thiện trong điều kiện làm việc và an ninh công việc làm cho nhân viên hài lòng với công việc của họ. (thực chất, việc này chỉ làm giảm sự bất mãn đối với công việc)
→ No',NULL,NULL,34,'An improvement in working conditions and job security makes staff satisfied with their jobs.','YES_NO_NOT_GIVEN',126,NULL),
	 ('2026-06-07 19:19:24.684549','user_56659',false,'2026-06-07 19:19:24.684549','user_56659','NO','Trích đoạn chứa đáp án:
While it seems likely that employees’ reactions to their job characteristics could be affected by a predisposition to view their work environment negatively, no evidence exists to support this hypothesis (Spector et al., 2000)
 
Keyword cần chú ý:
their workplace = work environment
tendency = predisposition
dislike = view...negatively
 
Giải thích đáp án:
Mặc dù có vẻ như phản ứng của nhân viên về đặc điểm công việc bị ảnh hưởng bởi khuynh hướng nhìn nhận môi trường làm việc của họ 1 cách tiêu cực, KHÔNG có bằng chứng nào chứng minh giả thiết này.
→ No',NULL,NULL,33,'Research has shown that staff have a tendency to dislike their workplace.','YES_NO_NOT_GIVEN',126,NULL),
	 ('2026-06-07 19:19:09.382071','user_56659',false,'2026-06-07 19:19:09.382071','user_56659','YES','Trích đoạn chứa đáp án:
Among the many cited reasons are low compensation, inadequate benefits, poor working conditions and compromised employee morale and attitudes (Maroudas et al., 2008).

Keyword cần chú ý:
One reason = Among many cited reason
poor morale = compromised employee morale and attitudes

Giải thích đáp án:
Dịch: Một lý do dối với tỉ lệ nghỉ việc cao trong ngành công nghiệp “không khói” là tinh thần làm việc thấp
→ Yes',NULL,NULL,32,'One reason for high staff turnover in the hospitality industry is poor morale.','YES_NO_NOT_GIVEN',126,NULL),
	 ('2026-06-07 19:18:52.957056','user_56659',false,'2026-06-07 19:18:52.957056','user_56659','C','Trích đoạn chứa đáp án:
Among the many cited reasons are low compensation, inadequate benefits, poor working conditions and compromised employee morale and attitudes (Maroudas et al., 2008).

Giải thích đáp án:
Sự không hài lòng về lương không phải là lý do duy nhất những nhân viên “không khói” chuyển việc (những nhân tố khác: tiền bồi thường thấp, những lợi ích không tương xứng, điều kiện làm việc tệ, sự gượng ép trong tinh thần và thái độ làm việc)
Đáp án: C. Maroudas et al.',NULL,NULL,31,'Dissatisfaction with pay is not the only reason why hospitality workers change jobs.','FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:18:40.616518','user_56659',false,'2026-06-07 19:18:40.616518','user_56659','D','Trích đoạn chứa đáp án:
Ng and Sorensen (2008) demonstrated that when managers provide recognition to employees, motivate employees to work together, and remove obstacles preventing effective performance, employees feel more obligated to stay with the company.

Keyword cần chú ý:
are less likely to change jobs = more obligated to stay
cooperation = employees to work together
is encouraged = motivate

Giải thích đáp án:
Dịch: Nhân viên sẽ ít chuyển việc khi sự hợp tác được khuyến khích.
Nội dung trích dẫn: Khi quản lý ... thúc đẩy nhân viên làm việc cùng nhau, nhân viên sẽ cảm thấy có trách nhiệm ở lại công ty nhiều hơn.
Đáp án: D. Ng and Sorensen',NULL,NULL,30,'Staff are less likely to change jobs if cooperation is encouraged.','FILL_IN_THE_BLANK',126,NULL),
	 ('2026-09-02 17:31:40','truongdx18vtit',false,'2026-09-02 17:31:40','truongdx18vtit','INTAKE ',NULL,'','',36,'','FILL_IN_THE_BLANK',158,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-09-03 17:31:40','truongdx18vtit',false,'2026-09-03 17:31:40','truongdx18vtit','GENERATOR',NULL,'','',37,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-09-04 17:31:40','truongdx18vtit',false,'2026-09-04 17:31:40','truongdx18vtit','POWER LINES',NULL,'','',38,'','FILL_IN_THE_BLANK',158,''),
	 ('2026-09-05 17:31:40','truongdx18vtit',false,'2026-09-05 17:31:40','truongdx18vtit','STREAM FLOW',NULL,'','',39,'To be effective, hydroelectric dams should be built across rivers with both sufficient head and ______.','FILL_IN_THE_BLANK',158,''),
	 ('2026-09-06 17:31:40','truongdx18vtit',false,'2026-09-06 17:31:40','truongdx18vtit','CONSUMERS',NULL,'','',40,'There needs to be a balance between the needs of ______ living in developed environments and the preservation of natural habitat.','FILL_IN_THE_BLANK',158,''),
	 ('2026-09-07 17:31:40','truongdx18vtit',false,'2026-09-07 17:31:40','truongdx18vtit','MATTHEW',NULL,'','',1,'','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-08 17:31:40','truongdx18vtit',false,'2026-09-08 17:31:40','truongdx18vtit','4126',NULL,'','',2,'','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-09 17:31:40','truongdx18vtit',false,'2026-09-09 17:31:40','truongdx18vtit','CREATIVE WRITING',NULL,'','',3,'','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-10 17:31:40','truongdx18vtit',false,'2026-09-10 17:31:40','truongdx18vtit','FAMILY FRIENDS',NULL,'','',4,'','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-11 17:31:40','truongdx18vtit',false,'2026-09-11 17:31:40','truongdx18vtit','PEER TUTOR',NULL,'','',5,'','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-12 17:31:40','truongdx18vtit',false,'2026-09-12 17:31:40','truongdx18vtit','TENNIS COACH',NULL,'','',6,'','FILL_IN_THE_BLANK',159,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-09-13 17:31:40','truongdx18vtit',false,'2026-09-13 17:31:40','truongdx18vtit','C',NULL,'','',7,'Weekdays','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-14 17:31:40','truongdx18vtit',false,'2026-09-14 17:31:40','truongdx18vtit','B',NULL,'','',8,'Evenings','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-15 17:31:40','truongdx18vtit',false,'2026-09-15 17:31:40','truongdx18vtit','B',NULL,'','',9,'Weekends','FILL_IN_THE_BLANK',159,''),
	 ('2026-09-16 17:31:40','truongdx18vtit',false,'2026-09-16 17:31:40','truongdx18vtit','A',NULL,'','',10,'School Holidays','FILL_IN_THE_BLANK',159,''),
	 ('2026-06-07 19:17:20.801562','user_56659',false,'2026-06-07 19:17:20.801562','user_56659','CONSUMERISM','Trích đoạn chứa đáp án:
They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism.

Keyword cần chú ý:
damage to environment = perceived threats of air pollution

Giải thích đáp án:
Đáp án sau giới từ “about” → đáp án là 1 danh từ.
Trong câu hỏi, ta tìm thấy cụm “damage. to the environment” đứng trước “and” và tìm được cụm từ paraphrase “perceived threats of air pollution” trong câu trích dẫn → Vậy đáp án ở sau “and”: “consumerism” (sự bảo vệ quyền lợi người tiêu dùng).',NULL,NULL,24,NULL,'FILL_IN_THE_BLANK',125,NULL),
	 ('2026-06-07 19:20:52.671861','user_56659',false,'2026-06-07 19:20:52.671861','user_56659','CHARACTERISTICS','Trích đoạn chứa đáp án:
Their findings support the view that fun may indeed have a beneficial effect, but the framing of that fun must be carefully aligned with both organizational goals and employee characteristics.

Keyword cần chú ý:
needed to fit with = must be carefully aligned with
company’s = organizational
on the staff = employee

Giải thích đáp án:
Đáp án 39 đứng sau sỡ hữu cách “company’s” và đáp án 40 đứng sau “the” → Hai đáp án đều là danh từ
2 đáp án đang ở cấu trúc song song (trước và sau “and”)
Cùng với những keywords được paraphrase → đáp án là 39. “goals” và 40. “characteristics”',NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:20:41.134677','user_56659',false,'2026-06-07 19:20:41.134677','user_56659','GOALS','Trích đoạn chứa đáp án:
Their findings support the view that fun may indeed have a beneficial effect, but the framing of that fun must be carefully aligned with both organizational goals and employee characteristics.

Keyword cần chú ý:
needed to fit with = must be carefully aligned with
company’s = organizational
on the staff = employee

Giải thích đáp án:
Đáp án 39 đứng sau sỡ hữu cách “company’s” và đáp án 40 đứng sau “the” → Hai đáp án đều là danh từ
2 đáp án đang ở cấu trúc song song (trước và sau “and”)
Cùng với những keywords được paraphrase → đáp án là 39. “goals” và 40. “characteristics”',NULL,NULL,39,NULL,'FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:20:27.866436','user_56659',false,'2026-06-07 19:20:27.866436','user_56659','TURNOVER','Trích đoạn chứa đáp án:
and manager support for fun had a favorable impact in reducing turnover.

Keyword cần chú ý:
management involvement = mannager support for the fun
led to = had as favorable impact in
lower = reducing

Giải thích đáp án:
Đáp án đứng sau “lower staff” → đáp án là một danh từ được “staff” bổ nghĩa
Dịch: sự tham gia của đội ngũ quản lý giúp tỉ lệ thay đổi nhân viên thấp hơn → “turnover” là đáp án của câu hỏi này',NULL,NULL,38,NULL,'FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:20:16.902132','user_56659',false,'2026-06-07 19:20:16.902132','user_56659','PERFORMANCE','Trích đoạn chứa đáp án:
It was found that fun activities had a favorable impact on performance

Keyword cần chú ý:
They discovered that = it was found that
activities designed for staff = activities
improved = has a favorable impact on

Giải thích đáp án:
Đáp án sau tính từ sỡ hữu “their” → đáp án là 1 danh từ
Dịch: Họ phát hiện ra rằng những hoạt động được thiết kế để nhân viên vui chơi đã cải thiện hiệu suất làm việc của họ. → “performance” là đáp án của câu hỏi này.',NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:18:26.278705','user_56659',false,'2026-06-07 19:18:26.278705','user_56659','B','Trích đoạn chứa đáp án:
Lucas also points out that ''the substance of HRM practices does not appear to be designed to foster constructive relations with employees or to represent a managerial approach that enables developing and drawing out the full potential of people, even though employees may be broadly satisfied with many aspects of their work'' (Lucas, 2002).

Keyword cần chú ý:
help workers improve their skills = enables developing and drawing out the full potential of people
little is done = does not appear to be designed to

Giải thích đáp án:
Dịch: Rất ít nỗ lực được thực hiện trong ngành “hospitality industry” - dịch vụ không khói (dịch vụ khách sạn - nhà hàng - du lịch) để giúp nhân viên phát triển kĩ năng của họ.
Những hoạt động cốt lõi của bộ phận quản lý nhân sự không được thiết kế để thuận lợi cho mối quan hệ cấu trúc giữa nhân viên hoặc để tạo nên 1 phương pháp quản lý giúp quản lý và tận dụng tiềm năng của con người,”.
Đáp án: B. Lucas',NULL,NULL,29,'
Little is done in the hospitality industry to help workers improve their skills.','FILL_IN_THE_BLANK',126,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-09-17 17:31:40','truongdx18vtit',false,'2026-09-17 17:31:40','truongdx18vtit','GOALS',NULL,'','',11,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-18 17:31:40','truongdx18vtit',false,'2026-09-18 17:31:40','truongdx18vtit','REPORT',NULL,'','',12,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-19 17:31:40','truongdx18vtit',false,'2026-09-19 17:31:40','truongdx18vtit','STRESS MANAGEMENT',NULL,'','',13,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-20 17:31:40','truongdx18vtit',false,'2026-09-20 17:31:40','truongdx18vtit','CALCULATORS',NULL,'','',14,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-21 17:31:40','truongdx18vtit',false,'2026-09-21 17:31:40','truongdx18vtit','SKILL LEVEL',NULL,'','',15,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-22 17:31:40','truongdx18vtit',false,'2026-09-22 17:31:40','truongdx18vtit','STOP SMOKING',NULL,'','',16,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-23 17:31:40','truongdx18vtit',false,'2026-09-23 17:31:40','truongdx18vtit','BACK CARE',NULL,'','',17,'','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-24 17:31:40','truongdx18vtit',false,'2026-09-24 17:31:40','truongdx18vtit','CHANGES',NULL,'','',18,'Health professionals will help people make long-lasting ______.','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-25 17:31:40','truongdx18vtit',false,'2026-09-25 17:31:40','truongdx18vtit','SERIOUS',NULL,'','',19,'Coaching is for people with ______ diseases','FILL_IN_THE_BLANK',160,''),
	 ('2026-09-26 17:31:40','truongdx18vtit',false,'2026-09-26 17:31:40','truongdx18vtit','PLAN',NULL,'','',20,'Coaches help people make a ______ and keep to it.','FILL_IN_THE_BLANK',160,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-09-27 17:31:40','truongdx18vtit',false,'2026-09-27 17:31:40','truongdx18vtit','C',NULL,'','[
  "A. school students.",
  "B. Open Day committee members.",
  "C. Open Day visitors."
]',21,'Clare and Grant must arrange a competition which will especially interest','MULTIPLE_CHOICE',161,''),
	 ('2026-09-28 17:31:40','truongdx18vtit',false,'2026-09-28 17:31:40','truongdx18vtit','B',NULL,'','["A. an iPod", "B. an iPad", "C. an iPhone"]',22,'What will the prize be?','MULTIPLE_CHOICE',161,''),
	 ('2026-09-29 17:31:40','truongdx18vtit',false,'2026-09-29 17:31:40','truongdx18vtit','A',NULL,'','["A. a university department", "B. Clare and Grant", "C. Rick Smith"]',23,'Who will be responsible for buying the prize?','MULTIPLE_CHOICE',161,''),
	 ('2026-09-30 17:31:40','truongdx18vtit',false,'2026-09-30 17:31:40','truongdx18vtit','A',NULL,'','["A. fun", "B. guesswork", "C. ability"]',24,'What is the most important aspect for entrants in the competition?','MULTIPLE_CHOICE',161,''),
	 ('2026-10-01 17:31:40','truongdx18vtit',false,'2026-10-01 17:31:40','truongdx18vtit','C',NULL,'','["A. a portal", "B. a new world of education", "C. a different time period"]',25,'In the science fiction series on television, what is on the other side of the gateway?','MULTIPLE_CHOICE',161,''),
	 ('2026-06-07 19:18:13.170546','user_56659',false,'2026-06-07 19:18:13.170546','user_56659','D','Trích đoạn chứa đáp án:
Ng and Sorensen (2008) demonstrated that when managers provide recognition to employees, motivate employees to work together, and remove obstacles preventing effective performance, employees feel more obligated to stay with the company.

Keyword cần chú ý:
the actions of managers = provide recognitions + motivate employees + remove obstacles
they shouldn’t move = more obligated to stay with the company

Giải thích đáp án:
Dịch: Những hành động của người quản lý nên làm cho đội ngũ nhân viên thấy rằng họ không nên chuyển qua 1 người chủ khác
Ý câu trích dẫn: Ng and Sorensen chứng minh rằng khi những quản lý thể hiện sự công nhận đối với nhân viên, thúc đẩy nhân viên làm việc cùng nhau, và loại bỏ những trở ngại ngăn chặn hiệu quả làm việc, nhân viên sẽ cảm thấy có trách nhiệm ở lại với công ty hơn.
Đáp án: D. Ng and Sorensen',NULL,NULL,28,'The actions of managers may make staff feel they shouldn’t move to a different employer.','FILL_IN_THE_BLANK',126,NULL),
	 ('2026-06-07 19:41:30.118441','user_56659',false,'2026-06-07 19:41:30.118441','user_56659','B','Trích đoạn chứa đáp án:
Deep-sea fish and whales have little or no light by day or by night.

Giải thích đáp án:
Câu hỏi: Ví dụ wildlife bên cạnh dơi không dùng thị lực để định hướng
Bài đọc: Những con cá ở sâu dưới lòng biển và cá voi thì cả ban ngày và ban đêm đều hầu như không thấy ánh sáng.
-> Không dùng ánh sáng để định hướng, tức là không dùng thị giác
-> Ví dụ về những loài bên cạnh dơi không định hướng bằng thị giác
-> Đáp án là paragraph B',NULL,NULL,1,'Examples of wildlife other than bats which do not rely on vision to navigate by
','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:41:42.518536','user_56659',false,'2026-06-07 19:41:42.518536','user_56659','A','Trích đoạn chứa đáp án:
In the time when the dinosaurs dominated the daytime economy, our mammalian ancestors probably only managed to survive at all because they found ways of scraping a living at night.

Keyword cần chú ý:
early mammals = our mammalian ancestors

Giải thích đáp án:
Câu hỏi: cách early mammals tránh chết (tuyệt chủng)
Bài đọc: Khủng long thống trị vào ban ngày thì tổ tiên động vật có vú phải tồn tại bằng cách_x0008_ kiếm _x0008_ăn vào ban đêm.
-> mammals thời này tồn tại bằng cách kiếm ăn vào ban đêm
-> Đáp án là paragraph A',NULL,NULL,2,'How early mammals avoided dying out','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:41:57.906637','user_56659',false,'2026-06-07 19:41:57.906637','user_56659','A','Trích đoạn chứa đáp án:
Given that there is a living to be made at night, and given that alternative daytime trades are thoroughly occupied, natural selection has favored bats that make a go of the night-hunting trade.

Keyword cần chú ý:
hunt in the dark = make a go of the night-hunting trade

Giải thích đáp án:
Câu hỏi: lý do bats săn mồi vào buổi đêm
Bài đọc: Vì thức ăn vào ban ngày đã hầu như bị “chiếm” hết rồi, thế nên nguyên tắc chọc lọc tự nhiên đã chỉ ra rằng dơi phải đi săn mồi vào ban đêm.
-> Đáp án là paragraph A',NULL,NULL,3,'Why bats hunt in the dark','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:42:10.055554','user_56659',false,'2026-06-07 19:42:10.055554','user_56659','E','Trích đoạn chứa đáp án:
But the underlying physical theories of radar and sonar are very similar, and much of our scientific understanding of the details of what bats are doing has come from applying radar theory to them.

Keyword cần chú ý:
our understanding = scientific understanding

Giải thích đáp án:
Câu hỏi: cách một phát hiện cụ thể giúp hiểu biết của con người về bats
Bài đọc: Lý thuyết vật lý về sóng radar và sonar rất giống nhau, và hầu hết hiểu biết về cụ thể cách bats sử dụng sóng âm đến nhờ áp dụng lý thuyết sóng radar.
-> lý thuyết radar giúp hiểu bats
-> Đáp án là paragraph E',NULL,NULL,4,'How a particular discovery has helped our understanding of bats','FILL_IN_THE_BLANK',139,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:42:23.574336','user_56659',false,'2026-06-07 19:42:23.574336','user_56659','D','Trích đoạn chứa đáp án:
After this technique has been invented, it was only a matter of time before weapons designers adapted it for the detection of submarines.

Giải thích đáp án:
Câu hỏi: Ứng dụng echolocation trong quân sự.
Bài đọc: Sau khi phát minh ra công nghệ này thì việc cải thiện nó thành một vật dò tìm tàu ngầm chỉ là vấn đề sớm hay muộn mà thôi.
-> các nhà thiết kế vũ khí áp dụng echolocation cho dò tìm tàu ngầm
-> Đáp án là paragraph D',NULL,NULL,5,'Early military uses of echolocation','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:42:35.809718','user_56659',false,'2026-06-07 19:42:35.809718','user_56659','PHANTOM','Trích đoạn chứa đáp án:
Experiments showed that, in fact, facial vision is nothing to do with touch or the front of the face, although the sensation may be referred to the front of the face, like the referred pain in a phantom limb.

Keyword cần chú ý:
arm or leg = limb

Giải thích đáp án:
"Facial vision" là nội dung đoạn D nên ta tìm thông tin cho các câu 6-9 ở đoạn này.
Keyword "sensation" xuất hiện trong câu "Experiment..." nói rằng cảm giác này giống cảm giác ở một "phantom limb" (chân/tay đã bị cắt bỏ nhưng cảm giác vẫn ở đó).
-> Đáp án là "phantom"',NULL,NULL,6,NULL,'FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:42:46.064429','user_56659',false,'2026-06-07 19:42:46.064429','user_56659','ECHOES/OBSTACLES','Trích đoạn chứa đáp án:
Blind people, without even being aware of the fact, are actually using echoes of their own footsteps and of other sounds, to sense the presence of obstacles.

Giải thích đáp án:
Bài đọc: Những người mù thường dùng âm thanh vọng lại từ bước chân hoặc những âm thanh khác để cảm nhận được sự xuất hiện của những vật cản hoặc trở ngại trên đường.
-> facial vision đến từ nhận biết "echoes" (tiếng vọng) từ tiếng bước chân của chính mình và âm thanh khác
-> Đáp án là "echoes"',NULL,NULL,7,NULL,'FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:42:56.747705','user_56659',false,'2026-06-07 19:42:56.747705','user_56659','DEPTH','Trích đoạn chứa đáp án:
Before this was discovered, engineers had already built instruments to exploit the principle, for example to measure the depth of the sea under a ship.

Keyword cần chú ý:
calculate = measure
seabed ~ sea

Giải thích đáp án:
Keyword "instruments" xuấ thiện ở câu ói rằng các kỹ sư đã xây dựng công cụ để sử dụng nguyên tắc này, như để đo "depth" (độ sâu) của biển dưới một con tàu.
-> Đáp án là "depth"',NULL,NULL,8,NULL,'FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:43:11.256043','user_56659',false,'2026-06-07 19:43:11.256043','user_56659','SUBMARINES','Trích đoạn chứa đáp án:
After this technique had been invented, it was only a matter of time before weapons designers adapted it for the detection of submarines.

Keyword cần chú ý:
finding = detection

Giải thích đáp án:
Bài đọc: những người thiết kế vũ khí áp dụng công nghệ này để phát hiện "submarines" (tàu ngầm).
-> Đáp án là "submarines"',NULL,NULL,9,NULL,'FILL_IN_THE_BLANK',139,NULL),
	 ('2026-10-02 17:31:40','truongdx18vtit',false,'2026-10-02 17:31:40','truongdx18vtit','THE PUBLIC',NULL,'','',26,'Who will judge the competition?','FILL_IN_THE_BLANK',161,''),
	 ('2026-06-07 19:43:33.135475','user_56659',false,'2026-06-07 19:43:33.135475','user_56659','NATURAL SELECTION','Trích đoạn chứa đáp án:
The Sonar and Radar pioneers didn''t know it then, but all the world now knows that bats, or rather natural selection working on bats, had perfected the system tens of millions of years earlier.

Giải thích đáp án:
Câu hỏi: Trước phát minh radar, cái gì đã dẫn đến hệ thống giống radar phức tạp ở bats.
Bài đọc: Lúc đó thì chưa có sự ra đời của ra-đa, nhưng "natural selection" (chọn lọc tự nhiên) trên với loài dơi đã giúp hoàn thiện hệ thống này hàng chục triệu năm trước.
-> Đáp án là "natural selection"',NULL,NULL,10,'Long before the invention of radar,…………… had resulted in a sophisticated radar-like system in bats.','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:43:48.702087','user_56659',false,'2026-06-07 19:43:48.702087','user_56659','RADIO WAVES/ECHOES','Trích đoạn chứa đáp án:
It is technically incorrect to talk about bat ''radar'', since they do not use radio waves.

Keyword cần chú ý:
inaccurate = incorrect

Giải thích đáp án:
Câu hỏi: Radar là từ không chính xác khi nói về dơi vì cái gì không được dùng trong hệ thống định hướng của chúng.
Bài đọc: Sử dụng từ "radio waves" (sóng radar) để nói về loài dơi thì thật ra là chưa chính xác vì chúng không sử dụng sóng radio.
-> Đáp án là "radio waves"',NULL,NULL,11,'Radar is an inaccurate term when referring to bats because………………are not used in their navigation system.','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:44:02.37302','user_56659',false,'2026-06-07 19:44:02.37302','user_56659','MATHEMATICAL THEORIES','Trích đoạn chứa đáp án:
But the underlying mathematical theories of radar and sonar are very similar.

Giải thích đáp án:
Câu hỏi: Radar và sonar đều dựa vào cái gì.
Bài đọc: "Mathematical theories" (lý thuyết toán học) của radar và sonar thì rất giống nhau.
-> Đáp án là "mathematical theories"',NULL,NULL,12,'Radar and sonar are based on similar…………………….','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:44:40.248861','user_56659',false,'2026-06-07 19:44:40.248861','user_56659','XI','Trích đoạn chứa đáp án:
At the height of the Roman Empire, nine major systems, with an innovative layout of pipes and wellbuilt sewers, supplied the occupants of Rome with as much water per person as is provided in many parts of the industrial world today.

Giải thích đáp án:
Bài đọc: Vào thời của đế quốc La Mã thì có đến 9 hệ thống ống nước tân tiến để cung cấp nước cho người dân của Rome, mà lượng nước này tương đương với mức mà thế giới công nghiệp ngày nay được cung cấp.
-> Paragraph A nói về hệ thống cung cấp nước trong lịch sử, với ví dụ ở Roman Empire cổ đại
-> Đáp án là heading xi. A description of ancient water supplies',NULL,NULL,14,'Paragraph A','FILL_IN_THE_BLANK',140,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:44:57.231413','user_56659',false,'2026-06-07 19:44:57.231413','user_56659','VII','Trích đoạn chứa đáp án:
Preventable water-related diseases kill an estimated 10,000 to 20,000 children every day, and the latest evidence suggests that we are falling behind in efforts to solve these problems.

Giải thích đáp án:
Trong đoạn có những từ khóa như: "diseases", "kill", …
-> liên quan đến sức khỏe
-> Đáp án là vii. The relevance to health',NULL,NULL,15,'Paragraph C','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:45:25.559614','user_56659',false,'2026-06-07 19:45:25.559614','user_56659','I','Trích đoạn chứa đáp án:
Some water experts are now demanding that existing infrastructure be used in smarter ways rather than building new facilities, which is increasingly considered the option of last, not first, resort.

Keyword cần chú ý:
scientists = expert

Giải thích đáp án:
Bài đọc: Các chuyên gia về nước đang yêu cầu hệ thống hạ tầng phải được sử dụng tốt hơn, hiệu quả hơn.
-> Đề xuất liên quan đến chính sách
-> Đáp án là i. Scientists’ call for a revision of policy',NULL,NULL,17,'Paragraph E','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:45:43.929083','user_56659',false,'2026-06-07 19:45:43.929083','user_56659','IX','Trích đoạn chứa đáp án:
Fortunately - and unexpectedly - the demand for water is not rising as rapidly as some predicted.

Giải thích đáp án:
Câu mở đầu cũng là topic sentence của đoạn nói về việc nhu cầu nước không tăng nhanh như nhiều người dự đoán.
-> Nhu cầu nước giảm
-> Đáp án là ix. A surprising downward trend in demand for water',NULL,NULL,18,'Paragraph F','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:45:59.963515','user_56659',false,'2026-06-07 19:45:59.963515','user_56659','II','Trích đoạn chứa đáp án:
What explains this remarkable turn of events? Two factors: …..

Giải thích đáp án:
Câu mở đầu cũng là topic sentence của đoạn đặt câu hỏi về nguyên nhân của việc nhu cầu nước giảm. Phần sau nêu ra hai yếu tố giải thích cho hiện tượng này.
-> Đáp án là ii. An explanation for reduced water use',NULL,NULL,19,'Paragraph G','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:46:16.019714','user_56659',false,'2026-06-07 19:46:16.019714','user_56659','X','Trích đoạn chứa đáp án:
But such projects must be built to higher specifications and with more accountability to local people and their environment than in the past.

Giải thích đáp án:
Đoạn này nói về việc khi xây các dự án để phục vụ nhu cầu dùng nước ở các nước đang phát triển thì cần đảm bảo “higher specifications” (tiêu chuẩn, yêu cầu cao) và “more accountability” (tính giải trình, minh bạch cho dự án).
-> Nâng cao tiêu chuẩn
-> Đáp án là x. The need to raise standards',NULL,NULL,20,'Paragraph H','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:47:05.467298','user_56659',false,'2026-06-07 19:47:05.467298','user_56659','NO','Trích đoạn chứa đáp án:
At the height of the Roman Empire, nine major systems, with an innovative layout of pipes and wellbuilt sewers, supplied the occupants of Rome with as much water per person as is provided in many parts of the industrial world today.

Giải thích đáp án:
Bài đọc: Hệ thống cung cấp nước của Roman Empire có khả năng cung cấp người dân Rome với lượng nước tương đương lượng mà người dân ở nước phát triển ngày nay.
Câu hỏi: Lượng nước con người sử dụng ở thế giới công nghiệp hoá cao hơn ở Ancient Rome.
-> NO',NULL,NULL,21,'Water use per person is higher in the industrial world than it was in Ancient Rome.','YES_NO_NOT_GIVEN',140,NULL),
	 ('2026-06-07 19:44:16.647092','user_56659',false,'2026-06-07 19:44:16.647092','user_56659','ZOOLOGIST','Trích đoạn chứa đáp án:
The American zoologist Donald Griffin, who was largely responsible for the discovery of sonar in bats, coined the term ''écholocation'' to cover both sonar and radar, whether used by animals or by human instruments.

Keyword cần chú ý:
first used the term = coined the term

Giải thích đáp án:
Câu hỏi: Từ ''echolocation'' được sử dụng lần đầu bởi người làm nghề gì.
Bài đọc: "Zoologist" (nhà động vật học) Donald Griffin đã dùng từ “echolocation” để chỉ về cả sonar và radar, dù là người hay vật.
-> Đáp án là "zoologist"',NULL,NULL,13,'The word ‘echolocation’ was first used by someone working as a………………….','FILL_IN_THE_BLANK',139,NULL),
	 ('2026-06-07 19:45:10.340968','user_56659',false,'2026-06-07 19:45:10.340968','user_56659','V','Trích đoạn chứa đáp án:
More than 20 % of all freshwater fish species are now threatened or endangered because dams and water withdrawals have destroyed the freeflowing river ecosystems where they thrive.

Giải thích đáp án:
Bài đọc: Hơn 20% những loài cá nước ngọt đang bị đe dọa, hoặc gặp nguy hiểm vì những cái đập và việc lấy nước đã phá hủy hệ sinh thái dòng chảy nơi mà chúng sinh sống.
-> Paragraph D có nội dung chính liên quan đến môi trường
-> Đáp án là v. Environmental effects',NULL,NULL,16,'Paragraph D','FILL_IN_THE_BLANK',140,NULL),
	 ('2026-06-07 19:48:04.305096','user_56659',false,'2026-06-07 19:48:04.305096','user_56659','YES','Trích đoạn chứa đáp án:
Food production has kept pace with soaring populations mainly because of the expansion of artificial irrigation systems that make possible the growth of 40 % of the world’s food.

Giải thích đáp án:
Bài đọc: Ngành công nghiệp sản xuất thực phẩm đã đuổi kịp với việc dân số gia tăng chủ yếu là nhờ sự mở rộng các hệ thống thuỷ lợi nhân tạo giúp tạo ra sự gia tăng 40% thực phẩm của thế giới.
-> Hệ thống thuỷ lợi giúp tăng số lượng lương thực sản xuất được
Câu hỏi: Cung cấp lương thực cho dân số đang tăng là khả thi chủ yếu nhờ hệ thống thuỷ lợi.
-> YES',NULL,NULL,22,'Feeding increasing populations is possible due primarily to improved irrigation systems','YES_NO_NOT_GIVEN',140,NULL),
	 ('2026-06-07 19:50:15.97305','user_56659',false,'2026-06-07 19:50:15.97305','user_56659','NOT GIVEN','Giải thích đáp án:
Câu hỏi: Hệ thống nước hiện đại bắt chước, làm theo hệ thống của người Hy Lạp và La Mã cổ.
Trong bài không có thông tin so sánh hệ thống hiện đại và các hệ thống cổ.
-> NOT GIVEN',NULL,NULL,23,'Modern water systems imitate those of the ancient Greeks and Romans.','YES_NO_NOT_GIVEN',140,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:50:37.77647','user_56659',false,'2026-06-07 19:50:37.77647','user_56659','NO','Although population, industrial output and economic productivity have continued to soar in developed nations, the rate at which people withdraw water from aquifers, rivers and lakes has slowed.

Giải thích đáp án:
Bài đọc: Mặc cho sự phát triển vượt bậc của công nghiệp nhưng mức nước mà con người lấy ra từ sông hồ lại không nhiều.
Câu hỏi: Phát triển công nghiệp đang làm tăng tổng nhu cầu nước.
-> NO',NULL,NULL,24,'Industrial growth is increasing the overall demand for water.','YES_NO_NOT_GIVEN',140,NULL),
	 ('2026-06-07 19:50:51.050286','user_56659',false,'2026-06-07 19:50:51.050286','user_56659','YES','Trích đoạn chứa đáp án:
But since 1980, the amount of water consumed per person has actually decreased, thanks to a range of new technologies that help to conserve water in homes and industry.

Keyword cần chú ý:
reduction = decrease

Giải thích đáp án:
Bài đọc: Nhờ có những công nghệ mới giúp giữ nước trong hộ gia đình và công nghiệp nên lượng nước mà mỗi người sử dụng lại giảm.
Câu hỏi: Công nghệ hiện đại đã giúp giảm lượng nước dùng trong gia đình.
-> YES',NULL,NULL,25,'Modern technologies have led to reduction in the domestic water consumption.','YES_NO_NOT_GIVEN',140,NULL),
	 ('2026-06-07 19:51:29.020781','user_56659',false,'2026-06-07 19:51:29.020781','user_56659','NOT GIVEN','Giải thích đáp án:
Câu hỏi: Trong tương lai, các chính phủ nên duy trì sở hữu các cơ sở hạ tầng về nước.
Thông tin về việc ai sở hữu hay theo tác giả chính phủ có nên tiếp tục sở hữu hạ tầng về nước hay không không được nhắc đến.
-> NOT GIVEN',NULL,NULL,26,'In the future, governments should maintain ownership of water infrastructures.','YES_NO_NOT_GIVEN',140,NULL),
	 ('2026-06-07 19:52:55.899504','user_56659',false,'2026-06-07 19:52:55.899504','user_56659','D','Trích đoạn chứa đáp án:
Educating Psyche by Bernie Neville is a book which looks at radical new approaches to learning.

Keyword cần chú ý:
not traditional = radical

Giải thích đáp án:
Câu hỏi: Quyển sách "Educating Psyche" chủ yếu nói về gì.
Tên sách được nhắc đến ở câu đầu tiên của bài. Trong đó nói quyển sách này nói về những cách tiếp cận khác biệt với việc học.
-> Cách tiếp cận khác với truyền thống
-> Đáp án là D. ways of learning which are not traditional',NULL,'["A. the power of suggestion in learning","B. a particular technique for leaning based on emotions","C. the effects of emotion on the imagination and the unconscious","D. ways of learning which are not traditional"]',27,'The book Educating Psyche is mainly concerned with','MULTIPLE_CHOICE',141,NULL),
	 ('2026-06-07 19:59:01.115045','user_56659',false,'2026-06-07 19:59:01.115045','user_56659','G','Trích đoạn chứa đáp án:
...few teachers are able to emulate the spectacular results of Lozanov and his associates.

Giải thích đáp án:
Từ cần điền là từ mô tả kết quả các giáo viên sử dụng phương pháp của Lozanov.
Bài đọc: rất ít giáo viên có thể đưa ra được những kết quả xuất sắc như Lozanov và cộng sự.
-> Kết quả của các giáo viên thường không có gì đặc biệt
-> G. unspectacular',NULL,NULL,40,NULL,'FILL_IN_THE_BLANK',141,NULL),
	 ('2026-06-07 19:57:00.638452','user_56659',false,'2026-06-07 19:57:00.638452','user_56659','NOT GIVEN','Trích đoạn chứa đáp án:
Another difference from conventional teaching is the evidence that students can regularly learn 1000 new words of a foreign language during a suggestopedic session, as well as grammar and idiom.

Giải thích đáp án:
Câu hỏi: giáo viên nói họ thích dùng suggestopedia hơn các phương pháp truyền thống cho việc dạy ngôn ngữ.
Trong bài không nhắc đến suy nghĩ của giáo viên về suggestopedia.
-> NOT GIVEN',NULL,NULL,35,'Teachers say they prefer suggestop
         
edia to traditional approaches to language teaching.','TRUE_FALSE_NOT_GIVEN',141,NULL),
	 ('2026-06-07 19:56:42.49528','user_56659',false,'2026-06-07 19:56:42.49528','user_56659','NOT GIVEN','Giải thích đáp án:
Câu hỏi: Học sinh nhận thấy được cải thiện trí nhớ và đây là một lợi ích gián tiếp (của suggestopedia).
Trong bài không nhắc đến "improvements in their memory" (cải thiện trí nhớ) của học sinh.
-> NOT GIVEN',NULL,NULL,34,'As an indirect benefit, students notice improvements in their memory.','TRUE_FALSE_NOT_GIVEN',141,NULL),
	 ('2026-06-07 19:56:25.820599','user_56659',false,'2026-06-07 19:56:25.820599','user_56659','TRUE','Trích đoạn chứa đáp án:
Some hours after the two-part session, there is a follow-up class [...] Such methods are not unusual in language teaching.

Giải thích đáp án:
Bài đọc: Các phương pháp này không khác thường trong việc giảng dạy ngôn ngữ.
Câu hỏi: Trong buổi học sau đó, các hoạt động dạy học giống phương pháp dùng trong lớp học truyền thống.
-> TRUE',NULL,NULL,33,'In the follow-up class, the teaching activities are similar to those used in conventional classes.','TRUE_FALSE_NOT_GIVEN',141,NULL),
	 ('2026-06-07 19:56:06.895594','user_56659',false,'2026-06-07 19:56:06.895594','user_56659','FALSE','Trích đoạn chứa đáp án:
Through meeting with the staff and satisfied students they develop the expectation that learning will be easy and pleasant.

Keyword cần chú ý:
demanding >< easy and pleasant

Giải thích đáp án:
Bài đọc: Việc học ngôn ngữ không yêu cầu cao mà ngược lại rất dễ dàng và thoải mái.
Câu hỏi: Trước lớp học suggestopedia, học sinh được cho biết trải nghiệm ngôn ngữ sẽ đòi hỏi nhiều và mệt mỏi.
-> FALSE',NULL,NULL,32,'Prior to the suggestopedia class, students are made aware that the language experience will be demanding.','TRUE_FALSE_NOT_GIVEN',141,NULL),
	 ('2026-06-07 19:55:45.784435','user_56659',false,'2026-06-07 19:55:45.784435','user_56659','FALSE','Trích đoạn chứa đáp án:
In the first part, the music is classical (Mozart, Beethoven, Brahms) and the teacher reads the text slowly and solemnly, with attention to the dynamics of the music. [...] This is followed by several minutes of silence. In the second part, they listen to baroque music (Bach, Corelli, Handel) while the teacher reads the text in a normal speaking voice.

Giải thích đáp án:
Bài đọc: Phần đầu học sinh nghe nhạc cổ điển và giáo viên đọc chậm, nghiêm túc. Phần hai học sinh nghe nhạc baroque còn giáo viên đọc giọng như nói bình thường.
-> Cả loại nhạc và tốc độ đọc của giáo viên đều thay đổi
Câu hỏi: Trong ví dụ ở khổ 4, biến số hay thứ duy nhất thay đổi là loại nhạc.
-> FALSE',NULL,NULL,31,'In the example of suggestopedic teaching in the fourth paragraph, the only variable that changes is the music.','TRUE_FALSE_NOT_GIVEN',141,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:55:20.738719','user_56659',false,'2026-06-07 19:55:20.738719','user_56659','C','Trích đoạn chứa đáp án:
Lozanov therefore made indirect instruction (suggestion) central to his teaching system. In suggestopedia, as he called his method, consciousness is shifted away from the curriculum to focus on something peripheral. 
 

Keyword cần chú ý:
 

think about something other than = shifted away from the curriculum to focus on something peripheral
indirect instruction (suggestion) central to his teaching system = Lozanov claims that teachers
 
Giải thích đáp án:
 

Câu hỏi: Lozanov nói rằng giáo viên nên huấn luyện học sinh làm gì.
-> Đáp án là C. think about something other than the curriculum content.',NULL,'["A. memorise details of the curriculum","B. develop their own sets of indirect instructions","C. think about so         mething other than the curriculum content","D. avoid overloading the capa         city of the brain"]',30,'Lozanov claims that teachers should train students to','MULTIPLE_CHOICE',141,NULL),
	 ('2026-10-03 17:31:40','truongdx18vtit',false,'2026-10-03 17:31:40','truongdx18vtit','GRADUATES OF ENGINEERING',NULL,'','',27,'Who will build the portal?','FILL_IN_THE_BLANK',161,''),
	 ('2026-10-04 17:31:40','truongdx18vtit',false,'2026-10-04 17:31:40','truongdx18vtit','PHOTO BOOTH',NULL,'','',28,'','FILL_IN_THE_BLANK',161,''),
	 ('2026-10-05 17:31:40','truongdx18vtit',false,'2026-10-05 17:31:40','truongdx18vtit','DETAILS',NULL,'','',29,'','FILL_IN_THE_BLANK',161,''),
	 ('2026-10-06 17:31:40','truongdx18vtit',false,'2026-10-06 17:31:40','truongdx18vtit','10TH AUGUST',NULL,'','',30,'','FILL_IN_THE_BLANK',161,''),
	 ('2026-10-07 17:31:40','truongdx18vtit',false,'2026-10-07 17:31:40','truongdx18vtit','FOOD',NULL,'','',31,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-08 17:31:40','truongdx18vtit',false,'2026-10-08 17:31:40','truongdx18vtit','FISHING',NULL,'','',32,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-09 17:31:40','truongdx18vtit',false,'2026-10-09 17:31:40','truongdx18vtit','FORESTRY',NULL,'','',33,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-10 17:31:40','truongdx18vtit',false,'2026-10-10 17:31:40','truongdx18vtit','THE DESTRUCTION',NULL,'','',34,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-11 17:31:40','truongdx18vtit',false,'2026-10-11 17:31:40','truongdx18vtit','GENETIC MATERIAL',NULL,'','',35,'','FILL_IN_THE_BLANK',162,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-10-12 17:31:40','truongdx18vtit',false,'2026-10-12 17:31:40','truongdx18vtit','CLIMATE CHANGE',NULL,'','',36,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-13 17:31:40','truongdx18vtit',false,'2026-10-13 17:31:40','truongdx18vtit','POLICY DEVELOPMENT',NULL,'','',37,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-14 17:31:40','truongdx18vtit',false,'2026-10-14 17:31:40','truongdx18vtit','GLOBAL NETWORK',NULL,'','',38,'','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-15 17:31:40','truongdx18vtit',false,'2026-10-15 17:31:40','truongdx18vtit','COST-EFFECTIVE',NULL,'','',39,'To be effective, hydroelectric dams should be built across rivers with both sufficient head and ______.','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-16 17:31:40','truongdx18vtit',false,'2026-10-16 17:31:40','truongdx18vtit','INFRASTRUCTURE',NULL,'','',40,'There needs to be a balance between the needs of ______ living in developed environments and the preservation of natural habitat.','FILL_IN_THE_BLANK',162,''),
	 ('2026-10-17 17:31:40','truongdx18vtit',false,'2026-10-17 17:31:40','truongdx18vtit','C',NULL,'','["A. exclusively for tax administration.", "B. exclusively by individual tax payers.", "C. for managing several government services."]',1,'A TFN is a number used','MULTIPLE_CHOICE',163,''),
	 ('2026-06-07 19:57:40.567897','user_56659',false,'2026-06-07 19:57:40.567897','user_56659','F','Trích đoạn chứa đáp án:
Lozanov acknowledges that the ritual surrounding suggestion in his own system is also a placebo, but maintains that without such a placebo people are unable or afraid to tap the reserve capacity of their brains.

Keyword cần chú ý:
admit = acknowledge

Giải thích đáp án:
Từ cần điền phải là một danh từ không đếm được chỉ thứ cần thiết để thuyết phục học sinh học suggestopedia hiệu quả.
Bài đọc: Lozanov thừa nhận cần dùng "ritual" (nghi thức).
-> F. ritual',NULL,NULL,37,NULL,'FILL_IN_THE_BLANK',141,NULL),
	 ('2026-06-07 19:57:24.001364','user_56659',false,'2026-06-07 19:57:24.001364','user_56659','TRUE','Trích đoạn chứa đáp án:
Another difference from conventional teaching is the evidence that students can regularly learn 1000 new words of a foreign language during a suggestopedic session, as well as grammar and idiom.

Giải thích đáp án:
Câu hỏi: Học sinh trong lớp suggestopedia nhớ được nhiều từ vựng hơn trong các lớp thường.
Cuối đoạn 5 nói đến việc học sinh suggestopedia có thể thường xuyên học 1000 từ mới, có thể hiểu là nhiều hơn lớp thường.
-> TRUE',NULL,NULL,36,'Students in a suggestopedia class retain more new vocabulary than those in ordinary classes.','TRUE_FALSE_NOT_GIVEN',141,NULL),
	 ('2026-06-07 19:54:34.869621','user_56659',false,'2026-06-07 19:54:34.869621','user_56659','B','Trích đoạn chứa đáp án:
If we think of a book we studied months or years ago, we will find it easier to recall peripheral details - the colour, the binding, the typeface, the table at the library where we sat while studying it - than the content on which we were concentrating. If we think of a lecture we listened to with great concentration, we will recall the lecturer''s appearance and mannerisms, our place in the auditorium, the failure of the airconditioning, much more easily than the ideas we went to learn.

Giải thích đáp án:
Câu hỏi: Trong bài đọc, tác giả dùng ví dụ về quyển sách và bải gỉang để cho thấy điều gì.
Tác giả nhắc đến ví dụ về cuốn sách và bài giảng để cho thấy điều được nói đến ở trước là: “we often remember what we have perceived peripherally” – chúng ta thường nhớ những điều mà ta nhận thức được bên ngoài.
-> Chứng minh lý thuyết của mình về learning (khi học ta chủ yếu nhớ những thứ bên lề) là đúng
-> Đáp án là B. his theory about methods of learning is valid.',NULL,'["A. both these are important for developing concentration","B. his theory about methods of learning is valid","C. reading is a better technique for learning than listening","D. we can remember things more easily under hypnosis"]',29,'
In this passage, the author uses the examples of a book and a lecture to illustrate that','MULTIPLE_CHOICE',141,NULL),
	 ('2026-06-07 19:53:47.277934','user_56659',false,'2026-06-07 19:53:47.277934','user_56659','A','Trích đoạn chứa đáp án:
If we think of a book we studied months or years ago, we will find it easier to recall peripheral details - the colour, the binding, the typeface, the table at the library where we sat while studying it - than the content on which we were concentrating. If we think of a lecture we listened to with great concentration, we will recall the lecturer''s appearance and mannerisms, our place in the auditorium, the failure of the airconditioning, ...

Giải thích đáp án:
Câu hỏi: Giả thuyết của Lozanov nói rằng khi ta cố nhớ thứ gì đó, điều gì xảy ra.
Đoạn nói về giải thuyết của Lozanov là đoạn thứ hai. Ở đây có ví dụ về việc nghĩ đến một quyển sách học một thời gian trước đây và thấy nhớ những chi tiết không quan trọng dễ dàng hơn.
-> Đáp án là A. unimportant details are the easiest to recall.',NULL,'["A. unimportant details are the easiest to recall","B. concentrating hard produces the best results","C. the most significant facts are most easily recalled","D. peripheral vision is not important"]',28,'Lozanov’s theory claims that, when we try to remember things,','MULTIPLE_CHOICE',141,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:35:43','user_05335',false,'2026-06-07 19:35:43','user_05335','SETTLERS','Trích đoạn chứa đáp án:
Dòng 8-9 đoạn B: This historical exploitation was then exacerbated
when settlers came to the islands. They hunted the tortoises...

Giải thích đáp án:
Những người định cư đến đảo săn loài rùa này
=> “settlers”','','',11,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:36:05','user_05335',false,'2026-06-07 19:36:05','user_05335','SPECIES','Trích đoạn chứa đáp án:
They also introduced alien species- ranging from cattle,
pigs, goats, rats and dogs to plants and ants - that either prey on the eggs and young
tortoises or damage or destroy their habitat.

Giải thích đáp án:
Con người mang động vật ngoại lai khác đến hòn đảo -> làm ảnh hưởng đến rùa.
=> “species”','','',12,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 18:45:34','user_05335',false,'2026-06-07 18:45:34','user_05335','II','Trích đoạn chứa đáp án:
Tourism in the mass form as we know it today is a distinctly twentieth-century phenomenon. Historians suggest that the advent of mass tourism began in England during the industrial revolution with the rise of the middle class and the availability of relatively inexpensive transportation. The creation of the commercial airline industry following the Second World War and the subsequent development of the jet aircraft in the 1950s signalled the rapid growth and expansion of international travel. This growth led to the development of a major new industry: tourism. In turn, international tourism became the concern of a number of world governments since it not only provided new employment opportunities but also produced a means of earning foreign exchange.

Giải thích đáp án:
1 Tourism is a 20th century phenomenon
2 3 Explanation and example of the rise of transportation
4 this growth led to the development of tourism
5 this development brought new employment opportunities and a means of earning foreign exchange
→ Trong đoạn này có thể thấy tác giả đang đi theo từng bước để giải thích sự development của mass tourism qua từng giai đoạn
→ Chọn heading ii: the development of mass tourism','','',1,'Paragraph B','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:45:58','user_05335',false,'2026-06-07 18:45:58','user_05335','I','rích đoạn chứa đáp án:
Tourism today has grown significantly in both economic and social importance. In most industrialised countries over the past few years the fastest growth has been seen in the area of services. One of the largest segments of the service industry, although largely unrecognised as an entity in some of these countries, is travel and tourism. According to the World Travel and Tourism Council (1992),Travel and tourism is the largest industry in the world on virtually any economic measure including value-added capital investment, employment and tax contributions,. In 1992’ the industry’s gross output was estimated to be $3.5 trillion, over 12 per cent of all consumer spending. The travel and tourism industry is the world’s largest employer the almost 130 million jobs, or almost 7 per cent of all employees. This industry is the world’s leading industrial contributor, producing over 6 per cent of the world’s national product and accounting for capital investment in excess of $422 billion m direct indirect and personal taxes each year. Thus, tourism has a profound impact both on the world economy and, because of the educative effect of travel and the effects on employment, on society itself

Giải thích đáp án:
1 Tourism has grown in both economic and social importance
2 The fastest growth has been seen in the area of services
3 One of the largest segments of service industry is travel and tourism
4 5 Travel đóng góp cho nền kinh tế (3.5 billion)
6 7 Travel đóng góp về mặt xã hội (tuyển dụng nhân sự)
8 Kết luận: Tourism có ảnh hưởng quan trọng tới nền kinh tế và tuyển dụng
→ Vậy đoạn này có thể thấy tác giả đang đi theo từng bước để giải thích tầm ảnh hưởng quan trọng của tourism lên economy and social
→ Chọn đáp án heading i - economic and social significance of tourism','','',2,'Paragraph C','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:46:19','user_05335',false,'2026-06-07 18:46:19','user_05335','V','Trích đoạn chứa đáp án:
However, the major problems of the travel and tourism industry that have hidden, or obscured, its economic impact are the diversity and fragmentation of the industry itself. The travel industry includes: hotels, motels and other types of accommodation; restaurants and other food services; transportation services and facilities; amusements, attractions and other leisure facilities; gift shops and a large number of other enterprises. Since many of these businesses also serve local residents, the impact of spending by visitors can easily be overlooked or underestimated. In addition, Meis (1992) points out that the tourism industry involves concepts that have remained amorphous to both analysts and decision makers. Moreover, in all nations this problem has made it difficult for the industry to develop any type of reliable or credible tourism information base in order to estimate the contribution it makes to regional, national and global economies. However, the nature of this very diversity makes travel and tourism ideal vehicles for economic development in a wide variety of countries, regions or communities

Giải thích đáp án:
1 Vấn đề của travel và tourism mà đang bị hidden đi đó là do sự phong phú trong nền công nghiệp du lịch
2 Giải thích cho sự phong phú trong nền công nghiệp du lịch: hotels, motels and other types of accommodation , etc
3 Major problem đang bị hidden: spending by visitors can be underestimated
4 Thêm 1 vấn đề tourism đang có mà bị hidden (In addition): tourism industry involves concept that have remained amorphous
5 Thêm 1 vấn đề tourism đang có mà bị hidden (Moreover): liên quan tới industry development
6 Linking word However → tương phản với tất cả ý trên (các ý trên đều negative) → idea câu 6 sẽ positive → Nhưng sự đa dạng này làm cho travel trở nên lý tưởng cho sự phát triển của nền kinh tế in a wide variety of countries
→ Vậy nguyên đoạn này bạn có thể thấy tác giả đang đi theo từng bước để giải thích những hidden difficulties of tourism that affect the economy
→ Chọn đáp án heading v: difficulty in recognising the economic effects of tourism','','',3,'Paragraph D','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:46:44','user_05335',false,'2026-06-07 18:46:44','user_05335','VII','Trích đoạn chứa đáp án:
Once the exclusive province of the wealthy, travel and tourism have become an institutionalised way of life for most of the population. In fact, McIntosh and Goeldner (1990) suggest that tourism has become the largest commodity in international trade for many nations and, for a significant number of other countries, it ranks second or third. For example, tourism is the major source of income in Bermuda, Greece, Italy, Spain, Switzerland and most Caribbean countries. In addition, Hawkins and Ritchie, quoting from data published by the American Express Company, suggest that the travel and tourism industry is the number one ranked employer in the Bahamas, Brazil, Canada, France, (the former) West Germany, Hong Kong, Italy, Jamaica, Japan, Singapore, the United Kingdom and the United States. However, because of problems of definition, which directly affect statistical measurement, it is not possible with any degree of certainty to provide precise, valid or reliable data about the extent of world-wide tourism participation or its economic impact. In many cases, similar difficulties arise when attempts are made to measure domestic tourism

Giải thích đáp án:
1 Travel và tourism trở thành 1 cách sống của hầu hết mọi người
2 Tourism trở thành mặt hàng lớn nhất trong thương mại quốc tế của nhiều quốc gia
3 Ví dụ: tourism là nguồn thu nhập chính ở Italy
4 Tourism là nhà tuyển dụng được xếp hạng đầu ở Canada
5 Tuy nhiên, vì vấn đề định nghĩa tourism nên không thể cung cấp dữ liệu chính xác về mức độ tham gia tourism
6 Trong nhiều trường hợp, những khó khăn tương tự nảy sinh
--> Qua đây, bạn có thể thấy, nguyên đoạn này đang giải thích về impact of tourism, và đặc biệt được thể hiện rõ hơn qua examples của các nước trên thế giới
→ Vậy heading thích hợp nhất là : heading vii - the world impact of tourism','','',4,'Paragraph E','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:47:05','user_05335',false,'2026-06-07 18:47:05','user_05335','TRUE','Trích đoạn chứa đáp án:
According to the World Travel and Tourism Council (1992),Travel and tourism is the largest industry in the world on virtually any economic measure including value-added capital investment, employment and tax contributions,

Giải thích đáp án:
Main idea: travel and tourism là ngành công nghiệp lớn nhất in the world ở bất kỳ khía cạnh nào - VD: investment, employment and tax contributions
So sánh với câu hỏi: The largest employment figures in the world are found in the travel and tourism industry = Travel and tourism is the largest industry in the world - including employment
→ Chọn đáp án TRUE','','',5,'The largest employment figures in the world are found in the travel and tourism industry.','TRUE_FALSE_NOT_GIVEN',142,NULL),
	 ('2026-06-07 18:47:23','user_05335',false,'2026-06-07 18:47:23','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
The travel and tourism industry is the world’s largest employer the almost 130 million jobs, or almost 7 per cent of all employees. This industry is the world’s leading industrial contributor, producing over 6 per cent of the world’s national product and accounting for capital investment in excess of $422 billion m direct indirect and personal taxes each year.

Giải thích đáp án:
Main idea: travel and tourism industry là the world''s largest employer & the world’s leading industrial contributor, sản xuất over 6% của sản lượng thế giới
→ Không đề cập về Australian gross national product
→ Chọn đáp án NOT GIVEN','','',6,'Tourism contributes over six per cent of the Australian gross national product.','TRUE_FALSE_NOT_GIVEN',142,NULL),
	 ('2026-06-07 18:47:41','user_05335',false,'2026-06-07 18:47:41','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
Thus, tourism has a profound impact both on the world economy and, because of the educative effect of travel and the effects on employment, on society itself.
 

Giải thích đáp án:
 

Main idea: tourism có ảnh hưởng lớn lên economy và society bởi vì sự ảnh hưởng của travel và sự ảnh hưởng lên thuê nhân công
→ Không đề cập tới lí do tourism khuyến khích sự recreation (promote recreation)
→ Chọn đáp án NOT GIVEN','','',7,'Tourism has a social impact because it promotes recreation.','TRUE_FALSE_NOT_GIVEN',142,NULL),
	 ('2026-06-07 18:47:58','user_05335',false,'2026-06-07 18:47:58','user_05335','TRUE','Trích đoạn chứa đáp án:
However, the major problems of the travel and tourism industry that have hidden, or obscured, its economic impact are the diversity and fragmentation of the industry itself.

Giải thích đáp án:
Main idea: 2 major problems là diversity and fragmentation - bị che khuất bởi ảnh hưởng của kinh tế
So sánh với câu hỏi: make its economic significance difficult to ascertain = have hidden or obscured its economic impact
—> Chọn đáp án TRUE','','',8,'Two main features of the travel and tourism industry make its economic significance difficult to ascertain.','TRUE_FALSE_NOT_GIVEN',142,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:48:15','user_05335',false,'2026-06-07 18:48:15','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
Since many of these businesses also serve local residents, the impact of spending by visitors can easily be overlooked or underestimated.

Giải thích đáp án:
Main idea: Kể từ khi các businesses phục vụ người dân địa phương, nên họ đánh giá thấp nguồn thu từ khách du lịch
--> Không có sự so sánh giữa visitor spending & the spending of residents
—> Chọn đáp án NOT GIVEN','','',9,'Visitor spending is always greater than the spending of residents in tourist areas.','TRUE_FALSE_NOT_GIVEN',142,NULL),
	 ('2026-06-07 18:48:32','user_05335',false,'2026-06-07 18:48:32','user_05335','FALSE','Trích đoạn chứa đáp án:
However, because of problems of definition, which directly affect statistical measurement, it is not possible with any degree of certainty to provide precise, valid or reliable data about the extent of world-wide tourism participation or its economic impact.

Giải thích đáp án:
Main idea: Bởi vì vấn đề định nghĩa travel --> nên ảnh hưởng tới việc thống kê . Do đó, không thể cung cấp số liệu chính xác
So sánh với câu hỏi: it is impossible to provide precise data # it is easy to show statistically how …
—> Chọn đáp án FASLE','','',10,'It is easy to show statistically how tourism affects individual economies.','TRUE_FALSE_NOT_GIVEN',142,NULL),
	 ('2026-06-07 18:48:52','user_05335',false,'2026-06-07 18:48:52','user_05335','SOURCE OF INCOME [OR] INDUSTRY','Trích đoạn chứa đáp án:
For example, tourism is the major source of income in Bermuda, Greece, Italy, Spain, Switzerland and most Caribbean countries.

Giải thích đáp án:
11. In Greece, tourism the most important ___
Main idea: tourism là nguồn thu nhập chính ở Greece
So sánh với câu hỏi: most important source of income = major source of income
—> Vì bạn được phép điền 3 words
--> Chọn đáp án: source of income','','',11,'In Greece, tourism the most important …………….. .','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:49:12','user_05335',false,'2026-06-07 18:49:12','user_05335','EMPLOYER','Trích đoạn chứa đáp án:
In addition, Hawkins and Ritchie, quoting from data published by the American Express Company, suggest that the travel and tourism industry is the number one ranked employer in the Bahamas, Brazil, Canada, France, (the former) West Germany, Hong Kong, Italy, Jamaica, Japan, Singapore, the United Kingdom and the United States.

Giải thích đáp án:
12. The travel and tourism industry in Jamaica is the major ___
Main idea: Travel and tourism industry là đứng hạng nhất về tuyển dụng ở Jamaica
So sánh với câu hỏi: is the major employer = is the number one ranked employer
—> Đáp án: Employer','','',12,'The travel and tourism industry in Jamaica is the major …………….. .','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 18:49:36','user_05335',false,'2026-06-07 18:49:36','user_05335','DOMESTIC TOURISM','Trích đoạn chứa đáp án:
However, because of problems of definition, which directly affect statistical measurement, it is not possible with any degree of certainty to provide precise, valid or reliable data about the extent of world-wide tourism participation or its economic impact.
In many cases, similar difficulties arise when attempts are made to measure domestic tourism.

Giải thích đáp án:
13. The problems associated with measuring international tourism are often reflected in the measurement of ___
Main idea: Bởi vì vấn đề định nghĩa, khó để provide precise data. Ở những trường hợp khác, những khó khăn tương tự cũng nảy sinh khi cố gắng để measure domestic tourism
--> Vậy, những vấn đề này còn được phản ánh qua sự đo lường về domestic tourism
—> Chọn đáp án: domestic tourism','','',13,'The problems associated with measuring international tourism are often reflected in the measurement of …………….. .','FILL_IN_THE_BLANK',142,NULL),
	 ('2026-06-07 19:36:18','user_05335',false,'2026-06-07 19:36:18','user_05335','EGGS','Trích đoạn chứa đáp án:
They also introduced alien species- ranging from cattle,
pigs, goats, rats and dogs to plants and ants - that either prey on the eggs and young
tortoises or damage or destroy their habitat.

Keyword cần chú ý:
prey ~ fed on

Giải thích đáp án:
Những con vật ngoại lai này cũng ăn rùa con hoặc trứng rùa
=> “eggs”','','',13,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 18:51:26','user_05335',false,'2026-06-07 18:51:26','user_05335','B','Trích đoạn chứa đáp án:
Summer leaves are green because they are full of chlorophyll, the molecule that captures sunlight converts that energy into new building materials for the tree.

Keyword cần chú ý:
a suggestion that S-V = It has also been proposed that
serve as a warning signal = convince herbivorous insects that they are healthy

Giải thích đáp án:
17. an explanation of the function of chlorophyll
Trong câu này, có thể bạn sẽ phân vân về từ mới molecule, nhưng nếu bạn xét kỹ về cấu trúc thì sẽ nhận ra đây chỉ là phần giải thích cho chất chlorophyll:
→ Chức năng của chlorophyll : thu nhận ánh sáng mặt trời và chuyển năng lượng đó thành nguyên liệu phát triển mới cho cây
→ Chọn đáp án: paragraph B','','',17,'an explanation of the function of chlorophyll
       ','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:50:43','user_05335',false,'2026-06-07 18:50:43','user_05335','H','Trích đoạn chứa đáp án:
Even if you had never suspected that this is what was going on when leaves turn red, there are clues out there. One is straightforward: on many trees, the leaves that are the reddest are those on the side of the tree which gets most sun. Not only that, but the red is brighter on the upper side of the leaf. It has also been recognised for decades that the best conditions for intense red colours are dry, sunny days and coo nights, conditions that nicely match those that make leaves susceptible to excess light

Keyword cần chú ý:
some evidence = there are clues

Giải thích đáp án:
16. some evidence to confirm a theory about the purpose of the red leaves
Main idea: có một số bằng chứng / manh mối có thể xác nhận mục đích của lá đỏ
One is …
not only that …
it has also been recognised for …
→ Main idea: đưa ra 3 bằng chứng để khẳng định lý thuyết
→ Chọn đáp án: Paragraph H','','',16,'some evidence to confirm a theory about the purpose of the red leaves','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:50:21','user_05335',false,'2026-06-07 18:50:21','user_05335','B','Trích đoạn chứa đáp án:
As fall approaches in the northern hemisphere, the amount of solar energy available declines considerably. For many trees – evergreen conifers being an exception – the best strategy is to abandon photosynthesis* until the spring. So rather than maintaining the now redundant leaves throughout the winter, the tree saves its precious resources and discards them.

Keyword cần chú ý:
trees drop their leaves = the tree discards them

Giải thích đáp án:
15. the reason why trees drop their leaves in autumn
Main idea: Vậy nên, thay vì giữ lá sắp rụng, cây sẽ loại bỏ chúng
=> Vậy, từ 3 main ideas trên --> Lí do lá rụng: the amount of solar energy decreases in autumn --> the tree saves its resources and discards leaves
→ Chọn đáp án: Paragraph B','','',15,'the reason why trees drop their leaves in autumn','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:50:01','user_05335',false,'2026-06-07 18:50:01','user_05335','C','Trích đoạn chứa đáp án:
The source of the red is widely known: it is created by anthocyanins, water-soluble plant pigments reflecting the red to blue range of the visible spectrum.

Keyword cần chú ý:
a description of sth (substance) = anthocyanins
the red colouration of leaves = The source of the red

Giải thích đáp án:
14. a description of the substance responsible for the red colouration of leaves
Main idea: Màu đỏ - được tạo ra bởi anthocyanin
+ anthocyanins được giải thích bằng water-soluble plant pigments → đây chính là a description
→ Chọn đáp án: Paragraph C','','',14,'a description of the substance responsible for the red colouration of leaves','FILL_IN_THE_BLANK',143,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:37:28','user_05335',false,'2026-06-07 19:37:28','user_05335','C','Trích đoạn chứa đáp án:
the air of the massive amounts of smog and pollution that
cause asthma, lung problems, eyesight issues and more in the people who live there.

Giải thích đáp án:
các hoạt động gây ô nhiễm và khói bụi mà con người gây ra tạo nên một số tính trạng cơ thể như
“asthma, lung problems, eyesight issue => Đáp án C','','',15,'examples of physical conditions caused by human be
         
haviour','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 19:37:02','user_05335',false,'2026-06-07 19:37:02','user_05335','D','Trích đoạn chứa đáp án:
It is an increasingly important area of study in a world
where diseases like polio are re-emerging...

Keyword cần chú ý:
re-emerging ~ not all... can be totally eliminated

Giải thích đáp án:
Bệnh như “polio” đang xuất hiện lại -> chấp nhận rằng không phải tất cả các bệnh đều có thể bị loại trừ => Đáp án D','','',14,'an acceptance that not all diseases can be totally eliminated','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 18:53:59','user_05335',false,'2026-06-07 18:53:59','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
What is still not fully understood, however, is why some trees resort to producing red pigments while others don’t bother, and simply reveal their orange or yellow hues. Do these trees have other means at their disposal to prevent overexposure to light in autumn?

Giải thích đáp án:
Main idea: những cây này có những cách nào khác để ngăn chặn sự tiếp xúc quá mức với ánh sáng không?
Qua 2 câu trên, không có thông tin về việc có khuynh hướng bị ảnh hưởng bởi ánh nắng mặt trời (are more likely to be damaged by sunlight.)
→ Chọn đáp án: NOT GIVEN','','',25,'Leaves which turn colours other than red are more likely to be damaged by sunlight.','TRUE_FALSE_NOT_GIVEN',143,NULL),
	 ('2026-06-07 18:53:41','user_05335',false,'2026-06-07 18:53:41','user_05335','TRUE','Trích đoạn chứa đáp án:
Perhaps the most plausible suggestion as to why leaves would go to the trouble of making anthocyanins when they’re busy packing up for the winter is the theory known as the ‘light screen’ hypothesis. It sounds paradoxical, because the idea behind this hypothesis is that the red pigment is made in autumn leaves to protect chlorophyll, the light-absorbing chemical, from too much light. Why does chlorophyll need protection when it is the natural world’s supreme light absorber? Why protect chlorophyll at a time when the tree is breaking it down to salvage as much of it as possible?

Keyword cần chú ý:
contradictory (a) (contradict (v)) = paradoxical

Giải thích đáp án:
Main idea: Tại sao chlorophyll lại cần bảo vệ khi mà nó là chất hấp thụ ánh sáng
So sánh với câu hỏi: The ‘light screen’ hypothesis would initially seem to contradict = it sounds paradoxical
→ Chọn đáp án: TRUE','','',24,'The ‘light screen’ hypothesis would initially seem to contradict what is known about chlorophyll.','TRUE_FALSE_NOT_GIVEN',143,NULL),
	 ('2026-06-07 18:53:22','user_05335',false,'2026-06-07 18:53:22','user_05335','FALSE','Trích đoạn chứa đáp án:
(D) Some theories about anthocyanins have argued that they might act as a chemical defence against attacks by insects or fungi, or that they might attract fruit-eating birds or increase a leaf''s tolerance to freezing. However there are problems with each of these theories 
(F) Perhaps the most plausible suggestion ... the red pigment is made in autumn leaves to protect chlorophyll, the light-absorbing chemical, from too much light
 
Giải thích đáp án:
Main idea: sắc tố đỏ giúp bảo vệ lá khỏi nhiệt độ đóng băng
increase a leafs tolerance to freezing = protect leaf from freezing temperatures.
likely = the most plausible suggestion
protect chlorophyll, the light-absorbing chemical, from too much light >< protect leaf from freezing temperatures.
--> Chọn đáp án: FALSE','','',23,'It is likely that the red pigments help to protect the leaf from freezing temperatures.','TRUE_FALSE_NOT_GIVEN',143,NULL),
	 ('2026-06-07 18:53:00','user_05335',false,'2026-06-07 18:53:00','user_05335','NORTH','Trích đoạn chứa đáp án:
And finally, trees such as maples usually get much redder the more north you travel in the northern hemisphere.

Giải thích đáp án:
22. The intensity of the red colour of leaves increases as you go further ___
Main idea: Bạn đi xa hơn về phía Bắc -> cường độ của màu đỏ của lá tăng lên
So sánh với câu hỏi: you go further ..................... = the more north you travel
→ Chọn đáp án: north','','',22,'','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:52:45','user_05335',false,'2026-06-07 18:52:45','user_05335','DRY','Trích đoạn chứa đáp án:
It has also been recognised for decades that the best conditions for intense red colours are dry, sunny days and cool nights, conditions that nicely match those that make leaves susceptible to excess light.

Giải thích đáp án:
21. Red leaves are most abundant when daytime weather conditions are ___ and sunny.
Main idea: điều kiện thời tiết cho intense red colours là dry và sunny days
So sánh với câu hỏi: ..................... and sunny = dry and sunny days
→ Chọn đáp án: dry','','',21,'','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:55:14','user_05335',false,'2026-06-07 18:55:14','user_05335','B','Trích đoạn chứa đáp án:
An agricultural worker, digging in the grounds of a derelict plantation, scraped open a grave – the first of dozens in a burial ground some 3,000 years old.

Keyword cần chú ý:
Has been found = digging in the grounds + scraped open the grave
Has been found = digging in the grounds + scraped open the grave
abandoned plantation = derelict

Giải thích đáp án:
Main idea: có 1 worker - đào trong khuôn viên của a derelict plantation - đào 1 ngôi mộ trong 1 khu chôn cất gần 3000 năm tuổi
So sánh với câu hỏi: been found on an abandoned plantation = digging in the grounds of a derelict plantation
→ Chọn đáp án B','','',27,'','FILL_IN_THE_BLANK',144,NULL),
	 ('2026-06-07 19:39:20','user_05335',false,'2026-06-07 19:39:20','user_05335','B','Trích đoạn chứa đáp án:
Malaria is much less of a problem in high-altitude deserts,
for instance.
.

Keyword cần chú ý:
less ~ rare

Giải thích đáp án:
Vùng mà một loại bệnh khá là hiếm gặp: Malaria (tiêu chảy) hiếm gặp ở vùng sa mạc có
cao độ lớn => Đáp án B','','',19,'a description of the type of area where a particular illness is rare','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-10-18 17:31:40','truongdx18vtit',false,'2026-10-18 17:31:40','truongdx18vtit','A',NULL,'','["A. taxed at a higher rate.", "B. unable to work.", "C. liable for Medicare contributions."]',2,'Without a TFN, the applicant would be','MULTIPLE_CHOICE',163,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-10-19 17:31:40','truongdx18vtit',false,'2026-10-19 17:31:40','truongdx18vtit','A',NULL,'','["A. a visa granting indefinite stay", "B. a visa with work rights", "C. a student visa"]',3,'What kind of visa does the applicant have?','MULTIPLE_CHOICE',163,''),
	 ('2026-10-20 17:31:40','truongdx18vtit',false,'2026-10-20 17:31:40','truongdx18vtit','B',NULL,'','["A. if you change your name.", "B. only once in a lifetime.", "C. when you claim a government benefit."]',4,'A TFN is issued','MULTIPLE_CHOICE',163,''),
	 ('2026-10-21 17:31:40','truongdx18vtit',false,'2026-10-21 17:31:40','truongdx18vtit','JGW',NULL,'','',5,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-22 17:31:40','truongdx18vtit',false,'2026-10-22 17:31:40','truongdx18vtit','HARBOUR DRIVE',NULL,'','',6,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-23 17:31:40','truongdx18vtit',false,'2026-10-23 17:31:40','truongdx18vtit','PEARCE',NULL,'','',7,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-24 17:31:40','truongdx18vtit',false,'2026-10-24 17:31:40','truongdx18vtit','MISS',NULL,'','',8,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-25 17:31:40','truongdx18vtit',false,'2026-10-25 17:31:40','truongdx18vtit','FIRST NAME',NULL,'','',9,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-26 17:31:40','truongdx18vtit',false,'2026-10-26 17:31:40','truongdx18vtit','15/11/1983',NULL,'','',10,'','FILL_IN_THE_BLANK',163,''),
	 ('2026-10-27 17:31:40','truongdx18vtit',false,'2026-10-27 17:31:40','truongdx18vtit','MILITARY',NULL,'','',11,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-10-28 17:31:40','truongdx18vtit',false,'2026-10-28 17:31:40','truongdx18vtit','EDUCATE',NULL,'','',12,'','FILL_IN_THE_BLANK',164,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-10-29 17:31:40','truongdx18vtit',false,'2026-10-29 17:31:40','truongdx18vtit','PERSONAL INFORMATION',NULL,'','',13,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-10-30 17:31:40','truongdx18vtit',false,'2026-10-30 17:31:40','truongdx18vtit','POSTINGS',NULL,'','',14,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-10-31 17:31:40','truongdx18vtit',false,'2026-10-31 17:31:40','truongdx18vtit','BULLYING',NULL,'','',15,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-06-07 18:56:54','user_05335',false,'2026-06-07 18:56:54','user_05335','C','Trích đoạn chứa đáp án:
There is one stubborn question for which archaeology has yet to provide any answers: how did the Lapita accomplish the ancient equivalent of a moon landing, many times over? No one has found one of their canoes or any rigging, which could reveal how the canoes were sailed. Nor do the oral histories and traditions of later Polynesians offer any insights, for they turn into myths long before they reach as far back in time as the Lapita.

Giải thích đáp án:

Khó khăn đang gặp phải là việc quá ít thông tin để biết lí do chính xác tại sao The Lapita có thể hoàn thành chuyến đi
--> Vậy đáp án phù hợp nhất là C
→ Chọn đáp án C - little information relating to this period can be relied upon for accuracy','','["A. the canoes that have been discovered offer relatively few clues.","B. archaeologists have shown limited interest in this area of research.","C. little information relating to this period can be relied upon for accuracy.","D. technological advances have altered the way such achievements are viewed."]',32,'According to the writer, there are difficulties explaining how the Lapita accomplished their journeys because','MULTIPLE_CHOICE',144,NULL),
	 ('2026-06-07 18:56:16','user_05335',false,'2026-06-07 18:56:16','user_05335','D','Trích đoạn chứa đáp án:
Other items included a Lapita burial urn with modeled birds arranged on the rim as though peering down at the human remains sealed inside.
‘It’s an important discovery,’ says Matthew Spriggs, professor of archaeology at the Australian National University and head of the international team digging up the site, ‘for it conclusively identifies the remains as Lapita.’

Keyword cần chú ý:
bones found inside = human remains sealed inside
are Lapita = Other items included a Lapita

Giải thích đáp án:
Main idea: Điều quan trọng cần được tìm thấy ở đây chính là discovery: a Lapita burial urn (Bình chôn cất Lapita)
--> Tại sao nó là important discovery: nó chứa human remains ở bên trong → cụ thể human remains chính là bones
→ Chọn đáp án D - bones','','',31,'','FILL_IN_THE_BLANK',144,NULL),
	 ('2026-06-07 18:56:00','user_05335',false,'2026-06-07 18:56:00','user_05335','G','Trích đoạn chứa đáp án:
Other items included a Lapita burial urn with modeled birds arranged on the rim as though peering down at the human remains sealed inside.
‘It’s an important discovery,’ says Matthew Spriggs, professor of archaeology at the Australian National University and head of the international team digging up the site, ‘for it conclusively identifies the remains as Lapita.’

Keyword cần chú ý:
found at the site is very important = It’s an important discovery
burial urn = a Lapita burial urn

Giải thích đáp án:
Main idea: 1 khám phá quan trọng: a Lapita burial urn -> Tại sao nó quan trọng it carried human remains
-> Vậy: Spriggs tin rằng điều quan trọng cần được tìm thấy ở đây chính là discovery: a Lapita burial urn
--> Chọn đáp án G - burial urn','','',30,'','FILL_IN_THE_BLANK',144,NULL),
	 ('2026-06-07 18:55:45','user_05335',false,'2026-06-07 18:55:45','user_05335','I','Trích đoạn chứa đáp án:
They were also pioneers who carried with them everything they would need to build new lives – their livestock, taro seedlings and stone tools.
Within the span of several centuries, the Lapita stretched the boundaries of their world from the jungle-clad volcanoes of Papua New Guinea to the loneliest coral outliers of Tonga.

Keyword cần chú ý:
Explored and colonised = stretched the boundaries of their world
Over several centuries = within the span of several centuries
Took = carried
animals and tools = their livestock, taro seedlings and stone tools.

Giải thích đáp án:
Main idea: The Lapita mang theo bên họ tất cả mọi thứ để có thể bắt đầu cuộc sống mới

→ bao gồm: livestock, taro seedlings and stone tools
-> Hay nói cách khác đây chính là animals & plants & stone tools
Bạn không thể chọn "plantation" vì nó mang nghĩa là đồn điền , khác với "plants"
-> Chọn đáp án I - animals','','',29,'','FILL_IN_THE_BLANK',144,NULL),
	 ('2026-06-07 18:55:29','user_05335',false,'2026-06-07 18:55:29','user_05335','F','Trích đoạn chứa đáp án:
An important archaeological discovery on the island of Efate in the Pacific archipelago of Vanuatu has revealed traces of an ancient seafaring people, the distant ancestors of todays, Polynesians.
The site came to light only by chance.
An agricultural worker, digging in the grounds of a derelict plantation, scraped open a grave – the first of dozens in a burial ground some 3,000 years old.
It is the oldest cemetery ever found in the Pacific islands, and it harbors the remains of an ancient people archaeologists call the Lapita

Keyword cần chú ý:
the cemetery = burial ground + It is the oldest cemetery
significant archaeological discovery = important archaeological discovery
accidentally = only by chance
an agricultural worker = an agricultural worker

Giải thích đáp án:
Main idea: The oldest cemetery (3000 years old) được tìm thấy bởi 1 agricultural worker và điều này chỉ được phát hiện tình cờ --> đây chính là "An important archaeological discovery"
→ Chọn đáp án F. archaeological discovery','','',28,'','FILL_IN_THE_BLANK',144,NULL),
	 ('2026-06-07 19:39:42','user_05335',false,'2026-06-07 19:39:42','user_05335','VACCINATIONS','Trích đoạn chứa đáp án:
While many diseases that affect humans have been
eradicated due to improvements in vaccinations and the availability of healthcare

Keyword cần chú ý:
eradicate ~ disappear

Giải thích đáp án:
Một số loại bệnh đã bị tiêu diệt nhờ sự phát triển của vaccine và hrrj thống y tế => vaccinations','','',20,'Certain disease have disappeared, thanks to better ……………………………… and healthcare.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-11-01 17:31:40','truongdx18vtit',false,'2026-11-01 17:31:40','truongdx18vtit','RESEARCH',NULL,'','',16,'','FILL_IN_THE_BLANK',164,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-11-02 17:31:40','truongdx18vtit',false,'2026-11-02 17:31:40','truongdx18vtit','COMPETE',NULL,'','',17,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-11-03 17:31:40','truongdx18vtit',false,'2026-11-03 17:31:40','truongdx18vtit','PLAY GAMES',NULL,'','',18,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-11-04 17:31:40','truongdx18vtit',false,'2026-11-04 17:31:40','truongdx18vtit','SING ',NULL,'','',19,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-11-05 17:31:40','truongdx18vtit',false,'2026-11-05 17:31:40','truongdx18vtit','WORKSHEETS',NULL,'','',20,'','FILL_IN_THE_BLANK',164,''),
	 ('2026-11-06 17:31:40','truongdx18vtit',false,'2026-11-06 17:31:40','truongdx18vtit','A',NULL,'','["A. if you change your name.", "B. only once in a lifetime.", "C. when you claim a government benefit."]',21,'Ted and Cleos research results will be presented as a','MULTIPLE_CHOICE',165,''),
	 ('2026-11-07 17:31:40','truongdx18vtit',false,'2026-11-07 17:31:40','truongdx18vtit','C',NULL,'','["A. from the Language School.", "B. from the Business School.", "C. randomly on campus."]',22,'They will select foreign students','MULTIPLE_CHOICE',165,''),
	 ('2026-06-07 19:00:43','user_05335',false,'2026-06-07 19:00:43','user_05335','YES','Trích đoạn chứa đáp án:
However they did it, the Lapita spread themselves a third of the way across the Pacific, then called it quits for reasons known only to them

Keyword cần chú ý:
halted their expansion across the Pacific = spread themselves a third of the way across the Pacific, then called it quits
It remains unclear = for reasons known only to them

Giải thích đáp án:
Main idea: The Lapita mở rộng con đường của họ qua Thái Bình Dương nhưng sau đó họ dừng lại → không ai biết lí do tại sao ngoài họ
So sánh với câu hỏi: It remains unclear = for reasons known only to them
--> Chọn đáp án YES','','',39,'
It remains unclear why the Lapita halted their expansion across the Pacific.','YES_NO_NOT_GIVEN',144,NULL),
	 ('2026-06-07 19:00:27','user_05335',false,'2026-06-07 19:00:27','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
He points out that climate data obtained from slow-growing corals around the Pacific indicate a series of unusually frequent El Ninos around the time of the Lapita expansion. By reversing the regular east-to-west flow of the trade winds for weeks at a time, these super El Ninos might have taken the Lapita on long unplanned voyages.

Giải thích đáp án:
Main idea: Dữ liệu cho thấy sự bất thường của hiện tượng El Ninos
--> Không có thông tin - Lapita học cách predict the duration of El Ninos
→ Chọn đáp án: NOT GIVEN','','',38,'The Lapita learnt to predict the duration of El Ninos.','YES_NO_NOT_GIVEN',144,NULL),
	 ('2026-06-07 19:00:01','user_05335',false,'2026-06-07 19:00:01','user_05335','YES','Trích đoạn chứa đáp án:
El Nino, the same climate disruption that affects the Pacific today, may have helped scatter the Lapita, Anderson suggests.

Keyword cần chú ý:
played a role = may have helped
in Lapita migration = scatter the Lapita
Extreme climate conditions = the same climate disruption

Giải thích đáp án:
Main idea: Hiện tượng El nino - the climate disruption giúp quá trình phân tán người Lapita
So sánh thông tin với câu hỏi: played a role in Lapita migration = helped scatter the Lapita
--> Chọn đáp án YES','','',37,'Extreme climate conditions may have played a role in Lapita migration.','YES_NO_NOT_GIVEN',144,NULL),
	 ('2026-06-07 18:59:36','user_05335',false,'2026-06-07 18:59:36','user_05335','NO','Trích đoạn chứa đáp án:
All this presupposes one essential detail, says Atholl Anderson, professor of prehistory at the Australian National University: the Lapita had mastered the advanced art of sailing against the wind. ‘And there’s no proof they could do any such thing,’ Anderson says.

Keyword cần chú ý:
It is now clear >< there’s no proof
sail into a prevailing wind. = mastered the advanced art of sailing against the wind

Giải thích đáp án:
Main idea: The Lapita had mastered the advanced art of sailing against the wind --> không có chứng cứ là họ có thể làm việc như vậy
So sánh câu hỏi: It is now clear # no proof
--> Chọn đáp án - NO','','',36,'It is now clear that the Lapita could sail into a prevailing wind.','YES_NO_NOT_GIVEN',144,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:59:09','user_05335',false,'2026-06-07 18:59:09','user_05335','C','Trích đoạn chứa đáp án:
For returning explorers, successful or not, the geography of their own archipelagoes would have provided a safety net. Without this to go by, overshooting their home ports, getting lost and sailing off into eternity would have been all too easy. Vanuatu, for example, stretches more than 500 miles in a northwest-southeast trend, its scores of inrervisible islands forming a backstop for mariners riding the trade winds home.

Giải thích đáp án:
Địa lý của khu vực giúp explorers bằng cách forming a backstop & riding the trade winds home
--> Chọn đáp án C - It provided a navigational aid for the Lapita','','["A. It played an important role in Lapita culture.","B. It meant there were relatively few storms at sea.","C. It provided a navigational aid for the Lapita.","D. It provided a navigational aid for the Lapita."]',35,'According to the eighth paragraph, how was the geography of the region significant?','MULTIPLE_CHOICE',144,NULL),
	 ('2026-06-07 19:40:42','user_05335',false,'2026-06-07 19:40:42','user_05335','MOSQUITO(E)S','Trích đoạn chứa đáp án:
... malaria-prone areas, which are usually tropical regions
that foster a warm and damp environment in which the mosquitos that can give people
this disease can grow.

Keyword cần chú ý:
give ~ cause
warm ~ hot

Giải thích đáp án:
Muỗi gây bệnh sinh trưởng ở vùng nóng ẩm => mosquitos','','',22,'Disease-causing ………………………………. are most likely to be found in hot, damp regions.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 19:40:11','user_05335',false,'2026-06-07 19:40:11','user_05335','ANTIBIOTIC         ','Trích đoạn chứa đáp án:
As a result, super-viruses and other infections resistant
to antibiotics are becoming more and more common.

Keyword cần chú ý:
resistant (sự chống lại) ~ usefulness(tính hiệu quả)

Giải thích đáp án:

Các loại vi rút và truyền nhiễm (cái mà kháng lại “antibiotics” thuốc kháng
sinh) ngày càng phổ biến -> thuốc kháng sinh mất hiệu quả => antibiotics','','',21,'Because there is more contact between people, ………………………………. are losing their usefulness.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-11-08 17:31:40','truongdx18vtit',false,'2026-11-08 17:31:40','truongdx18vtit','B',NULL,'','["A. collate the answers.", "B. rank the answers.", "C. know a lot about the answers."]',23,'The foreign students will have to','MULTIPLE_CHOICE',165,''),
	 ('2026-11-09 17:31:40','truongdx18vtit',false,'2026-11-09 17:31:40','truongdx18vtit','CHANCE TO TRAVEL',NULL,'','',24,'','FILL_IN_THE_BLANK',165,''),
	 ('2026-11-10 17:31:40','truongdx18vtit',false,'2026-11-10 17:31:40','truongdx18vtit','DEVELOP NEW SKILLS',NULL,'','',25,'','FILL_IN_THE_BLANK',165,''),
	 ('2026-11-11 17:31:40','truongdx18vtit',false,'2026-11-11 17:31:40','truongdx18vtit','LEARN ABOUT YOURSELF',NULL,'','',26,'','FILL_IN_THE_BLANK',165,''),
	 ('2026-11-12 17:31:40','truongdx18vtit',false,'2026-11-12 17:31:40','truongdx18vtit','STUDY DIFFERENT SUBJECTS',NULL,'','',27,'','FILL_IN_THE_BLANK',165,''),
	 ('2026-11-13 17:31:40','truongdx18vtit',false,'2026-11-13 17:31:40','truongdx18vtit','EMPLOYMENT OPPORTUNITIES',NULL,'','',28,'','FILL_IN_THE_BLANK',165,''),
	 ('2026-11-14 17:31:40','truongdx18vtit',false,'2026-11-14 17:31:40','truongdx18vtit','A',NULL,'','',29,'','FILL_IN_THE_BLANK',165,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:08:25','user_05335',false,'2026-06-07 19:08:25','user_05335','TEA','Trích đoạn chứa đáp án:
It just so happened that while she was sipping
some tea, one of the cocoons that she had
collected landed in the hot tea and started to
unravel into a fine thread.

Keyword cần chú ý:
landed in ~ fell into

Giải thích đáp án:
Từ cần điền là một danh từ: kén của 1 con tằm rơi
vào một thứ gì đó của vợ Hoàng Đế
Thông tin trong bài: Truyền thuyết kể rằng khi bà
Lei Tzu - vợ của Hoàng Đế đang thưởng thức trà
thì 1 cái kén đã rơi vào trong cốc trà của bà và nhả
ra 1 sợi tơ mịn
-> từ cần điền là "tea"','','',1,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:08:44','user_05335',false,'2026-06-07 19:08:44','user_05335','REEL','Trích đoạn chứa đáp án:
She also devised a special reel to draw the fibres
from the cocoon into a single thread so that they
would be strong enough to be woven into fabric.

Keyword cần chú ý:
devised = invented
draw sth from = pull out sth

Giải thích đáp án:
Từ cần điền là một danh từ: Vợ Hoàng Đế chế
tạo ra một vật gì đó để kéo sợi.
Thông tin trong bài: Bà ấy đã làm ra một cái guồng
quay tơ để kéo sợi tơ từ kén tằm thành 1 sợi chỉ
đủ dai để dệt vải
-> như vậy vật mà vợ Hoàng Đế chế tạo ra để kéo
sợi chính là cái guồng quay tơ - reel
-> từ cần điền là "reel"','','',2,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:09:10','user_05335',false,'2026-06-07 19:09:10','user_05335','WOMEN','Trích đoạn chứa đáp án:
Originally, silkworm farming was solely restricted to
women, and it was they who were responsible for
the growing, harvesting and weaving.

Keyword cần chú ý:
solely = only
"growing, harvesting, and
weaving" = the act of "producing
silk"

Giải thích đáp án:
Từ cần điền là 1 danh từ
Thông tin trong bài: Ban đầu, việc nuôi tằm chỉ
dành cho phụ nữ và họ phải đảm nhận những
công việc như trồng trọt, thu hoạch và dệt vải
-> chỉ có phụ nữ mới được tham gia vào công việc
sản xuất lụa
-> từ cần điền là "women"','','',3,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:09:40','user_05335',false,'2026-06-07 19:09:40','user_05335','ROYALTY','Trích đoạn chứa đáp án:
Silk quickly grew into a symbol of status, and
originally, only royalty were entitled to have clothes
made of silk.

Keyword cần chú ý:
entitled = allowed

Giải thích đáp án:
Từ cần điền là một danh từ
Thông tin trong bài: Khi lụa nhanh chóng trở thành
biểu tượng cho địa vị trong xã hội thì ban đầu chỉ
có tầng lớp quý tộc mới có quần áo làm từ lụa
-> tức là chỉ có tầng lớp quý tộc được mặc quần
áo lụa
-> từ cần điền là "royalty"','','',4,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:10:00','user_05335',false,'2026-06-07 19:10:00','user_05335','CURRENCY','Trích đoạn chứa đáp án:
Sometime during the Han Dynasty
(206 BC-220 AD), silk was so prized that it was
also used as a unit of currency. Government officials
were paid their salary in silk, and farmers paid their
taxes in grain and silk

Giải thích đáp án:
Từ cần điền là một danh từ: Lụa được sử dụng
như một hình thức của cái gì đó
Thông tin trong bài: Có 1 khoảng thời gian ở triều
đại nhà Hán, lụa được đề cao tới mức nó được sử
dụng như 1 đơn vị tiền tệ. Ví dụ: các quan chức
chính phủ được trả lương bằng lụa; những người
nông dân đóng thuế bằng gạo và lụa
-> lụa được sử dụng như 1 dạng tiền tệ
-> từ cần điền là','','',5,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:10:18','user_05335',false,'2026-06-07 19:10:18','user_05335','PAPER','Trích đoạn chứa đáp án:
The earliest indication of silk paper being used was
discovered in the tomb of a noble who is estimated
to have died around 168 AD.

Keyword cần chú ý:
indication = evidence

Giải thích đáp án:
Từ cần điền là một danh từ: bằng chứng được tìm
thấy của một vật gì đó làm từ lụa được sử dụng
vào khoảng năm 168 sau Công nguyên
Thông tin trong bài: Bằng chứng về giấy lụa được
sử dụng được tìm thấy trong ngôi mộ của 1 người
thuộc giới quý tộc đã qua đời vào khoảng năm 168
sau CN
-> từ cần điền là "paper"','','',6,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:10:34','user_05335',false,'2026-06-07 19:10:34','user_05335','WOOL','Trích đoạn chứa đáp án:
Demand for this exotic fabric eventually created
the lucrative trade route now known as the Silk
Road, taking silk westward and bringing gold, silver
and wool to the East.

Keyword cần chú ý:
gold, silver ~ precious metals

Giải thích đáp án:
Từ cần điền là 1 danh từ: những nhà thương gia
sử dụng con đường tơ lụa để vận chuyển lụa về
phía tây và mang về thứ gì đó và kim loại quý
Thông tin trong bài: Vì nhu cầu sử dụng lụa tăng
-> sinh ra con đường tơ lụa phục vụ mục đích
trao đổi: lụa với những kim loại quý và len. Những
người trao đổi chính là những thương gia
-> từ cần điền là "wool"','','',7,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:10:52','user_05335',false,'2026-06-07 19:10:52','user_05335','MONKS','Trích đoạn chứa đáp án:
According to another legend, monks working for
the Byzantine emperor Justinian smuggle silkworm
eggs to Constantinople (Istanbul in modern-day
Turkey) in 550 AD, concealed inside hollow
bamboo walking canes.

Keyword cần chú ý:
conceal = hide

Giải thích đáp án:
Từ cần điền là một danh từ
Thông tin trong bài: Các nhà sư dưới thời của
Hoàng đế Byzantine Justinian đã buôn lậu trứng
tằm tới Constantinople bằng cách giấu chúng
trong những chiếc gậy làm bằng tre -> đây là 1
trong số những truyền thuyết lý giải nguyên nhân
cả thế giới đều biết tới lụa vào thời đó
-> từ cần điền "monks"','','',8,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-06-07 19:11:10','user_05335',false,'2026-06-07 19:11:10','user_05335','NYLON','Trích đoạn chứa đáp án:
The nineteenth century and industrialisation saw the
downfall of the European silk industry[…] Then in the
twentieth century, new manmade fibres
such as nylon, started to be used in what had
traditionally been silk products, such as stockings
and parachutes.

Keyword cần chú ý:
downfall = decline

Giải thích đáp án:
Từ cần điền là một danh từ chỉ chất liệu: cái gì đó
và những sợi nhân tạo khác khiến cho sản xuất tơ
lụa trở nên suy thoái
Thông tin trong bài: Thế kỷ 19 với công nghiệp hóa
-> sản xuất tơ lụa ở châu Âu bắt đầu suy giảm
-> tiếp tục sang thế kỷ 20 những loại sợi nhân tạo
mới như ni lông được sử dụng để sản xuất sản
phẩm mà trước đó vốn làm từ lụa -> điều này
cũng khiến cho sản xuất tơ lụa bị suy giảm
-> từ cần điền là "nylon"','','',9,'','FILL_IN_THE_BLANK',145,NULL),
	 ('2026-11-15 17:31:40','truongdx18vtit',false,'2026-11-15 17:31:40','truongdx18vtit','C',NULL,'','',30,'','FILL_IN_THE_BLANK',165,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-11-16 17:31:40','truongdx18vtit',false,'2026-11-16 17:31:40','truongdx18vtit','1768',NULL,'','',31,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-17 17:31:40','truongdx18vtit',false,'2026-11-17 17:31:40','truongdx18vtit','FIRST ',NULL,'','',32,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-18 17:31:40','truongdx18vtit',false,'2026-11-18 17:31:40','truongdx18vtit','WARMTH',NULL,'','',33,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-06-07 19:11:42','user_05335',false,'2026-06-07 19:11:42','user_05335','FALSE','Trích đoạn chứa đáp án:
It was named the Silk Road after its most precious
commodity, which was considered to be worth
more than gold.

Keyword cần chú ý:
precious = valuable
commodity = material

Giải thích đáp án:
Thông tin trong bài: Con đường tơ lụa được đặt
tên theo tên của loại hàng quý giá nhất, và loại
hàng này được coi là giá trị hơn vàng
-> Như vậy có thể hiểu rằng "silk" chính là chất liệu
quý giá nhất và có giá trị hơn vàng
Đối chiếu với câu hỏi: Vàng là chất liệu quý giá
nhất được vận chuyển trên con đường tơ lụa
-> Không đúng với thông tin bài đọc
-> FALSE','','',10,'Gold was the most valuable material transported along the Silk Road.','TRUE_FALSE_NOT_GIVEN',145,NULL),
	 ('2026-06-07 19:12:02','user_05335',false,'2026-06-07 19:12:02','user_05335','TRUE','Trích đoạn chứa đáp án:
The Silk Road stretched over 6,000 kilometers from
Eastern China to the Mediterranean Sea. Few
merchants travelled the entire route; goods were
handled mostly by a series of middlemen.

Keyword cần chú ý:
merchants = tradesmen

Giải thích đáp án:
Thông tin trong bài: Con đường tơ lụa trải dài
6000km từ phía Đông Trung Quốc tới vùng biến
Địa Trung hải. Có rất ít thương nhân đi hết toàn
bộ tuyến đường, và đa phần hàng hóa được vận
chuyển bởi đơn vị trung gian
-> Như vậy con đường tơ lụa quá dài để có thể đi
hết -> những thương nhân đa phần đểu đi tới một
đoạn đường nhất định
Đối chiếu với câu hỏi: Phần lớn những thương
nhân chỉ đi 1 số đoạn nhất định của con đường
tơ lụa ->khớp với thông tin bài đọc
-> TRUE','','',11,'Most tradesmen only went along certain sections of the Silk Road.','TRUE_FALSE_NOT_GIVEN',145,NULL),
	 ('2026-06-07 19:12:23','user_05335',false,'2026-06-07 19:12:23','user_05335','FALSE','Trích đoạn chứa đáp án:
The Byzantines were as secretive as the Chinese,
however, and for many centuries the weaving and
trading of silk fabric was a strict imperial monopoly.
Then in the seventh century, the Arabs conquered
Persia, capturing their magnificent silks in the
process. Silk production thus spread through Africa,
Sicily and Spain as the Arabs swept through these
lands.

Keyword cần chú ý:
Africa, Sicily and Spain ~ the
West

Giải thích đáp án:
Thông tin trong bài: Khi có được trứng tằm do các
thầy tu mang về -> Đế quốc Đông La Mã (the
Byzantine) cũng rất kín tiếng trong việc sản xuất
tơ lụa và chiếm độc quyền dệt và buôn bán vải
lụa. Vào thế kỷ 17, Ả Rập chiếm Ba Tư -> chiếm
kỹ năng sản xuất tơ lụa -> từ đó sản xuất tơ lụa
lan rộng khắp châu Phi, Sicily và Tây Ban Nha
Đối chiếu với câu hỏi: Đế quốc Đông La Mã truyền
bá quy trình sản xuất tơ lụa khắp phía Tây
-> không đúng với thông tin trong bài vì Ả Rập là
nước truyền bá silk production pratice
-> FALSE','','',12,'The Byzantines spread the practice of silk production across the West.','TRUE_FALSE_NOT_GIVEN',145,NULL),
	 ('2026-06-07 19:12:39','user_05335',false,'2026-06-07 19:12:39','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
China has gradually recaptured its position as the
world’s biggest producer and exporter of raw silk
and silk yarn. Today, around 125,000 metric tons of
silk are produced in the world, and almost two
thirds of that production takes place in China.

Giải thích đáp án:
Thông tin trong bài: Trung Quốc lấy lại vị thế là
nhà sản xuất và xuất khẩu lụa thô và sợi tơ tằm
lớn nhất thế giới. Hiện nay, 2/3 lượng tơ lụa trên
thế giới được sản xuất bởi Trung Quốc
Đối chiếu với câu hỏi: Sợi tơ chiếm phần lớn lượng
tơ lụa xuât khẩu của Trung Quốc
-> dù bài đọc có nhắc tới việc lụa thô và sợi tơ tằm
được xuất khẩu đi các nước, bài đọc không hề
nhắc tới ý như đã đề cập trong câu hỏi
-> NOT GIVEN
','','',13,'Silk yarn makes up the majority of silk currently exported from China.','TRUE_FALSE_NOT_GIVEN',145,NULL),
	 ('2026-06-07 19:42:34','user_05335',false,'2026-06-07 19:42:34','user_05335','MOUNTAIN','Trích đoạn chứa đáp án:
for instance, it may be very difficult for people to
get medical attention because there is a mountain between their village and the nearest
hospital

Giải thích đáp án:
Physical barrier - rào chắn vật lí khiến người ta không đến được bệnh việnở đây là núi “mountain”=> mountain','','',26,'A physical barrier such as a ………………………………. Can prevent people from reaching a hospital.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 19:42:01','user_05335',false,'2026-06-07 19:42:01','user_05335','POLIO','Trích đoạn chứa đáp án:
It is an increasingly important area of study in a world where
diseases like Polio are re-emerging

Keyword cần chú ý:
re-emerging ~ eradicate

Giải thích đáp án:
Polio là một loại bệnh đã tái bùng phát => Polio','','',25,'…………………………… is one disease that is growing after having been eradicated.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-06-07 19:41:32','user_05335',false,'2026-06-07 19:41:32','user_05335','FORESTS','Trích đoạn chứa đáp án:
The rapid industrialisation of some countries in recent years
has also led to the cutting down of forests to allow for the expansion of big cities

Keyword cần chú ý:
expansion ~ growth

Giải thích đáp án:
Việc đô thị hóa dẫn đến tình trạng chặt rừng => forests','','',24,'The growth of cities often has an impact on nearby ……………………………..','FILL_IN_THE_BLANK',149,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:41:04','user_05335',false,'2026-06-07 19:41:04','user_05335','FACTORIES','Trích đoạn chứa đáp án:
Part of the problem is, of course, the massive number of cars
being driven , in addition to factories that run on coal power

Keyword cần chú ý:
power ~ fuel

Giải thích đáp án:
Các nhà máy đốt than là một tác nhân của sự ô nhiễm, trong đó than “coal” là một loại nhiên liệu cụ thể “particular fuel" =>factories','','',23,'One cause of pollution is ……………………………… that burn a particular fuel.','FILL_IN_THE_BLANK',149,NULL),
	 ('2026-11-19 17:31:40','truongdx18vtit',false,'2026-11-19 17:31:40','truongdx18vtit','STAIRCASE GROUP',NULL,'','',34,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-20 17:31:40','truongdx18vtit',false,'2026-11-20 17:31:40','truongdx18vtit','DAUGHTER',NULL,'','',35,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-21 17:31:40','truongdx18vtit',false,'2026-11-21 17:31:40','truongdx18vtit','1822',NULL,'','',36,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-22 17:31:40','truongdx18vtit',false,'2026-11-22 17:31:40','truongdx18vtit','INVENTOR',NULL,'','',37,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-23 17:31:40','truongdx18vtit',false,'2026-11-23 17:31:40','truongdx18vtit','MANUSCRIPT',NULL,'','',38,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-24 17:31:40','truongdx18vtit',false,'2026-11-24 17:31:40','truongdx18vtit','BICYCLE',NULL,'','',39,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-25 17:31:40','truongdx18vtit',false,'2026-11-25 17:31:40','truongdx18vtit','EXHIBIT',NULL,'','',40,'','FILL_IN_THE_BLANK',166,''),
	 ('2026-11-26 17:31:40','truongdx18vtit',false,'2026-11-26 17:31:40','truongdx18vtit','CANADIAN',NULL,'','',1,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-11-27 17:31:40','truongdx18vtit',false,'2026-11-27 17:31:40','truongdx18vtit','FURNITURE',NULL,'','',2,'','FILL_IN_THE_BLANK',167,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:16:08','user_05335',false,'2026-06-07 19:16:08','user_05335','E','Trích đoạn chứa đáp án:
The arctic tern resists distraction because it is
driven at that moment by an instinctive sense of
something we humans find admirable: larger
purpose.

Keyword cần chú ý:
resist =ignore

Giải thích đáp án:
Thông tin trong bài: Loài ''artic tern'' không bị tác
động bởi những tác động bên ngoài bởi chúng
được thúc đẩy bởi một mục đích lớn hơn
-> đây là mình họa cho đặc điểm di cư được đề
cập ở câu trên: những động vật di cư luôn duy trì
sự tập trung cao độ để hướng tới mục đích lớn hơn
-> đáp án là E','','',22,'Arctic terns illustrate migrating animals’ ability to','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:15:48','user_05335',false,'2026-06-07 19:15:48','user_05335','A','Trích đoạn chứa đáp án:
migrating animals maintain an intense attentiveness
to the greater mission, which keeps them
undistracted by temptations and undeterred by
challenges that would turn other animals aside.

Keyword cần chú ý:
challenges = difficulties
undettered = discouraged

Giải thích đáp án:
Thông tin trong bài: Trong quá trình di cư, các loài
vật luôn duy trì sụ tập trung cao độ tới điểm đến
của mình -> điều này giúp cho chúng
1. không bị sao nhãng bởi những cám dỗ (như đồ
ăn chẳng hạn)
2. không bị nản lòng bởi những thách thức
-> đáp án là A','','',21,'During migration, animals are unlikely to','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:15:18','user_05335',false,'2026-06-07 19:15:18','user_05335','C','Trích đoạn chứa đáp án:
they involve special behaviours concerning
preparation (such as overfeeding) and arrival

Keyword cần chú ý:
overfeeding = eat more than they
need

Giải thích đáp án:
Thông tin trong bài: Đặc điểm di cư thứ 3: những
loài vật có những biểu hiện đặc biệt liên quan tới
sự chuẩn bị, chằng hạn như ăn nhiều hơn mức
bình thường, và điểm đến.
-> đáp án là C','','',20,'To prepare for migration, animals are likely to','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:14:49','user_05335',false,'2026-06-07 19:14:49','user_05335','G','Trích đoạn chứa đáp án:
They tend to be linear, not zigzaggy

Keyword cần chú ý:
tend to = be likely to
linear = straight

Giải thích đáp án:
Thông tin trong bài: Đây là đặc điểm thứ 2 trong 5
đặc điểm di cư do Dingle định nghĩa -> các loài
động vật di cư có xu hướng di chuyển theo một
đường thẳng chứ không đi vòng vèo.
-> đáp án G','','',19,'According to Dingle, migratory routes are likely to','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:13:55','user_05335',false,'2026-06-07 19:13:55','user_05335','TRUE','Trích đoạn chứa đáp án:
They allow for the fact that, for example, aphids
will become sensitive to blue light (from the sky)
when it’s time for takeoff on their big journey, and
sensitive to yellow light (reflected from tender
young leaves) when it’s appropriate to land.

Giải thích đáp án:
Thông tin trong bài: "aphids" (loài rệp) nhạy cảm
với 2 loại ánh sáng:
1. Ánh sáng xanh của bầu trời khi chúng bắt đầu
hành trình di chuyển của mình
2. Ánh sáng vàng phản chiếu từ những chiếc lá
non cho biết thời điểm chúng nên dừng lại
-> Màu của ánh sáng có tác động tới cách di
chuyển của "aphids"
Đối chiếu với câu hỏi: Hành trình của "aphids" bị
tác động bởi sự ảnh sáng mà chúng cảm nhận
được -> khớp với thông tin trong bài
-> TRUE','','',17,'Aphids’ journeys are affected by changes in the light that they perceive.','TRUE_FALSE_NOT_GIVEN',146,NULL),
	 ('2026-06-07 19:13:17','user_05335',false,'2026-06-07 19:13:17','user_05335','TRUE','Trích đoạn chứa đáp án:
But migration is a complex issue, and biologists
define it differently, depending in part on what sorts
of animals they study.

Keyword cần chú ý:
biologists = experts
depending on = according to

Giải thích đáp án:
Thông tin trong bài: Di cư ở động vật là một vấn
đề phức tạp, và những nhà sinh vật học có cách
định nghĩa khác nhau khái niệm này, phụ thuộc vào
loài động vật mà họ nghiên cứu
Đối chiếu với câu hỏi: Định nghĩa của các chuyên
gia về di cư của động vật có thường khác nhau
tùy vào lĩnh vực nghiên cứu của họ
what sorts of animals they study ~ their area of
study
-> khớp với thông tin trong bài đọc
-> TRUE','','',15,'Experts’ definitions of migration tend to vary according to their area of study.','TRUE_FALSE_NOT_GIVEN',146,NULL),
	 ('2026-11-28 17:31:40','truongdx18vtit',false,'2026-11-28 17:31:40','truongdx18vtit','PARK',NULL,'','',3,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-11-29 17:31:40','truongdx18vtit',false,'2026-11-29 17:31:40','truongdx18vtit','250 (STERLING)',NULL,'','',4,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-11-30 17:31:40','truongdx18vtit',false,'2026-11-30 17:31:40','truongdx18vtit','PHONE',NULL,'','',5,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-12-01 17:31:40','truongdx18vtit',false,'2026-12-01 17:31:40','truongdx18vtit','10(TH) SEPTEMBER [OR] SEPTEMBER 10(TH)',NULL,'','',6,'','FILL_IN_THE_BLANK',167,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-12-02 17:31:40','truongdx18vtit',false,'2026-12-02 17:31:40','truongdx18vtit','MUSEUM',NULL,'','',7,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-12-03 17:31:40','truongdx18vtit',false,'2026-12-03 17:31:40','truongdx18vtit','TIME',NULL,'','',8,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-12-04 17:31:40','truongdx18vtit',false,'2026-12-04 17:31:40','truongdx18vtit','BLOND(E)',NULL,'','',9,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-12-05 17:31:40','truongdx18vtit',false,'2026-12-05 17:31:40','truongdx18vtit','87954( )82361',NULL,'','',10,'','FILL_IN_THE_BLANK',167,''),
	 ('2026-12-06 17:31:40','truongdx18vtit',false,'2026-12-06 17:31:40','truongdx18vtit','A',NULL,'','',11,'','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-07 17:31:40','truongdx18vtit',false,'2026-12-07 17:31:40','truongdx18vtit','A',NULL,'','',12,'','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-08 17:31:40','truongdx18vtit',false,'2026-12-08 17:31:40','truongdx18vtit','DIRECTION',NULL,'','',33,'','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-09 17:31:40','truongdx18vtit',false,'2026-12-09 17:31:40','truongdx18vtit','B/E',NULL,'','',13,'','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-10 17:31:40','truongdx18vtit',false,'2026-12-10 17:31:40','truongdx18vtit','B/E',NULL,'','',14,'','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-11 17:31:40','truongdx18vtit',false,'2026-12-11 17:31:40','truongdx18vtit','B',NULL,'','',15,'Using the internet          …………….','FILL_IN_THE_BLANK',168,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:16:53','user_05335',false,'2026-06-07 19:16:53','user_05335','BOTTLENECKS','Trích đoạn chứa đáp án:
These pronghorn are notable for the invariance of
their migration route and the severity of its
constriction at three bottlenecks.

Giải thích đáp án:
Từ cần điền là một danh từ: Chặng đường di cư
của đàn linh dương từ vườn quốc gia tới những
đồng cỏ có 3 cái gì đó
Thông tin trong bài: Chặng đường di cư của loài
linh dương đáng chú ý bỏi 2 điều:
1. Chúng luôn di chuyển theo 1 chặng cố định
2. Chặng đường của chúng rất trắc trở vì có 3 nút
thắt rất hẹp ở đó
-> từ cần điền là "bottlenecks"','','',25,'','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:16:37','user_05335',false,'2026-06-07 19:16:37','user_05335','PLAINS','Trích đoạn chứa đáp án:
One population, which spends the summer in the
mountainous Grand Teton National Park of the
western USA, follows a narrow route from its
summer range in the mountains, across a river, and
down onto the plains. Here they wait out the frozen
months, feeding mainly on sagebrush blown clear
of snow.

Giải thích đáp án:
Từ cần điền là một danh từ chỉ nơi trú của loài linh
dương vào mùa đông
Thông tin trong bài: Quần thể linh dương sống tại
Vườn quốc gia Grand Teton vào mùa hè sẽ di cư
theo tuyến đường đi qua núi -> qua sông -> xuống
đồng cỏ. Và chúng sẽ đợi ở tại đây (chính là ở
đồng cỏ) trong những tháng mùa đông băng
giá
-> mùa đông quần thể linh dương sống ở những
đồng cỏ
-> từ cần điền là "plains"','','',24,'','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:19:00','user_05335',false,'2026-06-07 19:19:00','user_05335','B','Trích đoạn chứa đáp án:
Some present the lives of colorful mathematicians.
Others describe important applications of
mathematics. Yet others go into mathematical
procedures, but assume that the reader is adept in
using algebra.

Giải thích đáp án:
Câu hỏi: tìm đoạn văn nhắc tới những chủ đề khác
nhau của những cuốn sách về toán
Trong đoan B, sau khi đề cập tới điểm khác biệt
của cuôn sách này so với những cuốn sách toán
khác, tác giả đã kể 1 vài ví dụ về những cuốn sách
về toán học: Một số viết về cuộc sống của những
nhà toán học, số khác viết về ứng dụng quan
trọng của toán học,..
-> đáp án là B','','',31,'mention of different focuses of books about mathematics','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:18:41','user_05335',false,'2026-06-07 19:18:41','user_05335','C','Trích đoạn chứa đáp án:
To illustrate our human potential, I cite a structural
engineer who is an artist, an electrical engineer who
is an opera singer, an opera singer who published
mathematical research, and a mathematician who
publishes short stories.

Giải thích đáp án:
Câu hỏi: tìm đoạn văn mà tác giả nhắc tới ví dụ về
những người sở hữu những năng lực không tương
thích với nhau.
Ở đoạn C, để minh họa cho những tiềm năng của
con người, tác giả đã đưa ra nhiều ví dụ, chằng
hạn như 1 kỹ sư là một nghệ sĩ, một kỹ sự điện là
ca sĩ hát opera,....
-> đáp án là C','','',30,'examples of people who each had abilities that seemed incompatible','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:17:55','user_05335',false,'2026-06-07 19:17:55','user_05335','B','Trích đoạn chứa đáp án:
I want to reveal not only some of the fascinating
discoveries, but, more importantly, the reasoning
behind them.
In that respect, this book differs from most books
on mathematics written for the general public.

Keyword cần chú ý:
not a typical book ~ differs from
most books

Giải thích đáp án:
Câu hỏi: tìm đoạn văn chứa thông tin nói tới cách
tiếp cận độc giả khiến cho cuốn sách này không
phải là 1 cuốn sách về toán học thông thường.
Ở đoạn B, tác giả của cuốn sách muốn tiết lộ những
khám phá thú vị và quan trọng hơn hết là những
lý do đằng sau những khám phá đó
-> và chính vì điều đó nên tác giả khẳng định rằng
cuốn sách này khác biệt với phần lớn những cuốn
sách về toán được viết cho công chúng
-> đáp án là B','','',28,'the way in which this is not a typical book about mathematics','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:17:33','user_05335',false,'2026-06-07 19:17:33','user_05335','D','Trích đoạn chứa đáp án:
Other scientists have written books to explain their
fields to non-scientists, but have necessarily had to
omit the mathematics, although it provides the
foundation of their theories.

Keyword cần chú ý:
omit the mathematics ~ assume
a lack of mathematical knowledge

Giải thích đáp án:
Câu hỏi: tìm thông tin của đoạn trong bài đề cập
tới cuốn sách viết mà lại thiếu kiến thức toán học
Thông tin trong bài: Ở đoạn D có nói tới thông tin
về việc những nhà khoa học viết những cuốn sách
về lĩnh vực của họ cho những người không chuyên,
phải bỏ đi những kiến thức về toán học mặc dù
chúng là tiền đề cho những lý thuyết khoa học của
họ
-> đáp án là D','','',27,'a reference to books that assume a lack of mathematical knowledge','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-12-12 17:31:40','truongdx18vtit',false,'2026-12-12 17:31:40','truongdx18vtit','B',NULL,'','',16,'Flexible working              …………….','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-13 17:31:40','truongdx18vtit',false,'2026-12-13 17:31:40','truongdx18vtit','C',NULL,'','',17,'Booking holidays            …………….','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-14 17:31:40','truongdx18vtit',false,'2026-12-14 17:31:40','truongdx18vtit','A',NULL,'','',18,'Working overtime           …………….','FILL_IN_THE_BLANK',168,''),
	 ('2026-12-15 17:31:40','truongdx18vtit',false,'2026-12-15 17:31:40','truongdx18vtit','A',NULL,'','',19,'Wearing trainers             …………….','FILL_IN_THE_BLANK',168,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-12-16 17:31:40','truongdx18vtit',false,'2026-12-16 17:31:40','truongdx18vtit','C',NULL,'','',20,'Bringing food to work    …………….','FILL_IN_THE_BLANK',169,''),
	 ('2026-12-17 17:31:40','truongdx18vtit',false,'2026-12-17 17:31:40','truongdx18vtit','B',NULL,'','["A. contain nearly half the world’s population.","B. include most of the world’s largest cities","C. are growing twice as fast as other cities"]',21,'Carla and Rob were surprised to learn that coastal cities','MULTIPLE_CHOICE',169,''),
	 ('2026-12-18 17:31:40','truongdx18vtit',false,'2026-12-18 17:31:40','truongdx18vtit','A',NULL,'','["A. A. may bring pollution to the cities.","B. may reduce the land available for agriculture.","C. may mean the countryside is spoiled by industry."]',22,'According to Rob, building coastal cities near to rivers
','MULTIPLE_CHOICE',169,''),
	 ('2026-12-19 17:31:40','truongdx18vtit',false,'2026-12-19 17:31:40','truongdx18vtit','C',NULL,'','["A. There were not enough for them.","B. They were made of unsuitable materials.","C. They did not allow for the effects of climate change."]',23,'What mistake was made when building water drainage channels in Miami in the 1950s?
','MULTIPLE_CHOICE',169,''),
	 ('2026-12-20 17:31:40','truongdx18vtit',false,'2026-12-20 17:31:40','truongdx18vtit','B',NULL,'','["A. take measures to restore ecosystems","B. pay for a new flood prevention system","C. stop disposing of waste materials into the ocean"]',24,'What do Rob and Carla think that the authorities in Miami should do immediately?','MULTIPLE_CHOICE',169,''),
	 ('2026-06-07 19:21:21','user_05335',false,'2026-06-07 19:21:21','user_05335','INTUITIVE','Trích đoạn chứa đáp án:
As the chapters will illustrate, mathematics is not
restricted to the analytical and numerical; intuition
plays a significant role.

Giải thích đáp án:
Từ cần điền là một tính từ: Tác giả muốn chỉ ra
rằng toán học đòi hỏi phải có 1 tư duy như thế nào
đó và kỹ năng phân tích.
Thông tin trong bài: Toán học không chỉ giới hạn ở
những con số và sự phân tích, mà bên cạnh đó trực
giác cũng đóng 1 vai trò quan trọng.
-> toán học đòi hỏi phải có tư duy trực giác và kỹ
năng phân tích
intuition = intuitive thinking
-> từ cần điền là "intuitive"','','',37,'The writer intends to show that mathematics requires……………… thinking, as well as analytical skills.','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:20:28','user_05335',false,'2026-06-07 19:20:28','user_05335','BEGINNER','Trích đoạn chứa đáp án:
Occasionally, in some difficult musical compositions,
there are beautiful, but easy parts – parts so simple a
beginner could play them. So it is with mathematics
as well.

Keyword cần chú ý:
parts = areas

Giải thích đáp án:
Từ cần điền là một danh từ
Thông tin trong bài: Đôi khi trong một bản nhạc khó,
có những khúc nhạc hay, nhưng dễ - đến nỗi mà
một người mới nhập môn cũng có thể chơi được.
Và đối với toán học cũng như vậy
-> như vậy trong cả âm nhạc và toán học có những
phần phù hợp đối với người mới bắt đầu
-> từ cần điền là "beginner"','','',35,'Some areas of both music and mathematics are suitable for someone who is a………………','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:20:04','user_05335',false,'2026-06-07 19:20:04','user_05335','F','Trích đoạn chứa đáp án:
As I wrote, I kept in mind two types of readers:
those who enjoyed mathematics until they were
turned off by an unpleasant episode, usually around
fifth grade, and mathematics aficionados, who will
find much that is new throughout the book. This book
also serves readers who simply want to sharpen
their analytical skills. Many careers, such as law
and medicine, require extended, precise analysis.

Keyword cần chú ý:
types = categories

Giải thích đáp án:
Câu hỏi: tìm đoạn văn đề cập tới những đối tượng
độc giả khác nhau của cuốn sách này
Trong đoạn F, tác giả đã đề cập tới 3 đối tượng
độc giả mà ông nghĩ tới khi viết cuốn sách này
1. those who enjoyed mathematics until they were
turned off by an unpleasant episode - những người
yêu thích toán học cho đến khi họ bị nản chí bởi 1
chương khó hiểu
2. mathematics aficionados - những người đam mê
toán học
3. readers who simply want to sharpen
their analytical skills - những người muốn mài giũa
kỹ năng phân tích
-> đáp án là F','','',34,'a reference to different categories of intended readers of this book','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:19:43','user_05335',false,'2026-06-07 19:19:43','user_05335','A','Trích đoạn chứa đáp án:
There are some discoveries in advanced
mathematics that do not depend on specialized
knowledge, not even on algebra, geometry, or
trigonometry. Instead, they may involve, at most, a
little arithmetic, such as ‘them sum of two odd
numbers is even’, common sense. Each of the eight
chapters in this book illustrates this phenomenon.
Anyone can understand every step in the reasoning.

Keyword cần chú ý:
each of the eight chapter ~ the
whole book

Giải thích đáp án:
Câu hỏi: tìm đoạn văn chứa lời khẳng đỉnh rầng ai
cũng có thể đọc được cuốn sách này
Ở đoạn A, tác giả đã giải thích rằng có một số
những lĩnh vực toán học nâng cao không phụ
thuộc vào kiến thức chuyên sâu, mà thay vào đó
chỉ cần "a little arithmetic'' và "common sense"
là đủ.
Sau đó tác giả khẳng định rằng cả 8 chương trong
sách sẽ minh họa cho điều ông vừa đề cập, bởi
vậy nên bất kỳ ai cũng có thể hiểu được từng
bước lý luận trong này
-> ai cũng có thể hiểu tức là ai cũng có thể đọc
được cuốn sách này
-> đáp án A','','',33,'a claim that the whole of the book is accessible to everybody
','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:19:27','user_05335',false,'2026-06-07 19:19:27','user_05335','E','Trích đoạn chứa đáp án:
You will turn these pages much more slowly than
when reading a novel or a newspaper.

Keyword cần chú ý:
a novel; a newspaper = publication

Giải thích đáp án:
Câu hỏi: tìm đoạn văn có chỉ ra sự khác nhau giữa
việc đọc cuốn sách này với những ấn phẩm khác
Trong đoạn E, tác giả so sánh rằng ta sẽ đọc cuốn
sách này chậm hơn so là khi đọc tiểu thuyết hay
đọc báo.
-> đáp án E','','',32,'a contrast between reading this book and reading other kinds of publication','FILL_IN_THE_BLANK',147,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-12-21 17:31:40','truongdx18vtit',false,'2026-12-21 17:31:40','truongdx18vtit','A',NULL,'','["A. greater coordination of activities","B. more sharing of information","C. agreement on shared policies"]',25,'What do they agree should be the priority for international action?','MULTIPLE_CHOICE',169,''),
	 ('2026-12-22 17:31:40','truongdx18vtit',false,'2026-12-22 17:31:40','truongdx18vtit','B',NULL,'','',26,'Historical background          ……………..','FILL_IN_THE_BLANK',169,''),
	 ('2026-12-23 17:31:40','truongdx18vtit',false,'2026-12-23 17:31:40','truongdx18vtit','A',NULL,'','',27,'Geographical factors            ……………..
','FILL_IN_THE_BLANK',169,''),
	 ('2026-12-24 17:31:40','truongdx18vtit',false,'2026-12-24 17:31:40','truongdx18vtit','F',NULL,'','',28,'Past mistakes                         ……………..','FILL_IN_THE_BLANK',169,''),
	 ('2026-12-25 17:31:40','truongdx18vtit',false,'2026-12-25 17:31:40','truongdx18vtit','G',NULL,'','',29,'
Future risks                             ……………..','FILL_IN_THE_BLANK',169,''),
	 ('2026-12-26 17:31:40','truongdx18vtit',false,'2026-12-26 17:31:40','truongdx18vtit','C',NULL,'','',30,'International implications    ……………..','FILL_IN_THE_BLANK',170,''),
	 ('2026-12-27 17:31:40','truongdx18vtit',false,'2026-12-27 17:31:40','truongdx18vtit','INDUSTRY',NULL,'','',31,'','FILL_IN_THE_BLANK',170,''),
	 ('2026-12-28 17:31:40','truongdx18vtit',false,'2026-12-28 17:31:40','truongdx18vtit','CONSTANT',NULL,'','',32,'','FILL_IN_THE_BLANK',170,''),
	 ('2026-12-29 17:31:40','truongdx18vtit',false,'2026-12-29 17:31:40','truongdx18vtit','FLOOR',NULL,'','',34,'','FILL_IN_THE_BLANK',170,''),
	 ('2026-12-30 17:31:40','truongdx18vtit',false,'2026-12-30 17:31:40','truongdx18vtit','BAY',NULL,'','',36,'','FILL_IN_THE_BLANK',170,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-12-31 17:31:40','truongdx18vtit',false,'2026-12-31 17:31:40','truongdx18vtit','GATES',NULL,'','',37,'','FILL_IN_THE_BLANK',170,''),
	 ('2027-01-01 17:31:40','truongdx18vtit',false,'2027-01-01 17:31:40','truongdx18vtit','FUEL',NULL,'','',38,'','FILL_IN_THE_BLANK',170,''),
	 ('2027-01-02 17:31:40','truongdx18vtit',false,'2027-01-02 17:31:40','truongdx18vtit','JOBS',NULL,'','',39,'','FILL_IN_THE_BLANK',170,''),
	 ('2027-01-03 17:31:40','truongdx18vtit',false,'2027-01-03 17:31:40','truongdx18vtit','MIGRATION',NULL,'','',40,'','FILL_IN_THE_BLANK',170,''),
	 ('2027-01-04 17:31:40','truongdx18vtit',false,'2027-01-04 17:31:40','truongdx18vtit','PREDICTABLE',NULL,'','',35,'','FILL_IN_THE_BLANK',170,''),
	 ('2027-01-05 17:31:40','truongdx18vtit',false,'2027-01-05 17:31:40','truongdx18vtit','JAMIESON',NULL,'','',1,'','FILL_IN_THE_BLANK',171,''),
	 ('2026-06-07 19:32:16','user_05335',false,'2026-06-07 19:32:16','user_05335','V','Trích đoạn chứa đáp án:
This inhospitable environment is home to the giant Galapagos
tortoise

Keyword cần chú ý:
the islands ~ this inhospitable enviroment

Giải thích đáp án:
Đây là môi trường cư trú của loài rùa => đáp án v','','',1,'Paragraph A','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:32:40','user_05335',false,'2026-06-07 19:32:40','user_05335','III','Trích đoạn chứa đáp án:
From the 17th century onwards , pirates took a few on
board for food , but the arrival of whaling ships in the 1790s saw this exploitation grow
exponentially.

Giải thích đáp án:
Nói về sự việc gây bất lợi cho loài rùa, rồi nhắc đến các sự việc gây bất lợi
khác phát triển từ sự việc ban đầu => Đáp án iii','','',2,'Paragraph B','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:33:00','user_05335',false,'2026-06-07 19:33:00','user_05335','VIII','Trích đoạn chứa đáp án:
In 1989, work began on a tortoise-breeding centre just
outside the town of Puerto Villamil on Isabela,dedicated to protecting the island’s
tortoise populations

Keyword cần chú ý:
began ~ start

Giải thích đáp án:
Đoạn này nói về công việc bảo tồn được bắt đầu từ 1989 với trung tâm nhân giống rùa cạn => viii','','',3,'Paragraph C','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:46:07','user_05335',false,'2026-06-07 19:46:07','user_05335','A','Trích đoạn chứa đáp án:
What is rather more significant is the finding that the
dopamine neurons in the caudate were at their most active around 15 seconds before
the participants’ favourite moments in the music

Giải thích đáp án:
Điều ấn tượng nhất của nghiên cứu là thời gian não người nghe phản ứng lại âm nhạc => A','','["A. the timing of participants’ neural responses to the music","B. the impact of the music of participants’ emotional state","C. the section of participants’ brains which was activated by the music","D. the type of music which had the strongest effect on participants’ brains"]',34,'What does the writer find interesting about the results of the Montreal study?','MULTIPLE_CHOICE',150,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:45:22','user_05335',false,'2026-06-07 19:45:22','user_05335','C','Trích đoạn chứa đáp án:
they were able to obtain an impressively exact and detailed
portrait of music in the brain

Keyword cần chú ý:
impressively exact and detailed portrait of music = remarkably
precise data

Giải thích đáp án:
Nghiên cứu đã khắc họa một cách chi tiết và chính xác hình ảnh của âm nhạc trong bộ não =>C','','["A. Its aims were innovative.","B. The approach was too simplistic.","C. The approach was too simplistic.","D. The approach was too simplistic."]',33,'what view of the Montreal study does the writer express in the second paragraph?','MULTIPLE_CHOICE',150,NULL),
	 ('2026-06-07 19:44:46','user_05335',false,'2026-06-07 19:44:46','user_05335','B','Trích đoạn chứa đáp án:
even though music says little, it still manages to touch us
deeply

Keyword cần chú ý:
intense ~ deeply

Giải thích đáp án:
Âm nhạc ảnh hưởng sâu sắc đến chúng ta.
-> cường độ các phản ứng thể chất của cơ thể đối với âm nhạc => B','','["A. how dramatically our reactions to music can vary","B. how intense our physical responses to music can be","C. how little we know about the way that music affects us","D. how much music can tell us about how our brains operate"]',32,'What point does the writer emphasise in the first paragraph?','MULTIPLE_CHOICE',150,NULL),
	 ('2026-06-07 19:44:05','user_05335',false,'2026-06-07 19:44:05','user_05335','FOOD','Trích đoạn chứa đáp án:
a region of the brain involved in learning stimulus-response
associations , and in anticipating food and other ‘reward’ stimuli.

Keyword cần chú ý:
expectation ~ anticipate

Giải thích đáp án:
“Food” trong câu gốc được để song song với “reward stimuli” (các kích thích tạo ra thỏa
mãn ), thức ăn cũng được coi đồng dạng với kích thích tạo ra thỏa mãn =>food','','',31,'','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:43:49','user_05335',false,'2026-06-07 19:43:49','user_05335','ANTICIPATORY PHASE','Giải thích chi tiết đáp án 

Trích đoạn chứa đáp án:
The researchers call this the ‘ anticipatory phase ’

Keyword cần chú ý:
call ~ known as

Giải thích đáp án:
Câu trước nhắc đến giai đọan mà một vùng não hưng phấn nhất. Câu này nói đến tên
giai đoạn đó là gì => anticipatory phase','','',30,'','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:43:35','user_05335',false,'2026-06-07 19:43:35','user_05335','CAUDATE','Trích đoạn chứa đáp án:
the caudate- a region of the brain involved in learning
stimulus-response associations .... were at their most active around 15 seconds before
the participants’ favourite moments in the music

Keyword cần chú ý:
15 seconds ~ just before

Giải thích đáp án:
“caudate” là vùng mã não hưng phấn nhất ngay trước khi (just before) đoạn nhạc mà người nghe thích nhất => caudate','','',29,'','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:43:18','user_05335',false,'2026-06-07 19:43:18','user_05335','PLEASURE','Trích đoạn chứa đáp án:
...in both the dorsal and ventral regions of the brain. As
these two regions have long been linked with the experience of pleasure

Keyword cần chú ý:
feeling ~ experience

Giải thích đáp án:
Hai vùng của não liên quan tới (associated with) cảm giác thỏa mãn (pleasure) ->pleasure','','',28,'','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:43:00','user_05335',false,'2026-06-07 19:43:00','user_05335','DOPAMINE','Trích đoạn chứa đáp án:
The first thing they discovered is that music triggers the
production of dopamine - a chemical with a key role in setting people’s moods

Keyword cần chú ý:
produce ~ release

Giải thích đáp án:
Việc ghe nhạc kích thích não giải sản xuất (produce) chất dopamine =>dopamine','','',27,'','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:33:23','user_05335',false,'2026-06-07 19:33:23','user_05335','I','Trích đoạn chứa đáp án:
But if people wait too long after that point, the
tortoises eventually become too large to transport.
Đoạn đang nói về việc di chuyển rùa khi còn nhỏ không thích hợp, còn nếu khi lớn thì
rùa quá to và nặng không phù hợp di chuyển -> vấn đề thời gian “timing”

Keyword cần chú ý:
point ~ timing

Giải thích đáp án:
Đoạn đang nói về việc di chuyển rùa khi còn nhỏ không thích hợp, còn nếu khi lớn thì
rùa quá to và nặng không phù hợp di chuyển -> vấn đề thời gian “timing” => Đáp án i','','',4,'Paragraph D','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:33:48','user_05335',false,'2026-06-07 19:33:48','user_05335','IV','Trích đoạn chứa đáp án:
the environmentalist and Galapagos National Park liaison
officer Godfrey Merlin, a visiting private motor yacht captain and a helicopter pilot
gathered around a table in a small cafe in Puerto Ayora on the island of Santa Cruz to
work out more ambitious reintroduction

Keyword cần chú ý:
more ambitious reintroduction ~ bigger idea

Giải thích đáp án:
Team của Merlin họp để đưa ra kế hoạch đưa rùa trở lại cuộc sống hoang dã
=> Đáp án iv','','',5,'Paragraph E','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:34:17','user_05335',false,'2026-06-07 19:34:17','user_05335','VI','Trích đoạn chứa đáp án:
During a period of three days, a group of volunteers from the
breeding centre worked around the clock to prepare the young tortoises for transport

Keyword cần chú ý:
around the clock ~ carefully prepared

Giải thích đáp án:
Đoạn này nói về công tác chuẩn bị cho việc di chuyển rùa. =>Đáp án vi','','',6,'Paragraph F','FILL_IN_THE_BLANK',148,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:34:38','user_05335',false,'2026-06-07 19:34:38','user_05335','II','Trích đoạn chứa đáp án:
Eventually, one tiny tortoise came across a fully grown
giant who had been lumbering around the island for around a hundred years

Keyword cần chú ý:
tiny ~ young
fully grown ~ old

Giải thích đáp án:
Đoạn này mô tả một con rùa con gặp một con rùa trưởng thành => Đáp án ii','','',7,'Paragraph G','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:34:53','user_05335',false,'2026-06-07 19:34:53','user_05335','PIRATES','Trích đoạn chứa đáp án:
From the 17th century onwards, pirates took a few on
board for food

Keyword cần chú ý:
small numbers ~ a few

Giải thích đáp án:
Hải tặc “pirates” mang rùa lên tàu
=> “pirates”','','',8,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:35:10','user_05335',false,'2026-06-07 19:35:10','user_05335','FOOD','Trích đoạn chứa đáp án:
Dòng 2-3 đoạn B: From the 17th century onwards , pirates took a few on
board for food.

Giải thích đáp án:
Rùa được mang lên tàu làm thức ăn => food','','',9,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:35:25','user_05335',false,'2026-06-07 19:35:25','user_05335','OIL','Trích đoạn chứa đáp án:
Dòng 6-7 đoạn B: Sometimes, their bodies were processed into high-
grade oil .

Keyword cần chú ý:
process ~ produce

Giải thích đáp án:
Cơ thể rùa dùng để chế biến dầu
=> “oil”','','',10,'','FILL_IN_THE_BLANK',148,NULL),
	 ('2026-06-07 19:48:48','user_05335',false,'2026-06-07 19:48:48','user_05335','C','Trích đoạn chứa đáp án:
While earlier theories of music focused on the way a sound can refer to the real world of images and experiences

Keyword cần chú ý:
pictures and events = images and experiences

Giải thích đáp án:
Lý thuyết về âm nhạc chỉ ra rằng âm nhạc có thế giúp hình dung ra các hình ảnh, sự việc => C','','',40,'Earlier theories of music suggested that','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:48:26','user_05335',false,'2026-06-07 19:48:26','user_05335','E','Trích đoạn chứa đáp án:
He wants to preserve an element of uncertainty in his
music, making our brains beg for the one chord he refuses to give us. Beethoven saves
that chord for the end.

Keyword cần chú ý:
save ~ delay

Giải thích đáp án:
Meyer phân tích rằng nhạc của Bethoven trì hoãn việc cho người nghe những gì họ muốn nghe, bằng cách để dành âm đó vào cuối bản nhạc. => E','','',39,'Meyer’s analysis of Beethoven’s music shows that','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:48:07','user_05335',false,'2026-06-07 19:48:07','user_05335','B','Trích đoạn chứa đáp án:
Numerous studies, after all, have demonstrated that
dopamine neurons quickly adapt to predictable rewards.

Keyword cần chú ý:
Numerous studies ~ many studies

Giải thích đáp án:
Các nơ ron sẽ thích nghi với những thỏa mãn có thể dự đoán được
-> B','','',38,'Many studies have demonstrated that','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:47:48','user_05335',false,'2026-06-07 19:47:48','user_05335','F','Trích đoạn chứa đáp án:
the dopamine neurons....were at their most active around
15 seconds before the participants’ favourite moments in the music

Keyword cần chú ý:
before ~ prior

Giải thích đáp án:
Các nơ-ron não có hoạt động trước khi người nghe nghe những điểm nhấn của bản nhạc =>F','','',37,'The Montreal researchers discovered that','FILL_IN_THE_BLANK',150,NULL),
	 ('2026-06-07 19:46:41','user_05335',false,'2026-06-07 19:46:41','user_05335','B','Trích đoạn chứa đáp án:
To demonstrate this psychological principle, the musicologist
Leonard Meyer, in his classic book Emotion and Meaning in Music

Giải thích đáp án:
nguyên lí này ở đây chính là Montreal study đã được đề cập.
-> tác giả nhắc đến Meyer để hỗ trợ cho phát hiện trong Montreal study =>B','','["A. to propose an original theory about the subject","B. to propose an original theory about the subject","C. to propose an original theory about the subject","D. to propose an original theory about the subject"]',35,'Trích đoạn chứa đáp án:
What is rather more significant is the finding that the
dopamine neurons in the caudate were at their most active around 15 seconds before
the participants’ favourite moments in the music

Giải thích đáp án:
Điều ấn tượng nhất của nghiên cứu là thời gian não người nghe phản ứng lại âm nhạc => A','MULTIPLE_CHOICE',150,NULL),
	 ('2027-01-06 17:31:40','truongdx18vtit',false,'2027-01-06 17:31:40','truongdx18vtit','AFTERNOON',NULL,'','',2,'','FILL_IN_THE_BLANK',171,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2027-01-07 17:31:40','truongdx18vtit',false,'2027-01-07 17:31:40','truongdx18vtit','COMMUNICATION',NULL,'','',3,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-08 17:31:40','truongdx18vtit',false,'2027-01-08 17:31:40','truongdx18vtit','WEEK',NULL,'','',4,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-09 17:31:40','truongdx18vtit',false,'2027-01-09 17:31:40','truongdx18vtit','10/TEN',NULL,'','',5,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-10 17:31:40','truongdx18vtit',false,'2027-01-10 17:31:40','truongdx18vtit','SUIT',NULL,'','',6,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-11 17:31:40','truongdx18vtit',false,'2027-01-11 17:31:40','truongdx18vtit','PASSPORT',NULL,'','',7,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-12 17:31:40','truongdx18vtit',false,'2027-01-12 17:31:40','truongdx18vtit','PERSONALITY',NULL,'','',8,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-13 17:31:40','truongdx18vtit',false,'2027-01-13 17:31:40','truongdx18vtit','FEEDBACK',NULL,'','',9,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-14 17:31:40','truongdx18vtit',false,'2027-01-14 17:31:40','truongdx18vtit','RIVER',NULL,'','',15,'','FILL_IN_THE_BLANK',171,''),
	 ('2027-01-15 17:31:40','truongdx18vtit',false,'2027-01-15 17:31:40','truongdx18vtit','1422',NULL,'','',16,'','FILL_IN_THE_BLANK',172,''),
	 ('2026-06-07 18:54:45','user_05335',false,'2026-06-07 18:54:45','user_05335','B','Trích đoạn chứa đáp án:
So rather than maintaining the now redundant leaves throughout the winter, the tree saves its precious resources and discards them. But before letting its leaves go, the tree dismantles their chlorophyll molecules and ships their valuable nitrogen back into the twigs. As chlorophyll is depleted, other colours that have been dominated by it throughout the summer begin to be revealed. This unmasking explains the autumn colours of yellow and orange, but not the brilliant reds and purples of trees such as the maple or sumac.

Giải thích đáp án:
1 Cây tiết kiệm nguồn tài nguyên quý giá và cây rụng lá
2 Nhưng trước khi rụng lá, cây sẽ gỡ các phân tử diệp lục và vận chuyển khí nitơ trở lại cành cây.
3 Khi chất chlorophyll bị cạn kiệt, các màu khác bắt đầu được tiết lộ
4 Việc này giải thích màu sắc mùa thu là vàng và cam, nhưng không phải là màu đỏ và tím rực rỡ
--> Từ đây, bạn có thể hiểu quá trình chuyển màu của lá
-> Cụ thể: chlorophyll bị giảm → cây rụng lá → các màu khác bắt đầu được tiết lộ ra
→ Câu 5 kết lại: Đây là sự giải thích cho “the autumn colours of yellow and orange”
--> Đáp án thích hợp nhất: B - how leaves turn orange and yellow in autumn','','["A. why conifers remain green in winter","B. how leaves turn orange and yellow in autumn","C. how herbivorous insects choose which trees to lay their eggs in","D. why anthocyanins are restricted to certain trees"]',26,'For which of the following questions does the writer offer an explanation?','MULTIPLE_CHOICE',143,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 18:52:30','user_05335',false,'2026-06-07 18:52:30','user_05335','UPPER','Trích đoạn chứa đáp án:
Not only that, but the red is brighter on the upper side of the leaf.

Giải thích đáp án:
20. The ___ surfaces of leaves contain the most red pigment.
Main idea: Màu đỏ thường sáng hơn ở mặt trên của lá
→ So với câu hỏi: Vì bạn đang đi tìm which side of the leave và trong phần info này đã đề cập là upper side + yếu tố the red is brighter
--> Chọn đáp án: upper','','',20,'','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:52:05','user_05335',false,'2026-06-07 18:52:05','user_05335','SUN(LIGHT)','Trích đoạn chứa đáp án:
One is straightforward: on many trees, the leaves that are the reddest are those on the side of the tree which gets most sun.

Giải thích đáp án:
19. The most vividly coloured red leaves are found on the side of the tree facing the ___
Main idea: Ở nhiều cây, những chiếc lá đỏ nhất là những chiếc lá ở phía cây nhận được nhiều ánh nắng mặt trời nhất
--> Which side -> the side of the tree which gets the most sun
→ Chọn đáp án: sun','','',19,'','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 18:51:45','user_05335',false,'2026-06-07 18:51:45','user_05335','E','Trích đoạn chứa đáp án:
It has also been proposed that trees may produce vivid red colours to convince herbivorous insects that they are healthy and robust and would be easily able to mount chemical defences against infestation.

Giải thích đáp án:
18. a suggestion that the red colouration in leaves could serve as a warning signal
Main idea: Màu đỏ sặc sỡ là dấu hiệu cảnh báo tới côn trùng rằng cây cối đang rất khỏe mạnh
→ Chọn đáp án: Paragraph E','','',18,'a suggestion that the red colouration in leaves could serve as a warning signal
','FILL_IN_THE_BLANK',143,NULL),
	 ('2026-06-07 19:01:02','user_05335',false,'2026-06-07 19:01:02','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
They probably never numbered more than a few thousand in total, and in their rapid migration eastward they encountered hundreds of islands – more than 300 in Fiji alone.

Giải thích đáp án:
Main idea: Tổng số người Lapita không bao giờ nhiều hơn vài nghìn người, và trong cuộc di cư nhanh chóng về phía đông, họ đã gặp hàng trăm hòn đảo - chỉ riêng ở Fiji đã có hơn 300 hòn đảo.
--> Không có thông tin - the majority of Lapita settled on Fiji.
--> Chọn đáp án: NOT GIVEN','','',40,'It is likely that the majority of Lapita settled on Fiji.','YES_NO_NOT_GIVEN',144,NULL),
	 ('2026-06-07 18:58:27','user_05335',false,'2026-06-07 18:58:27','user_05335','D','Trích đoạn chứa đáp án:
The Lapita''s thrust into the Pacific was eastward, against the prevailing trade winds, Irwin notes. Those nagging headwinds, he argues, may have been the key to their success. ‘They could sail out for days into the unknown and assess the area, secure in the knowledge that if they didn’t find anything, they could turn about and catch a swift ride back on the trade winds. This is what would have made the whole thing work.’ Once out there, skilled seafarers would have detected abundant leads to follow to land: seabirds, coconuts and twigs carried out to sea by the tides, and the afternoon pile-up of clouds on the horizon which often indicates an island in the distance.
 
Giải thích đáp án:
''This'' ở câu này refer to "the knowledge", cụ thể nếu họ không tìm thấy gì, họ có thể quay ngược về nhà nhanh chóng theo chiều gió. Như vậy đáp án D là đúng - belief=the knowledge, could turn about and swift ride back = be able to return home.','','["A. the Lapita’s seafaring talent","B. the Lapita s ability to detect signs of land","C. the Lapita’s extensive knowledge of the region","D. the Lapita’s belief they would be able to return home"]',34,'What does ‘This’ refer to in the seventh paragraph?','MULTIPLE_CHOICE',144,NULL),
	 ('2026-06-07 18:57:49','user_05335',false,'2026-06-07 18:57:49','user_05335','A','Trích đoạn chứa đáp án:
All we can say for certain is that the Lapita had canoes that were capable of ocean voyages, and they had the ability to sail them,’ says Geoff Irwin, a professor of archaeology at the University of Auckland. Those sailing skills, he says, were developed and passed down over thousands of years by earlier mariners who worked their way through the archipelagoes of the western Pacific, making short crossings to nearby islands. The real adventure didn’t begin, however, until their Lapita descendants sailed out of sight of land, with empty horizons on every side. This must have been as difficult for them as landing on the moon is for us today. Certainly it distinguished them from their ancestors, but what gave them the courage to launch out on such risky voyages?
Giải thích đáp án:

Tác giả đang tập trung khai thác vào chuyến đi của The Lapita, và điều extraordinary về họ là: sailed out of sight with empty horizons
So sánh với câu trả lời: sailed out of sight with empty horizons = sailed beyond the point where land was visible
--> Chọn đáp án A - They sailed beyond the point where land was visible','','["A. They sailed beyond the point where land was visible.","B. Their cultural heritage discouraged the expression of fear.","C. They were able to build canoes that withstood ocean voyages.","D. Their navigational skills were passed on from one generation to the next."]',33,'According to the sixth paragraph, what was extraordinary about the Lapita?','MULTIPLE_CHOICE',144,NULL),
	 ('2027-01-16 17:31:40','truongdx18vtit',false,'2027-01-16 17:31:40','truongdx18vtit','TOP',NULL,'','',17,'','FILL_IN_THE_BLANK',172,''),
	 ('2027-01-17 17:31:40','truongdx18vtit',false,'2027-01-17 17:31:40','truongdx18vtit','TIME',NULL,'','',10,'','FILL_IN_THE_BLANK',172,''),
	 ('2027-01-18 17:31:40','truongdx18vtit',false,'2027-01-18 17:31:40','truongdx18vtit','B',NULL,'','["A. Liverpool","B. Heysham","C. Luton"]',12,'Where can customers meet the tour manager before travelling to the Isle of Man?','MULTIPLE_CHOICE',172,''),
	 ('2026-06-07 19:17:08','user_05335',false,'2026-06-07 19:17:08','user_05335','CORRIDOR/PASSAGEWAY','Trích đoạn chứa đáp án:
At one of the bottlenecks, forested hills rise to form
a V, leaving a corridor of open ground only about
150 metres wide, filled with private homes.

Keyword cần chú ý:
open ground = land
only about 150 metres wide ~
narrow

Giải thích đáp án:
Từ cần điền là một danh từ
Thông tin trong bài: Ở một nút thắt (bottleneck),
những ngọn đồi cao tạo thành hình chữ V, tạo
nên 1 lối đi nối các vùng đất chỉ rộng khoảng 150m
với nhiều căn nhà được xây dựng ở đó
Đối chiếu với câu hỏi: Một vấn đề mà loài linh
dương gặp phải trên chặng đường của chúng
chính là những căn nhà đang được xây dựng tại
lối đi hẹp nối các vùng đất
-> từ cần điền là "corridor"','','',26,'','FILL_IN_THE_BLANK',146,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:16:22','user_05335',false,'2026-06-07 19:16:22','user_05335','SPEED','Trích đoạn chứa đáp án:
Pronghorn, dependent on distance vision and speed
to keep safe from predators, traverse high, open
shoulders of land, where they can see and run.

Keyword cần chú ý:
be dependent on = rely on
distance vision = eyesight
keep safe from = avoid

Giải thích đáp án:
Từ cần điền là một danh từ :loài linh dương dựa
vào thị lực và một thứ gì đó để giúp chúng thoát
khỏi kẻ thù.
Thông tin trong bài: Loài linh dương dựa vào tầm
nhìn xa và tốc độ để giữ chúng an toàn khỏi những
động vật ăn thịt
-> từ cần điền là "speed"','','',23,'','FILL_IN_THE_BLANK',146,NULL),
	 ('2026-06-07 19:14:13','user_05335',false,'2026-06-07 19:14:13','user_05335','FALSE','Trích đoạn chứa đáp án:
The value of his definition, Dingle argues, is that it
focuses attention on what the phenomenon of
wildebeest migration shares with the phenomenon
of the aphids, and therefore helps guide
researchers towards understanding how evolution
has produced them all.

Giải thích đáp án:
Thông tin trong bài: DIngle đưa ra định nghĩa về di
cư và tập trung vào điểm tương đồng giữa hiện
tượng di cư của linh dương đầu bò (wildebeest)
và loài rệp -> để từ đó giúp những nhà nghiên cứu
khác hiểu rõ hơn về sự tiến hóa đã tạo ra những
hiên tượng này.
Đối chiếu với câu hỏi: Mục đích của DIngle là phân
biệt hành vi di cư của những loài vật khác nhau
-> trái với thông tin trong bài đọc
-> FALSE','','',18,'Dingles aim is to distinguish between the migratory behaviours of different species.','TRUE_FALSE_NOT_GIVEN',146,NULL),
	 ('2026-06-07 19:13:36','user_05335',false,'2026-06-07 19:13:36','user_05335','NOT GIVEN','Trích đoạn chứa đáp án:
Paragraph 4 + paragraph 5

Giải thích đáp án:
"aphids" được nhắc tới đoạn 4 và đoạn 5 trong bài
đọc
Ở đoạn 4: Sự di chuyển của "aphids" được coi như
là một loại hình di cư: daily vertical movements by
zooplankton in the ocean [...] can be considered
migration. So can the movement of aphids
Ở đoạn 5: đề cập tới định nghĩa của di cư của nhà
sinh vật học Dingle. Đoạn văn này chỉ ra định nghĩa
của Dingle khác so với định nghĩa của Joe Berger.
bằng cách đưa ra ví dụ phân biệt các hình thức di
chuyển với di cư
Đối chiếu với thông tin trong bài: Có rất ít chuyên
gia đồng tình rằng sự di chuyển của "aphids" được
coi là di cư
-> Trong bài đề cập tới thông tin "movement of
aphids can be considered migration", tuy nhiên
hoàn toàn không có thông tin về việc các chuyên
gia có đồng tình với ý kiến trên hay không
-> NOT GIVEN','','',16,'Very few experts agree that the movement of aphids can be considered migration.','TRUE_FALSE_NOT_GIVEN',146,NULL),
	 ('2026-06-07 19:13:00','user_05335',false,'2026-06-07 19:13:00','user_05335','FALSE','Trích đoạn chứa đáp án:
An arctic tern, on its 20,000 km flight from the
extreme south of South America to the Arctic circle,
will take no notice of a nice smelly herring offered
from a bird-watcher’s boat along the way. While
local gulls will dive voraciously for such handouts,
the tern flies on.

Keyword cần chú ý:
handouts ~ food

Giải thích đáp án:
Thông tin trong bài: Tác giả so sánh hành vi của 2
loài "artic tern" và "gulls" nhìn thấy thức ăn.
Có thể nhận thấy hành vi của 2 loài vật này khác
nhau thông qua cấu trúc câu: While local gulls will
dive voraciously for such handouts, the tern flies on
-> "local gulls" sẽ lao ra để ăn ngấu nghiến, còn
"artic tern" vẫn tiếp tục hành trình di cư của chúng
Đối chiếu với câu hỏi: "local gulls" và "artic terns"
phản ứng giống nhau khi nhìn thấy thức ăn
-> không đúng với ý trong bài
-> FALSE','','',14,'Local gulls and migrating arctic terns behave in the same way when offered food.','TRUE_FALSE_NOT_GIVEN',146,NULL),
	 ('2026-06-07 19:22:34','user_05335',false,'2026-06-07 19:22:34','user_05335','THEOREMS','Trích đoạn chứa đáp án:
I attribute much of my success there to having
learned, through the study of mathematics, and, in
particular, theorems, how to analyze complicated
principles.

Giải thích đáp án:
Từ cần điền là một danh từ
Thông tin trong bài: Người luật sư nói rằng phần lớn
thành công của ông chính là nhờ việc học toán, và
đặc biệt là những định lý (theorems)
-> như vậy "theorems" đã giúp nhiều nhất trong số
những lĩnh vực toán học
-> đáp án là "theorems"','','',40,'A lawyer found that studying………………. helped even more than other areas of mathematics in the study of law.','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:22:04','user_05335',false,'2026-06-07 19:22:04','user_05335','EXPERIMENTS','Trích đoạn chứa đáp án:
It may help to have a pencil and paper ready to check
claims and carry out experiments.

Keyword cần chú ý:
perform = carry out

Giải thích đáp án:
Từ cần điền là một danh từ: Tác giả khuyến nghị
độc giả làm cái gì đó khi đọc cuốn sách này
Thông tin trong bài: Tác giả nói rằng những độc giả
không chuyên về lĩnh vực toán vẫn có thể hiểu được
những lý luận toán học trong cuốn sách này. Và để
đạt được điều đó, ông khuyến nghị độc giả chuẩn bị
một chiếc bút và giấy để kiểm chứng và thực nghiệm
luôn
-> từ cần điền là "experiments"','','',39,'The writer advises non-mathematical readers to perform………………. while reading','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:21:41','user_05335',false,'2026-06-07 19:21:41','user_05335','SCIENTISTS','Trích đoạn chứa đáp án:
Other scientists have written books to explain their
fields to non-scientists, but have necessarily had to
omit the mathematics, although it provides the
foundation of their theories.

Keyword cần chú ý:
omit = leave out
provides the foundation of = is
central to

Giải thích đáp án:
Từ cần điền là một danh từ chỉ người: Những cuốn
sách viết bởi ai đó đã phải bỏ đi những kiến thức về
toán học mà vốn là trọng tâm cho những lý thuyết
của họ.
Thông tin trong bài: Những nhà khoa học khi viết
sách về lĩnh vực của mình phải cắt bỏ những phần
liên quan tới toán học, mặc dù những kiến thức này
là nền tảng cho lý thuyết của họ
-> từ cần điền là "scientists"','','',38,'Some books written by………………. have had to leave out the mathematics that is central to their theories.','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:20:59','user_05335',false,'2026-06-07 19:20:59','user_05335','ARITHMETIC','Trích đoạn chứa đáp án:
There are some discoveries in advanced
mathematics that do not depend on specialized
knowledge, not even on algebra, geometry, or
trigonometry. Instead they may involve, at most, a
little arithmetic, such as ‘the sum of two odd numbers
is even’, and common sense.

Keyword cần chú ý:
a little ~ no more than a limited
knowledge of

Giải thích đáp án:
Từ cần điền là một danh từ: Đôi khi có thể hiểu
toán học nâng cao mà chỉ cần sử dụng kiến thức
hạn chế về cái gì đó.
Thông tin trong bài: tác giả đã giải thích rằng có
một số những lĩnh vực toán học nâng cao không
phụ thuộc vào kiến thức chuyên sâu, mà thay vào
đó chỉ cần một chút kiến thức về số học là đủ.
-> từ cần điền là ''arithmetic''','','',36,'It is sometimes possible to understand advanced mathematics using no more than a limited knowledge of………………','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:18:23','user_05335',false,'2026-06-07 19:18:23','user_05335','G','Trích đoạn chứa đáp án:
A physician wrote, ‘The discipline of analytical
thought processes [in mathematics] prepared me
extremely well for medical school. In medicine one
is faced with a problem which must be thoroughly
analyzed before a solution can be found. The
process is similar to doing mathematics.’
A lawyer made the same point, “Although I had no
background in law – not even one political science
course — I did well at one of the best law schools. I
attribute much of my success there to having
learned, through the study of mathematics, and, in
particular, theorems, how to analyze complicated
principles. Lawyers who have studied mathematics
can master the legal principles in a way that most
others cannot.’

Giải thích đáp án:
Câu hỏi: đoạn văn chứa thông tin về ví dụ của
những cá nhân đã được giúp đỡ nhờ toán học như
thế nào
Trong đoạn G, tác giả đã đưa ra 2 ví dụ về bác sĩ
và luật sư rồi trích dẫn lời kể của họ về việc toán
học đã giúp họ như thế nào trong công việc
-> đáp án là G','','',29,'personal examples of being helped by mathematics','FILL_IN_THE_BLANK',147,NULL),
	 ('2026-06-07 19:38:57','user_05335',false,'2026-06-07 19:38:57','user_05335','D','Trích đoạn chứa đáp án:
Health geography is the combination of, on the one hand,
knowledge regarding geography and methods used
to analyse and interpret geographical information, and on the other, the study of health,
diseases and healthcare practices around the world

Keyword cần chú ý:
mixture ~ combination

Giải thích đáp án:
Health geography là kết hợp (combination) của hai lĩnh vực nghiên
cứu => Đáp án D','','',18,'a description of health geography as a mixture of different academic fields','FILL_IN_THE_BLANK',149,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-07 19:47:20','user_05335',false,'2026-06-07 19:47:20','user_05335','D','Trích đoạn chứa đáp án:
Meyer argued that the emotions we find in music come from
the unfolding events of the music itself.

Keyword cần chú ý:
unfoolding events ~ internal structure

Giải thích đáp án:
cảm xúc của người nghe đến từ chính âm nhạc
-> Phản ứng của người nghe với âm nhạc là do cấu trúc của bản nhạc => D','','["A. the way that the music evokes poignant memories in the listener","B. the association of certain musical chords with certain feelings","C. the listener’s sympathy with the composer’s intentions","D. the internal structure of the musical composition"]',36,'According to Leonard Meyer, what causes the listener’s emotional response to music?','MULTIPLE_CHOICE',150,NULL),
	 ('2026-06-19 17:31:40','truongdx18vtit',false,'2026-06-19 17:31:40','truongdx18vtit','CITY CENTRE',NULL,'','',1,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-20 17:31:40','truongdx18vtit',false,'2026-06-20 17:31:40','truongdx18vtit','TRANSPORT CENTRE',NULL,'','',2,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-21 17:31:40','truongdx18vtit',false,'2026-06-21 17:31:40','truongdx18vtit','12000M2',NULL,'','',3,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-22 17:31:40','truongdx18vtit',false,'2026-06-22 17:31:40','truongdx18vtit','40',NULL,'','',4,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-23 17:31:40','truongdx18vtit',false,'2026-06-23 17:31:40','truongdx18vtit','WHEELCHAIR',NULL,'','',5,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-24 17:31:40','truongdx18vtit',false,'2026-06-24 17:31:40','truongdx18vtit','JULY',NULL,'','',6,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-25 17:31:40','truongdx18vtit',false,'2026-06-25 17:31:40','truongdx18vtit','WALLS',NULL,'','',7,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-26 17:31:40','truongdx18vtit',false,'2026-06-26 17:31:40','truongdx18vtit','KITCHEN',NULL,'','',8,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-27 17:31:40','truongdx18vtit',false,'2026-06-27 17:31:40','truongdx18vtit','CARPET',NULL,'','',9,'','FILL_IN_THE_BLANK',151,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-28 17:31:40','truongdx18vtit',false,'2026-06-28 17:31:40','truongdx18vtit','THREE YEARS',NULL,'','',10,'','FILL_IN_THE_BLANK',151,''),
	 ('2026-06-29 17:31:40','truongdx18vtit',false,'2026-06-29 17:31:40','truongdx18vtit','JOB',NULL,'','',11,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-06-30 17:31:40','truongdx18vtit',false,'2026-06-30 17:31:40','truongdx18vtit','CAREER GOALS',NULL,'','',12,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-01 17:31:40','truongdx18vtit',false,'2026-07-01 17:31:40','truongdx18vtit','QUALIFICATION',NULL,'','',13,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-02 17:31:40','truongdx18vtit',false,'2026-07-02 17:31:40','truongdx18vtit','GRADES',NULL,'','',14,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-03 17:31:40','truongdx18vtit',false,'2026-07-03 17:31:40','truongdx18vtit','Higher Education Providers',NULL,'','',15,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-04 17:31:40','truongdx18vtit',false,'2026-07-04 17:31:40','truongdx18vtit','Apprenticeship Scheme',NULL,'','',16,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-05 17:31:40','truongdx18vtit',false,'2026-07-05 17:31:40','truongdx18vtit','School Careers Advisor',NULL,'','',17,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-06 17:31:40','truongdx18vtit',false,'2026-07-06 17:31:40','truongdx18vtit','Career Services',NULL,'','',18,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-07 17:31:40','truongdx18vtit',false,'2026-07-07 17:31:40','truongdx18vtit','Student Support Association',NULL,'','',19,'','FILL_IN_THE_BLANK',152,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-07-08 17:31:40','truongdx18vtit',false,'2026-07-08 17:31:40','truongdx18vtit','Libraries',NULL,'','',20,'','FILL_IN_THE_BLANK',152,''),
	 ('2026-07-09 17:31:40','truongdx18vtit',false,'2026-07-09 17:31:40','truongdx18vtit','QUESTIONNAIRES',NULL,'','',21,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-10 17:31:40','truongdx18vtit',false,'2026-07-10 17:31:40','truongdx18vtit','LOSS OF CONTROL',NULL,'','',22,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-11 17:31:40','truongdx18vtit',false,'2026-07-11 17:31:40','truongdx18vtit','PREOCCUPATION',NULL,'','',23,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-12 17:31:40','truongdx18vtit',false,'2026-07-12 17:31:40','truongdx18vtit','LOSS OF RELATIONSHIPS',NULL,'','',24,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-13 17:31:40','truongdx18vtit',false,'2026-07-13 17:31:40','truongdx18vtit','ESCAPE',NULL,'','',25,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-14 17:31:40','truongdx18vtit',false,'2026-07-14 17:31:40','truongdx18vtit','SHYNESS',NULL,'','',26,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-15 17:31:40','truongdx18vtit',false,'2026-07-15 17:31:40','truongdx18vtit','ALIENATION',NULL,'','',27,'','FILL_IN_THE_BLANK',153,''),
	 ('2026-07-16 17:31:40','truongdx18vtit',false,'2026-07-16 17:31:40','truongdx18vtit','STRANGERS',NULL,'','',28,'','FILL_IN_THE_BLANK',153,''),
	 ('2027-01-30 17:31:40','truongdx18vtit',false,'2027-01-30 17:31:40','truongdx18vtit','C',NULL,'','["A. There is conflicting evidence about whether oldest children perform best in intelligence tests.","B. There is little doubt that birth order has less influence on academic achievement than socio-economic status.","C. Some studies have neglected to include important factors such as family size."]',27,'What do the speakers say about the evidence relating to birth order and academic success?','MULTIPLE_CHOICE',173,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2027-01-31 17:31:40','truongdx18vtit',false,'2027-01-31 17:31:40','truongdx18vtit','A',NULL,'','["A. It is mainly thanks to their roles as teachers for their younger siblings.","B. The advantages they have only lead to a slightly higher level of achievement.","C. The extra parental attention they receive at a young age makes little difference."]',28,'What does Ruth think is surprising about the difference in oldest children’s academic performance?
','MULTIPLE_CHOICE',173,''),
	 ('2027-02-01 17:31:40','truongdx18vtit',false,'2027-02-01 17:31:40','truongdx18vtit','B/D',NULL,'','',29,'','FILL_IN_THE_BLANK',173,''),
	 ('2027-02-02 17:31:40','truongdx18vtit',false,'2027-02-02 17:31:40','truongdx18vtit','GRASS(ES)',NULL,'','',35,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-03 17:31:40','truongdx18vtit',false,'2027-02-03 17:31:40','truongdx18vtit','B/D',NULL,'','',30,'','FILL_IN_THE_BLANK',173,''),
	 ('2027-02-04 17:31:40','truongdx18vtit',false,'2027-02-04 17:31:40','truongdx18vtit','SHELTER',NULL,'','',31,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-05 17:31:40','truongdx18vtit',false,'2027-02-05 17:31:40','truongdx18vtit','OIL',NULL,'','',32,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-06 17:31:40','truongdx18vtit',false,'2027-02-06 17:31:40','truongdx18vtit','ROADS',NULL,'','',33,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-07 17:31:40','truongdx18vtit',false,'2027-02-07 17:31:40','truongdx18vtit','INSECTS',NULL,'','',34,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-08 17:31:40','truongdx18vtit',false,'2027-02-08 17:31:40','truongdx18vtit','C',NULL,'','',26,'a child with much older siblings','FILL_IN_THE_BLANK',173,''),
	 ('2027-02-09 17:31:40','truongdx18vtit',false,'2027-02-09 17:31:40','truongdx18vtit','WATER',NULL,'','',36,'','FILL_IN_THE_BLANK',174,'');
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2027-02-10 17:31:40','truongdx18vtit',false,'2027-02-10 17:31:40','truongdx18vtit','DRY',NULL,'','',38,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-11 17:31:40','truongdx18vtit',false,'2027-02-11 17:31:40','truongdx18vtit','SIMPLE',NULL,'','',39,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-12 17:31:40','truongdx18vtit',false,'2027-02-12 17:31:40','truongdx18vtit','SOIL',NULL,'','',37,'','FILL_IN_THE_BLANK',174,''),
	 ('2027-02-13 17:31:40','truongdx18vtit',false,'2027-02-13 17:31:40','truongdx18vtit','NEST(S)',NULL,'','',40,'','FILL_IN_THE_BLANK',174,''),
	 ('2026-06-10 19:29:12','truongdx18vtit',false,'2026-06-10 19:29:12','truongdx18vtit','EGG','Trích đoạn chứa đáp án:
SARAH: For example, they work together to design a special cover that goes round an egg, so that when it’s inside they can drop it from a height and it doesn’t break.

Giải thích đáp án:
Create a cover for an (1) _____ so they can drop it from a height
Đáp án cần điền là một danh từ, cái mà được bao bọc (cover)
-> egg','','',1,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:29:21','truongdx18vtit',false,'2026-06-10 19:29:21','truongdx18vtit','TOWER','Trích đoạn chứa đáp án:
SARAH: Well, they have a competition to see who can make the highest tower.

Keyword cần chú ý:
build = make

Giải thích đáp án:
2 Take part in a competition to build the tallest (2) _____.
Đáp án cần điền là một danh từ, cái mà được xây dựng (build)
-> tower','','',2,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:29:31','truongdx18vtit',false,'2026-06-10 19:29:31','truongdx18vtit','CAR','Trích đoạn chứa đáp án:
SARAH: For example, one thing they do is to design and build a car that’s attached to a balloon, and the force of the air in that actually powers the car and makes it move along.

Keyword cần chú ý:
power = make ... move

Giải thích đáp án:
3 Make a (3) ____ powered by a balloon.
Đáp án cần điền là một danh từ, cái được vận
hành (powered) bởi một quả bóng bay (balloon)
-> car','','',3,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:29:42','truongdx18vtit',false,'2026-06-10 19:29:42','truongdx18vtit','ANIMALS','Trích đoạn chứa đáp án:
"SARAH: So they work out how to build model vehicles, things like cars and trucks, but also how to construct animals using the same sorts of material and technique, and then they learn how they can program them and make them move."

Giải thích đáp án:
4 Activities:
Build model cars, trucks and (4) _____. And learn how to program them so they can move.
Đáp án cần điền là một danh từ, thứ được tạo ra (build)
-> animals','','',4,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:29:50','truongdx18vtit',false,'2026-06-10 19:29:50','truongdx18vtit','BRIDGE','Trích đoạn chứa đáp án:
"SARAH: Yes, with the Junior Engineers, it’s to use recycled materials like card and wood to build a bridge, and the longest one gets a prize."

Giải thích đáp án:
5 Take part in a competition to build the longest (5) _____ using card and wood.
Đáp án cần điền là một danh từ, cái được tạo nên (build) từ việc sử dụng bìa (card) và gỗ
(wood).
-> bridge','','',5,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:30:04','truongdx18vtit',false,'2026-06-10 19:30:04','truongdx18vtit','MOVIE/FILM','Trích đoạn chứa đáp án:
SARAH: Then they have something a bit different, which is to think up an idea for a five-minute movie and then film it, using special animation software. You’d be amazed what they come up with

Keyword cần chú ý:
with = using

Giải thích đáp án:
6 Create a short (6) _____ with special
software.
Đáp án cần điền là một danh từ, cái mà được
tạo ra (create) bằng một phần mềm đặc biệt
(special software)
-> movie/film','','',6,'','FILL_IN_THE_BLANK',179,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 19:30:20','truongdx18vtit',false,'2026-06-10 19:30:20','truongdx18vtit','DECORATE','Trích đoạn chứa đáp án:
"SARAH: Exactly. And then they also build a robot in the shape of a human, and they decorate it and program it so that it can move its arms and legs."

Keyword cần chú ý:
humanoid robot = robot in the shape of a human

Giải thích đáp án:
7 Build, (7) _____ and program a humanoid robot.
Đáp án cần điền là một động từ
-> decorate','','',7,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:30:30','truongdx18vtit',false,'2026-06-10 19:30:30','truongdx18vtit','WEDNESDAYS','Trích đoạn chứa đáp án:
"FATHER: And are the classes on a Monday, too?
SARAH: They used to be, but we found it didn’t give our staff enough time to clear up after the first workshop, so we moved them to Wednesdays. The classes are held in the morning from ten to eleven."

Giải thích đáp án:
8 Held on (8) _____ from 10 am to 11 am
Đáp án cần điền là một danh từ
-> Wednesdays','','',8,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:30:41','truongdx18vtit',false,'2026-06-10 19:30:41','truongdx18vtit','FRADSTONE','Trích đoạn chứa đáp án:
"SARAH: They’re in building 10A-there’s a big sign on the door, you can’t miss it, and that’s in Fradstone Industrial Estate
SARAH: Fradstone -that’s F-R-A-D-S-T-O- N-E"

Giải thích đáp án:
9 Building 10A, (9) _____ Industrial Estate, Grasford.
Đáp án cần điền có thể là một tên riêng
-> Fradstone','','',9,'','FILL_IN_THE_BLANK',179,NULL),
	 ('2026-06-10 19:34:39','truongdx18vtit',false,'2026-06-10 19:34:39','truongdx18vtit','C/E','Trích đoạn chứa đáp án:
JESS: So have I. When they gave us all those handouts with details of books and websites to look at. I was really put off, but the more I read, the more interested I got.
TOM: Me too. I found I could research so many different aspects of birds in art- colour. movement, texture.

Giải thích đáp án:
21-22 Which TWO parts of the introductory stage to their art projects do JESS and TOM agree were useful?
Trong script chỉ ra rằng các ban đầu JESS cảm thấy rất chán khi mà đọc handout nhưng càng đọc JESS lại càng thấy cuốn.
-> E. The handouts with research sources.','','',21,'','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 20:35:54','truongdx18vtit',false,'2026-06-10 20:35:54','truongdx18vtit','35 [OR] THIRTY FIVE','Trích đoạn chứa đáp án:
PETER: There''s a charge of £35, including lunch, or £40 if you want to camp in the woods.
 
Giải thích đáp án:
 

Từ cần điền là một con số cụ thể
-> cần nghe xem mức giá cho buổi học (không bao gồm phí cắm trại) là bao nhiêu
Ta nghe thấy PETER nói tới 2 mức giá £35 và £40. Tuy nhiên, mức giá £35 chỉ bao gồm chi phí bữa ăn trưa, còn £40 là chi phí bao gồm cắm trại
-> đáp án cần điền là ''35''','','',10,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:36:28','truongdx18vtit',false,'2026-06-10 20:36:28','truongdx18vtit','A','Trích đoạn chứa đáp án:
But please note if there are more than nine people on either side of the boat, we''ll move some of you over. Otherwise, all eighteen of us will end up in the sea.

Giải thích đáp án:
Nội dung câu hỏi:
Số người tối đa có thể đứng trên mỗi bên của con thuyền là bao nhiêu?
Trong đoạn nghe, người nói đã lưu ý rằng nếu có hơn 9 người ở hai bên thuyền thì sẽ phải chuyển bớt một số người đi, nếu không thì tất cả sẽ bị chìm
-> có thể hiểu rằng số người tối đa cho mỗi bên thuyền là 9 người
-> đáp án A','','["A. 9","B. 15","C. 18"]',11,'What is the maximum number of people who can stand on each side of the boat?','MULTIPLE_CHOICE',184,NULL),
	 ('2026-06-10 20:36:57','truongdx18vtit',false,'2026-06-10 20:36:57','truongdx18vtit','C','Trích đoạn chứa đáp án:
We’ve recently upgraded all our boats. They used to be jet black, but our new ones now have these comfortable dark red seats and a light-green exterior in order to stand out from others and help promote our company. This gives our boats a rather unique appearance, don''t you think?

Giải thích đáp án:
Nội dung câu hỏi:
Các thuyền du lịch có màu gì?
Trong đọạn nghe, người nói có đề cập đến cả 3 màu thuộc 3 đáp án: jet black, dark red, và light green
Tuy nhiên
Đáp án A. dark red : đây là màu của những cái ghế trên thuyền (''...comfortable dark red seats..'') -> loại
Đáp án B. jet balck : đây là màu đã từng được dùng cho thuyền -> loại vì câu hỏi hỏi về màu sắc hiện tại của những con thuyền
-> đáp án đúng là C. (''...our new ones now have......a light-green exterior..'')','','["A. dark red","B. jet black","C. light green"]',12,'What colour are the tour boats?','MULTIPLE_CHOICE',184,NULL),
	 ('2026-06-10 20:37:23','truongdx18vtit',false,'2026-06-10 20:37:23','truongdx18vtit','B','Trích đoạn chứa đáp án:
We offer you a free lunchbox during the trip and we have three types. Lunchbox 1 contains ham and tomato sandwiches. Lunchbox 2 contains a cheddar cheese roll and Lunchbox 3 is salad-based and also contains eggs and tuna.

Giải thích đáp án:
Nội dung câu hỏi:
Loại suất ăn trưa nào phù hợp cho người không ăn thịt hoặc cá?
Ta thấy giống như câu 12, người nói cũng đã đề cập đến cả 3 loại hộp ăn: Lunch box 1, lunch box 2, lunch box 3
-> ta cần nghe chính xác thông tin của từng loại để thực hiện loại trừ đáp án
Đáp án A. Lunch box 1 bao gồm giăm bông và bánh kẹp cà chua -> loại vì suất ăn này có thịt
Đáp án B. Lunch box 2 bao gồm cuốn phô mai cheddar -> suất ăn này không có cả thịt và cá -> đáp ứng yêu cầu của câu hỏi
-> chọn đáp án B
Phân tích nốt đáp án C. Lunch box 3 có salad trứng và cá ngừ -> loại vì hộp ăn trưa này có tuna (cá ngừ).','','["A. Lunch box 1","B. Lunch box 2","C. Lunch box 3"]',13,'Which lunchbox is suitable for someone who doesn’t eat meat or fish?','MULTIPLE_CHOICE',184,NULL),
	 ('2026-06-10 20:37:52','truongdx18vtit',false,'2026-06-10 20:37:52','truongdx18vtit','B','Trích đoạn chứa đáp án:
I''m sure I don''t have to ask you not to throw anything into the sea. We don''t have any bins to put litter in, but Jess, myself or Ray, our other guide, will collect it from you after lunch and put it all in a large plastic sack

Giải thích đáp án:
Nội dung câu hỏi:
Mọi người nên làm gì với rác của mình?
Nghe thấy người nói đã đề cập đến việc xử lý rác ''We don''t have any bins to put litter in''
-> như vậy người nói đã đề cập đến việc họ không có vật dụng gì để đựng rác cả
-> loại đáp án C (vì đáp án C nói rằng rác cần được để vào các thùng được cung cấp trên thuyền)
Tiếp theo, ta nghe thấy ''but Jess, myself or Ray, our other guide, will collect it from you''
-> các nhân viên sẽ là những người đi thu gom rác
-> đáp án đúng là B','','["A. take it home","B. hand it to a member of staff","C. put it in the bins provided on the boat"]',14,'What should people do with their litter?','MULTIPLE_CHOICE',184,NULL),
	 ('2026-06-10 19:37:29','truongdx18vtit',false,'2026-06-10 19:37:29','truongdx18vtit','PUBLICATION','Trích đoạn chứa đáp án:
Amazingly, we still have access to these ideas, despite the fact that the most famous Stoics never wrote anything down for publication.

Giải thích đáp án:
32 The Stoics’ ideas are surprisingly well known, despite not being intended for _____.
Những ý tưởng của người theo chủ nghĩa khắc kỷ rất nổi tiếng mặc dù không nhằm mục đích _____.
Đáp án có thể là một danh từ.
-> publication','','',32,'','FILL_IN_THE_BLANK',182,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 19:37:13','truongdx18vtit',false,'2026-06-10 19:37:13','truongdx18vtit','PRACTICAL','Trích đoạn chứa đáp án:
Specifically, I am referring to Stoicism, which, in my opinion, is the most practical of all philosophies and therefore the most appealing.

Giải thích đáp án:
31 Stoicism is still relevant today because of its _____ appeal.
Chủ nghĩa khắc kỷ vẫn còn có ích đến ngày nay bởi vì _____.
Đáp án có thể là một tính từ, bổ nghĩa cho danh từ appeal (thu hút).
-> practical','','',31,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:37:38','truongdx18vtit',false,'2026-06-10 19:37:38','truongdx18vtit','CHOICES','Trích đoạn chứa đáp án:
In the words of Epictetus: “external events I cannot control, but the choices I make with regard to them. I do control”.

Keyword cần chú ý:
in response ~ with regard to

Giải thích đáp án:
33 Epictetus said that external events cannot be controlled but the _____ people make in response can be controlled.
Epictetus cho rằng việc kiểm soát các sự kiện bên ngoài là không thể nhưng mọi người có thể kiểm soát _____.
Đáp án có thể là một danh từ, đứng sau mạo từ the.
-> choices','','',33,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:33:40','truongdx18vtit',false,'2026-06-10 19:33:40','truongdx18vtit','G','Trích đoạn chứa đáp án:
Somewhere you’ll be keen to find is the staff canteen. This is right next to reception. I can confidently say that the food’s very good, but the view isn’t. The windows on one side look onto a corridor and courtyard, which aren’t very attractive at all, and on the other onto the Access Road, which isn’t much better.

Giải thích đáp án:
Dịch: Phòng căng-tin của nhân viên (Staff canteen) nằm ở phía bên phải khu vực lễ tân (reception). Có thể nhìn ra hành lang (corridor) và sân trong (courtyard). Nằm hướng về phía đường Access (Access Road)
-> G','','',17,'staff canteen ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:34:18','truongdx18vtit',false,'2026-06-10 19:34:18','truongdx18vtit','A','Trích đoạn chứa đáp án:
And finally, the boardroom, where you’ll be meeting sometimes. That has quite a pleasant view, as it looks out on to the trees. Go along the corridor past the courtyard, right to the end. The boardroom is on the left, next to the factory

Giải thích đáp án:
Dịch: Phòng ban giám đốc (Boardroom) nằm ở cuối hành lang và có thể nhìn thấy cây cối.
-> A','','',20,'boardroom ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:32:55','truongdx18vtit',false,'2026-06-10 19:32:55','truongdx18vtit','C','Trích đoạn chứa đáp án:
"I’d better give you some idea of what you’ll be doing during your two weeks with us, so you know what to expect. Most mornings you’ll have a presentation from one of the managers, to learn about their department, starting this morning with research and development."
 

Keyword cần chú ý:
 

talk = presentation
 

Giải thích đáp án:
 

14 The programme for the work experience group includes
-> C, talks by staff
(Mặc dù trong bài có nhắc đến từ nghiên cứu (research), tuy nhiên ngữ cảnh trong bài hoàn toàn không để cập đến thời gian nghiên cứu (time to do research) -> loại A
Trong quá khứ thì một giáo viên từ trường của bạn sẽ đến vào cuối mỗi tuần để xem nhóm đang tiến triển như nào, tuy nhiên năm nay thì không có. -> loại B','','["A. time to do research.","B. meetings with a teacher.","C. talks by staff."]',14,'The programme for the work experience group includes','MULTIPLE_CHOICE',180,NULL),
	 ('2026-06-10 19:40:44','truongdx18vtit',false,'2026-06-10 19:40:44','truongdx18vtit','LOGIC','Trích đoạn chứa đáp án:
The idea is that we can take control of our lives by challenging the irrational beliefs that create our faulty thinking, symptoms and behaviours by using logic instead.

Keyword cần chú ý:
base on ~ use

Giải thích đáp án:
38 people learn to base their thinking on _____.
Đáp án có thể là một danh từ thứ thứ tạo nên nền tảng cho các suy nghĩ của con người
-> logic','','',38,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 21:29:08','truongdx18vtit',false,'2026-06-10 21:29:08','truongdx18vtit','SPEED','Trích đoạn chứa đáp án:
And one thing that researchers are finding especially interesting is the speed with which they’re doing this – we’re not talking about gradual evolution here – these animals are changing fast. (Q33)

Keyword cần chú ý:
speed = how fast

Giải thích đáp án:
Những loài này đang thay đổi rất nhanh
-> với tốc độ cao hơn bình thường
-> (unusual) speed','','',33,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:29:24','truongdx18vtit',false,'2026-06-10 21:29:24','truongdx18vtit','BRAIN(S)','Trích đoạn chứa đáp án:
And she found that during that time, these small mammals had experienced a jump in brain size when compared to rural mammals (Q34)

Keyword cần chú ý:
increase = a jump in

Giải thích đáp án:
Kích thước não tăng
-> brain','','',34,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:29:40','truongdx18vtit',false,'2026-06-10 21:29:40','truongdx18vtit','FOOD','Trích đoạn chứa đáp án:
And Snell-Rood thinks that this change might reflect the cognitive demands of adjusting to city life – having to look in different places to find food, for example, and coping with a whole new set of dangers. (Q35)

Keyword cần chú ý:
locate = find
look in different places to find = locate new sources of
deal with = cope with

Giải thích đáp án:
Phải tìm những nguồn thức ăn mới
-> food','','',35,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:29:56','truongdx18vtit',false,'2026-06-10 21:29:56','truongdx18vtit','BEHAVIOUR(S)/BEHAVIOR(S)','Trích đoạn chứa đáp án:
Then over in Germany at the Max Planck Institute, there’s another biologist called Catarina Miranda who’s done some experiments with blackbirds living in urban and rural areas. And she’s been looking not at their anatomy but at their behaviour (Q36)

Giải thích đáp án:
Catarina Miranda không tập trung vào anatomy (cấu tạo giải phẫu) mà behaviour (hành vi) những loài này
-> behaviour','','',36,'','FILL_IN_THE_BLANK',178,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:30:07','truongdx18vtit',false,'2026-06-10 21:30:07','truongdx18vtit','NEW','Trích đoạn chứa đáp án:
But there’s one type of situation that does seem to frighten the urban blackbirds, and that’s anything new – anything they haven’t experienced before (Q37)

Giải thích đáp án:
Những tình huống mới vẫn làm những loài này sợ
-> new','','',37,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:30:21','truongdx18vtit',false,'2026-06-10 21:30:21','truongdx18vtit','STRESS','Trích đoạn chứa đáp án:
He’s found that when they’re under stress, their endocrine systems react by reducing the amount of hormones such as corticosterone into their blood (Q38).

Keyword cần chú ý:
lower = reduce

Giải thích đáp án:
Khi gặp stress động vật sản sinh ít hormone hơn
-> stress','','',38,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:31:29','truongdx18vtit',false,'2026-06-10 21:31:29','truongdx18vtit','TAIL(S)','Trích đoạn chứa đáp án:
[...] they’ve been looking at how squirrels communicate in an urban environment, and they’ve found that a routine part of their communication is carried out by waving their tails (Q39)

Giải thích đáp án:
Sóc ở thành thị dùng đuôi trong giao tiếp
-> tails','','',39,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:31:42','truongdx18vtit',false,'2026-06-10 21:31:42','truongdx18vtit','PERMANENT','Trích đoạn chứa đáp án:
One possibility is that we may see completely new species developing in cities. But on the other hand, it’s possible that not all of these adaptations will be permanent (Q40).

Keyword cần chú ý:
some may not be = not all will be

Giải thích đáp án:
Những sự thích nghi này có thể không vĩnh viễn
-> permanent','','',40,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 19:33:26','truongdx18vtit',false,'2026-06-10 19:33:26','truongdx18vtit','C','Trích đoạn chứa đáp án:
The factory is the very big room on the far side of the site. Next to it is the warehouse, which can be accessed by lorries going up the road to the turning area at the end. You can get to the warehouse by crossing to the far side of the courtyard, and then the door is on your right.

Giải thích đáp án:
Dịch: Warehouse (nhà kho) nằm cạnh nhà máy. Nếu đi bằng xe tải (lorries) thì có thể đến nhà kho bằng cách đi thẳng (nhà kho nằm gần khu vực rẽ ở cuối - turning area at the end) . Hoặc có thể đi từ khu vực tiếp tân, xuyên qua về phía xa nhất của sân trong, nhà kho nằm bên phải.
-> C','','',16,'warehouse ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:33:09','truongdx18vtit',false,'2026-06-10 19:33:09','truongdx18vtit','H','Trích đoạn chứa đáp án:
As you can see, we’re in the reception area which we try to make attractive and welcoming to visitors. There is a corridor running left from here, if you go along that, the door facing you at the end is the entrance to the coffee room. This looks out onto the main road on one side, and some trees on the other, and that’ll be where you meet each morning.

Giải thích đáp án:
Dịch: Coffee room (Phòng cà phê) nằm ở cuối hành lang (có thể nhìn ra (look out) đường cái (main road), hoặc nhìn thấy cây (trees)
-> H','','',15,'coffee room ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:33:53','truongdx18vtit',false,'2026-06-10 19:33:53','truongdx18vtit','B','Trích đoạn chứa đáp án:
You’ll be using the meeting room quite often, and you’ll find it by walking along the corridor to the left of the courtyard, and continuing along it to the end. The meeting room is the last one on the right, and I’m afraid there’s no natural daylight in the room.

Giải thích đáp án:
_x0008_Dịch: Phòng họp (meeting room) nằm ở cuối của hành phía bên phải.
-> B','','',18,'meeting room ➡️','FILL_IN_THE_BLANK',180,NULL),
	 ('2026-06-10 19:32:02','truongdx18vtit',false,'2026-06-10 19:32:02','truongdx18vtit','A','Trích đoạn chứa đáp án:
Stevenson was given the opportunity to make goods for hospitals and other players in the healthcare industry, so that’s what we did for the first five years

Keyword cần chú ý:
manufacture = make

Giải thích đáp án:
12 Originally, Stevenson’s manufactured goods for
-> A, the healthcare industry.
Với ngành công nghiệp ô tô thì công ty Stevenson đã trì hoãn 5 năm trước khi đi vào hoạt động sản xuất. (tức không phải công ty Stevenson ban đầu sản xuất hàng cho ngành công nghiệp này) -> loại B
Kế hoạch dài hạn của công ty Stevenson là sản xuất các linh phụ kiện cho ngành công nghiệp công cụ máy móc, nhưng điều này chưa bao giờ xảy ra -> loại C','','["A. the healthcare industry.","B. the automotive industry.","C. the machine tools industry."]',12,'Originally, Stevenson’s manufactured goods for…','MULTIPLE_CHOICE',180,NULL),
	 ('2026-06-10 19:31:26','truongdx18vtit',false,'2026-06-10 19:31:26','truongdx18vtit','C','Trích đoạn chứa đáp án: "He set up this company when he finished his apprenticeship, in 1926"  Keyword cần chú ý: found = set up (a company)  Giải thích đáp án: 11 Stevenson’s was founded in Đáp án đúng là C. 1926 1923 là năm mà Ronald Stevenson bước vào ngành thép khi mà anh ấy rời ghế nhà trường -> loại A 1924 là năm mà Stevenson bắt đầu lên kế hoạch thành lập công ty (2 năm sau công ty mới được thành lập) -> loại B','','["A. 1923","B. 1924","C. 1926"]',11,'Stevenson’s was founded in…','MULTIPLE_CHOICE',180,NULL),
	 ('2026-06-10 19:32:30','truongdx18vtit',false,'2026-06-10 19:32:30','truongdx18vtit','B','Trích đoạn chứa đáp án:
Over the years, we’ve expanded the premises considerably -we were lucky that the site is big enough, so moving to a new location has never been necessary.

Keyword cần chú ý:
no plan to move = moving ... not necessary

Giải thích đáp án:
13 What does the speaker say about the company premises?
-> B, The company has no plans to move.
Đáp án A và C là các đáp án bẫy dành cho những người nghe được từ "moving" nhưng không hiểu hết nghĩa của câu.','','["A. The company has recently moved.","B. The company has no plans to move.","C. The company is going to move shortly."]',13,'What does the speaker say about the company premises?','MULTIPLE_CHOICE',180,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 19:36:37','truongdx18vtit',false,'2026-06-10 19:36:37','truongdx18vtit','F','Trích đoạn chứa đáp án:
JESS: Interesting. There’s Gauguin’s picture Vairumati. He did it in Tahiti. It’s a woman with a white bird behind her that is eating a lizard, and what I’m interested in is what idea this bird refers to. Apparently, it’s a reference to the never-ending cycle of existence.

Keyword cần chú ý:
continuity of life ~ never-ending cycle of existence

Giải thích đáp án:
29 Vairumati (Gauguin)
Bức vẽ Vairumati của Gauguin gợi lên cho JESS về chu kỳ tồn tại không bao giờ chấm dứt.
-> F. the continuity of life','','',29,'Vairumati (Gauguin) ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:36:10','truongdx18vtit',false,'2026-06-10 19:36:10','truongdx18vtit','A','Trích đoạn chứa đáp án:
JESS: Do you know that picture of a kingfisher by van Gogh -it’s perching on a reed growing near a stream.
TOM: Yes it’s got these beautiful blue and red and black shades
JESS: Mm hm. I’ve actually chosen it because I saw a real kingfisher once when I was little. I was out walking with my grandfather, and I’ve never forgotten it.
TOM: So we can use a personal link?
JESS: Sure.

Giải thích đáp án:
27 Kingfisher (van Gogh)
Hình ảnh chim bói cá gợi cho JESS về kỷ niệm khi còn nhỏ. Cô ấy đã nhìn một con chim bói cá thực ngoài đời khi đang đi dạo với ông.
-> A. a childhood memory','','',27,'Kingfisher (Van Gogh) ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:35:45','truongdx18vtit',false,'2026-06-10 19:35:45','truongdx18vtit','D','Trích đoạn chứa đáp án:
TOM: Like, I chose a painting of a falcon by Landseer. I like it because the bird’s standing there with his head turned to one side, but he seems to be staring straight at you. But I can’t just say it’s a bit scary, can I?
JESS: You could talk about the possible danger suggested by the bird’s look.
TOM: Oh, ok.

Keyword cần chú ý:
potential threated = suggested danger

Giải thích đáp án:
25 Falcon (Landseer)
JESS cho rằng cái nhìn của chim đại bàng
(Landseer) gợi lên mối nguy hiểm tiềm tàng
-> D. a potential threat','','',25,'Falcon (Landseer) ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:35:19','truongdx18vtit',false,'2026-06-10 19:35:19','truongdx18vtit','B/E','Trích đoạn chứa đáp án:
JESS: Someone told me it’s best not to be too precise about your actual outcome at this stage, so you have more scope to explore your ideas later on. So I’m going to go back to my proposal to make it a bit more vague.
TOM: Really? OK. I’ll change that too then.

Giải thích đáp án:
23-24 In which TWO ways do both JESS and TOM decide to change their proposals?
JESS nói có người khuyên không nên mô tả kết quả quá cụ thể và chính xác ở giai đoạn này để sau có thể phát triển những ý tưởng rộng hơn. Do vậy, JESS sẽ sửa proposal để nó không quá cụ thể và TOM cũng nói mình sẽ làm tương tự.
-> B, by being less specific about the outcome','','',24,'','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:36:51','truongdx18vtit',false,'2026-06-10 19:36:51','truongdx18vtit','G','Trích đoạn chứa đáp án:
TOM: Wow. I chose a portrait of a little boy, Giovanni de Medici. He’s holding a tiny bird in one fist. I like the way he’s holding it carefully so he doesn’t hurt it.

Giải thích đáp án:
30 Portrait of Giovanni de Medici
Chú ý: Nature (n): là toàn bộ động vật, thực vật tồn tại mà không phải do con người tạo ra.
Bức ảnh chân dung của Giovanni de Medici gợi lên cho TOM về hình ảnh một cậu bé cầm một con chim nhỏ trên tay cẩn thận để không làm nó bị thương. (a tiny bird chính là paraphrase của nature).
-> G. protection of nature','','',30,'
Portrait of Giovanni de Medici ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:35:57','truongdx18vtit',false,'2026-06-10 19:35:57','truongdx18vtit','C','Trích đoạn chứa đáp án:
JESS: There’s a picture of a fish hawk by Audubon I like. It’s swooping over the water with a fish in its talons, and with great black wings which take up most of the picture.
TOM: So you could discuss it in relation to predators and food chains?
JESS: Well actually I think I’ll concentrate on the impression of rapid motion it gives

Keyword cần chú ý:
fast movement = rapid motion

Giải thích đáp án:
26 Fish hawk (Audubon)
JESS cho rằng hình ảnh con chim ó gợi lên sự di chuyển nhanh.
-> C. fast movement','','',26,'Fish hawk (Audubon) ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:36:25','truongdx18vtit',false,'2026-06-10 19:36:25','truongdx18vtit','H','Trích đoạn chứa đáp án:
TOM: OK. There’s a portrait called William Wells. I can’t remember the artist but it’s a middle-aged man who’s just shot a bird. And his expression and the way he’s holding the bird in his hand suggests he’s not sure about what he’s done. To me it’s about how ambiguous people are in the way they exploit the natural world.

Keyword cần chú ý:
confused ~ ambiguous

Giải thích đáp án:
28 Portrait of William Wells
Hình ảnh chân dung của William Wells gợi cho TOM về một người đàn ông trung tuổi, người vừa bắn một con chim. Cách ông ta giữ con chim trên tay cho thấy ông ta không chắc chắn về điều mình vừa làm.
-> H. a confused attitude to nature','','',28,'
Portrait of William Wells ➡️','FILL_IN_THE_BLANK',181,NULL),
	 ('2026-06-10 19:40:00','truongdx18vtit',false,'2026-06-10 19:40:00','truongdx18vtit','NEGATIVE','Trích đoạn chứa đáp án:
The modern day philosopher and writer Nassim Nicholas Taleb defines a Stoic as someone who has a different perspective on experiences which most of us would see as wholly negative.

Keyword cần chú ý:
consider = see as

Giải thích đáp án:
34 A Stoic is someone who has a different view on experiences which others would consider as _____.
Người theo chủ nghĩa khắc kỷ có cái nhìn khác với các trải nghiệm mà người khác cho là _____.
Đáp án có thể là một tính từ hoặc một danh từ.
-> negative','','',34,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:43:02','truongdx18vtit',false,'2026-06-10 19:43:02','truongdx18vtit','PRACTICE/PRACTISE','Trích đoạn chứa đáp án:
I would argue that studying Stoicism is as relevant today as it was 2,000 years ago, thanks to its brilliant insights into how to lead a good life. At the very root of the thinking, there is a very simple way of living- control what you can and accept what you can’t. This is not as easy as it sounds and will require considerable practice- it can take a lifetime to master.

Keyword cần chú ý:
a lot of = considerable

Giải thích đáp án:
40 Relevance of Stoicism - It requires a lot of _____ but Stoicism can help people to lead a good life.
Việc nghiên cứu chủ nghĩa khắc kỷ đòi hỏi rất nhiều _____ nhưng chủ nghĩa này có thể giúp mọi người sống một cuộc sống tốt.
Đáp án có thể là một danh từ.
-> practice / practise','','',40,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:40:20','truongdx18vtit',false,'2026-06-10 19:40:20','truongdx18vtit','CAPITALISM','Trích đoạn chứa đáp án:
The economist Adam Smith’s theories on capitalism were significantly influenced by the Stoicism that he studied as a schoolboy, under a teacher who had translated Marcus Aurelius’ works.

Keyword cần chú ý:
ideas ~ theories

Giải thích đáp án:
36 Adam Smith’s ideas on _____ were influenced by Stoicism.
Những ý tưởng của Adam Smith về _____ bị ảnh hưởng bởi chủ nghĩa khắc kỷ.
Đáp án có thể là một danh từ.
-> capitalism','','',36,'','FILL_IN_THE_BLANK',182,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 19:40:09','truongdx18vtit',false,'2026-06-10 19:40:09','truongdx18vtit','PLAY','Trích đoạn chứa đáp án:
George Washington was introduced to Stoicism by his neighbours at age seventeen, and later, put on a play based on the life of Cato to inspire his men.

Keyword cần chú ý:
organise = put on
motivate = inspire

Giải thích đáp án:
35 George Washington organised a _____ about Cato to motivate his men.
Đáp án cần điền là một danh từ, cái mà được George Washington tổ chức để khích lệ đội quân của mình.
-> play','','',35,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:40:29','truongdx18vtit',false,'2026-06-10 19:40:29','truongdx18vtit','DEPRESSION','Trích đoạn chứa đáp án:
Stoicism had a profound influence on Albert Ellis, who invented Cognitive Behaviour Therapy, which is used to help people manage their problems by changing the way that they think and behave. It’s most commonly used to treat depression.

Keyword cần chú ý:
(be a) treatment for = be used to treat

Giải thích đáp án:
37 Cognitive Behaviour Therapy (CBT) - the treatment for _____ is based on ideas from Stoicism
Việc chữa trị cho _____ dựa trên những ý tưởng từ chủ nghĩa khắc kỷ
Đáp án có thể là một danh từ.
-> depression','','',37,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 19:40:55','truongdx18vtit',false,'2026-06-10 19:40:55','truongdx18vtit','OPPORTUNITY','Trích đoạn chứa đáp án:
Stoicism has also become popular in the world of business. Stoic principles can build the resilience and state of mind required to overcome setbacks because Stoics teach turning obstacles into opportunity. A lesson every business entrepreneur needs to learn.

Giải thích đáp án:
39 In business, people benefit from Stoicism by identifying obstacles as _____.
Trong kinh doanh, mọi người hưởng lợi từ chủ nghĩa khắc kỷ bằng việc nhìn nhận các khó khăn như _____.
Đáp án có thể là một danh từ hoặc tính từ.
-> opportunity','','',39,'','FILL_IN_THE_BLANK',182,NULL),
	 ('2026-06-10 20:34:21','truongdx18vtit',false,'2026-06-10 20:34:21','truongdx18vtit','LITTER','Trích đoạn chứa đáp án:
JAN: Could you tell me something about your activities, please?
PETER: Of course. Well, we have a mixture of regular activities and special events. One of the regular ones is trying to keep the beach free of litter.

Giải thích đáp án:
Từ cần điền là một danh từ
--> cần xác định xem ở bãi biển không có vật gì ở đó
Nghe thấy Peter nói rằng ''...trying to keep the beach free of litter''
, tức là cố gắng giữ cho bãi biển không có rác
--> từ cần điền là ''litter''','','',1,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:34:31','truongdx18vtit',false,'2026-06-10 20:34:31','truongdx18vtit','DOGS','Trích đoạn chứa đáp án:
JAN: Is it OK to take dogs?
PETER: I''m afraid not. as they''re banned from the beach itself. You can take them along the cliffs, though. And children are welcome

Giải thích đáp án:
Từ cần điền là một danh từ
--> cần nghe xem ngoài việc đảm bảo không có rác thì còn thứ gì khác nữa cũng không được xuất hiện ở bãi biển
Nghe thấy Jan hỏi rằng ''Is it ok to take dogs?'' (Dắt chó đi cùng thì có được không?) và Peter đáp lại rằng ''I''m afraid not. as they''re banned
from the beach'' (Tôi e là không, vì chúng bị cấm không được vào bãi biển)
-> Như vậy chó không được xuất hiện ở bãi biển
-> đáp án cần điền là ''dogs''','','',2,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:34:41','truongdx18vtit',false,'2026-06-10 20:34:41','truongdx18vtit','INSECTS','Trích đoạn chứa đáp án:
PETER: We''ve just finished making and installing nesting boxes for birds to use, and next we''re going to work on encouraging insects - they''re important for the biodiversity of the reserve

Keyword cần chú ý:
to work on encouraging... ~ taking action to attract...

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem nhiệm vụ là thu hút cái gì đến khu bảo tồn thiên nhiên
Vì trước mục cần điền là ''nesting boxes for birds installed''
-> Khi Peter nói rằng ''We''ve just finished making and
installing nesting boxes for birds to use..'' -> đáp án sắp tới
Sau khi Peter đề cập đến nhiệm vụ lắp đặt hộp làm tổ cho loài chim (..nesting boxes...), ta nghe thấy nhiệm vụ tiếp theo chính là khuyến khích (encouraging) các loài côn trùng tới đây vì chúng đóng vai trò quan trọng cho sự đa dạng sinh học của khu bảo tồn
-> đáp án cần điền là ''insects''','','',3,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:34:51','truongdx18vtit',false,'2026-06-10 20:34:51','truongdx18vtit','BUTTERFLIES','Trích đoạn chứa đáp án:
PETER: Oh, and we''re also running a project to identify the different species of butterflies that visit the reserve.

Keyword cần chú ý:
types ~ species

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem nhiệm vụ tiếp theo ở khu bảo tồn là xác định một loại gì đó
Peter nhắc đến một dự án đang được thực hiện đó là xác định các loài bướm khác nhau - ''..identify different species of butterflies..''. Ở đây người nói đã sử dụng từ ''species'' thay cho từ ''types'' xuất hiện trong câu hỏi
-> đáp án cần điền là ''butterflies''','','',4,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:35:00','truongdx18vtit',false,'2026-06-10 20:35:00','truongdx18vtit','WALL','Trích đoạn chứa đáp án:
PETER: Another job we''re doing at the reserve is replacing the wall on the southern side between the parking area and our woodshed. It was badly damaged in a storm

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem có thứ gì đó mới được xây dựng ở trong khu bảo tồn thiên nhiên
Khi Peter nói ''Another job we''re doing at the reserve...''
-> ta biết đáp án sắp tới
Peter nói rằng một công việc khác mà họ đang tiến hành ở khu bảo tồn đó là thay thế một bức tường cũ và sau đó Peter giải thích rằng do bức tường đã bị hư hỏng nặng nề trong một trận bão (...replacing the wall on the southern side...It was badly damagaed...''
-> như vậy thứ mới được xây dựng ở khu bảo tồn là bức tường - wall
-> đáp án cần điền là ''wall''','','',5,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:35:13','truongdx18vtit',false,'2026-06-10 20:35:13','truongdx18vtit','ISLAND','Trích đoạn chứa đáp án:
PETER: We''ll be meeting in the car park at Dunsmore Beach at low tide - that''s when the sands are dry enough for us to walk to the island without getting wet

Giải thích đáp án:
Từ cần điền là một danh từ. Chú ý đáp án cần điền thuộc phần nội dung về những sự kiện sắp tới vào thứ Bảy
Khi Peter nói rằng ''We''ll be meeting in the car park at Dunsmore Beach..''
-> phần thông tin chứa đáp án sắp xuất hiện
Sau đó ta nghe thấy Peter nói rằng họ sẽ gặp nhau trong bãi đậu xe ở Bãi biển Dunsmore khi thủy triều xuống - đó là thời điểm cát đủ khô để họ có thể đi bộ ra đảo mà không bị ướt
-> Peter cho rằng họ có thể đi bộ qua bãi cát và tới hòn đảo (khi mà cát đã đủ khô vào lúc thủy triều xuống)
-> đáp án cần điền là ''island''','','',6,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:35:24','truongdx18vtit',false,'2026-06-10 20:35:24','truongdx18vtit','BOOTS','Trích đoạn chứa đáp án:
PETER: And of course, it''ll be wet walking across and back, so make sure your boots are waterproof

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem loại trang phục phù hợp nào họ sẽ mặc cho sự kiện vào thứ Bảy
Ta nghe thấy Peter đề cập rằng khi đi qua bãi cát có thể sẽ bị ướt nên những người tham gia cần đảm bảo rằng đôi ủng của họ không thấm nước
-> Như vậy, loại trang phục phù họp mà những người tham gia cần mang trong sự kiện ngày thứ Bảy chính là đôi ủng/đôi giày bốt
-> đáp án cần điền là ''boots''','','',7,'','FILL_IN_THE_BLANK',183,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 20:35:33','truongdx18vtit',false,'2026-06-10 20:35:33','truongdx18vtit','BEGINNERS','Trích đoạn chứa đáp án:
PETER: Great. Then later this month we’re having a one-day woodwork session in Hopton Wood.
JAN: I''ve never tried that before. Is it OK for beginners to take part?
PETER: Definitely

Keyword cần chú ý:
Ok for ~ suitable for
take part = participate

Giải thích đáp án:
Từ cần điền là một danh từ. Đây có thể là danh từ chỉ người bởi theo sau là động từ (participate in: tham gia vào)
-> cần nghe xem buổi làm đồ gỗ - woodwork session sẽ phù hợp cho đối tượng nào tham gia
Vì đáp án cần điền thuộc nội dung về 1 sự kiện mới - buổi làm đồ gỗ
-> Khi Peter nói ''...later this month we’re having a one-day woodwork session...''
-> cần chú ý nghe vì thông tin chứa đáp án sắp tới
Ta nghe thấy JAN đã hỏi rằng liệu những người mới bắt đầu có tham gia buổi làm đồ gỗ được không
-> sau đó PETER đã trả lời “chắc chắn rồi” (definitely).
-> như vậy buổi học làm đồ gỗ phù hợp cho những người mới bắt đầu - ''beginners'' tham gia
-> đáp án là beginners','','',8,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:35:43','truongdx18vtit',false,'2026-06-10 20:35:43','truongdx18vtit','SPOONS','Trích đoạn chứa đáp án:
PETER: You''ll be starting with wooden spoons, and of course learning how to use the tools.

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem trong buổi học, những người tham gia sẽ học làm món đồ gì từ gỗ
Nội dung bài nghe là PETER nói rằng JAN sẽ có thể làm ra những chiếc thìa bằng gỗ.
-> Như vậy, buổi học sẽ hướng dẫn làm những chiếc thìa bằng gỗ
-> đáp án là ''spoons''','','',9,'','FILL_IN_THE_BLANK',183,NULL),
	 ('2026-06-10 20:46:23','truongdx18vtit',false,'2026-06-10 20:46:23','truongdx18vtit','PAPER','Trích đoạn chứa đáp án:
In some hospitals, patients who can’t walk can have a paper ''finger labyrinth’ brought to their bed.

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe thông tin về một loại vật liệu để làm ''finger labyrinths'' - ''mê cung ngón tay''
Nội dung đoạn nghe:
Trong bài nghe có đề cập đến việc các bệnh nhân không thể đi bộ có thể có paper ''finger labyrinth'' được mang tới giường của họ.
-> như vậy ''finger labyrinth'' được làm từ giấy
-> đáp án cần điền là ''paper''','','',39,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:38:06','truongdx18vtit',false,'2026-06-10 20:38:06','truongdx18vtit','A','Trích đoạn chứa đáp án:
This area is famous for its ancient lighthouse, which you''ll see from the boat as we turn past the first little island. It was built in 1838 to protect sailors as a number of shipwrecks had led to significant loss of life. The construction itself was complicated as some of the original drawings kept by the local council show. It sits right on top of the cliffs in a very isolated spot. In the nineteenth century there were many jobs there, such as polishing the brass lamps, chopping firewood and cleaning windows, that kept lighthouse keepers busy. These workers were mainly prison convicts until the middle of that century when ordinary families willing to live in such circumstances took over.

Giải thích đáp án:
Câu hỏi yêu cầu người nghe tìm ra 2 đặc điểm của ''lighthouse'' mà Lou nhắc đến
Khi nghe thấy đoạn ''This area is famous for its ancient lighthouse...''
-> chú ý là đáp án sắp xuất hiện
Đầu tiên, người nghe đề cập đến thời gian xây dựng của lighthouse ''It was built in 1838 to protect sailors as a number of shipwrecks had led to significant loss of life.'' - Nó (lighthouse) được xây dựng vào năm 1838 để bảo vệ các thủy thủ vì một số vụ đắm tàu đã dẫn đến thiệt hại đáng kể về nhân mạng
-> như vậy ta thấy Lou đã đề cập đến lý do vì sao ngọn hải đăng đã được xây dựng (là để bảo vệ các thủy thủ)
-> chọn đáp án là A.','','',15,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:38:17','truongdx18vtit',false,'2026-06-10 20:38:17','truongdx18vtit','D','Trích đoạn chứa đáp án:
This area is famous for its ancient lighthouse, which you''ll see from the boat as we turn past the first little island. It was built in 1838 to protect sailors as a number of shipwrecks had led to significant loss of life. The construction itself was complicated as some of the original drawings kept by the local council show. It sits right on top of the cliffs in a very isolated spot. In the nineteenth century there were many jobs there, such as polishing the brass lamps, chopping firewood and cleaning windows, that kept lighthouse keepers busy. These workers were mainly prison convicts until the middle of that century when ordinary families willing to live in such circumstances took over.

Giải thích đáp án:
Câu hỏi yêu cầu người nghe tìm ra 2 đặc điểm của ''lighthouse'' mà Lou nhắc đến.
Sau khi nghe về lý do xây dựng lighthouse, ta nghe thấy Lou đã đề cập đến local concil (hội đồng địa phương) và bản vẽ ban đầu ''original drawings''
-> có thể suy luận Lou đang đề cập đến người thiết kế bản vẽ (đáp án B)
Tuy nhiên bản vẽ chỉ do hội đồng địa phương lưu trữ ''The construction itself was complicated as some of the original drawings kept by the local council show''
-> loại đáp án B
Tiếp theo Lou cũng đã đề cập đến thế kỷ 19
-> mốc thời gian cho thấy dấu hiệu xuất hiện của đáp án C (nói về thời gian xây dựng). Tuy nhiên phần này chủ yếu nói về những việc làm chứ không nói về thời gian xây dựng lighthouse
-> loại đáp án C
Tiếp theo nữa, Lou cũng đã đề cập các công nhân trong tòa hải đăng đều là những tù nhân ''These workers were mainly prison convicts''
-> như vậy ta thấy Lou đã đề cập đến những đối tượng làm việc ở lighthouse -> khớp với nội dung của đáp án D
-> chọn đáp án D','','',16,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:38:30','truongdx18vtit',false,'2026-06-10 20:38:30','truongdx18vtit','B/C','Trích đoạn chứa đáp án:
I know everyone loves the penguins, but they''re very shy and, unfortunately, tend to hide from passing boats, but you might see birds in the distance, such as sea eagles, flying around the cliff edges where they nest. When we get to the rocky area inhabited by fur seals, we''ll stop and watch them swimming around the coast. They’re inquisitive creatures so don’t be surprised if one pops up right in front of you. Their predators, orca whales, hunt along the coastline too, but spotting one of these is rare. Dolphins, on the other hand, can sometimes approach on their own or in groups as they ride the waves beside us.

Giải thích đáp án:
Câu hỏi yêu cầu người nghe tìm ra hai loài sinh vật mà có thể sẽ tiến lại gần con thuyền
Vì đối tượng của câu hỏi là creatures -> khi người nói nhắc tới ''I know everyone loves the penguins..''
-> chú ý đáp án sắp xuất hiện
Đầu tiên, ta nghe thấy Lou đã nhắc đến chim cánh cụt, nhưng chúng rất nhát và thường trốn các tàu chạy qua
-> loại đáp án E (trái với câu hỏi)
Tiếp theo, Lou cũng nhắc đến đại bàng biển - ''sea eagles'' nhưng loài vật này chỉ bay vòng quanh vách núi nơi chúng làm tổ
-> sea eagles cũng không tới gần con thuyền
-> loại đáp án A
Lou cũng nhắc đến loài hải câu lông - ''fur seals'' và mô tả chúng là một loại vật tò mò, khách du lịch có thể xem chúng bơi và thỉnh thoảng những con vật này sẽ nhảy lên khỏi mặt nước ngay trước mặt du khách
-> như vậy hải cẩu lông - fur seals là loài vật có khả nắng sẽ tới gần chiếc thuyền
-> chọn đáp án B','','',17,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:38:44','truongdx18vtit',false,'2026-06-10 20:38:44','truongdx18vtit','B/C','Trích đoạn chứa đáp án:
I know everyone loves the penguins, but they''re very shy and, unfortunately, tend to hide from passing boats, but you might see birds in the distance, such as sea eagles, flying around the cliff edges where they nest. When we get to the rocky area inhabited by fur seals, we''ll stop and watch them swimming around the coast. They’re inquisitive creatures so don’t be surprised if one pops up right in front of you. Their predators, orca whales, hunt along the coastline too, but spotting one of these is rare. Dolphins, on the other hand, can sometimes approach on their own or in groups as they ride the waves beside us.

Giải thích đáp án:
Câu hỏi yêu cầu người nghe tìm ra hai loài sinh vật mà có thể sẽ tiến lại gần con thuyền
Tiếp nối phần nghe phía trên, ta nghe tiếp thấy Lou đã đề cập đến loài cá voi sát thủ - orca whales nhưng đã đề cập rằng rất hiếm để thấy chúng
-> loài cá voi sát thủ khó có khả năng sẽ đến gần con tàu
-> loại đáp án D. whales.
Cuối ùng là Lou đã đề cập đến dolphins, và cho biết rằng khác với cá voi, có thể thi thoảng tiếp cận được chúng hoặc cả đàn vì chúng thường bơi theo sóng theo sau chúng ta
-> chọn đáp án C.','','',18,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:38:57','truongdx18vtit',false,'2026-06-10 20:38:57','truongdx18vtit','D/E','Trích đoạn chứa đáp án:
Lastly, I want to mention the caves. Tasmania is famous for its caves and the ones we''ll pass by are so amazing that people are lost for words when they see them. They can only be approached by sea, but if you feel that you want to see more than we’re able to show you, then you can take a kayak into the area on another day and one of our staff will give you more information on that. What we’ll do is to go through a narrow channel, past some incredible rock formations and from there we’ll be able to see the openings to the caves, and at that point we’ll talk to you about what lies beyond.

Giải thích đáp án:
Câu hỏi yêu cầu tìm ra 2 luận điểm mà Lou đề cập đến về nhưng hang động
Khi Lou bắt đầu giới thiệu là ''Lastly. I want to mention the caves''
-> khi đó ta biết đáp án sắp xuất hiện
Lou đã đề cập rằng chỉ có đi qua biển mới tới được các hang động đó
-> như vậy hiển nhiên là du khách không thể đi bộ để đến được các hang động
-> chọn đáp án E','','',19,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:39:10','truongdx18vtit',false,'2026-06-10 20:39:10','truongdx18vtit','D/E','Trích đoạn chứa đáp án:
Lastly, I want to mention the caves. Tasmania is famous for its caves and the ones we''ll pass by are so amazing that people are lost for words when they see them. They can only be approached by sea, but if you feel that you want to see more than we’re able to show you, then you can take a kayak into the area on another day and one of our staff will give you more information on that. What we’ll do is to go through a narrow channel, past some incredible rock formations and from there we’ll be able to see the openings to the caves, and at that point we’ll talk to you about what lies beyond.

Giải thích đáp án:
Câu hỏi yêu cầu tìm ra 2 luận điểm mà Lou đề cập đến về nhưng hang động
Tiếp theo, ta nghe thấy ở câu cuối Lou đã đề cập đến việc mọi người sẽ có thể đến các cửa hang và tại điểm đó Lou và các đồng nghiệp sẽ nói về các thứ bên trong hang
-> chọn đáp án D.
Lưu ý:
Không chọn đáp án A. bởi vì mặc dù Lou đã đề cập mọi người có thể đi tới cái hang bằng các tàu kayak (nhỏ) nhưng câu A. lại là các tàu lớn.
Không chọn đáp án B và C vì Lou đã không đề cập đến các thông tin trong 2 đáp án đó.','','',20,'','FILL_IN_THE_BLANK',184,NULL),
	 ('2026-06-10 20:39:53','truongdx18vtit',false,'2026-06-10 20:39:53','truongdx18vtit','A','Trích đoạn chứa đáp án:
TIM: My farm was great, but arranging the work experience was hard. One problem was it was miles away and I don''t drive. And also, I really wanted a placement for a month, but I could only get one for two weeks.
DIANA: I was lucky. The farmer let me stay on the farm so I didn''t have to travel. But finding the right sort of farm to apply to wasn''t easy.

Giải thích đáp án:
Nội dụng câu hỏi:
Cả Diana và Tim đều gặp phải vấn đề gì khi sắp xếp kinh nghiệm làm việc của họ?
Nội dung đoạn nghe:
Ở phần này vì câu hỏi liên quan đến vấn đề sắp xếp kinh nghiệm làm việc
-> khi nghe thấy Tim nói rằng ''but arranging the work experience was hard.'' - ''..nhưng việc sắp xếp kinh nghiệm làm việc thật khó''
-> thông tin chứa đáp án sắp xuất hiện
Sau khi Tim kể về khó khăn của mình trong việc sắp xếp kinh nghiệm làm việc, Diana cũng trả lời rằng cho rằng việc tìm một nông trại phù hợp để nộp đơn xin việc rất khó khăn và Tim cũng đã đồng ý như thế.
-> chọn đáp án A.
Lưu ý:
Mặc dù thông tin trong đáp án B và C có xuất hiện nhưng đó chỉ là vấn đề của mỗi Tim -> loại','','["A. making initial contact with suitable farms","B. organising transport to and from the farm","C. finding a placement for the required length of time"]',21,'What problem did both Diana and Tim have when arranging their work experience?','MULTIPLE_CHOICE',185,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 20:40:23','truongdx18vtit',false,'2026-06-10 20:40:23','truongdx18vtit','B','Trích đoạn chứa đáp án:
TIM: My farm was mostly livestock, especially sheep., really enjoyed helping out with them. I was up most of one night helping a sheep deliver a lamb ..
DIANA: On your own?
TIM: No. The farmer was there… and he told me what to do. It wasn''t a straightforward birth, but I managed. It was a great feeling to see the lamb stagger to its feet and start feeding almost straight away, and to know that it was OK.

Giải thích đáp án:
Nội dung câu hỏi:
Tim rất vui được giúp đỡ....
-> cần nghe xem công việc nào mà Tim muốn giúp đỡ
Nội dung đoạn nghe:
Tim cho rằng anh ấy thích thú giúp những con cừu và đã kể rằng anh ấy từng giúp một con cừu gặp khó khăn khi sinh con
-> chọn đáp án B. một con cừu gặp khó khăn trong việc sinh nở','','["A. a lamb that had a broken leg.","B. a sheep that was having difficulty giving birth.","C. a newly born lamb that was having trouble feeding."]',22,'Tim was pleased to be able to help','MULTIPLE_CHOICE',185,NULL),
	 ('2026-06-10 20:40:51','truongdx18vtit',false,'2026-06-10 20:40:51','truongdx18vtit','B','Trích đoạn chứa đáp án:
DIANA: Yes. my farm had sheep too. I he farm was in a vallev and thev had a lowland breed called Suffolks, although the farmer said thevd had other breeds in the past.
TIM: So were they bred for their meat?
DIANA: Mostly, yes.

Keyword cần chú ý:
bred = reared
mostly = mainly

Giải thích đáp án:
Nội dung câu hỏi:
Diana nói những con cừu trong trang trại của cô ấy...
-> cần chú ý tập trung vào phần nói của Diana
Nội dung đoạn nghe:
Khi Diana nói rằng trang trại của cô ấy cũng có cừu
-> chú ý đoạn nghe chứa đáp án sắp xuất hiện
Sau đó ta nghe thấy Tim hỏi Diana rằng các con cừu ở nông trại cô ấy làm thường được nuôi để lấy thịt phải không.
-> Diana trả lời là có, hầu hết
-> đáp án là B. chủ yếu được nuôi để lấy thịt','','["A. were of various different varieties.","B. were mainly reared for their meat.","C. had better quality wool than sheep on the hills."]',23,'Diana says the sheep on her farm','MULTIPLE_CHOICE',185,NULL),
	 ('2026-06-10 20:41:22','truongdx18vtit',false,'2026-06-10 20:41:22','truongdx18vtit','A','Trích đoạn chứa đáp án:
TIM: I was interested in the amount of supplements they add to animals'' feed nowadays. Like, even the chickens dot extra vitamins and electrolytes in their feed.
DIANA: Yes. I found that too. And they''re not cheap. But my farmer said some are overpriced for what they are.

Keyword cần chú ý:
particularly = specially

Giải thích đáp án:
Nội dung câu hỏi:
Học sinh đã học được gì về việc bổ sung chất bổ sung vào thức ăn cho gà?
Nội dung đoạn nghe:
Khi Tim nhắc đến ''supplements they add to animals'' feed...''
-> đáp án sắp xuất hiện
Diana đã nói rằng người nông dân không cho gà ăn những chất bố sung đó mỗi ngày (as a matter of routine), chỉ cho chúng ăn khi chúng có vẻ như đặc biệt cần
-> Tim đã đồng ý như thế vì người nông dân ở chỗ anh ấy cũng nói như thế.
-> chọn đáp án A. Những thứ này chỉ nên được cung cấp nếu đặc biệt cần thiết.','','["A. These should only be given if specially needed.","B. It is worth paying extra for the most effective ones.","C. The amount given at one time should be limited."]',24,'What did the students learn about adding supplements to chicken feed?','MULTIPLE_CHOICE',185,NULL),
	 ('2026-06-10 20:45:58','truongdx18vtit',false,'2026-06-10 20:45:58','truongdx18vtit','TREE','Trích đoạn chứa đáp án:
Eleven examples of turf labyrinths survive today, including the largest one at Saffron Walden, England, which used to have a large tree in the middle of it.

Keyword cần chú ý:
big = large
centre = middle
once had = used to have

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem có thứ gì đó to ở chính giữa ''turf labyrinths''
Nội dung đoạn nghe:
Khi người nói nhắc đến ''eleven examples of turf labyrinths....''
-> đáp án sắp xuất hiện
Trong bài nghe có đề cập đến 11 ví dụ của ''turf labyrinths'' còn xót lại đến ngày nay, bao gồm một nơi ở Anh, nơi mà từng có một cái cây lớn ở giữa. -> từ cần điền là ''tree''','','',37,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:42:04','truongdx18vtit',false,'2026-06-10 20:42:04','truongdx18vtit','C','Trích đoạn chứa đáp án:
DIANA: I made a really embarrassing mistake when | was working in the milk shed. Some cows had been treated with antibiotics, so their milk wasn''t suitable for human consumption, and it had to be put in a separate container. But I got mixed up, and I poured some milk from the wrong cow in with the milk for humans, so the whole lot had to be thrown away. The farmer wasn''t too happy with me.

Giải thích đáp án:
Nội dung câu hỏi:
Điều gì đã xảy ra khi Diana đang làm việc với những con bò sữa?
Nội dung đoạn nghe:
Khi nghe thấy Diana nói rằng cô ấy đã mác 1 sai lầm đáng xấu hổ khi almf việc trong nhà kho sữa - ''....I made a really embarrassing mistake when I was working in the milk shed''
-> đoạn nghe chứa thông tin sắp xuất hiện
DIANA đã mô tả rằng một số con bò được chữa trị bằng kháng sinh cho nên sữa của chúng không phù hợp cho người tiêu dùng và cần phải để riêng ra. Tuy nhiên cô ấy đã nhầm lẫn khi đổ sửa của một số con bò (loại sữa này là loại không phù hợp để tiêu thụ) vào sữa cho người.
-> ta thấy thông tin này nằm trong đáp án C. Cô ấy đã mắc sai lầm trong chu trình bảo quản sữa
-> chọn đáp án C
Lưu ý:
Không chọn đáp án B vì sửa bị bỏ đi là vì chúng bị trộn giữa 2 loại sữa, điều này là bắt buộc chứ không phải do Diana vô ý.
Cũng không chọn đáp án C vì thông tin trong đáp án không xuất hiện ở bài nghe','','["A. She identified some cows incorrectly.","B. She accidentally threw some milk away.","C. She made a mistake when storing milk."]',25,'What happened when Diana was working with dairy cows?','MULTIPLE_CHOICE',185,NULL),
	 ('2026-06-10 20:42:29','truongdx18vtit',false,'2026-06-10 20:42:29','truongdx18vtit','C','Trích đoạn chứa đáp án:
TIM: I asked my farmer now much he depended on the vet to deal with health problems. I’d read reports that the livestocks health is affected as farmers are under pressure to increase production. Well. he didn''t agree with that. But he said that actually some of the stuff the vets do, like minor operations, he''d be quite capable of doing himself.
DIANA: Yeah. My farmer said the same. But he reckons vets'' skills are still needed.

Giải thích đáp án:
Nội dung câu hỏi:
Cả hai người nông dân đã đề cập đến điều gì về thú y và nông nghiệp?
Nội dung đoạn nghe
Ta nghe thấy Tim đã thuật lại việc khi anh ấy hỏi người nông dân và người nông dân bên trang trại của anh ấy đã nói rằng một số những công việc của bác sĩ thú y như các cuộc phẫu thuật nhỏ thì người nông dân ở trang trại của TIM có thể tự làm được
-> sau đó Diana cũng đồng tình với Tim ''Yeah. My farmer said the same''
-> thông tin này có thể thấy ở đáp án C. Một số công việc có thể do nông dân làm thay vì bác sĩ thú y
DIANA cũng đã đồng tình như thế và cho rằng người
nông dân của DIANA cũng có thể tự làm được
-> đáp an C','','["A. Vets are failing to cope with some aspects of animal health.","B. There needs to be a fundamental change in the training of vets.","C. Some jobs could be done by the farmer rather than by a vet."]',26,'What did both farmers mention about vets and farming?','MULTIPLE_CHOICE',185,NULL),
	 ('2026-06-10 20:42:52','truongdx18vtit',false,'2026-06-10 20:42:52','truongdx18vtit','A','Trích đoạn chứa đáp án:
TIM: OK. So medical terminology.
DIANA: Well, my heart sank when I saw that, especially right at the beginning of the course. And I did struggle with it
TIM: I''d thought it''d be hard, but actually I found it all quite straightforward

Keyword cần chú ý:
straightforward ~ easier

Giải thích đáp án:
Câu hỏi từ 27-30 yeu cầu người nghe chọn quan điểm của 2 sinh viên (Diana và Tim) về các chương trình học của khóa học về thú y của họ
Nội dung đoạn nghe
Đầu tiên ta nghe thấy tên của chương trình học đầu tiên ''medical terminology''
Khi đề cập đến “medical terminology” thì Tim đã cho rằng anh ấy tưởng nó khó nhưng hóa ra nó khá dễ
-> Như vậy ''medical terminology'' dễ hơn Tim đã tưởng tượng
-> chọn đáp án A. Tim thấy môn này dễ dàng hơn mong đợi.','','',27,'Medical terminology','FILL_IN_THE_BLANK',185,NULL),
	 ('2026-06-10 20:43:36','truongdx18vtit',false,'2026-06-10 20:43:36','truongdx18vtit','E','Trích đoạn chứa đáp án:
TIM: What did you think about diet and nutrition?
DIANA: OK. I suppose
TIM: Do you remember what they told us about pet food and the fact that there''s such limited checking into whether or not it''s contaminated? I mean in comparison with the checks on food for humans - I thought that was terrible.

Giải thích đáp án:
Câu hỏi từ 27-30 yeu cầu người nghe chọn quan điểm của 2 sinh viên (Diana và Tim) về các chương trình học của khóa học về thú y của họ
Nội dung đoạn nghe:
Tiếp theo ta nghe thấy Tim hỏi Diana về ''diet and nutrition
-> đây là chương trình học tiếp theo
Diana thì cho rằng môn này Ok còn Tim thấy rất tệ khi được biết về khâu kiểm tra vệ sinh thực phẩm của thức ăn cho vật nuôi
-> đáp án là E. Tim đã bị sốc với điều gì đó anh ấy học được trong chương trình học này.','','',28,'Diet and nutrition','FILL_IN_THE_BLANK',185,NULL),
	 ('2026-06-10 20:45:27','truongdx18vtit',false,'2026-06-10 20:45:27','truongdx18vtit','COINS','Trích đoạn chứa đáp án:
In Ancient Greece, the labyrinth spiral was used on coins around four thousand years ago.

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem những người Hy Lạp cổ đại đã sử dụng biểu tượng ở trên vật gì/thứ gì
Nội dung đoạn nghe:
Ta nghe thấy người nói có đề cập đến các mê cung xoắn ốc đã được dùng
trên các đồng xu vào thời Hy Lạp cổ đại - ''In Ancient Greece, the labyrinth spiral was used on coins''
-> như vậy người Hy Lạp cổ đại đã sử dụng biểu tượng ở trên những đồng xu
-> đáp án cần điền là ''coins''','','',36,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:46:12','truongdx18vtit',false,'2026-06-10 20:46:12','truongdx18vtit','BREATHING','Trích đoạn chứa đáp án:
More recently labyrinths have experienced something of a revival. Some believe that walking a labyrinth promotes healing and mindfulness, and there are those who believe in its emotional and physical benefits, which include slower breathing and a restored sense of balance and perspective.

Keyword cần chú ý:
reduce...rate = slower
walking a labyrinths = walking a maze

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe thông tin có liên quan tới tỷ lệ gì đó của 1 người có thể giảm xuống nếu đi bộ trong mê cung
Nội dung đoạn nghe:
Trong bài nghe có đề cập đến việc đi bộ trong mê cung có thể giảm nhịp thở (breathing)
-> từ cần điền là breathing','','',38,'','FILL_IN_THE_BLANK',186,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 20:43:51','truongdx18vtit',false,'2026-06-10 20:43:51','truongdx18vtit','F','Trích đoạn chứa đáp án:
DIANA: Mm. think the module that really impressed me was the animal disease one. when we looked at domesticated animals in different parts of the world, like camels and water buffalo and alpaca, the economies of so many countries depend on these, but scientists don''t know much about the diseases that affect them.
TIM: Yes, I thought they''d know a lot about was of controlling and eradicating those diseases, but that''s not the case at all.

Keyword cần chú ý:
how little is known about some aspects of this ~ scientists don’t know much about the diseases”.

Giải thích đáp án:
Câu hỏi từ 27-30 yeu cầu người nghe chọn quan điểm của 2 sinh viên (Diana và Tim) về các chương trình học của khóa học về thú y của họ
Nội dung đoạn nghe:
Tiếp theo, ta nghe thấy Diana nói tời ''animal disease''
-> tên chương trình học tiếp theo
Trong bài nghe DIANA có nói rằng động vật đã được thuần hóa ở các khu vực khác nhau trên thế giới, như lạc đà, trâu nước và alpaca, nền kinh tế của rất nhiều quốc gia phụ thuộc vào loài động vật này, nhưng
các nhà khoa học lại không biết nhiều về những căn bệnh của những loài vật này có thể ảnh hưởng đến các quốc gia đó
-> TIM đã cho rằng anh ấy tưởng rằng họ biết nhiều về các cách đề kiểm soát và diệt trừ các bệnh dịch nhưng thực tế không như thế.
-> chọn đáp án F. Cả hai đều ngạc nhiên về việc người ta biết rất ít về một số khía cạnh của điều này','','',29,'Animal disease','FILL_IN_THE_BLANK',185,NULL),
	 ('2026-06-10 20:44:07','truongdx18vtit',false,'2026-06-10 20:44:07','truongdx18vtit','C','Trích đoạn chứa đáp án:
TIM: I loved the wildlife medication unit. Things like helping birds that have been caught in oil spills. That''s something I hadn''t thought about before.
DIANA: Yeah. I thought I might write my dissertation on something connected with that.
TIM: Right. So.

Giải thích đáp án:
Câu hỏi từ 27-30 yeu cầu người nghe chọn quan điểm của 2 sinh viên (Diana và Tim) về các chương trình học của khóa học về thú y của họ
Nội dung đoạn nghe:
Cuối cùng ta nghe thấy Tim nói đến ''wildlife medication''
-> đây là tên môn cuối
Khi đề cập đến “Wild life medication”, Tim nói rằng anh ấy thích môn này và những việc như giúp đỡ những chú chim bị dính dầu là điều mà anh ấy đã không nghĩ đến trước đây là mình sẽ làm.
-> Sau đó Diana đã cho rằng cô ấy nghĩ cô ấy sẽ viết luận văn về một số thứ liên quan đến chủ đề này.
-> Như vậy có thể suy luận rằng khi viết luận chắc hẳn Diana sẽ phải nghiên cứu thêm về chủ đề này,
-> chọn đáp án C. Diana có thể nghiên cứu thêm về điều này.','','',30,'Wildlife medication','FILL_IN_THE_BLANK',185,NULL),
	 ('2026-06-10 20:44:27','truongdx18vtit',false,'2026-06-10 20:44:27','truongdx18vtit','PUZZLE','Trích đoạn chứa đáp án:
A maze is quite different as it is a kind of puzzle with an intricate network of paths.

Keyword cần chú ý:
kind of = type of

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem mazes - các mê cùng là 1 loại của cái gì
Nội dung đoạn nghe:
Khi người nghe nhắc đến ''A maze is quite different..''
-> đáp án sắp xuất hiện
Trong bài nghe có đề cập đến một mê cung là một dạng câu đố với một mạng lưới đường đi phức tạp.
-> từ cần điền là ''puzzle''','','',31,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:44:38','truongdx18vtit',false,'2026-06-10 20:44:38','truongdx18vtit','LOGIC','Trích đoạn chứa đáp án:
Entering a maze usually involves getting lost a few times before using logic to work out the pattern and find your way to the centre and then out again.

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem thứ gì là cần thiết để có thể định hướng và đi qua mê cung
Nội dung đoạn nghe:
Trong bài nghe có đề cập đến việc bước vào một mê cung thường người tham gia sẽ bị lạc trước khi sử dụng tư duy “logic” để xác định được các mô hình và tìm đường đi đến trung tâm của mê cùng và thoát ra ngoài.
-> như vậy cần phải có tư duy logic để có thể định hướng đường đi trong mê cung
-> từ cần điền là ''logic''','','',32,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:44:50','truongdx18vtit',false,'2026-06-10 20:44:50','truongdx18vtit','CONFUSION','Trích đoạn chứa đáp án:
The word ‘maze’ is believed to come from a Scandinavian word for a state of confusion. This is where the word ‘amazing’ comes from.

Keyword cần chú ý:
come from = is derived from
a feeling of = a state of

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe về nguồn gốc của từ ''maze'' và từ đó bắt nguồn từ một từ mang nghĩa cảm giác của cái gì
Nội dung đoạn nghe:
Trong bài nghe, người nói giới thiệu rằng từ ''maze'' - mê cung được cho là bắt nguồn từ một từ Scandinavia để biểu hiện trạng thái hoang mang - ''a state of confusion''
-> đáp án cần điền là ''confusion''','','',33,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:45:00','truongdx18vtit',false,'2026-06-10 20:45:00','truongdx18vtit','MEDITATION','Trích đoạn chứa đáp án:
Labyrinths are thought to encourage a feeling of calm and have been used as a meditation and prayer tool in many cultures over many centuries.

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem ''labyrinths'' - mê cung được sử dụng trong việc gì/sự kiện nào bên cạnh việc cầu nguyện
Nội dung đoạn nghe:
Trong bài nghe có đề cập đến việc các mê cung mang lại cảm giác yên tĩnh và được sử dụng như 1 công cụ để thiền và cầu nguyện trong nhiều nền văn hóa
-> như vậy ngoài việc cầu nguyện thì mê cung còn được sử dụng cho mục đích thiền - meditation
-> đáp án cần điền là meditation''','','',34,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:45:15','truongdx18vtit',false,'2026-06-10 20:45:15','truongdx18vtit','STONE','Trích đoạn chứa đáp án:
The earliest examples of the labyrinth spiral pattern have been found carved into stone, from Sardinia to Scandinavia, from Arizona to India to Africa. In Europe, these spiral carvings date from the late Bronze Age.

Keyword cần chú ý:
..carvings date from the late Bronze Age ~ ancient carvings

Giải thích đáp án:
Từ cần điền là một danh từ
-> cần nghe xem một vật gì được chạm khắc lên vào thời kỳ cổ đại mà được tìm thấy qua các nên văn hóa
Nội dung đoạn nghe:
Vì câu hỏi nằm trong phần nội dung về những ví dụ về những mô hình mê cuung xoắn ốc
-> khi người nói dẫn vào ''The earliest examples of the labyrinth..''
-> chú ý đáp án sắp xuất hiện
Trong bài nghe có đề cập đến các ví dụ sớm nhất của những mô hình mê cung xoắn ốc đã được khắc lên đá từ các nơi khác nhau từ thời kỳ đồ đá. Trong đoạn này từ “carvings” - danh từ ở câu hỏi đã được diễn đạt lại bằng động từ carved trong đoạn nghe.
-> từ cần điền là stone','','',35,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:46:37','truongdx18vtit',false,'2026-06-10 20:46:37','truongdx18vtit','ANXIETY','Trích đoạn chứa đáp án:
For example, one study found that walking a labyrinth provided ‘short-term calming, relaxation, and relief from anxiety’ for Alzheimer’s patients. So, what is it about labyrinths that makes their appeal so universal? Well ...

Keyword cần chú ý:
Alzheimer’s sufferers = Alzheimer''s patients

Giải thích đáp án:
Từ cần điền là một danh từ (vì đứng sau động từ ''experience''
-> cần nghe xem những người mắc hội chứng Alzheimer chịu đựng cái gì ít hơn
Nội dung đoạn nghe:
Trong bài nghe có đề cập rằng việc đi bộ trong mê cung có thể mang lại sự bình tĩnh, thư giãn và giảm sự lo lắng cho các bệnh nhân Alzheimer.
-> những người mắc hội chứng Alzheimer chịu đựng sự lo lắng ít hơn
-> từ cần điền là ''anxiety''','','',40,'','FILL_IN_THE_BLANK',186,NULL),
	 ('2026-06-10 20:59:51','truongdx18vtit',false,'2026-06-10 20:59:51','truongdx18vtit','DW30( )7YZ','Trích đoạn chứa đáp án:

So next your postcode, please. It''s DW30 7YZ.

Keyword cần chú ý:

postcode

Giải thích đáp án:

Từ cần điền vào chỗ trống là một chuỗi ký tự cả số lẫn chữ (mã bưu điện), từ postcode cần được lưu ý vì khi nghe thấy từ này là đoạn băng chuẩn bị đọc chuỗi ký tự ra.','','',1,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:00:03','truongdx18vtit',false,'2026-06-10 21:00:03','truongdx18vtit','24(TH) APRIL [OR] APRIL 24(TH)','Trích đoạn chứa đáp án:

Right, so now I want to ask you some questions about how you travelled here today. Did you use public transport? Yes. I came by bus. OK. And that was today. It’s the 24th of April, isn’t it? Isn''t it the 25th? No, actually, you’re right.

Keyword cần chú ý:

Date of bus journey

Giải thích đáp án:

Từ cần điền vào chỗ trống là một ngày. Đề bài hỏi thời gian của chuyến xe bus mà Sadie đã đi. Từ khóa ở đây là date (ngày). Đoạn băng cũng có sự đánh lừa khi đưa ra 2 trường thông tin về ngày đầu tiên là ngày 24th April nhưng sau đó Sadie tưởng rằng là ngày 25th April nhưng lại tự nhận ra là mình nhầm nên đáp án vẫn là ngày 24th April.','','',2,'','FILL_IN_THE_BLANK',187,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:00:14','truongdx18vtit',false,'2026-06-10 21:00:14','truongdx18vtit','DENTIST','Trích đoạn chứa đáp án:

Ha ha. And what was the reason for your trip today? I can see you’ve got some shopping with you. Yes. I did some shopping but the main reason I came here was to go to the dentist.

Keyword cần chú ý:

reason

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau mạo từ ''the''. Từ cần chú ý ở đây là reason (lý do) Sadie đến địa điểm này. Người khảo sát hỏi lý do Sadie đến đây và nhận thấy cô có một chút đồ mua sắm theo người. Đoạn băng đưa ra thông tin đầu tiên là Sadie đã đi mua sắm nhưng Sadie bảo rằng lý do chính khiến cô đến đây là để gặp nha sĩ.','','',3,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:00:24','truongdx18vtit',false,'2026-06-10 21:00:24','truongdx18vtit','PARKING','Trích đoạn chứa đáp án:

Good. Do you normally travel by bus into the city centre? Yes. I stopped driving in ages ago because parking was so difficult to find and it costs so much.

Keyword cần chú ý:

bus, because cost of

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau giới từ ''of''. Từ cần chú ý ở đây là cost (chi phí). Người khảo sát hỏi Sadie liệu cô ấy có thường xuyên sử dụng xe bus để di chuyển vào thành phố không. Sadie trả lời có và giải thích rằng cô lựa chọn xe bus vì việc tìm được chỗ đỗ xe ô tô quá khó và chi phí đỗ xe thì cũng cao.','','',4,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:00:35','truongdx18vtit',false,'2026-06-10 21:00:35','truongdx18vtit','CLAXBY','Trích đoạn chứa đáp án:

That''s good. So where did you start your journey? At the bus stop on Claxby Street. Is that C-L-A-X-B-Y? That’s right.

Keyword cần chú ý:

start your journey = Got on bus, Street

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ riêng. Từ cần chú ý là got on bus, cùng nghĩa với nơi cô ấy bắt đầu đi. Người khảo sát hỏi Sadie về nơi cô ấy bắt xe bus. Sadie trả lời về tên đường nơi cô ấy bắt xe buýt và đánh vần tên đường đó.','','',5,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:00:48','truongdx18vtit',false,'2026-06-10 21:00:48','truongdx18vtit','LATE','Trích đoạn chứa đáp án:

And how satisfied with the service are you? Do you have any complaints? Well, as I said, it’s very convenient and quick when it’s on time, but this morning it was late. Only about 10 minutes, but still.

Keyword cần chú ý:

complaints

Giải thích đáp án:

Từ cần điền vào chỗ trống là một tính từ do đứng sau to be ''was''. Người khảo sát hỏi Sadie xem cô ấy có phàn nàn gì về dịch vụ không. Sadie nói rằng xe bus rất tiện và nhanh khi nó tới đúng giờ nhưng chuyến sáng nay của cô ấy bị muộn.','','',6,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:00:59','truongdx18vtit',false,'2026-06-10 21:00:59','truongdx18vtit','EVENING','Trích đoạn chứa đáp án:

Yes, I understand that’s annoying. And what about the timetable? Do you have any comments about that? Mmm. I suppose I mainly use the bus during the day, but any time I’ve been in town in the evening —for dinner or at the cinema —I’ve noticed you have to wait a long time for a bus — there aren’t that many.

Keyword cần chú ý:

frequency = timetable

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau mạo từ ''the''. Từ cần chú ý là frequency bị paraphrase trong đoạn băng thành timetable. Sadie trả lời với người khảo sát rằng cô chủ yếu sử dụng xe bus vào ban ngày nhưng những lần nào cô vào thành phố buổi tối (để đi xem phim hoặc ăn tối) thì cô phải đợi rất lâu mới có một chuyến xe bus.','','',7,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:14:02','truongdx18vtit',false,'2026-06-10 21:14:02','truongdx18vtit','EMPLOYMENT','Employment prospects have improved enormously, contributing to rising living standards for the whole community.

Keyword cần chú ý:

opportunities = prospects

Giải thích đáp án:

Từ cần điền vào chỗ trống là danh từ hoặc tính từ. Do cơ hội việc làm tăng lên đáng kể, giúp nâng cao mức sống của toàn bộ cộng đồng dân cư nên nạn săn voi cũng giảm đi. Ở đây từ điền vào chỗ trống là danh từ employment.','','',38,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:27:01','truongdx18vtit',false,'2026-06-10 21:27:01','truongdx18vtit','CHOOSE','Trích đoạn chứa đáp án:
Official: They focus on seasonal products, and as well as teaching you how to cook them, they also show you how to choose (Q1) them.
Lớp này tập trung vào các nguyên liệu theo mùa, ngoài ra rọ còn dạy bạn cách nấu chúng, cũng như cách lựa chọn các nguyên liệu.

Giải thích đáp án:
How to (1) ……….. and cook with seasonal products
Cách (1) ……… .. và nấu ăn với các đồ có theo mùa.
→ Chỗ trống cần điền là 1 verb nguyên thể
-> choose','','',1,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:01:15','truongdx18vtit',false,'2026-06-10 21:01:15','truongdx18vtit','SUPERMARKET','Trích đoạn chứa đáp án:

OK, thanks. So now I’d like to ask you about your car use. Well, I have got a car but I don’t use it that often. Mainly just to go to the supermarket. But that’s about it really. My husband uses it at the weekends to go to the golf club.

Keyword cần chú ý:

car

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau mạo từ ''the''. Người khảo sát hỏi về việc sử dụng xe ô tô cá nhân của Sadie. Sadie có trả lời rằng cô có ô tô song không sử dụng mấy, chủ yếu chỉ là để đi siêu thị. Ngoài ra, đoạn băng cũng đưa ra thông tin thừa, gây nhiễu như việc chồng cô ấy cũng sử dụng ô tô để đi tới CLB golf vào cuối tuần.','','',8,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:01:31','truongdx18vtit',false,'2026-06-10 21:01:31','truongdx18vtit','POLLUTION','Trích đoạn chứa đáp án:

What about the city bikes you can rent? Do you ever use those? No — I’m not keen on cycling there because of all the pollution. But I would like to get a bike — it would be good to use it to get to work.

Keyword cần chú ý:

Dislikes travelling by bike = not keen on cycling, because of

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau mạo từ ''the''. Từ cần chú ý ở đây là lý do tại sao Sadie lại dislikes travelling by bike đã bị paraphrase thành not keen on cycling trong đoạn băng. Sadie không thích đạp xe trong thành phố vì môi trường ô nhiễm.','','',9,'','FILL_IN_THE_BLANK',187,NULL),
	 ('2026-06-10 21:01:43','truongdx18vtit',false,'2026-06-10 21:01:43','truongdx18vtit','STORAGE','Trích đoạn chứa đáp án:

So why haven’t you got one now? Well, I live in a flat — on the second floor and it doesn’t have any storage — so we''d have to leave it in the hall outside the flat.

Keyword cần chú ý:

Doesn’t own a bike = haven’t you got one, a lack of

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau giới từ ''of'' trong cụm ''a lack of''. Người khảo sát hỏi tại sao Sadie nói rằng mình thích có một chiếc xe đạp nhưng lại không mua một chiếc. Sadie trả lời do cô đang sống trong một căn hộ ở tầng hai và nó không có chỗ để để một chiếc xe đạp vì thế nếu mua thì phải để xe đạp ngoài hành lang.','','',10,'','FILL_IN_THE_BLANK',187,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:02:29','truongdx18vtit',false,'2026-06-10 21:02:29','truongdx18vtit','C','Trích đoạn chứa đáp án:

By the way, I hope you''re all comfortable — we have brought in extra seats so that no one has to stand, but it does mean that the people at the back of the room may be a bit squashed. We''ll only be here for about half an hour so, hopefully, that’s OK.

Keyword cần chú ý:

apologise, the seats, extra seats, close together = squashed

Giải thích đáp án:

Đề bài hỏi rằng tại sao người nói lại xin lỗi về chỗ ngồi. Từ đoạn băng ta sẽ nghe được việc họ phải xếp thêm chỗ ngồi để không ai phải đứng nhưng điều đó đồng người với việc những người cuối phòng phải ngồi sát với nhau. Ý này đồng nghĩa với đáp án C','','["A. They are too small.","B. There are not enough of them.","C. Some of them are very close together."]',11,'Why does the speaker apologise about the seats?','MULTIPLE_CHOICE',188,NULL),
	 ('2026-06-10 21:02:58','truongdx18vtit',false,'2026-06-10 21:02:58','truongdx18vtit','A','Trích đoạn chứa đáp án:

One of the first questions we’re often asked is how old you need to be to volunteer. Well, you can be as young as 16 or you can be 60 or over; it all depends on what type of voluntary work you want to do. Other considerations, such as reliability, are crucial in voluntary work and age isn’t related to these, in our experience.

Keyword cần chú ý:

age = how old, volunteers, is less important than = isn''t related

Giải thích đáp án:

Đề bài hỏi rằng người nói đã nói gì về tuổi của các tình nguyện viên. Từ đoạn băng ta sẽ nghe thấy từ tuổi (age) đã được paraphrase thành how old và cụm as young as 16 or you can be 60 or over. Bên cạnh đó, từ reliability cũng xuất hiện nhưng đây là một phẩm chất mà nhà tuyển dụng đang tìm kiếm và họ cũng nói rằng phẩm chất này, theo kinh nghiệm của họ, thường không liên quan đến tuối. Vì vậy, đáp án A là đáp án đúng.','','["A. The age of volunteers is less important than other factors.","B. Young volunteers are less reliable than older ones.","C. Most volunteers are about 60 years old."]',12,'What does the speaker say about the age of volunteers?','MULTIPLE_CHOICE',188,NULL),
	 ('2026-06-10 21:03:48','truongdx18vtit',false,'2026-06-10 21:03:48','truongdx18vtit','A','Trích đoạn chứa đáp án:

Another question we get asked relates to training. Well, there’s plenty of that and it’s all face-to-face. What’s more, training doesn’t end when you start working for us — it takes place before, during and after periods of work. Often, it’s run by other experienced volunteers as managers tend to prefer to get on with other things.

Keyword cần chú ý:

training, continuous = doesn''t end

Giải thích đáp án:

Đề bài hỏi người nói đã nói gì về việc huấn luyện. Từ đoạn băng ta thấy người nói đã đề cập rằng việc huấn luyện không kết thúc khi tình nguyện viên bắt đầu làm việc mà nó diễn ra trước khi làm việc, trong khi làm việc và sau quá trình làm việc. Vì vậy, việc huấn luyện ở đây diễn ra liên tục nên đáp án A là đúng.','','["A. It is continuous.","B. It is conducted by a manager.","C. It takes place online."]',13,'What does the speaker say about training?','MULTIPLE_CHOICE',188,NULL),
	 ('2026-06-10 21:04:07','truongdx18vtit',false,'2026-06-10 21:04:07','truongdx18vtit','B/E','Trích đoạn chứa đáp án:

But it is critical that you have enough hours in the day for whatever role we agree is suitable for you — if being a volunteer becomes stressful then it’s best not to do it at all. You may think that your income is important, but we don’t ask about that. It’s up to you to decide if you can work without earning money. What we value is dedication. Some of our most loyal volunteers earn very little themselves but still give their full energy to the work they do with us.

Keyword cần chú ý:

TWO issues, consider before, apply, availability = have enough hours, commitment = dedication

Giải thích đáp án:

Đâu là hai yếu tố cần thiết phải có khi apply vào vị trí tình nguyện viên. Từ đoạn băng ta sẽ nghe được điều quan trọng đầu tiên là phải có đủ thời gian làm việc trong ngày, điều này tương ứng với từ availability. Bên cạnh đó, người nói cũng đề cập tới sự tận tâm, điều này tương ứng với commitment. Như vậy, hai đáp án đúng là B và E.','','',14,'','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:27:09','truongdx18vtit',false,'2026-06-10 21:27:09','truongdx18vtit','PRIVATE','Trích đoạn chứa đáp án:
Woman: And could I get a private (Q2)lesson there?
Và tôi có thể học riêng ở lớp học đó không?
 
Keyword cần chú ý:
lesson ~ classes
 
Giải thích đáp án:
Also offers (2) ……….. classes
Đồng thời cung cấp các lớp học (2) …………
→ Chỗ trống câu 2 cần điền là 1 adj
-> private','','',2,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:04:24','truongdx18vtit',false,'2026-06-10 21:04:24','truongdx18vtit','B/E','Trích đoạn chứa đáp án:

But it is critical that you have enough hours in the day for whatever role we agree is suitable for you — if being a volunteer becomes stressful then it’s best not to do it at all. You may think that your income is important, but we don’t ask about that. It’s up to you to decide if you can work without earning money. What we value is dedication. Some of our most loyal volunteers earn very little themselves but still give their full energy to the work they do with us.

Keyword cần chú ý:

TWO issues, consider before, apply, availability = have enough hours, commitment = dedication

Giải thích đáp án:

Đâu là hai yếu tố cần thiết phải có khi apply vào vị trí tình nguyện viên. Từ đoạn băng ta sẽ nghe được điều quan trọng đầu tiên là phải có đủ thời gian làm việc trong ngày, điều này tương ứng với từ availability. Bên cạnh đó, người nói cũng đề cập tới sự tận tâm, điều này tương ứng với commitment. Như vậy, hai đáp án đúng là B và E.','','',15,'','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:05:29','truongdx18vtit',false,'2026-06-10 21:05:29','truongdx18vtit','B','Trích đoạn chứa đáp án:

You may wish simply to help us raise money. If you have the creativity to come up with an imaginative or novel way of fundraising. we’d be delighted, as standing in the local streets or shops with a collection box can be rather boring!

Keyword cần chú ý:

fundraising = raise money

Giải thích đáp án:

Về mặt gây quỹ, người nói có cho biết rằng họ cần những người có sức sáng tạo cao, có thể nghĩ ra những phương pháp mới, sáng tạo. Tương thích với ý nghĩa này là đáp án B.','','',16,'Fundraising','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:05:48','truongdx18vtit',false,'2026-06-10 21:05:48','truongdx18vtit','G','Trích đoạn chứa đáp án:

One outdoor activity that we need volunteers for is litter collection and for this it''s useful if you can walk for long periods, sometimes uphill.

Keyword cần chú ý:

litter collection, fitness = can walk for long period

Giải thích đáp án:

Về hoạt động thu gom rác, người nói cho biết rằng họ cần những người có thể chất tốt vì hoạt động này đòi hỏi tình nguyện viên phải đi bộ quãng đường dài, đôi lúc là phải lên đồi. Tương thích với ý nghĩa này là đáp án G.','','',17,'Litter collection
','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:06:08','truongdx18vtit',false,'2026-06-10 21:06:08','truongdx18vtit','D','Trích đoạn chứa đáp án:

If you enjoy working with children, we have three vacancies for what are called ‘playmates’. These volunteers help children learn about staying healthy through a range of out-of-school activities. You don’t need to have children yourself, but it’s good if you know something about nutrition and can give clear instructions.

Keyword cần chú ý:

play mates'', understading of food and diet = know something about nutrition

Giải thích đáp án:

Về hoạt động chơi với trẻ nhỏ, tình nguyện viên không cần phải có con mới có thể tham gia vào hoạt động này nhưng sẽ tốt nếu có kiến thức về dinh dưỡng. Từ nutrition trong đoạn băng đã được paraphrase thành food and diet trong đáp án. Đáp án tương thích là đáp án D.','','',18,'PLAYMATES','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:06:32','truongdx18vtit',false,'2026-06-10 21:06:32','truongdx18vtit','A','Trích đoạn chứa đáp án:

If that doesn’t appeal to you, maybe you would be interested in helping out at our story club for disabled children, especially if you have done some acting.

Keyword cần chú ý:

story club, experience on stage = acting

Giải thích đáp án:

Về hoạt động câu lạc bộ kịch cho trẻ khuyết tật, tình nguyện viên có kinh nghiệm diễn xuất sẽ rất phù hợp. Từ acting trong đoạn băng được paraphrase bằng cụm experience on stage. Đáp án là A.','','',19,'Storyclub','FILL_IN_THE_BLANK',188,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:06:48','truongdx18vtit',false,'2026-06-10 21:06:48','truongdx18vtit','F','Trích đoạn chứa đáp án:

The last area I’ll mention today is first aid. Volunteers who join this group can end up teaching others in vulnerable groups who may be at risk of injury. Initially, though, your priority will be to take in a lot of information and not forget any important steps or details.

Keyword cần chú ý:

first aid, good memory = not forget

Giải thích đáp án:

Về hoạt động sơ cứu, người nói cho biết rằng họ cần những người có thể nhận nhiều thông tin và không quên những bước làm hoặc chi tiết quan trọng. Điều này tương đồng với việc có một trí nhớ tốt. Đáp án là F.','','',20,'First aid','FILL_IN_THE_BLANK',188,NULL),
	 ('2026-06-10 21:07:55','truongdx18vtit',false,'2026-06-10 21:07:55','truongdx18vtit','A','Trích đoạn chứa đáp án:

It wasn’t that. I went early so that I’d get a seat and not have to stand, but then this guy sat right in front of me and he was so tall! It''s hard to see through people’s heads, isn’t it? Impossible! Anyway, to answer your question, I thought it was really interesting, especially what the speaker said about the job market.

Keyword cần chú ý:

problem, her view, blocked

Giải thích đáp án:

Chantal đã kể rằng cô ấy đã không thể nhìn thấy diễn giả do có một người đàn ông ngồi trước cô ấy mà anh ta lại quá cao, chắn mất tầm nhìn của cô. Điều này tương đồng với đáp án A.','','["A. Her view of the speaker was blocked.","B. She was unable to find an empty seat.","C. The students next to her were talking."]',21,'What problem did Chantal have at the start of the talk?','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:08:26','truongdx18vtit',false,'2026-06-10 21:08:26','truongdx18vtit','B','Trích đoạn chứa đáp án:

That''s right — and we know we can’t all have that ‘dream job’. Yeah, but it looks like there’s a whole range of ... areas of work that we hadn''t even thought of — like fashion journalism, for instance.

Keyword cần chú ý:

job market, variety = a whole range of, realised = hadn''t even thought of

Giải thích đáp án:

Hai người đã tỏ ra ngạc nhiên khi nhận ra rằng có rất nhiều lĩnh vực nghề nghiệp mà hai người chưa từng nghĩ tới như báo thời trang. Điều này tương đồng với đáp án B.','','["A. It has become more competitive than it used to be.","B. There is more variety in it than they had realised.","C. Some areas of it are more exciting than others."]',22,'What were Hugo and Chantal surprised to hear about the job market?','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:14:17','truongdx18vtit',false,'2026-06-10 21:14:17','truongdx18vtit','WEAPONS','Trích đoạn chứa đáp án:

Poaching is no longer an issue, as former poachers are able to find more reliable sources of income. In fact, many of them volunteered to give up their weapons, as they were no longer of any use to them.

Keyword cần chú ý:

reduction = is no longer an issue, poachers

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do tương đồng về nghĩa với từ ''poachers''. Do người dân có khả năng tìm được một nguồn thu nhập ổn định hơn, nên nạn săn bắt không còn là một vấn đề và những người săn bắt trước đây tình nguyện từ bỏ vũ khí vì không còn dùng đến chúng nữa.','','',39,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:08:53','truongdx18vtit',false,'2026-06-10 21:08:53','truongdx18vtit','A','Trích đoạn chứa đáp án:

It was a bit harsh, though! We know it’s a tough industry. Yeah — and we’re only first years, after all. We’ve got a lot to learn.

Keyword cần chú ý:

unfair to them = it was a bit harsh, at times = we''re only first years

Giải thích đáp án:

Khi nghe diễn giả trình bày về sự thật của ngành, của công việc họ cảm thấy nó hơi quá thẳng thắn và dường như diễn giả có thái độ cho rằng họ còn quá thiếu hiểu biết. Họ biết lĩnh vực mà họ theo học rất cạnh tranh nhưng họ mới chỉ là sinh viên năm nhất và chưa sẵn sàng để nghe những lời như vậy. Vì vậy, họ thấy thông điệp của diễn giả đưa ra chưa phù hợp với họ tại thời điểm bây giờ. Đáp án tương thích là đáp án A.','','["A. unfair to them at times.","B. hard for them to follow.","C. critical of the industry."]',23,'Hugo and Chantal agree that the speaker’s message was','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:09:20','truongdx18vtit',false,'2026-06-10 21:09:20','truongdx18vtit','C','Trích đoạn chứa đáp án:

Well, we had numerous talks on careers, which was good, but none of them were very inspiring. They could have asked more people like today’s speaker to talk to us.

Keyword cần chú ý:

criticise = none of them were very interesting, advice = talk on careers, who

Giải thích đáp án:

Họ nói rằng những lời khuyên hướng nghiệp ở trường phổ thông không tạo ra được động lực, họ được nghe rất nhiều ngành nghề nhưng không phải từ những chuyên gia - những người ở trong ngành. Vì vậy, họ muốn những diễn giả như ngày hôm nay khi người nói cũng là người hiểu về ngành. Đáp án tương thích là đáp án C.','','["A. when they received the advice","B. how much advice was given","C. who gave the advice"]',24,'What do Hugo and Chantal criticise about their school careers advice?','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:09:50','truongdx18vtit',false,'2026-06-10 21:09:50','truongdx18vtit','B','Trích đoạn chứa đáp án:

Well. I promised myself that I’d go through this course and keep an open mind till the end. But I think it’s better to pick an area of the industry now and then aim to get better and better at it. Well, I think we’ll just have to differ on that issue!

Keyword cần chú ý:

disagree = differ in that issue, choose = pick up, career = an area of the industry

Giải thích đáp án:

Khi bàn về ảnh hưởng cuộc buổi diễn thuyết tới sự nghiệp, họ có những suy nghĩ khác nhau. Chantal nói rằng anh sẽ tiếp tục học và giữ tâm lý cởi mở đến cuối cùng. Hugo thì nghĩa rằng nên chọn một lĩnh vực cụ thể của ngành và trau dồi lĩnh vực đó. Vì vậy, họ có sự khác nhau về thời điểm chọn cho mình một chuyên môn. Đáp án là B.','','["A. which is the best career in fashion.","B. when to choose a career in fashion","C. why they would like a career in fashion."]',25,'When discussing their future, Hugo and Chantal disagree on','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:10:18','truongdx18vtit',false,'2026-06-10 21:10:18','truongdx18vtit','A','Trích đoạn chứa đáp án:

One thing’s for certain, though. From what she said, we’ll be unpaid assistants in the industry for quite a long time. Mmm. I’m prepared for that, aren’t you?

Keyword cần chú ý:

realistic = prepared for that, the practice = unpaid assistant

Giải thích đáp án:

Khi nói về việc họ sẽ phải trở thành những trợ lý không lương trong thời gian dài, Hugo đã nói rằng anh hoàn toàn sẵn sàng cho việc đó trong khi Chantal thì nói rằng việc làm việc không lương như vậy có thể đúng với diễn giả và mọi người khác nhưng không phải anh ấy. Ở đây, ta thấy Hugo đã chấp nhận sự thật về việc làm việc không lương nên đáp án là A.','','["A. He is realistic about the practice.","B. He feels the practice is dishonest.","C. He thinks others want to change the practice."]',26,'How does Hugo feel about being an unpaid assistant?','MULTIPLE_CHOICE',189,NULL),
	 ('2026-06-10 21:10:33','truongdx18vtit',false,'2026-06-10 21:10:33','truongdx18vtit','B/E','Trích đoạn chứa đáp án:

Mmm. And then he was so mean, telling her she was more interested in her own appearance than his! But — she did realise he was right about that, which really made me think. I’m always considering my own clothes but now I can see you should be focusing on your client! She obviously regretted losing the job. Well, as she said, she should have hidden her negative feelings about him, but she didn''t.

Keyword cần chú ý:

pay attention = more intersted in, how she looked = her own apperance, openly disliking = negative feelings

Giải thích đáp án:

Khi nói về hai sai lầm mà diễn giả mắc phải trong công việc đầu tiên của cô ấy, hai người đã kể lại rằng lỗi sai đầu tiên là diễn giả quan tâm đến bề ngoài của mình hơn của khách hàng (trong khi cô ấy là 1 stylist). Lỗi thứ hai là cô ấy đã bộc lộ cả những cảm xúc tiêu cực của mình với khách hàng, trong khi cô ấy nên giấu kín chúng. Hai lỗi này tương tự với đáp B và E','','',27,'','FILL_IN_THE_BLANK',189,NULL),
	 ('2026-06-10 21:10:45','truongdx18vtit',false,'2026-06-10 21:10:45','truongdx18vtit','B/E','Trích đoạn chứa đáp án:

Mmm. And then he was so mean, telling her she was more interested in her own appearance than his! But — she did realise he was right about that, which really made me think. I’m always considering my own clothes but now I can see you should be focusing on your client! She obviously regretted losing the job. Well, as she said, she should have hidden her negative feelings about him, but she didn''t.

Keyword cần chú ý:

pay attention = more intersted in, how she looked = her own apperance, openly disliking = negative feelings

Giải thích đáp án:

Khi nói về hai sai lầm mà diễn giả mắc phải trong công việc đầu tiên của cô ấy, hai người đã kể lại rằng lỗi sai đầu tiên là diễn giả quan tâm đến bề ngoài của mình hơn của khách hàng (trong khi cô ấy là 1 stylist). Lỗi thứ hai là cô ấy đã bộc lộ cả những cảm xúc tiêu cực của mình với khách hàng, trong khi cô ấy nên giấu kín chúng. Hai lỗi này tương tự với đáp B và E','','',28,'','FILL_IN_THE_BLANK',189,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:14:39','truongdx18vtit',false,'2026-06-10 21:14:39','truongdx18vtit','TOURISM','Trích đoạn chứa đáp án:

All this has been a big draw for tourism, which contributes five times more than the illegal wildlife trade to GDP, and this is mainly because of the elephants. There’s also been a dramatic rise in interest ...

Keyword cần chú ý:

increase in, = a big draw, contributor to GDP

Giải thích đáp án:

Từ cần điền vào chỗ trông là một danh từ do đứng sau giới từ ''in''. Đàn voi đã khiến cho Nkhotakota thu hút được du khách, điều này đã đóng góp vào GDP nhiều hơn gấp 5 lần so với việc săn bắt trái phép.','','',40,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:11:04','truongdx18vtit',false,'2026-06-10 21:11:04','truongdx18vtit','C/A','Trích đoạn chứa đáp án:

I think that’s an issue for manufacturers, not designers. However, it would be useful to know if there’s a gap in the market— you know, an item that no one’s stocking but that consumers are looking for. Yeah, people don’t give up searching. They also take things back to the store if they aren’t right. Yeah. Imagine you worked in an expensive shop and you found out the garments sold there were being returned because they ... fell apart in the wash! Yeah, it would be good to know that kind of thing.

Keyword cần chú ý:

return, fashion items = garments, fashion designs = an item, people want = consumers are looking for, can’t find = no one''s stocking

Giải thích đáp án:

Khi nói về những ưu điểm khi làm việc tại các cửa hàng bán quần áo, hai người đồng ý rằng việc làm ở đấy sẽ giúp cho họ biết được đâu là những mặt hàng được người tiêu dùng săn đón song không có ai bán. Bên cạnh đó, họ cũng hiểu hơn về lý do tại sao mà người mua hàng lại trả lại những sản phẩm họ đã mua. Hai ý này lần lượt tương ứng với đáp án C và A.','','',29,'','FILL_IN_THE_BLANK',189,NULL),
	 ('2026-06-10 21:11:17','truongdx18vtit',false,'2026-06-10 21:11:17','truongdx18vtit','C/A','Trích đoạn chứa đáp án:

I think that’s an issue for manufacturers, not designers. However, it would be useful to know if there’s a gap in the market— you know, an item that no one’s stocking but that consumers are looking for. Yeah, people don’t give up searching. They also take things back to the store if they aren’t right. Yeah. Imagine you worked in an expensive shop and you found out the garments sold there were being returned because they ... fell apart in the wash! Yeah, it would be good to know that kind of thing.

Keyword cần chú ý:

return, fashion items = garments, fashion designs = an item, people want = consumers are looking for, can’t find = no one''s stocking

Giải thích đáp án:

Khi nói về những ưu điểm khi làm việc tại các cửa hàng bán quần áo, hai người đồng ý rằng việc làm ở đấy sẽ giúp cho họ biết được đâu là những mặt hàng được người tiêu dùng săn đón song không có ai bán. Bên cạnh đó, họ cũng hiểu hơn về lý do tại sao mà người mua hàng lại trả lại những sản phẩm họ đã mua. Hai ý này lần lượt tương ứng với đáp án C và A.','','',30,'','FILL_IN_THE_BLANK',189,NULL),
	 ('2026-06-10 21:12:00','truongdx18vtit',false,'2026-06-10 21:12:00','truongdx18vtit','FENCES','Trích đoạn chứa đáp án:

Elephants were routinely knocking down fences around the park, which then had to be repaired at a significant cost.

Keyword cần chú ý:

damage = knocking down fences, park

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau ''damage to'', là chủ thể chịu tác động. Đoạn băng nói rằng voi thường xuyên đạp đổ hàng rào quanh công viên, làm tốn chi phí sửa chữa. Đồng nghĩa với việc voi gây ra thiệt hại tới hàng rào của công viên.','','',31,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:12:22','truongdx18vtit',false,'2026-06-10 21:12:22','truongdx18vtit','FAMILY','Trích đoạn chứa đáp án:

Elephants were moved in groups of between eight and twenty, all belonging to one family.

Keyword cần chú ý:

a suitable group = groups of between eight and twenty, the same = one, selected

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau mạo từ ''the'' cùng tính từ ''same''. Đoạn băng nói rằng đàn voi đã được tách ra thành từng nhóm từ 8 đến 20 con, thuộc cùng một gia đình.','','',32,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:12:41','truongdx18vtit',false,'2026-06-10 21:12:41','truongdx18vtit','HELICOPTERS','Trích đoạn chứa đáp án:

A team of vets and park rangers flew over the park in helicopters and targeted a group. which were rounded up and directed to a designated open plain.

Keyword cần chú ý:

vets and park staff = vets and park rangers, use of, help guide = rounded up and directed, open plain

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau giới từ ''of''. Một đội của các bác sỹ thú ý và nhân viên của công viên đã bay qua công viên bằng máy bay trực thăng để điều hướng một nhóm các con voi tới đồng bằng.','','',33,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:12:55','truongdx18vtit',false,'2026-06-10 21:12:55','truongdx18vtit','STRESS','Trích đoạn chứa đáp án:

This also had to be done as quickly as possible so as to minimise the stress caused.

Keyword cần chú ý:

completed quickly = as quick as possible, reduce = minimise

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do là tân ngữ. Việc bắn phi tiêu gây mê cho voi phải được thực hiện nhanh chóng nhất có thể để giảm thiếu stress.','','',34,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:13:11','truongdx18vtit',false,'2026-06-10 21:13:11','truongdx18vtit','SIDES','Trích đoạn chứa đáp án:

To avoid the risk of suffocation, the team had to make sure none of the elephants were lying on their chests because their lungs could be crushed in this position. So all the elephants had to be placed on their sides.

Keyword cần chú ý:

turned on = to be placed, avoid damage = avoid the risk

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau từ ''their'', là bộ phận của con voi. Để tránh nguy cơ bị ngạt thở, đội (bác sĩ và nhân viên khu rừng) phải đảm bảo rằng không có con voi nào được nằm sấp do việc đó có thể làm phổi của chúng bị đè vỡ nên tất cả các con voi đều phải nằm nghiêng.','','',35,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:13:25','truongdx18vtit',false,'2026-06-10 21:13:25','truongdx18vtit','BREATHING','Trích đoạn chứa đáp án:

It was very important to keep an eye on their breathing —if there were fewer than six breaths per minute, the elephant would need urgent medical attention.

Keyword cần chú ý:

elephant’s = their, monitored constantly = keep an eye on

Giải thích đáp án:

Từ cần điền vào chỗ trống là một danh từ do đứng sau sở hữu cách (elephant''s). Phải thường xuyên để mắt tới nhịp thở của các con voi, nếu chúng thở dưới sáu nhịp một phút thì chúng cần chăm sóc y tế đặc biệt.','','',36,'','FILL_IN_THE_BLANK',190,NULL),
	 ('2026-06-10 21:13:48','truongdx18vtit',false,'2026-06-10 21:13:48','truongdx18vtit','FEET','Trích đoạn chứa đáp án:

Measurements were taken of each elephant’s tusks — elephants with large tusks would be at greater risk from poachers — and also of their feet.

Keyword cần chú ý:

data = measurements, the size = larger, their tusks

Giải thích đáp án:

tusks: ngà voi Từ cần điền vào chỗ trống là một danh từ do tương đồng về nghĩa với ''tusks''. Họ phải đo đạc kích thước ngà voi và chân của chúng vì nếu hai thứ này có kích cỡ càng lớn thì những con voi đó càng trở thành mục tiêu săn bắt.','','',37,'','FILL_IN_THE_BLANK',190,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:27:19','truongdx18vtit',false,'2026-06-10 21:27:19','truongdx18vtit','20/TWENTY PER( )CENT [OR] 20%','Trích đoạn chứa đáp án:
Official: And this company has a special deal for clients where they offer a discount of 20 percent (Q3) if you return for a further class.
Và công ty này có một ưu đãi đặc biệt cho các khách hàng là giảm giá 20% nếu bạn tham gia tiếp một lớp học khác.
 

Keyword cần chú ý:
 

clients who return get a 20% discount = offer a discount of 20 percent if you return for a further class
 

Giải thích đáp án:
 

Clients who return get a (3) ……….. discount
→ Chỗ trống câu 3 cần điền là 1 số cụ thể (bao nhiêu %)
-> 20%','','',3,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:27:28','truongdx18vtit',false,'2026-06-10 21:27:28','truongdx18vtit','HEALTHY','Trích đoạn chứa đáp án:
They concentrate on teaching you to prepare healthy (Q4) food, and they have quite a lot of specialist staff.
Lớp ở đây tập trung dạy học viên nấu thực phẩm tốt cho sức khỏe, và họ có rất nhiều nhân viên có tay nghề cao.

Giải thích đáp án:
Food that is (4) ………..
Thức ăn mà (4) ……… ..
→ Chỗ trống cần điền là 1 adj
-> healthy','','',4,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:27:36','truongdx18vtit',false,'2026-06-10 21:27:36','truongdx18vtit','BONES','Trích đoạn chứa đáp án:
It’s more to do with recipes that look at specific needs, like including ingredients that will help build up your bones (Q5) and make them stronger, that sort of thing.
Nó thì tập trung nhiều vào các công thức nấu ăn có nhu cầu cụ thể như thức ăn giúp xương phát triển và vững chắc hơn, đại loại như vậy.

Keyword cần chú ý:
strengthen = make stronger, build up

Giải thích đáp án:
Includes recipes to strengthen your (5) ………..
Bao gồm các công thức để củng cố (5) ……… ..
→ Chỗ trống câu 5 cần điền là 1 noun
-> bones','','',5,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:27:46','truongdx18vtit',false,'2026-06-10 21:27:46','truongdx18vtit','LECTURE','Trích đoạn chứa đáp án:
And if you want to know more about them, every Thursday evening they have a lecture (Q6) at the school. It’s free and you don’t need to book or anything, just turn up at 7.30.
Và nếu bạn muốn biết thêm thông tin về họ, mỗi tối ngày thứ Năm họ có một bài giảng tại trường. Lớp thì không mất học phí và bạn cũng không cần đăng ký trước, chỉ cần đến lúc 7.30.

Giải thích đáp án:
They have a free (6) ………… every Thursday
Họ có một (6) ……… … miễn phí vào thứ Năm hàng tuần
→ Chỗ trống câu 6 cần điền là noun đếm được số ít','','',6,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:27:55','truongdx18vtit',false,'2026-06-10 21:27:55','truongdx18vtit','ARRETSA','Trích đoạn chứa đáp án:
Official: OK, there’s one more place you might be interested in. That’s got a rather strange name, it’s called The Arretsa (Q7) Centre – that’s spelled A-R-R-E-T-S-A.
Ok, còn một nơi nữa bạn có thể thích đấy. Nó có một cái tên rất lạ, gọi là Trung tâm Arresta. Đánh vần là A-R-R-E-T-S-A.

Giải thích đáp án:
The (7) ……….. Centre
Trung tâm (7) ………
→ Chỗ trống cần điền là tên riêng
-> Arretsa','','',7,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:28:05','truongdx18vtit',false,'2026-06-10 21:28:05','truongdx18vtit','VEGETARIAN','Trích đoạn chứa đáp án:
Official: They’ve got a very good reputation. They do a bit of meat and fish cookery but they mostly specialise in vegetarian (Q8) dishes.
Họ rất nổi tiếng. Họ dạy nấu một ít thức ăn có thịt và cá, nhưng tập trung chủ yếu vào các món ăn chay.

Keyword cần chú ý:
mostly specialise in ~ mainly

Giải thích đáp án:
Mainly (8) ……….. food
Chủ yếu là thức ăn (8) ……… ..
→ Chỗ trống cần điền là 1 adj
-> vegetarian','','',8,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:28:14','truongdx18vtit',false,'2026-06-10 21:28:14','truongdx18vtit','MARKET','Trích đoạn chứa đáp án:
Is it just by the market (Q9)?
Có phải là nó gần với chợ không?

Keyword cần chú ý:
near = just by

Giải thích đáp án:
Located near the (9) ………..
Được đặt ở gần (9) ……… ..
→ Chỗ trống câu 9 cần điền là 1 noun chỉ địa điểm cụ thể
-> market','','',9,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:28:26','truongdx18vtit',false,'2026-06-10 21:28:26','truongdx18vtit','KNIFE','Trích đoạn chứa đáp án:
And they also offer a special two-hour course in how to use a knife (Q10).
Họ ở ngay bên cạnh và họ cũng cung cấp một khóa học đặc biệt kéo dài hai giờ về cách sử dụng dao.

Giải thích đáp án:
A special course in skills with a (10) ….. is sometimes available
Một khóa học đặc biệt về kỹ năng với …. thỉnh thoảng có sẵn
→ Chỗ trống câu 10 cần điền 1 noun đếm được số ít bắt đầu bằng 1 phụ âm.
','','',10,'','FILL_IN_THE_BLANK',175,NULL),
	 ('2026-06-10 21:28:44','truongdx18vtit',false,'2026-06-10 21:28:44','truongdx18vtit','CROW','Trích đoạn chứa đáp án:
One species which is well known as being highly adaptable is the crow, and there’ve been various studies about how they manage to learn new skills (Q31)

Keyword cần chú ý:
adaptability ~ highly adaptable

Giải thích đáp án:
crow được nhắc đến là loài thích nghi tốt và học nhiều kĩ năng mới
-> crow','','',31,'','FILL_IN_THE_BLANK',178,NULL),
	 ('2026-06-10 21:28:55','truongdx18vtit',false,'2026-06-10 21:28:55','truongdx18vtit','CLIFFS','Trích đoạn chứa đáp án:
Another successful species is the pigeon, because they’re able to perch on ledges on the walls of city buildings, just like they once perched on cliffs by the sea. (Q32).

Giải thích đáp án:
Pigeon đậu trên gờ tường của các toà nhà giống như chúng từng đậu trên các mỏm đã trên biển
-> walls of city building giống như cliffs
-> cliffs','','',32,'','FILL_IN_THE_BLANK',178,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:34:35','truongdx18vtit',false,'2026-06-10 21:34:35','truongdx18vtit','A','Trích đoạn chứa đáp án:
So, why do we need to make these changes to traffic systems in Granford?
[...]
But it’s the overall rise in the volume of traffic of all kinds that’s concerning us (Q11).

Keyword cần chú ý:
amount = volume
increase = rise

Giải thích đáp án:
Người nói nhắc đến "overall rise in the volume of traffic of all kinds" - chính là đáp án A.
Chúng ta cũng có thể loại trừ hai đáp án còn lại vì người nói khẳng định số vụ tai nạn không tăng và không nhắc đến "type of vehicles" (loại phương tiện).','','["A. The number of traffic accidents has risen.","B. The amount of traffic on the roads has increased.","C. The types of vehicles on the roads have changed."]',11,'Why are changes needed to traffic systems in Granford?
','MULTIPLE_CHOICE',176,NULL),
	 ('2026-06-10 21:35:08','truongdx18vtit',false,'2026-06-10 21:35:08','truongdx18vtit','C','Trích đoạn chứa đáp án:
People were very concerned about the lack of visibility on some roads due to cars parked along the sides of the roads (Q12).

Keyword cần chú ý:
inconvenience ~ lack of visibility

Giải thích đáp án:
Người nói _x0008_chia sẻ kết quả khảo sát là người dân đặc biệt lo lắng về việc giảm tầm nhìn do "parked cars" (xe đỗ hai bên đường). Chú ý đến cụm từ này, ta hiểu "inconvenience" trong câu trả lời là "lack of visibility on some road" và chọn phương án C.
Ở câu sau đó, người nói nêu một số mối quan ngại mà người ta kì vọng người dân sẽ đặc biệt quan tâm, là tắc đường gần trường học khi phụ huynh đưa đón con (phương án A) và khói bụi gây ô nhiễm từ xe tải (phương án B). Tuy nhiên, người dân quan tâm đến "parked cars" hơn. -> C','','["A. dangerous driving by parents.","B. pollution from trucks and lorries.","C. inconvenience from parked cars."]',12,'In a survey, local residents particularly complained about','MULTIPLE_CHOICE',176,NULL),
	 ('2026-06-10 21:35:38','truongdx18vtit',false,'2026-06-10 21:35:38','truongdx18vtit','B','Trích đoạn chứa đáp án:
But, of course, it’s no good introducing new regulations if we don’t have a way of making sure that everyone obeys them (Q13)

Keyword cần chú ý:
follow = obey

Giải thích đáp án:
Người nói chia sẻ chẳng có ích gì nếu đưa ra một luật mới mà không có cách đảm bảo người dân sẽ tuân theo -> đáp án B
Người nói cũng khẳng định đã "keep proposal within budget" (đảm bảo không quá ngân sách) và "[...] with the help of representatives from the police force" trái với lần lượt B và C nên có thể loại hai phương án này.','','["A. raising money to pay for them.","B. finding a way to make people follow them.","C. getting the support of the police."]',13,'According to the speaker, one problem with the new regulations will be','MULTIPLE_CHOICE',176,NULL),
	 ('2026-06-10 21:35:57','truongdx18vtit',false,'2026-06-10 21:35:57','truongdx18vtit','E','Trích đoạn chứa đáp án:
Now, we already have a set of traffic lights in the High Street at the junction with Station Road, but we’re planning to have another set at the other end, at the School Road junction (Q14)

Giải thích đáp án:
Đã có một bộ đèn giao thông ở chỗ giao High Street và Station Road, nên loại A.
Bộ đèn giao thông mới (set of traffic lights) sẽ được đặt ở chỗ giao High Street và School Road -> đáp án là E.','','',14,'New traffic lights','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:36:11','truongdx18vtit',false,'2026-06-10 21:36:11','truongdx18vtit','D','Trích đoạn chứa đáp án:
We’re decided we definitely need a pedestrian crossing. We considered putting this on School Road, just outside the school, but in the end we decided that could lead to a lot of traffic congestion so we decided to locate it on the High Street, crossing the road in front of the supermarket (Q15)

Giải thích đáp án:
Ban đầu dự kiến làm vạch kẻ đường mới trên School Road, ngay ngoài trường học nhưng lo sợ thêm tắc nghẽn -> loại G.
Sau đó quyết định làm ở High Street, trước cửa siêu thị -> chọn D','','',15,'Pedestrian crossing
','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:36:27','truongdx18vtit',false,'2026-06-10 21:36:27','truongdx18vtit','B','Trích đoạn chứa đáp án:
At present, parking isn’t allowed on the High Street outside the library, but we’re going to change that, and allow parking there (Q16)

Giải thích đáp án:
Parking (dừng đỗ) trước đây bị cấm ở ngoài thư viện, nhưng giờ sẽ được cho phép -> chọn B','','',16,'
Parking allowed','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:36:40','truongdx18vtit',false,'2026-06-10 21:36:40','truongdx18vtit','G','Trích đoạn chứa đáp án:
There’ll be a new ‘No Parking’ sign on School Road, just by the entrance to the school (Q17)

Giải thích đáp án:
Biển "No Parking" sign sẽ được đặt trên School Road, ngay
gần cổng vào trường -> chọn G','','',17,'New ‘No Parking’ sign','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:36:51','truongdx18vtit',false,'2026-06-10 21:36:51','truongdx18vtit','C','Trích đoạn chứa đáp án:
we’ve got two new disabled parking spaces on the side road up towards the bank (Q18)

Giải thích đáp án:
Có 2 chỗ đỗ cho người khuyết tật ở đường ngách hướng ngân hàng -> chọn C','','',18,'New disabled parking spaces
','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:37:13','truongdx18vtit',false,'2026-06-10 21:37:13','truongdx18vtit','H','Trích đoạn chứa đáp án:
We also plan to widen the pavement on School Road. We think we can manage to get an extra half-metre on the bend just before you get to the school, on the same side of the road (Q19).

Giải thích đáp án:
Mở rộng vỉa hè trên School Road ngay khúc quẹo ngay trước khi đến trường học nhưng cùng phía với trường -> chọn H','','',19,'Widened pavement
','FILL_IN_THE_BLANK',176,NULL),
	 ('2026-06-10 21:37:29','truongdx18vtit',false,'2026-06-10 21:37:29','truongdx18vtit','I','Trích đoạn chứa đáp án:
Finally, we’ve introduced new restrictions on loading and unloading for the supermarket, so lorries will only be allowed to stop there before 8 am. That’s the supermarket on School Road (Q20) – we kept to the existing arrangements with the High Street supermarket.

Giải thích đáp án:
Hạn chế dừng chất/dỡ hàng trước supermarket (siêu thị) trên School Road -> I','','',20,'Lorry loading/unloading restrictions …………….','FILL_IN_THE_BLANK',176,NULL);
INSERT INTO public.test_questions (created_at,created_by,is_deleted,updated_at,updated_by,correct_answer,explanation,image_url,"options",question_number,question_text,question_type,section_id,explantion) VALUES
	 ('2026-06-10 21:38:28','truongdx18vtit',false,'2026-06-10 21:38:28','truongdx18vtit','A','Trích đoạn chứa đáp án:
Jack: Yeah, but practically everything we do is going to feed into that. No, there’s an (Q21) optional module on seed structure and function in the third year that I might do. so I thought it might be useful for that. If I choose that option, I don’t have to do a dissertation module.
Đúng vậy, nhưng thực tế mọi thứ chúng ta làm sẽ về nó. À không, có một mô-đun tùy chọn về cấu trúc và chức năng của hạt giống trong năm thứ ba mà tớ có thể làm. vì vậy tớ nghĩ nó có thể hữu ích cho việc đó. Nếu tớ chọn phương án đó, thì tớ sẽ không phải thực hiện một mô-đun luận văn nữa.

Giải thích đáp án:
21. Why is Jack interested in investigating seed germination?
A. He may do a module on a related topic later on
B. He wants to have a career in plant science
C. He is thinking of choosing this topic for his dissertation
→ Tại sao Jack quan tâm đến việc nghiên cứu sự nảy mầm của hạt giống?
A. Anh ấy có thể làm một mô-đun về một chủ đề liên quan sau đó
B. Anh ấy muốn có một sự nghiệp trong khoa học thực vật
C. Anh ấy đang nghĩ đến việc chọn chủ đề này cho luận văn của mình
Chú ý đến thông tin “Why Jack is interested”
Jack nói có một mô đun về cấu tạo và chức năng của hạt giống cho năm 3 và làm thí nghiệm về seed germination có thể có ích cho mô đun này (A).','','["A. He may do a module on a related topic later on.","B. He wants to have a career in plant science.","C. He is thinking of choosing this topic for his dissertation."]',21,'Why is Jack interested in investigating seed germination?','MULTIPLE_CHOICE',177,NULL),
	 ('2026-06-10 21:39:00','truongdx18vtit',false,'2026-06-10 21:39:00','truongdx18vtit','C','Jack: That should be fine if we start now. A lot of the other possible experiments need quite a bit longer (Q22). Sẽ tốt hơn nếu chúng ta bắt đầu ngay bây giờ. Nhiều thử nghiệm khả thi khác cần lâu hơn một chút.  Giải thích đáp án: 22. Jack and Emma agree the main advantage of their present experiment is that it can be A. described very easily B. carried out inside the laboratory C. completed in the time available → Jack và Emma đồng ý rằng lợi thế chính của thử nghiệm hiện tại của họ là nó có thể A. được mô tả rất dễ dàng B. thực hiện bên trong phòng thí nghiệm C. hoàn thành trong thời gian có sẵn Chú ý đến thông tin “main advantage” Jack nói hai bạn sẽ đủ thời gian cho thí nghiệm này nếu bắt đầu sớm, trong khi nhiều thí nghiệm khác sẽ cần nhiều thời gian hơn. Emma đồng ý và nói đây là lợi thế của thí nghiệm này.','','["A. described very easily.","B. carried out inside the laboratory.","C. completed in the time available."]',22,'Jack and Emma agree the main advantage of their present experiment is that it can be','MULTIPLE_CHOICE',177,NULL),
	 ('2026-06-10 21:39:28','truongdx18vtit',false,'2026-06-10 21:39:28','truongdx18vtit','B','Trích đoạn chứa đáp án:
Jack: Yeah. We need to have a word with the tutor if we’re going to go ahead with it though. I’m sure our aim’s OK. It’s not very ambitious but the assignment’s only ten percent of our final mark, isn’t it? But we need to be sure we’re the only ones doing it (Q23).
Ừm. Mặc dù vậy, chúng ta cần phải nói chuyện với giáo viên nếu chúng ta sẽ bắt đầu với nó. Tớ chắc rằng mục tiêu của chúng ta ổn. Nó không quá tham vọng nhưng bài tập này chỉ chiếm mười phần trăm số điểm cuối cùng của chúng ta, phải không? Nhưng chúng ta cần chắc chắn rằng chúng ta là những người duy nhất làm điều đó.

Keyword cần chú ý:
whether anyone else has chosen this topic = we need to be sure we’re the only ones doing it

Giải thích đáp án:
23. What do they decide to check with their tutor?
A. whether their aim is appropriate
B. whether anyone else has chosen this topic
C. whether the assignment contributes to their final grade
→ Họ quyết định kiểm tra điều gì với giáo viên của họ?
A. mục tiêu của họ có phù hợp không
B. liệu có ai khác đã chọn chủ đề này không
C. liệu bài tập có đóng góp vào điểm cuối cùng của họ hay không
Chú ý đến thông tin “check with tutor”
Jack biết mục tiêu của thí nghiệm ổn vì không quá tham vọng (A) và bài tập này có giá trị 10% số điểm cuối kì (C) nên loại hai phương án này. Còn lại B đúng vì Jack cũng nói cần chắc chắn chỉ có hai bạn đang làm đề tài này.','','["A. whether their aim is appropriate","B. whether anyone else has chosen this topic","C. whether the assignment contributes to their final grade"]',23,'What do they decide to check with their tutor?','MULTIPLE_CHOICE',177,NULL),
	 ('2026-06-10 21:39:59','truongdx18vtit',false,'2026-06-10 21:39:59','truongdx18vtit','C','Trích đoạn chứa đáp án:
Emma: I found it quite hard to follow – lots about the theory, which I hadn’t expected (Q24).
Tớ cảm thấy khá khó để làm theo – rất nhiều về lý thuyết, điều mà tớ không ngờ tới.

Giải thích đáp án:
24. They agree that Grave’s book on seed germination is disappointing because
A. it fails to cover recent advances in seed science
B. the content is irrelevant for them
C. its focus is very theoretical
→ Họ đồng ý rằng cuốn sách của Grave về sự nảy mầm của hạt giống rất đáng thất vọng vì
A. nó không bao gồm những tiến bộ gần đây trong khoa học hạt giống
B. nội dung không liên quan đến họ
C. trọng tâm của nó là rất lý thuyết
Chú ý đến thông tin “Grave’s book” và “disappointing”
Emma nói cuốn sách khá nhiều lý thuyết thay vì các vấn đề thực tế (C) và Jack đồng ý.','','["A. it fails to cover recent advances in seed science.","B. the content is irrelevant for them.","C. its focus is very theoretical."]',24,'They agree that Graves’ book on seed germination is disappointing because','MULTIPLE_CHOICE',177,NULL),
	 ('2026-06-10 21:40:32','truongdx18vtit',false,'2026-06-10 21:40:32','truongdx18vtit','B','Trích đoạn chứa đáp án:
Jack: That’s the one. I knew a bit about it already, but not about this research. His analysis of figures comparing the times of the fires and the proportion of seeds that germinated was done in a lot of detail – very impressive (Q25).
Đó là cuốn tớ đã đọc. Tớ đã biết một chút về nó, nhưng không phải về nghiên cứu này. Những phân tích về các số liệu so sánh thời gian của anh ấy xảy ra cháy và tỷ lệ hạt nảy mầm được thực hiện rất chi tiết – rất ấn tượng.

Keyword cần chú ý:
thorough = in a lot of details

Giải thích đáp án:
25. What does Jack say about the article on seed germination by Lee Hall?
A. the diagrams of plant development are useful
B. the analysis of seed germination statistics is thorough
C. the findings on seed germination after fires are surprising
→ Jack nói gì về bài báo về sự nảy mầm của hạt giống của Lee Hall?
A. sơ đồ phát triển thực vật rất hữu ích
B. phân tích thống kê độ nảy mầm của hạt là kỹ lưỡng
C. những phát hiện về sự nảy mầm của hạt sau khi cháy thật đáng ngạc nhiên
Chú ý đến thông tin “article by Lee Hall”
Jack nói phần phân tích dữ liệu rất chi tiết (B). "Diagram" được nhắc đến nằm ở một article khác (loại A) và Jack không nói có ngạc nhiên về kết quả hay không (loại C).','','["A. The diagrams of plant development are useful.","B. The analysis of seed germination statistics is thorough.","C. The findings on seed germination after fires are surprising."]',25,'What does Jack say about the article on seed germination by Lee Hall?','MULTIPLE_CHOICE',177,NULL),
	 ('2026-06-10 21:40:45','truongdx18vtit',false,'2026-06-10 21:40:45','truongdx18vtit','G','Trích đoạn chứa đáp án:
Jack: [...] So, how many. sorts do we need? About four different ones (Q26)?
Mà cậu nghĩ là chúng ta cần bao nhiêu loại? Khoảng bốn loại khác nhau được không?

Keyword cần chú ý:
type = sort

Giải thích đáp án:
Select seeds of different 26…………… and sizes.
Jack nói cần chọn 4 sorts of seeds -> "G. types"','','',26,'','FILL_IN_THE_BLANK',177,NULL),
	 ('2026-06-10 21:40:57','truongdx18vtit',false,'2026-06-10 21:40:57','truongdx18vtit','C','Trích đoạn chứa đáp án:
Jack: Then, for each seed we need to find out how much it weighs, and also measure its (Q27) dimensions, and we need to keep a careful record of all that.
Sau đó, đối với mỗi hạt giống, chúng ta cần tìm hiểu xem nó nặng bao nhiêu, đồng thời đo kích thước của nó, và chúng ta cần ghi chép cẩn thận về tất cả những điều đó.

Keyword cần chú ý:
weight = how much it weights
size = measure its dimensions

Giải thích đáp án:
Measure and record the 27……………. and size of each one.
Cần đo "how much it weighs" -> "C. weight"','','',27,'','FILL_IN_THE_BLANK',177,NULL),
	 ('2026-06-10 21:41:10','truongdx18vtit',false,'2026-06-10 21:41:10','truongdx18vtit','H','Trích đoạn chứa đáp án:
Emma: That’ll be quite time-consuming. And we also need to decide how deep we’re (Q28) going to plant the seeds – right on the surface, a few millimetres down, or several centimetres.
Nó sẽ khá tốn thời gian đấy. Và chúng ta cũng cần quyết định xem sẽ gieo hạt ở độ sâu bao nhiêu – ngay trên bề mặt, sâu xuống vài mm hoặc vài cm.

Keyword cần chú ý:
depth = how deep

Giải thích đáp án:
Decide on the 28……………… to be used.
Cần quyết định "how deep" -> "H. depths"','','',28,'','FILL_IN_THE_BLANK',177,NULL),
	 ('2026-06-10 21:41:22','truongdx18vtit',false,'2026-06-10 21:41:22','truongdx18vtit','A','Trích đoạn chứa đáp án:
Jack: OK. So then we get planting. Do you think we can plant several seeds together in (Q29) the same plant pot?
Ừm. Sau đó chúng thì chúng ta bắt đầu trồng. Cậu có nghĩ rằng chúng ta có thể gieo nhiều hạt cùng nhau trong cùng một chậu cây không?
EMMA: No, I think we need a different one for each seed.
Không, tớ nghĩ chúng ta cần một chậu riêng cho mỗi hạt.

Giải thích đáp án:
Use a different 29…………….. for each seed and label it.
Cần dùng các chậu cây khác nhau cho mỗi hạt
-> từ gần nhất với "plant pot" là "A. container"
Câu sau Jack có nhắc đến "coloured label" nhưng "label" đã được nhắc đến riêng ở cuối câu nên không thể là "colour".','','',29,'','FILL_IN_THE_BLANK',177,NULL),
	 ('2026-06-10 21:41:32','truongdx18vtit',false,'2026-06-10 21:41:32','truongdx18vtit','E','Trích đoạn chứa đáp án:
Jack: [...] Then we see if our plants have come up, and write (Q30) down how tall they’ve grown.
Sau đó, chúng ta sẽ xem cây của chúng ta đã mọc lên chưa, và ghi chép lại chiều cao của chúng.

Keyword cần chú ý:
the plant''s height = how tall they''ve grown

Giải thích đáp án:
Sau đó ghi lại "how tall they''ve grown"
-> "E. Height"','','',30,'','FILL_IN_THE_BLANK',177,NULL);
