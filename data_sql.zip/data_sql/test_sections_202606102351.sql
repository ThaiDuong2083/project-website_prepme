INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-05-30 17:31:40','',false,'2026-05-30 17:31:40','','','','<p><strong>Summarize the information by selecting and reporting the main features and make comparisons where relevant.</strong></p><p><strong>(20: for test purposes, use and refer to the current year)</strong></p><div class=""image-wrapper""><img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780738373/a8b1ba2e-3272-4068-b040-0686eb5f5caf_c766fc2c84b4e36f80b0f832c664d44c6fbe3107.jpg" alt="Southland''s main exports chart"" style=""max-width: 100%; height: auto;" /></div>','Most people would agree that car ownership has increased in recent years and is causing a range of problems, particularly in built-up areas. I think there are a number of ways that governments can aim to deal with this.

Many big cities in the world have traffic problems but these problems vary. For example, it is reasonably easy to drive around my city alter 10 am and before 5 pm. However, outside these hours, you have to allow double the usual time to reach your destination. In some other cities, traffic is congested at all times, and there is the continual sound of car horns as people try to get wherever they want to go.

One of the best approaches governments can take in busy cities is to encourage the use of public transport. This means the transport facilities have to be well run and people must be able to afford them. Buses, trains and trains are good ways of getting around, and if they are cheap and reliable, people will use them.

Another approach is to discourage people from actually entering the city by building car parks and shopping centres on the outskirts. Many cities around the world do this quite successfully and oiler passengers bus transport into the centre, if they need it.

At peak travel periods, governments can also run campaigns to encourage people to be less dependent on their cars. Apparently, a lot of car trips involve very short Journeys to. say. the supermarket or local school. These are often unnecessary, but we automatically get in our cars without thinking.

Clearly we all have a responsibility to look alter our cities. Governments can do a lot to improve the situation and part of what they do should involve encouraging individuals to consider alternatives to driving.',1,'Task 1',13),
	 ('2026-05-31 17:31:40','',false,'2026-05-31 17:31:40','','','','<div class="writing-task">
    <p>
        <strong>
            In some countries an increasing number of people are suffering from health problems
            as a result of eating too much fast food. It is therefore necessary for governments
            to impose a higher tax on this kind of food.
        </strong>
    </p>

    <p>
        <strong>
            To what extent do you agree or disagree with this opinion?
        </strong>
    </p>
</div>','Increasing car ownership has become a major issue in many cities around the world. As more people choose to use private vehicles, traffic congestion, pollution, and other urban problems have become increasingly serious. Governments should take several measures to address these challenges.

One of the main problems caused by the growing number of cars is traffic congestion. In many large cities, roads become extremely crowded during peak hours, making travel slow and stressful. Commuters often spend a significant amount of time stuck in traffic, which reduces productivity and negatively affects their quality of life. Furthermore, heavy traffic contributes to air and noise pollution, creating an unhealthy environment for residents.

To tackle these issues, governments should invest more in public transportation systems. Reliable, affordable, and convenient buses, trains, and metro services can encourage people to leave their cars at home. When public transport is efficient, many commuters are willing to switch from private vehicles, which helps reduce the number of cars on the road.

Another effective solution is to develop park-and-ride facilities on the outskirts of cities. People can park their cars outside the city center and continue their journey using public transportation. This approach has been successfully implemented in many countries and has helped decrease congestion in urban areas.

In addition, governments should raise public awareness about the disadvantages of excessive car use. Educational campaigns can encourage citizens to walk, cycle, or use public transport for short journeys instead of relying on their cars. Such behavioral changes can significantly reduce unnecessary traffic.

In conclusion, the increasing number of privately owned cars has created various problems, especially in urban areas. By improving public transportation, developing alternative transport facilities, and encouraging people to reduce their dependence on cars, governments can effectively address these challenges and create more sustainable cities.',2,'Task 2',13),
	 ('2026-06-01 17:31:40','',false,'2026-06-01 17:31:40','','','','<div class="writing-task">
    <p>
        <strong>
            The pie charts below show the online shopping sales for retail sectors in New Zealand in 2003 and 2013.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780738839/0ff749ef-b2e6-4f01-aa6a-63145a6c4f42_81db5278818d46735f5c3518b8e366435f09c58b.jpg"
            alt="Online sales for retail sectors in New Zealand in 2003 and 2013"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','This bar chart illustrates the performance of Southland''s primary exports in 2000 and 2013. It also indicates future projections for 2025. According to the data, it seems likely that international tourism will become the dominant industry, although dairy exports will remain strong. In 2000, we can see that tourism was the greatest exports earner of the three industries, with revenue standing at just over �8 billion.

This figure has increased slightly, so that now, in 2013, it has reached almost �9 billion. It is estimated that international tourism will continue to grow, so that by 2025, it will be earning around �10 billion for the country. In 2000. dairy exports were worth around �7 billion, but since then there has been a dramatic increase, and sales for this year are approximately �10 billion. Experts are predicting that exports in this area may fall slightly, so a figure of �9.5 billion is expected for 2025. Meat products are the third key industry in Southland, but sales have dropped since 2000 and now stand at �5.5 billion. It is expected that sales will continue to decrease in the future.

(187 words)',1,'Task 1',14),
	 ('2026-06-02 17:31:40','',false,'2026-06-02 17:31:40','','','','<div class="writing-task">
    <p>
        <strong><em>
            Nowadays technology is increasingly being used to monitor what people are saying and doing
            (for example, through cellphone tracking and security cameras). In many cases, the people
            being monitored are unaware that this is happening.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Do you think the advantages of this development outweigh the disadvantages?
        </em></strong>
    </p>
</div>','The growth of the fast food industry has, without doubt, impacted on the eating habits and the health of many societies daround the world. Diabetes, high cholesterol, heart and respiratory problems are all on the rise due to fatty and sugar-rich food. However, the question is whether higher tax would improve this situation or not.

From an economic point of view, higher tax might seem sensible. In countries such as the USA, Australia and Britain, the healthcare system spends a large part of its budget on people with diet-related health problems. It could be argued that these people have caused their own illnesses because of their choice of food. In this case, vhs should they expect the state to pay for their treatment? The tax could help fund the healthcare system.

However, we also need to consider which socio-economic group consumes fast food as the main part of their diet. Statistics indicate that lower income groups eat more of this food than wealthier people. One possible reason for this is that fast food is far cheaper than fresh produce. This is because many governments offer large subsidies to farmers who provide products for the fast food industry. such as corn, wheat and beef. Fruit and vegetables, on the other hand. are not subsidised. Research suggests that many families simply cannot afford to buy healthy food or pay higher taxes on fast food. For them, fast food is not a choice but a necessity.

In conclusion, imposing a higher tax on fast food does not seem to be the answer. If the government chose to do this, it would only lead to greater poverty and families facing further hardship.',2,'Task 2',14),
	 ('2026-07-16 17:31:40','user_56659',false,'2026-07-16 17:31:40','user_56659','','','<p><strong>Health</strong></p>

<ul>
    <li>Is it important to you to eat healthy food? [Why/Why not?]</li>
    <li>If you catch a cold, what do you do to help you feel better? [Why?]</li>
    <li>Do you pay attention to public information about health? [Why/Why not?]</li>
    <li>What could you do to have a healthier lifestyle?</li>
</ul>','',1,'Part 1',33),
	 ('2026-06-03 17:31:40','',false,'2026-06-03 17:31:40','','','','<div class="writing-task">
    <p>
        <strong>
            The chart below shows the changes that took place in three different areas of crime in Newport city centre from 2003�2012.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780739084/63123436-60a0-4011-b61c-a851bea106f4_ce75f28d3757ce11b9af8a7ca94ffbac666e0782.jpg"
            alt="The changing rates of crime in the inner city from 2003 to 2012"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','This graph illustrates how crime rates altered in Newport Inner city during the period 2003-2012. We can see immediately that the greatest change occurred in the number of burglaries, while incidents of theft remained low but steady.

In 2003, we can see that burglary was the most common crime, with approximately 3.400 reported cases. The figure rose to around 3.700 in 2004. but then there was a downward trend until 2008. At this point the figure stood at just over 1.000 incidents. This rose slightly in 2009, then continued to fluctuate for the remaining period.

In 2003, the number of cars being stolen stood at around 2,800 and followed a similar trend to burglary until 2006. At this point the number rose, standing at around 2,200 in 2007. There was a marginal decrease in the following year, but from then on. the trend was generally upwards.

Finally, robbery has always been a fairly minor problem for Newport. The number of offences committed changed little over nine years. It is interesting to note that the figure of approximately 700 in 2003 is the same figure for 2012.',1,'Task 1',15),
	 ('2026-06-04 17:31:40','',false,'2026-06-04 17:31:40','','','','<div class="writing-task">
    <p>
        <strong><em>
            In the past, when students did a university degree, they tended to study in their own country.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Nowadays, they have more opportunity to study abroad.
        </em></strong>
    </p>

    <p>
        <strong><em>
            What are the advantages and disadvantages of this development?
        </em></strong>
    </p>

    <p>
        <strong><em>
            You should use your own ideas, knowledge and experience and support your arguments with examples and relevant evidence.
        </em></strong>
    </p>
</div>','The pursuit of knowledge is a concept that is valued by most cultures. In the 21st century, we now have many more options regarding how and where to find that knowledge. If you are a French national, you can apply to do an economics degree in the USA. and likewise an American citizen can take a course in linguistics in France. Indeed, most universities across the world now have a good proportion of foreign students enrolled in their programmes.

Certainly, there are numerous advantages of studying in a different country. Many students choose to do this because they know that a particular university, for instance Stanford Business School, has an excellent reputation. Graduating from here, they believe, will increase their chances of securing a decent position in a company back home. Students studying abroad also have the opportunity to form friendships with people of various nationalities: in time, these may develop into useful professional networks. Furthermore, living far from family and friends can enable young people to become more independent and self-sufficient.

Unfortunately, the experience of studying abroad is not always a positive one. Research suggests that a small percentage of young people struggle to adapt to their new environment and suffer from severe culture shock. The situation can become worse if the student is not mature enough to cope by themselves. Different approaches to teaching and learning may also come as an unwelcome surprise to some students.

In essence, the key to a good experience at a foreign university is an open mind. II a student is presented with this opportunity, they should certainly seize it.',2,'Task 2',15),
	 ('2026-06-05 17:31:40','',false,'2026-06-05 17:31:40','','','','<div class="writing-task">
    <p>
        <strong>
            The maps below show the village of Stokeford in 1930 and in 2010.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780739222/6c8abfc3-4c26-4b7d-9a80-efe154bd5c2e_a642676f3b016a39238980ec427c939f2f5e21cf.jpg"
            alt="The village of Stokeford in 1930 and 2010"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The maps illustrate how the village of Stokeford changed between 1930 and 2010.

Overall, Stokeford underwent significant development over the 80-year period. The most noticeable changes were the replacement of farmland and gardens with residential housing and the construction of a retirement home, while the bridge, river, post office and primary school remained largely unchanged.

In 1930, Stokeford was a small rural village. There were several areas of farmland located to the east and south of the village, and a large house stood in the southeastern part. A primary school was situated near the centre, while a post office and a small number of houses were located along the road on the western side. There was also a garden area adjacent to the large house.

By 2010, the village had become much more residential. Most of the farmland had been cleared and replaced by numerous new houses. The large house in the southeast was demolished and a retirement home was built on the site. In addition, the former gardens were redeveloped into residential properties. Despite these extensive changes, the bridge crossing the river in the north, the primary school and the post office all remained in their original locations.',1,'Task 1',16),
	 ('2026-06-06 17:31:40','',false,'2026-06-06 17:31:40','','','','<div class="writing-task">
    <p>
        <strong><em>
            The continued rise in the world''s population is the greatest problem faced by humanity at the present time.
        </em></strong>
    </p>

    <p>
        <strong><em>
            What are the causes of this continued rise?
        </em></strong>
    </p>

    <p>
        <strong><em>
            Do you agree that it is the greatest problem faced by humanity?
        </em></strong>
    </p>
</div>','The world''s population has been increasing steadily for many decades, and some people believe that this trend represents the greatest challenge facing humanity today. This essay will discuss the reasons behind continued population growth and explain why I partly agree that it is one of the most serious global problems.

One major cause of population growth is the significant improvement in healthcare and living standards. Advances in medical technology have reduced mortality rates and increased life expectancy in many countries. Diseases that were once fatal can now be treated effectively, allowing people to live longer lives. Another factor is the high birth rate in certain developing nations, where cultural traditions and limited access to family-planning services encourage larger families.

Although population growth creates a range of difficulties, I do not believe it is the single greatest problem facing humanity. A rapidly growing population places pressure on housing, food supplies, healthcare systems and natural resources. In densely populated areas, governments often struggle to provide adequate public services and employment opportunities. Furthermore, increased consumption can contribute to environmental degradation and climate change.

However, other global issues may be equally or even more serious. Climate change, for instance, threatens ecosystems, food security and the livelihoods of millions of people worldwide. Likewise, armed conflicts, poverty and economic inequality continue to affect large portions of the global population. In many cases, these problems are interconnected with population growth rather than being caused solely by it.

In conclusion, population growth is largely driven by improved healthcare and high birth rates in some regions. While it undoubtedly creates significant challenges, I do not agree that it is the greatest problem facing humanity, as issues such as climate change and global inequality are equally pressing and require urgent attention.',2,'Task 2',16),
	 ('2026-06-07 17:31:40','',false,'2026-06-07 17:31:40','','','','<div class="writing-task">
    <p>
        <strong>
            The chart below shows the annual number of rental and sales (in various formats) of films from a particular store between 2002 and 2011.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780739736/5e095225-7e44-446d-a5ae-8f9fbc6ce012_122b400da5e09b30f63d36bb94ae20c3b0c8c7df.jpg"
            alt="Annual number of film rentals and sales from 2002 to 2011"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The number of rentals and sales in various formats of films, between 2002 and 2011 in a particular store has changed a lot. Sometimes it has been very low and sometimes very high. The number of rental since 2002 has been decreasing every year. Comparing the number of rentals in 2002 with 2011,

It''s possible noticing that in 2002 it was about 180.000 rentals against approximately 55.000 in 2011. In regarding the number of VMS sales, comparing the period between 2002 and 2005. it has happened as well. In 2002 the number of VMS sales was about 85.000 sales, against 65.000 in 2005. 40.000 in 2004 and about 10.0(H) sales in 2005. Alter that lime, this store slopped to sale VMS. By another side, the number of DVD sales grew up between 2002 and 2007. From approximately 45.000 in 2002. more than 100.000 in 2005. to more than 200.000 in 2007. However, since 2008, it has been going down slightly. In 2011
this number was less than 180,000.

The number of Blu-Ray vales has started since 2007 and it has growing up slowly. In 2007 it was nowhere near as significant as DVD sales but I guess it will grow up drastically in a few years. Actually the number of DVD asales is still very higher than another products in that place.',1,'Task 1',17);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-06-08 17:31:40','',false,'2026-06-08 17:31:40','','','','<div class="writing-task">
    <p>
        <strong><em>
            Some people get into debt by buying things they don''t need and can''t afford.
        </em></strong>
    </p>

    <p>
        <strong><em>
            What are the reasons for this behaviour?
        </em></strong>
    </p>

    <p>
        <strong><em>
            What action can be taken to prevent people from having this problem?
        </em></strong>
    </p>
</div>','Nowadays we are living in a society based on consuming. As a result, some people have problems in dealing with this budget and they gel into debt by buying things they don''t need and can�t afford.

This kind of behavior is encountered quite often in our present days, mainly because of the possibility of buying goods in leasing. Hence, people buy most of the goods using the credit card without having a clear idea on how much money they possess or they owe.

 

Also, another cause for this behavior could be psychological. The advertisement and the subliminal messages one encounters in a regular day in a big city has an enormous impact on one''s brain. The main problem is the lack of awareness of the serious effects that advertisement can have on people.

In order to prevent people from adopting this dangerous behavior, measures should be taken so as to raise awareness among people. Also, one must learn how to manage his budget in order to get a balance between necessity and pleasure. Keeping a record on income and monthly spendings would be very helpful and would give to the consumer an overall image on how his budget should be spent.

All summed up. the chances of becoming a victim of the consumer''s society are high nowadays due to the surrounding temptations but this problem could be easily avoid by being aware of this dangers and having a rational attitude when dealing with money.',2,'Task 2',17),
	 ('2026-06-09 17:31:40','user_56659',false,'2026-06-09 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            It is important for children to learn the difference between right and wrong at an early age. Punishment is necessary to help them learn this distinction.
        </em></strong>
    </p>

    <p>
        <strong><em>
            To what extent do you agree or disagree with this opinion?
        </em></strong>
    </p>

    <p>
        <strong><em>
            What sort of punishment should parents and teachers be allowed to use to teach good behaviour to children?
        </em></strong>
    </p>
</div>','It is often argued that children should be taught the difference between right and wrong from a young age and that punishment is an essential part of this process. While I agree that children need clear boundaries and consequences for inappropriate behaviour, I believe that punishment should be reasonable, educational, and never involve physical or emotional harm.

Teaching children moral values at an early age is crucial because it helps them develop a sense of responsibility and respect for others. Young children are still learning how their actions affect those around them, and without guidance, they may struggle to distinguish acceptable behaviour from unacceptable behaviour. In this regard, appropriate punishment can serve as a useful tool by helping children understand the consequences of their actions and discouraging them from repeating negative behaviour.

However, not all forms of punishment are effective or acceptable. Physical punishment, such as hitting or spanking, can cause psychological damage and may encourage aggression rather than good behaviour. Similarly, humiliating children through insults or public embarrassment can negatively affect their self-esteem and emotional development. Instead, parents and teachers should focus on non-violent methods that encourage learning and self-discipline.

Several forms of punishment can be both effective and appropriate. For example, parents may temporarily remove privileges such as screen time or access to favourite activities when children behave badly. Teachers can use strategies such as extra responsibilities, time-outs, or asking students to reflect on their actions through written explanations. These approaches help children understand why their behaviour was wrong while maintaining their dignity and promoting personal growth.

In conclusion, I agree that some form of punishment is necessary to help children learn the difference between right and wrong. Nevertheless, such punishment should be constructive, proportionate, and aimed at teaching rather than causing fear or harm. By using positive and educational disciplinary methods, parents and teachers can guide children towards becoming responsible and well-behaved adults.
',2,'Task 2',18),
	 ('2026-06-10 17:31:40','user_56659',false,'2026-06-10 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            You should spend about 20 minutes on this task.
        </strong>
    </p>

    <p>
        <strong>
            The first chart below shows how energy is used in an average Australian household. The second chart shows the greenhouse gas emissions which result from this energy use.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780766211/1b2a57af-7c58-47b1-a773-7041e5065c55_230fbac6879e1423f86d8b83a1f4629868014542.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The two pie charts illustrate the proportions of energy consumption in an average Australian household and the corresponding percentages of greenhouse gas emissions generated by each energy-use category.

Overall, heating and water heating account for the largest shares of household energy consumption. However, while heating consumes the most energy, it produces a relatively smaller proportion of greenhouse gas emissions. By contrast, other appliances and refrigeration generate a higher share of emissions than their respective energy consumption levels. Cooling and lighting contribute the smallest proportions in both charts.

In terms of energy use, heating is the largest category, accounting for 42% of total household energy consumption. Water heating ranks second at 30%, while other appliances make up 15%. Refrigeration, lighting and cooling represent much smaller proportions, at 7%, 4% and 2% respectively.

Regarding greenhouse gas emissions, water heating remains the largest contributor at 32%. Other appliances account for 28% of total emissions, nearly double their share of energy consumption. Similarly, refrigeration produces 14% of emissions despite consuming only 7% of household energy. In contrast, heating generates just 15% of greenhouse gas emissions, considerably lower than its 42% share of energy use. Lighting and cooling are responsible for relatively small proportions of emissions, at 8% and 3% respectively.
',1,'Task 1',18),
	 ('2026-06-11 17:31:40','user_56659',false,'2026-06-11 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The charts below show the percentage of water used for different purposes in six areas of the world.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780766855/ff4c280b-e2f1-435c-ac0f-3f1133ad53da_60c51e2fd4b1607d573dfe72c001d89ecb46f6c2.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The six pie charts illustrate the proportion of water use in different regions, including North America, South America, Europe, Africa, Central Asia and South East Asia, in three sectors: industrial, agricultural and domestic.

Overall, agricultural water use accounts for the largest proportion in four areas: South America, Africa, Central Asia and South East Asia, while industrial water use represents the highest figure in North America and Europe. In contrast, domestic water use records the lowest share in most regions.

In terms of agricultural water use, Central Asia has the highest proportion at approximately 88%, followed by Africa, South East Asia and South America at about 84%, 81% and 71% respectively. In contrast, North America and Europe have a much lower proportion, both remaining below 40% in this field.

With regard to industrial water use, North America and Europe account for the highest proportions, at nearly half of the total, while the figures for the remaining regions are significantly lower, ranging from 5% to 12%.

For domestic water use, South America records the highest proportion at 19%, followed by Europe and North America at 15% and 13% respectively. By contrast, the figures for Africa, Central Asia and South East Asia are considerably lower, accounting for 9%, 7% and 7% respectively.',1,'Task 1',19),
	 ('2026-06-12 17:31:40','user_56659',false,'2026-06-12 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            Governments should spend money on railways rather than roads.
        </em></strong>
    </p>

    <p>
        <strong><em>
            To what extent do you agree or disagree with this statement?
        </em></strong>
    </p>
</div>','Governments should spend money on railways rather than roads.

To what extent do you agree or disagree with this statement?',2,'Task 2',19),
	 ('2026-06-13 17:31:40','user_56659',false,'2026-06-13 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The bar chart below shows the percentage of Australian men and women in different age groups who did regular physical activity in 2010.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780766956/c0044df3-a8c7-4cc1-bd63-c6636c9c3467_8a1472844ee0cc71a2ae05665d4684c197b4d95f.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The bar chart compares the percentages of males and females who participated in regular physical activity in 2010 across six different age groups.

Overall, women were more physically active than men in all age groups except those aged 15 to 24. Male participation declined markedly from the youngest age group to the 35–44 category before gradually increasing in older age groups. In contrast, female participation remained relatively stable throughout the period. The gender gap also narrowed considerably among the oldest participants.

In the 15–24 age group, men recorded a higher participation rate than women, at 52.8% and 47.7% respectively. However, this pattern was reversed in all subsequent age categories. Among people aged 25–34, 48.9% of women engaged in regular physical activity, compared with only 42.2% of men.

The largest gender difference was observed among those aged 35–44, where the figure for women stood at 52.5%, while the corresponding figure for men fell to just 39.5%, the lowest rate recorded for either gender. Female participation remained higher in the older age groups, reaching 53.3% among those aged 45–54 and 53% among individuals aged 55–64. By comparison, the proportions for men were 43.1% and 45.1% respectively.

In the oldest age group, comprising people aged 65 and over, the gap between the two genders was minimal, with 47.1% of women and 46.7% of men taking part in regular physical activity.
',1,'Task 1',20),
	 ('2026-06-14 17:31:40','user_56659',false,'2026-06-14 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            Some people believe that it is good to share as much information as possible in scientific research, business and the academic world. Others believe that some information is too important or too valuable to be shared freely.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Discuss both these view and give your own opinion.
        </em></strong>
    </p>
</div>','In today''s knowledge-based society, there is an ongoing debate about whether information in scientific research, business and academia should be shared freely. While some people argue that open access to information promotes progress and innovation, others believe that certain types of information are too valuable or sensitive to be made publicly available. This essay will discuss both perspectives before explaining why I believe a balanced approach is the most appropriate.

On the one hand, sharing information freely can bring significant benefits to society. In scientific research, the open exchange of findings enables researchers from different countries to collaborate, verify results and accelerate discoveries. For example, during global health crises, the rapid sharing of medical data can contribute to the development of effective treatments and vaccines. Similarly, in academia, free access to knowledge allows students and scholars to learn from one another, fostering intellectual growth and innovation. In the business world, the exchange of ideas and technological advancements can also encourage competition and drive economic development.

On the other hand, not all information should be available to everyone. Certain scientific findings may pose serious risks if they fall into the wrong hands. For instance, research related to biological weapons or cybersecurity vulnerabilities could be exploited for harmful purposes. In business, companies invest substantial resources in developing products, technologies and strategies. If proprietary information were shared freely, firms could lose their competitive advantage, reducing incentives for innovation. Likewise, academic institutions and researchers often spend years producing original work, and unrestricted sharing may undermine intellectual property rights.

In my opinion, while the free flow of information is essential for social and technological progress, some restrictions are necessary to protect security, privacy and commercial interests. Information that benefits society as a whole should generally be accessible, whereas sensitive or commercially valuable data should be shared only under appropriate regulations and safeguards.

In conclusion, although open access to information can promote innovation and collaboration, unrestricted sharing may create security and economic concerns. Therefore, a balance should be struck between encouraging knowledge exchange and protecting information that is sensitive or highly valuable.
',2,'Task 2',20),
	 ('2026-06-15 17:31:40','user_56659',false,'2026-06-15 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            Living in a country where you have to speak a foreign language can cause serious social problems, as well as practical problems.
        </em></strong>
    </p>

    <p>
        <strong><em>
            To what extent do you agree or disagree with this statement?
        </em></strong>
    </p>
</div>','It is often argued that living in a foreign country where people must communicate in a language other than their mother tongue can lead to significant difficulties. I strongly agree with this view because language barriers can create both social isolation and practical challenges in everyday life.

One major issue is the social problems that arise from an inability to communicate effectively. Language is the primary means through which people build relationships and integrate into society. Individuals who are not fluent in the local language may find it difficult to make friends, participate in community activities or express their thoughts and feelings clearly. As a result, they can experience loneliness, frustration and even discrimination. For example, immigrants who struggle with the local language often find it challenging to establish social networks, which can negatively affect their mental well-being and sense of belonging.

In addition to social difficulties, practical problems are also common. People who cannot communicate confidently in the local language may face obstacles when carrying out everyday tasks such as shopping, visiting a doctor, opening a bank account or dealing with government agencies. Misunderstandings can lead to inconvenience and, in some cases, serious consequences. For instance, a patient who is unable to describe symptoms accurately may receive inappropriate medical treatment. Similarly, language barriers in the workplace can reduce productivity and limit employment opportunities.

However, some people argue that modern technology has made communication easier through translation applications and online services. While these tools can be helpful, they cannot fully replace the ability to communicate naturally and effectively in a foreign language. Nuances, cultural references and complex information are often lost in translation, meaning that language difficulties remain a significant challenge.

In conclusion, I strongly agree that living in a country where a foreign language must be spoken can cause serious social and practical problems. Although technological developments have reduced some of these difficulties, language barriers continue to affect people''s ability to integrate into society and manage daily life effectively.
',2,'Task 2',21),
	 ('2026-06-16 17:31:40','user_56659',false,'2026-06-16 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            Some people believe that it is best to accept a bad situation, such as an unsatisfactory job or shortage of money. Others argue that it is better to try and improve such situations.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Discuss both these views and give your own opinion.
        </em></strong>
    </p>
</div>','People often face difficult circumstances in life, such as financial hardship or dissatisfaction with their jobs. While some believe that accepting these situations is the most practical approach, others argue that individuals should make efforts to improve their circumstances. This essay will discuss both views before explaining why I believe striving for improvement is generally the better option.

On the one hand, there are several reasons why people choose to accept an unfavourable situation. Firstly, not everyone has the resources, opportunities or abilities required to change their circumstances. For example, a person living in a region with limited employment opportunities may have little choice but to remain in a job they dislike. Secondly, accepting reality can reduce stress and help individuals focus on aspects of life that they can control. Constantly pursuing change without success may lead to frustration, disappointment and mental exhaustion. Therefore, in some cases, acceptance can be a practical and emotionally healthy response.

On the other hand, many people believe that making an effort to improve a difficult situation is essential for personal growth and long-term success. Individuals who actively seek better opportunities are more likely to achieve their goals and improve their quality of life. For instance, someone who is dissatisfied with their current job may choose to acquire new skills, pursue further education or search for a more rewarding career. Similarly, people facing financial difficulties can often improve their situation by developing better financial habits or exploring additional sources of income. Without the willingness to pursue change, progress would be impossible both for individuals and for society as a whole.

In my opinion, although accepting certain circumstances may sometimes be necessary, people should generally strive to improve situations that negatively affect their lives. While change may involve risks and challenges, it often creates opportunities for personal development, greater happiness and financial stability. Acceptance should be viewed as a temporary response rather than a permanent solution whenever improvement is realistically achievable.

In conclusion, some people believe that accepting difficult situations is the most sensible approach, whereas others argue that individuals should attempt to improve their circumstances. I believe that while acceptance can occasionally be beneficial, making efforts to create positive change is usually the more effective and rewarding choice.
',2,'Task 2',22),
	 ('2026-06-17 17:31:40','user_56659',false,'2026-06-17 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            In some countries, owning a home rather than renting one is very important for people.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Why might this be the case? Do you think this is a positive or negative situation?
        </em></strong>
    </p>
</div>','In many countries, owning a home is regarded as a major life achievement and is often considered more desirable than renting. This preference can be attributed to financial, cultural and psychological factors. In my opinion, this trend is largely positive, although it may also bring certain challenges.

There are several reasons why home ownership is highly valued. Firstly, buying a house provides a sense of security and stability. Homeowners do not have to worry about rising rents, lease expirations or being asked to move by landlords. This is particularly important for families who want a stable environment in which to raise their children. Secondly, property is often viewed as a long-term investment. In many countries, house prices tend to increase over time, allowing homeowners to build wealth and achieve greater financial security. In contrast, renting is sometimes perceived as spending money without gaining a valuable asset.

Cultural factors also play an important role. In some societies, owning a home is associated with social status, independence and personal success. Many people believe that purchasing a property demonstrates financial responsibility and marks an important milestone in adulthood. As a result, home ownership is often encouraged by both families and governments.

I believe that this situation is generally positive. Owning a home can provide individuals with a strong sense of belonging and encourage them to invest in their local communities. Homeowners are often more willing to maintain their properties and contribute to neighbourhood development because they have a long-term interest in the area. Furthermore, the financial benefits of property ownership can help people achieve greater economic stability in the future.

However, excessive emphasis on home ownership may create problems. Some individuals may take on large debts to purchase properties they cannot comfortably afford, leading to financial stress. Therefore, while owning a home can be beneficial, it should be pursued responsibly and according to one''s financial circumstances.

In conclusion, people in many countries prefer owning homes because it offers security, financial advantages and social recognition. Despite some potential drawbacks, I believe that the importance placed on home ownership is generally a positive development for both individuals and society.
',2,'Task 2',23);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-06-18 17:31:40','user_56659',false,'2026-06-18 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            In some countries, more and more people are becoming interested in finding out about the history of the house or building they live in.
        </em></strong>
    </p>

    <p>
        <strong><em>
            What are the reasons for this?
        </em></strong>
    </p>

    <p>
        <strong><em>
            How can people research this?
        </em></strong>
    </p>
</div>','In several countries, an increasing number of people are becoming interested in learning about the history of the houses or buildings in which they live. This trend can be attributed to a variety of cultural, personal and financial reasons. There are also several effective ways for people to research the background of their properties.

One reason for this growing interest is simple curiosity. Many people want to know who lived in their home previously, when the building was constructed and whether any significant events are associated with it. Such information can help residents feel more connected to their property and local community. In addition, some individuals are interested in discovering whether their homes have historical or architectural value. For example, a house that was once owned by a famous person or built during a particular historical period may be considered culturally significant.

Another important reason is related to financial and practical concerns. Understanding a property''s history can reveal information about past renovations, structural problems or legal issues. This knowledge may help homeowners make informed decisions about maintenance, insurance or future property sales. In some cases, a building with historical importance may even increase in value, making such research financially beneficial.

There are several methods people can use to investigate the history of their homes. One common approach is to consult public records held by local authorities, which often contain information about construction dates, ownership history and building permits. People can also visit local libraries, museums or historical societies, where archives and photographs may provide valuable insights. In addition, speaking with long-term residents or previous owners can be an excellent way to learn about a property''s past. Nowadays, online databases and government websites have made historical research even more accessible, allowing people to find relevant information quickly and conveniently.

In conclusion, people are increasingly interested in the history of their homes due to personal curiosity, cultural appreciation and practical considerations. By using public records, historical archives, local knowledge and online resources, they can gain a deeper understanding of the properties in which they live.
',2,'Task 2',24),
	 ('2026-06-19 17:31:40','user_56659',false,'2026-06-19 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong><em>
            Write about the following topic:
        </em></strong>
    </p>

    <p>
        <strong><em>
            It is important for people to take risks, both in their professional lives and their personal lives.
        </em></strong>
    </p>

    <p>
        <strong><em>
            Do you think the advantages of taking risks outweigh the disadvantages?
        </em></strong>
    </p>

    <p>
        <strong><em>
            Give reasons for your answer and include any relevant examples from your own knowledge or experience.
        </em></strong>
    </p>
</div>','Taking risks is an inevitable part of life, whether in one''s career or personal circumstances. While taking risks can sometimes lead to failure, I believe that the potential benefits are far greater than the drawbacks because risks often create opportunities for growth, success and self-development.

One significant advantage of taking risks is that it enables people to achieve goals that would otherwise be unattainable. In professional life, individuals who are willing to step outside their comfort zones are more likely to gain promotions, start successful businesses or develop innovative ideas. For example, many entrepreneurs invest considerable amounts of time and money into ventures without any guarantee of success. Although some businesses fail, those that succeed often generate substantial rewards and contribute to economic growth. If people were unwilling to take risks, many technological and scientific advancements would never occur.

Risk-taking is also beneficial in personal life. Trying new experiences, moving to a different city or pursuing a challenging educational opportunity can help individuals develop confidence and resilience. People often learn valuable lessons from both success and failure, enabling them to make better decisions in the future. For instance, a student who decides to study abroad may initially face difficulties adapting to a new culture, but the experience can broaden their perspective and improve their independence.

Admittedly, taking risks does involve certain disadvantages. Poor decisions can result in financial losses, career setbacks or emotional stress. A person who leaves a stable job to pursue a business idea may face significant uncertainty if the venture fails. However, these negative outcomes can often be reduced through careful planning and informed decision-making. Moreover, even unsuccessful attempts frequently provide valuable experience that contributes to future success.

In conclusion, although taking risks may lead to occasional failures and challenges, I believe the advantages outweigh the disadvantages. Risk-taking encourages personal growth, creates opportunities for achievement and drives innovation, making it an essential aspect of both professional and personal development.
',2,'Task 2',25),
	 ('2026-06-20 17:31:40','user_56659',false,'2026-06-20 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The two maps below show road access to a city hospital in 2007 and in 2010.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features and make comparison where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780768006/7ebcb529-28ca-4e70-8987-990769e49b9c_657686013774dea8bdb11f053a8d702119219c85.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The provided maps demonstrate alterations in the road infrastructure leading to a city hospital from 2007 to 2010.

The changes made to the road access to the hospital included the addition of a roundabout on City Road, relocation of the staff car park to the south side, transformation of the bus stop into a bus station, and the maintenance of the public car park on the west side.

In 2007, the hospital was sited at the northern extremity of the city road junction, surrounded by a Ring Road. Initially, the car park was shared by staff and the public; however, by 2010, this area was designated solely for staff. Additionally, a new public car park was established east of the hospital, with direct access to the encircling ring road.

Significant alterations in 2010 included the installation of two roundabouts at crucial intersections between the city road and the hospital road. Furthermore, the removal of six bus stops on the hospital road made way for a sizeable bus station situated to the west of the hospital road, now linked to the two newly constructed roundabouts.',1,'Task 1',21),
	 ('2026-06-21 17:31:40','user_56659',false,'2026-06-21 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The chart below show the average percentages in typical meals of three types of nutrients, all of which may be unhealthy if eaten too much.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780768319/6f6860d4-5c79-405a-848b-39974b85ef6c_task-1-test-1-cam-14.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The three pie charts illustrate the average proportions of sodium, saturated fat, and added sugar consumed in typical American meals, divided among breakfast, lunch, dinner, and snacks.


Overall, the most notable patterns are that dinner contributes the largest share of both sodium and saturated fat, whereas snacks dominate in terms of added sugar. By contrast, breakfast consistently accounts for the smallest proportion across all three nutrients.


Looking first at sodium intake, dinner makes up the largest portion at 43%, which is around 14 percentage points higher than lunch (29%). Breakfast and snacks each account for a considerably smaller figure of 14%, indicating that sodium consumption is most concentrated in main meals rather than light ones.


A broadly similar trend is observed for saturated fat. Dinner again leads with 37%, followed by lunch at 26%. Snacks contribute a moderate 21%, while breakfast is the least significant at 16%. Thus, both sodium and fat intake peak at the evening meal, with breakfast remaining the lowest source.


By contrast, the distribution of added sugar shows a different picture. Snacks are by far the largest contributor at 42%, almost double the figure for dinner (23%). Lunch and breakfast record the smallest proportions, at 19% and 16% respectively.',1,'Task 1',22),
	 ('2026-06-22 17:31:40','user_56659',false,'2026-06-22 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The chart below shows the results of a survey about people’s coffee and tea buying and drinking habits in five Australian cities.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780801627/21a92159-ee5b-4791-a235-4ed680b9a335_ed94b092f2c82249.png"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The bar graph displays the result of how many people prefer to buy coffee and tea and also provides their drinking habits by completing a survey in five different cities in Australia.

Overall, Consuming tea or coffee in a cafe is significantly higher whereas, buying  fresh coffee is the lowest when compared to the other two and purchasing instant coffee stands in the middle.

Residents of cities like Sydney, Melbourne, and Hobart are the biggest contributors to local cafes for drinking tea or coffee at more than 60% while, the other two cities, Brisbane and Adelaide are approximately at 55% and 50% respectively. Moreover, purchasing  fresh coffee rather than  instant coffee is comparatively lesser in most cities of Australia and only Sydney and Melbourne are relatively higher than 40%, the rest of the cities are below that percentage.

However, Instant coffee is consumed more in Brisbane and Hobart with around more than 52% while  Adelaide and Melbourne city range between  almost 42% to 50% and Sydney city is the least contributor to it.',1,'Task 1',23),
	 ('2026-06-23 17:31:40','user_56659',false,'2026-06-23 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The maps below show an industrial area in the town of Norbiton, and planned future development of the site.
        </strong>
    </p>

    <p>
        <strong>
            Summarise the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <strong>
            Write at least 150 words.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780802047/7f7dacd5-2e67-423e-9bab-996aa02a9f0c_281bc83b351c5356fbb221149c62a86cc40cb8a3.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The two maps display an industrial area in the town of Norbiton, currently and a proposed plan for its transformation in the future.

At this time, the Norbiton industrial area, located east of the town and south of the continuous river below farmland, consists mainly of numerous factories. In addition, one roundabout connects the eastern highway with a short road in the center of the industrial area, near which factories are located.

In the future, it is planned to completely change this place and reconstruct it into a residential neighborhood. According to the second map, all factories will be removed. Instead, the area will be built up with residential buildings and urban infrastructure, such as shops to the southwest of the roundabout, a medical center to the southeast, a school at the end of the eastern small road, and a playground to the northeast. Another change is that a new smaller roundabout will be constructed below the older one on the highway. In addition, a new road will be built, stretching from the old roundabout to residential houses located on the former farmland. As for the agricultural fields, their area will be significantly reduced and they will remain only in the west.

In conclusion, the future development of the Norbiton industrial area will result in the expansion of the town and the elimination of the non-residential part.',1,'Task 1',25),
	 ('2026-07-17 17:31:40','user_56659',false,'2026-07-17 17:31:40','user_56659','','','<p><strong>Describe an occasion when you had to wait a long time for someone or something to arrive.</strong></p>

<p>You should say:</p>

<ul>
    <li>who or what you were waiting for</li>
    <li>how long you had to wait</li>
    <li>why you had to wait a long time</li>
</ul>

<p>and explain how you felt about waiting a long time.</p>','',2,'Part 2',33),
	 ('2026-08-01 17:31:40','user_56659',false,'2026-08-01 17:31:40','user_56659','','','<p><strong>Describe the neighbourhood you lived in when you were a child.</strong></p>

<p>You should say:</p>

<ul>
    <li>where in your town/city the neighbourhood was</li>
    <li>what kind of people lived there</li>
    <li>what it was like to live in this neighbourhood</li>
</ul>

<p>and explain whether you would like to live in this neighbourhood in the future.</p>','',2,'Part 2',38),
	 ('2026-06-24 17:31:40','user_56659',false,'2026-06-24 17:31:40','user_56659','','','<div class="writing-task">
    <p>
        <strong>
            The charts below show the changes in ownership of electrical appliances and amount of time spent doing housework and households in one country between 1920 and 2019.
        </strong>
    </p>

    <p>
        <strong>
            Summarize the information by selecting and reporting the main features, and make comparisons where relevant.
        </strong>
    </p>

    <p>
        <img
            src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780801897/0b202e86-db16-4a1e-9a08-7c80994289e0_a8c932f95d601a3948d100eb7bd92016716a6cbc.jpg"
            alt="Task image"
            style="max-width: 100%; height: auto;"
        />
    </p>
</div>','The provided line charts illustrate changes in ownership of electrical appliances and time spent on household chores in households of a particular country from 1920 to 2019.

Overall, a significant increase in the adoption of electrical appliances like washing machines, refrigerators, and vacuum cleaners can be observed, while there was a notable decline in the hours dedicated to housework per week.

Notably, in 1920, no households owned a refrigerator, but by 1960, the ownership had surged to 90% and eventually reached 100% in 1980, maintaining that level until 2019. Similarly, the ownership of vacuum cleaners started at 0% in 1920, increased to 60% by 1960, and reached full saturation by 2000 after remaining stable at 80% from 1980. The ownership of washing machines saw a steep rise from 30% in 1920 to over 70% in 1960, slightly dropped to 60% in 1980, and then increased again to over 70% by 2019.

In contrast, the time spent on housework per week experienced a sharp decline from 50 hours in 1920 to 30 hours by 1960, further decreasing to 20 hours in 1980, and finally settling at 15 hours from 2000 to 2019. This indicates a substantial reduction in the time allocated for household chores over the years, reflecting the impact of technological advancements in alleviating domestic work burdens..',1,'Task 1',24),
	 ('2026-06-25 17:31:40','user_56659',false,'2026-06-25 17:31:40','user_56659','','','<p><strong>Home town or city</strong></p>

<ul>
    <li>What kind of place is your town/city?</li>
    <li>What''s the most interesting part of your town/city?</li>
    <li>Has your town/city changed in any way in your life time? [How?]</li>
    <li>Would you say your town/city is a good place for young people to live? [Why? / Why not?]</li>
</ul>

<p><strong>Shopping</strong></p>

<ul>
    <li>What kind of things do you prefer shopping for?</li>
    <li>In what kind of places do you like to go shopping? [Why?]</li>
    <li>What effect has online shopping had in your country?</li>
    <li>What would you recommend that tourists buy from your country? [Why?]</li>
</ul>','',1,'Part 1',26);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-06-26 17:31:40','user_56659',false,'2026-06-26 17:31:40','user_56659','','','<p><strong>Describe a popular teacher that you know.</strong></p>

<p>You should say:</p>

<ul>
    <li>what this teacher looks like</li>
    <li>what sort of person this teacher is</li>
    <li>what this teacher helped you to learn</li>
</ul>

<p>and explain why this teacher is popular.</p>','',2,'Part 2',26),
	 ('2026-06-27 17:31:40','user_56659',false,'2026-06-27 17:31:40','user_56659','','','<p><strong>Education in school</strong></p>

<ul>
    <li>What can schools do to help students prepare for the next stage in their lives?</li>
    <li>What advice would you give to someone who doesn’t like school?</li>
    <li>What can schools teach children that they can''t learn from their parents?</li>
</ul>

<p><strong>Education after school</strong></p>

<ul>
    <li>In general, what opportunities are available to students after they leave school?</li>
    <li>How do you think school life differs from university life?</li>
    <li>How important do you think it is for individuals to carry on learning after they have finished school and university?</li>
</ul>','',3,'Part 3',26),
	 ('2026-06-28 17:31:40','user_56659',false,'2026-06-28 17:31:40','user_56659','','','<p><strong>Your life</strong></p>

<p>
    Let’s talk about what you do. Do you work or are you a student?
    [Examiner chooses appropriate questions.]
</p>

<p><strong>Work</strong></p>

<ul>
    <li>What job do you do?</li>
    <li>What skills do you need for your job?</li>
    <li>What do you particularly like about your job?</li>
</ul>

<p><strong>Study</strong></p>

<ul>
    <li>What subject are you studying?</li>
    <li>Why did you want to study that subject?</li>
    <li>How long have you been studying (English/nursing/accountancy, etc.)?</li>
</ul>

<p><strong>Television</strong></p>

<ul>
    <li>How often do you watch television?</li>
    <li>What kinds of television programmes are most popular in your country?</li>
    <li>Is there anything you would like to change about television in your country? [Why? / Why not?]</li>
</ul>','',1,'Part 1',27),
	 ('2026-06-29 17:31:40','user_56659',false,'2026-06-29 17:31:40','user_56659','','','<p><strong>Describe a restaurant you enjoyed going to.</strong></p>

<p>You should say:</p>

<ul>
    <li>where the restaurant was</li>
    <li>who you went with</li>
    <li>what type of food you ate in this restaurant</li>
</ul>

<p>and explain why you thought the restaurant was good.</p>','',2,'Part 2',27),
	 ('2026-06-30 17:31:40','user_56659',false,'2026-06-30 17:31:40','user_56659','','','<p><strong>Food and society</strong></p>

<ul>
    <li>Do you think that people eat healthier food than they did in the past? [Why? / Why not?]</li>
    <li>How important do you think it is for families to eat meals together?</li>
    <li>What effects has modern technology had on the food we eat?</li>
</ul>

<p><strong>Restaurant</strong></p>

<ul>
    <li>Why do people go to restaurants when they want to celebrate important occasions?</li>
    <li>Do you think that food prepared at home is always better than in restaurants?</li>
    <li>Which are more popular in your country: fast food restaurants or traditional restaurants? [Why?]</li>
</ul>','',3,'Part 3',27),
	 ('2026-07-01 17:31:40','user_56659',false,'2026-07-01 17:31:40','user_56659','','','<p><strong>Your country</strong></p>

<ul>
    <li>Do most people live in houses or apartments in your country?</li>
    <li>What do people usually do in their free time in your country?</li>
    <li>What do you enjoy most about living in your country?</li>
    <li>Would you say that your country is a good place to visit? [Why?]</li>
</ul>

<p><strong>Food</strong></p>

<ul>
    <li>What is your favourite meal?</li>
    <li>Do you prefer to eat out or eat at home? [Why?]</li>
    <li>Are there any traditional meals that you would recommend? [Why?]</li>
    <li>How have people''s eating habits changed in your country?</li>
</ul>','',1,'Part 1',28),
	 ('2026-07-02 17:31:40','user_56659',false,'2026-07-02 17:31:40','user_56659','','','<p><strong>Describe a television programme that you watch.</strong></p>

<p>You should say:</p>

<ul>
    <li>which kind of television programme it is</li>
    <li>what usually happens in the television programme</li>
    <li>why you enjoy watching the television programme</li>
</ul>

<p>and explain why you would recommend the television programme to other people.</p>','',2,'Part 2',28),
	 ('2026-07-03 17:31:40','user_56659',false,'2026-07-03 17:31:40','user_56659','','','<p><strong>The role of advertising on television</strong></p>

<ul>
    <li>How do you feel about the amount of advertising on television?</li>
    <li>In what ways has television advertising changed in the last ten years?</li>
    <li>To what extent are people influenced by the advertising they see on television?</li>
</ul>

<p><strong>The effect of films on society</strong></p>

<ul>
    <li>Why do people still enjoy going to the cinema to watch a film?</li>
    <li>What sort of influence can films have on people?</li>
    <li>Should film-makers be responsible for the impact their films can have on people?</li>
</ul>','',3,'Part 3',28),
	 ('2026-07-04 17:31:40','user_56659',false,'2026-07-04 17:31:40','user_56659','','','<p><strong>Introduction</strong></p>

<ul>
    <li>Let''s talk about where you live ...</li>
    <li>What do you like most about your home town?</li>
    <li>Is your home town a popular place for tourists to visit? [Why? / Why not?]</li>
    <li>Has your home town changed much in recent years? [Why? / Why not?]</li>
</ul>

<p><strong>Now let’s talk about writing.</strong></p>

<ul>
    <li>What different types of writing do you do, for example letters, emails, reports or essays?</li>
    <li>Do you prefer writing with a pen or using a computer? [Why?]</li>
    <li>Do you write more now or less than you did a few years ago? [Why?]</li>
    <li>Do you like to write stories or poems? [Why? / Why not?]</li>
</ul>

<p><strong>Music. Let’s talk about music.</strong></p>

<ul>
    <li>How often do you listen to music? [Why?]</li>
    <li>Do you prefer to buy CDs or download music from the Internet? [Why?]</li>
    <li>Have you always liked the same kind of music? [Why? / Why not?]</li>
    <li>Is there a musical instrument you would like to learn to play? [Why? / Why not?]</li>
</ul>','',1,'Part 1',29),
	 ('2026-07-05 17:31:40','user_56659',false,'2026-07-05 17:31:40','user_56659','','','<p><strong>Describe a time when you helped someone.</strong></p>

<p>You should say:</p>

<ul>
    <li>who you helped and why</li>
    <li>how you helped this person</li>
    <li>what the result was</li>
</ul>

<p>and explain how you felt about helping this person.</p>','',2,'Part 2',29);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-07-06 17:31:40','user_56659',false,'2026-07-06 17:31:40','user_56659','','','<p><strong>Helping neighbours</strong></p>

<ul>
    <li>(describe) practical things people can do to help their neighbours</li>
    <li>(explain) why neighbours should help each other</li>
    <li>(consider) whether people in small towns help each other more than people in cities</li>
</ul>

<p><strong>Jobs that involve helping people</strong></p>

<ul>
    <li>(identify) jobs that focus on helping other people</li>
    <li>(outline) the qualities that people need to do jobs that involve helping others</li>
    <li>(comment on) whether salaries for jobs that involve helping people are generally too low</li>
</ul>

<p><strong>Attitudes towards helping other people</strong></p>

<ul>
    <li>(account for) some people not wanting to help other people</li>
    <li>(agree/disagree) governments have a responsibility to help people</li>
    <li>(consider) whether some people deserve help more than others</li>
</ul>','',3,'Part 3',29),
	 ('2026-07-07 17:31:40','user_56659',false,'2026-07-07 17:31:40','user_56659','','','<p><strong>Films/Movies</strong></p>

<ul>
    <li>When was the last time you went to the cinema?</li>
    <li>How popular are cinemas where you live? [Why?]</li>
    <li>What sorts of films/movies do you enjoy most? [Why?]</li>
    <li>Where do you prefer to watch films/movies, at the cinema or at home? [Why?]</li>
</ul>

<p><strong>Special days</strong></p>

<ul>
    <li>What are the most important festivals in your culture? [Why?]</li>
    <li>How do people celebrate New Year in your culture? [Why?]</li>
    <li>Which festival did you enjoy celebrating most when you were a child? [Why?]</li>
    <li>Which festival in another country would you like to go to? [Why?]</li>
</ul>','',1,'Part 1',30),
	 ('2026-07-08 17:31:40','user_56659',false,'2026-07-08 17:31:40','user_56659','','','<p><strong>Describe a shopping centre/mall that you have visited or that you know about.</strong></p>

<p>You should say:</p>

<ul>
    <li>where the shopping centre/mall is</li>
    <li>how people travel to the shopping centre/mall</li>
    <li>what kinds of shops it has</li>
</ul>

<p>and explain whether you think it is a good place to go shopping.</p>','',2,'Part 2',30),
	 ('2026-07-09 17:31:40','user_56659',false,'2026-07-09 17:31:40','user_56659','','','<p><strong>Different types of shop</strong></p>

<ul>
    <li>Where do people in your country buy food?</li>
    <li>Is it better to buy clothes in small shops?</li>
    <li>What are the advantages of internet shopping?</li>
</ul>

<p><strong>Customer service in shops</strong></p>

<ul>
    <li>What is good customer service?</li>
    <li>Why do some shops provide better customer service than other shops?</li>
    <li>How important is customer service to the success of a shop?</li>
</ul>

<p><strong>Shopping and society</strong></p>

<ul>
    <li>Why is shopping such a popular activity?</li>
    <li>What are the advantages to society of a highly developed shopping centre?</li>
    <li>Is society becoming increasingly materialistic?</li>
</ul>','',3,'Part 3',30),
	 ('2026-07-10 17:31:40','user_56659',false,'2026-07-10 17:31:40','user_56659','','','<p><strong>Weekends</strong></p>

<ul>
    <li>How do you usually spend your weekends? [Why?]</li>
    <li>Which is your favorite part of the weekend? [Why?]</li>
    <li>Do you think your weekends are long enough? [Why/Why not?]</li>
    <li>How important do you think it is to have free time at the weekends? [Why?]</li>
</ul>','',1,'Part 1',31),
	 ('2026-07-11 17:31:40','user_56659',false,'2026-07-11 17:31:40','user_56659','','','<p><strong>Describe someone you know who does something well.</strong></p>

<p>You should say:</p>

<ul>
    <li>who this person is</li>
    <li>how you know this person</li>
    <li>what they do well</li>
</ul>

<p>and explain why you think this person is so good at doing this.</p>','',2,'Part 2',31),
	 ('2026-07-12 17:31:40','user_56659',false,'2026-07-12 17:31:40','user_56659','','','<p><strong>Skills and abilities</strong></p>

<ul>
    <li>What skills and abilities do people most want to have today? Why</li>
    <li>Which skills should children learn at school? Are there any skills which they should learn at home? What are they?</li>
    <li>Which skills do you think will be important in the future? Why?</li>
</ul>

<p><strong>Salaries for skilled people</strong></p>

<ul>
    <li>Which kinds of jobs have the highest salaries in your country? Why is this?</li>
    <li>Are there any other jobs that you think should have high salaries? Why do you think that?</li>
    <li>Some people say it would be better for society if everyone got the same salary. What do you think about that? Why?</li>
</ul>','',3,'Part 3',31),
	 ('2026-07-13 17:31:40','user_56659',false,'2026-07-13 17:31:40','user_56659','','','<p><strong>Food and cooking</strong></p>

<ul>
    <li>What sorts of food do you like eating most? [Why?]</li>
    <li>Who normally does the cooking in your home? [Why/Why not?]</li>
    <li>Do you watch cookery programmes on TV? [Why/Why not?]</li>
    <li>In general, do you prefer eating out or eating at home? [Why?]</li>
</ul>','',1,'Part 1',32),
	 ('2026-07-14 17:31:40','user_56659',false,'2026-07-14 17:31:40','user_56659','','','<p><strong>Describe a house/apartment that someone you know lives in.</strong></p>

<p>You should say:</p>

<ul>
    <li>whose house/apartment this is</li>
    <li>where the house/apartment is</li>
    <li>what it looks like inside</li>
</ul>

<p>and explain what you like or dislike about this person''s house/apartment.</p>','',2,'Part 2',32),
	 ('2026-07-15 17:31:40','user_56659',false,'2026-07-15 17:31:40','user_56659','','','<p><strong>Different types of home</strong></p>

<ul>
    <li>What kinds of home are most popular in your country? Why is this?</li>
    <li>What do you think are the advantages of living in a house rather than an apartment?</li>
    <li>Do you think that everyone would like to live in a larger home? Why is that?</li>
</ul>

<p><strong>Finding a place to live</strong></p>

<ul>
    <li>How easy is it to find a place to live in your country?</li>
    <li>Do you think it''s better to rent or to buy a place to live in? Why?</li>
    <li>Do you agree that there is a right age for young adults to stop living with their parents? Why is that?</li>
</ul>','',3,'Part 3',32);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-07-18 17:31:40','user_56659',false,'2026-07-18 17:31:40','user_56659','','','<p><strong>Arriving early</strong></p>

<ul>
    <li>In what kinds of situations should people always arrive early?</li>
    <li>How important is it to arrive early in your country?</li>
    <li>How can modern technology help people to arrive early?</li>
</ul>

<p><strong>Being patient</strong></p>

<ul>
    <li>What kinds of jobs require the most patience?</li>
    <li>Is it always better to be patient in work (or studies)?</li>
    <li>Do you agree or disagree that the older people are, the more patient they are?</li>
</ul>','',3,'Part 3',33),
	 ('2026-07-19 17:31:40','user_56659',false,'2026-07-19 17:31:40','user_56659','','','<p><strong>Television programmes</strong></p>

<ul>
    <li>Where do you usually watch TV programmes/shows? [Why/why not?]</li>
    <li>What''s your favorite TV programme/show? [Why?]</li>
    <li>Are there any programmes/shows you don''t like watching? [Why/why not?]</li>
    <li>Do you think you will watch more TV or fewer TV programmes/shows in the future? [Why/why not?]</li>
</ul>','',1,'Part 1',34),
	 ('2026-07-20 17:31:40','user_56659',false,'2026-07-20 17:31:40','user_56659','','','<p><strong>Describe someone you know who has started a business.</strong></p>

<p>You should say:</p>

<ul>
    <li>who this person is</li>
    <li>what work this person does</li>
    <li>why this person decided to start a business</li>
</ul>

<p>and explain whether you would like to do the same kind of work as this person.</p>','',2,'Part 2',34),
	 ('2026-07-21 17:31:40','user_56659',false,'2026-07-21 17:31:40','user_56659','','','<p><strong>Choosing work</strong></p>

<ul>
    <li>What kinds of jobs do young people not want to do in your country?</li>
    <li>Who is best at advising young people about choosing a job: teachers or parents?</li>
    <li>Is money always the most important thing when choosing a job?</li>
</ul>

<p><strong>Work-Life balance</strong></p>

<ul>
    <li>Do you agree that many people nowadays are under pressure to work longer hours and take less holiday?</li>
    <li>What is the impact on society of people having a poor working-life balance?</li>
    <li>Could you recommend some effective strategies for governments and employers to ensure people have a good work-life balance?</li>
</ul>','',3,'Part 3',34),
	 ('2026-07-22 17:31:40','user_56659',false,'2026-07-22 17:31:40','user_56659','','','<p><strong>Future</strong></p>

<ul>
    <li>What job would you like to have ten years from now? [Why?]</li>
    <li>How useful will English be for your future? [Why/why not?]</li>
    <li>How much travelling do you hope to do in the future? [Why/why not?]</li>
    <li>How do you think your life will change in the future? [Why/why not?]</li>
</ul>','',1,'Part 1',35),
	 ('2026-07-23 17:31:40','user_56659',false,'2026-07-23 17:31:40','user_56659','','','<p><strong>Describe a book that you enjoyed reading because you had to think a lot.</strong></p>

<p>You should say:</p>

<ul>
    <li>what this book was</li>
    <li>why you decided to read it</li>
    <li>what reading this book made you think about</li>
</ul>

<p>and explain why you enjoyed reading this book.</p>','',2,'Part 2',35),
	 ('2026-07-24 17:31:40','user_56659',false,'2026-07-24 17:31:40','user_56659','','','<p><strong>Children and reading</strong></p>

<ul>
    <li>What are the most popular types of children''s books in your country?</li>
    <li>What are the benefits of parents reading books to their children?</li>
    <li>Should parents always let children choose the books they read?</li>
</ul>

<p><strong>Electronic books</strong></p>

<ul>
    <li>How popular are electronic books in your country?</li>
    <li>What are the advantages of parents reading electronic books (compared to printed books)?</li>
    <li>Will electronic books ever completely replace printed books in the future?</li>
</ul>','',3,'Part 3',35),
	 ('2026-07-25 17:31:40','user_56659',false,'2026-07-25 17:31:40','user_56659','','','<p><strong>Email</strong></p>

<ul>
    <li>What kinds of emails do you receive about your work or studies?</li>
    <li>Do you prefer to email, phone, or text your friends? [Why?]</li>
    <li>Do you reply to emails and messages as soon as you receive them? [Why/why not?]</li>
    <li>Are you happy to receive emails that are advertising things? [Why/why not?]</li>
</ul>','',1,'Part 1',36),
	 ('2026-07-26 17:31:40','user_56659',false,'2026-07-26 17:31:40','user_56659','','','<p><strong>Describe a hotel that you know</strong></p>

<p>You should say:</p>

<ul>
    <li>where this hotel is</li>
    <li>what this hotel looks like</li>
    <li>what facilities this hotel has</li>
</ul>

<p>and explain whether you think this is a nice hotel to stay in.</p>','',2,'Part 2',36),
	 ('2026-07-27 17:31:40','user_56659',false,'2026-07-27 17:31:40','user_56659','','','<p><strong>Staying in hotels</strong></p>

<ul>
    <li>What things are important when people are choosing a hotel?</li>
    <li>Why do some people not like staying in hotels?</li>
    <li>Do you think staying in a luxury hotel is a waste of money?</li>
</ul>

<p><strong>Working in a hotel</strong></p>

<ul>
    <li>Do you think hotel work is a good career for life?</li>
    <li>How does working in a big hotel compare with working in a small hotel?</li>
    <li>What skills are needed to be a successful hotel manager?</li>
</ul>','',3,'Part 3',36);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-07-28 17:31:40','user_56659',false,'2026-07-28 17:31:40','user_56659','','','<p><strong>People you study/work with</strong></p>

<ul>
    <li>Who do you spend most time studying/working with? [Why?]</li>
    <li>What kinds of things do you study/work on with other people? [Why?]</li>
    <li>Are there times when you study/work better by yourself? [Why/why not?]</li>
    <li>Is it important to like the people you study/work with? [Why/why not?]</li>
</ul>','',1,'Part 1',37),
	 ('2026-07-29 17:31:40','user_56659',false,'2026-07-29 17:31:40','user_56659','','','<p><strong>Describe a tourist attraction you enjoyed visiting.</strong></p>

<p>You should say:</p>

<ul>
    <li>what this tourist attraction is</li>
    <li>when and why you visited it</li>
    <li>what you did there</li>
</ul>

<p>and explain why you enjoyed visiting this tourist attraction.</p>','',2,'Part 2',37),
	 ('2026-07-30 17:31:40','user_56659',false,'2026-07-30 17:31:40','user_56659','','','<p><strong>Different kinds of tourist attractions</strong></p>

<ul>
    <li>What are the most popular tourist attractions in your country?</li>
    <li>How do the types of tourist attractions that younger people like to visit compare with those that older people like to visit?</li>
    <li>Do you agree that some tourist attractions (e.g national museums/galleries) should be free to visit?</li>
</ul>

<p><strong>The importance of international tourism</strong></p>

<ul>
    <li>Why is tourism important to a country?</li>
    <li>What are the benefits to individuals of visiting another country as tourists?</li>
    <li>How necessary is it for tourists to learn the language of the country they''re visiting?</li>
</ul>','',3,'Part 3',37),
	 ('2026-07-31 17:31:40','user_56659',false,'2026-07-31 17:31:40','user_56659','','','<p><strong>History</strong></p>

<ul>
    <li>What did you study in history lessons when you were at school?</li>
    <li>Did you enjoy studying history at school? [Why/Why not?]</li>
    <li>How often do you watch TV programmes about history now? [Why/Why not?]</li>
    <li>What period in history would you like to learn more about? [Why?]</li>
</ul>','',1,'Part 1',38),
	 ('2026-08-02 17:31:40','user_56659',false,'2026-08-02 17:31:40','user_56659','','','<p><strong>Neighbours</strong></p>

<p>Example questions:</p>

<ul>
    <li>What sort of things can neighbours do to help each other?</li>
    <li>How well do people generally know their neighbours in your country?</li>
    <li>How important do you think it is to have good neighbours?</li>
</ul>

<p><strong>Facilities in cities</strong></p>

<p>Example questions:</p>

<ul>
    <li>Which facilities are most important to people living in cities?</li>
    <li>How does shopping in small local shops differ from shopping in large city centre shops?</li>
    <li>Do you think that children should always go to the school nearest to where they live?</li>
</ul>','',3,'Part 3',38),
	 ('2026-08-03 17:31:40','user_56659',false,'2026-08-03 17:31:40','user_56659','','','<div>

<p><strong>The changing role of airports</strong></p>

<p><strong>A</strong> In recent times developing commercial revenues has become more challenging for airports due to a combination of factors, such as increased competition from Internet shopping, restrictions on certain sales, such as tobacco, and new security procedures that have had an impact on the dwell time of passengers. Moreover, the global economic downturn has caused a reduction in passenger numbers while those that are travelling generally have less money to spend. This has meant that the share of revenue from non-aeronautical revenues actually peaked at 54% at the turn of the century and has subsequently declined slightly. Meanwhile, the pressures to control the level of aeronautical revenues are as strong as ever due to the poor financial health of many airlines and the rapid rise of the low-cost carrier sector.</p>

<p><strong>B</strong> Some of the more obvious solutions to growing commercial revenues, such as extending the merchandising space or expanding the variety of shopping opportunities, have already been tried to their limit at many airports. A more radical solution is to find new sources of commercial revenue within the terminal, and this has been explored by many airports over the last decade or so. As a result, many terminals are now much more than just shopping malls and offer an array of entertainment, leisure, and beauty and wellness facilities. At this stage of facilities provision, the airport also has the possibility of taking on the role of the final destination rather than merely a facilitator of access.</p>

<p><strong>C</strong> At the same time, airports have been developing and expanding the range of services that they provide specifically for the business traveller in the terminal. This includes offering business centres that supply support services, meeting or conference rooms and other space for special events. Within this context, Jarach (2001) discusses how dedicated meetings facilities located within the terminal and managed directly by the airport operator may be regarded as an expansion of the concept of airline lounges or as a way to reconvert abandoned or underused areas of terminal buildings. Previously it was primarily airport hotels and other facilities offered in the surrounding area of the airport that had the potential to take on this role and become active as a business space (McNeill, 2009).</p>

<p><strong>D</strong> When an airport location can be promoted as a business venue, this may increase the overall appeal of the airport and help it become more competitive in both attracting and retaining airlines and their passengers. In particular, the presence of meeting facilities could become one of the determining factors taken into consideration when business people are choosing airlines and where they change their planes. This enhanced attractiveness itself may help to improve the airport operator’s financial position and future prospects, but clearly this will be dependent on the competitive advantage that the airport is able to achieve in comparison with other venues.</p>

<p><strong>E</strong> In 2011, an online airport survey was conducted and some of the areas investigated included the provision and use of meeting facilities at airports and the perceived role and importance of these facilities in generating income and raising passenger numbers. In total, there were responses from staff at 154 airports and 68% of these answered ‘yes’ to the question: Does your airport own and have meetings facilities available for hire? The existence of meeting facilities therefore seems high at airports. In addition, 28% of respondents that did not have meeting facilities stated that they were likely to invest in them during the next five years. The survey also asked to what extent respondents agreed or disagreed with a number of statements about the meeting facilities at their airport. 49% of respondents agreed that they have put more investment into them during recent years; 41% agreed that they would invest more in the immediate future. These are fairly high proportions considering the recent economic climate.</p>

<p><strong>F</strong> The survey also asked airports with meeting facilities to estimate what proportion of users are from the local area, i.e. within a 90-minute drive from the airport, or from abroad. Their findings show that meeting facilities provided by the majority of respondents tend to serve local versus non-local or foreign needs. 63% of respondents estimated that over 60% of users are from the local area. Only 3% estimated that over 80% of users are from abroad. It is therefore not surprising that the facilities are of limited importance when it comes to increasing use of flights at the airport: 16% of respondents estimated that none of the users of their meeting facilities use flights when travelling to or from them, while 56% estimated that 20% or fewer of the users of their facilities use flights.</p>

<p><strong>G</strong> The survey asked respondents with meeting facilities to estimate how much revenue their airport earned from its meeting facilities during the last financial year. Average revenue per airport was just $12,959. Meeting facilities are effectively a non-aeronautical source of airport revenue. Only 1% of respondents generated more than 20% non-aeronautical revenue from their meetings facilities; none generated more than 40%. Given the focus on local demand, it is not surprising that less than a third of respondents agreed that their meeting facilities support business and tourism development in their home region or country.</p>

<p><strong>H</strong> The findings of this study suggest that few airports provide meetings facilities as a serious commercial venture. It may be that, as owners of large property, space is available for meeting facilities at airports and could play an important role in serving the needs of the airport, its partners, and stakeholders such as government and the local community. Thus, while the local orientation means that competition with other airports is likely to be minimal, competition with local providers of meetings facilities is likely to be much greater.</p>

<div><p><strong>Questions 23-26</strong></p><p><strong>Survey findings</strong> Despite financial constraints due to the (23) ____________________, a significant percentage of airports provide and wish to further support business meeting facilities. Also, just under 30% of the airports surveyed plan to provide these facilities within (24) ____________________. However, the main users of the facilities are (25) ____________________, and as many as 16% of respondents to the survey stated that their users did not take any (26) ____________________ at the airport.</p></div></div>','',2,'Passage 2',40),
	 ('2026-08-04 17:31:40','user_56659',false,'2026-08-04 17:31:40','user_56659','','','<div>

<p><strong>Is photography art?</strong></p>

<p>This may seem a pointless question today. Surrounded as we are by thousands of photographs, most of us take for granted that, in addition to supplying information and seducing customers, camera images also serve as decoration, afford spiritual enrichment, and provide significant insights into the passing scene. But in the decades following the discovery of photography, this question reflected the search for ways to fit the mechanical medium into the traditional schemes of artistic expression.</p>

<p>The much-publicized pronouncement by painter Paul Delaroche that the daguerreotype* signalled the end of painting is perplexing because this clever artist also forecast the usefulness of the medium for graphic artists in a letter written in 1839. Nevertheless, it is symptomatic of the swing between the outright rejection and qualified acceptance of the medium that was fairly typical of the artistic establishment. Discussion of the role of photography in art was especially spirited in France, where the internal policies of the time had created a large pool of artists, but it was also taken up by important voices in England. In both countries, public interest in this topic was a reflection of the belief that national stature and achievement in the arts were related.</p>

<p>From the maze of conflicting statements and heated articles on the subject, three main positions about the potential of camera art emerged. The simplest, entertained by many painters and a section of the public, was that photographs should not be considered ‘art’ because they were made with a mechanical device and by physical and chemical phenomena instead of by human hand and spirit; to some, camera images seemed to have more in common with fabric produced by machinery in a mill than with handmade creations fired by inspiration. The second widely held view, shared by painters, some photographers, and some critics, was that photographs would be useful to art but should not be considered equal in creativeness to drawing and painting. Lastly, by assuming that the process was comparable to other techniques such as etching and lithography, a fair number of individuals realized that camera images were or could be as significant as handmade works of art and that they might have a positive influence on the arts and on culture in general.</p>

<p>Artists reacted to photography in various ways. Many portrait painters – miniaturists in particular – who realized that photography represented the ‘handwriting on the wall’ became involved with daguerreotyping or paper photography in an effort to save their careers; some incorporated it with painting, while others renounced painting altogether. Still other painters, the most prominent among them the French painter, Jean-Auguste-Dominique Ingres, began almost immediately to use photography to make a record of their own output and also to provide themselves with source material for poses and backgrounds, vigorously denying at the same time its influence on their vision or its claims as art.</p>

<p>The view that photographs might be worthwhile to artists was enunciated in considerable detail by Lacan and Francis Wey. The latter, an art and literary critic, who eventually recognised that camera images could be inspired as well as informative, suggested that they would lead to greater naturalness in the graphic depiction of anatomy, clothing, likeness, expression, and landscape. By studying photographs, true artists, he claimed, would be relieved of menial tasks and become free to devote themselves to the more important spiritual aspects of their work.</p>

<p>Wey left unstated what the incompetent artist might do as an alternative, but according to the influential French critic and poet Charles Baudelaire, writing in response to an exhibition of photography in 1859, lazy and untalented painters would become photographers. Fired by a belief in art as an imaginative embodiment of cultivated ideas and dreams, Baudelaire regarded photography as ‘a very humble servant of art and science’; a medium largely unable to transcend ‘external reality’. For this critic, photography was linked with ‘the great industrial madness’ of the time, which in his eyes exercised disastrous consequences on the spiritual qualities of life and art.</p>

<p>Eugene Delacroix was the most prominent of the French artists who welcomed photography as help-mate but recognized its limitations. Regretting that ‘such a wonderful invention’ had arrived so late in his lifetime, he still took lessons in daguerreotyping, and both commissioned and collected photographs. Delacroix’s enthusiasm for the medium can be sensed in a journal entry noting that if photographs were used as they should be, an artist might ‘raise himself to heights that we do not yet know’.</p>

<p>The question of whether the photograph was document or art aroused interest in England also. The most important statement on this matter was an unsigned article that concluded that while photography had a role to play, it should not be ‘constrained’ into ‘competition’ with art; a more stringent viewpoint led critic Philip Gilbert Hamerton to dismiss camera images as ‘narrow in range, emphatic in assertion, telling one truth for ten falsehoods’.</p>

<p>These writers reflected the opposition of a section of the cultural elite in England and France to the ‘cheapening of art’ which the growing acceptance and purchase of camera pictures by the middle class represented. Technology made photographic images a common sight in the shop windows of Regent Street and Piccadilly in London and the commercial boulevards of Paris. In London, for example, there were at the time some commercial establishments where portraits, landscapes, and photographic reproductions of works of art could be bought. This appeal to the middle class convinced the elite that photographs would foster a desire for realism instead of idealism, even though some critics recognized that the work of individual photographers might display an uplifting style and substance that was consistent with the defining characteristics of art.</p>

<div><p><strong>Questions 31-34</strong></p><p><strong>Complete the summary of paragraph 3 using the list of words A-G below.</strong></p><p><strong>A</strong> inventive<br><strong>B</strong> similar<br><strong>C</strong> beneficial<br><strong>D</strong> next<br><strong>E</strong> mixed<br><strong>F</strong> justified<br><strong>G</strong> inferior</p><p><strong>Camera art</strong><br>In the early days of photography, opinions on its future were (31) ____________________, but three clear views emerged. A large number of artists and ordinary people saw photographs as (32) ____________________ to paintings because of the way they were produced. Another popular view was that photographs could have a role to play in the art world, despite the photographer being less (33) ____________________. Finally, a smaller number of people suspected that the impact of photography on art and society could be (34) ____________________.</p></div><div><p><strong>Questions 35-40</strong></p><p><strong>Look at the following statements and the list of people, A-E, below. Match each statement with the correct person.</strong></p><p><strong>Write the correct letter, A-E, in boxes 35-40 on your answer sheet.</strong></p><p><strong>A</strong> Jean-Auguste-Dominique Ingres<br><strong>B</strong> Francis Wey<br><strong>C</strong> Charles Baudelaire<br><strong>D</strong> Eugene Delacroix<br><strong>E</strong> Philip Gilbert Hamerton</p></div></div>','',3,'Passage 3',40),
	 ('2026-08-05 17:31:40','user_56659',false,'2026-08-05 17:31:40','user_56659','','','<div>

<p><strong>The Dover Bronze Age Boat</strong></p>

<p>It was 1992. In England, workmen were building a new road through the heart of Dover, to connect the ancient port and the Channel Tunnel, which, when it opened just two years later, was to be the first land link between Britain and Europe for over 10,000 years. A small team from the Canterbury Archaeological Trust (CAT) worked alongside the workmen, recording new discoveries brought to light by the machines.</p>

<p>At the base of a deep shaft six metres below the modem streets a wooden structure was revealed. Cleaning away the waterlogged site overlying the timbers, archaeologists realised its true nature. They had found a prehistoric boat, preserved by the type of sediment in which it was buried. It was then named the Dover Bronze-Age Boat.</p>

<p>About nine metres of the boat’s length was recovered; one end lay beyond the excavation and had to be left. What survived consisted essentially of four intricately carved oak planks: two on the bottom, joined along a central seam by a complicated system of wedges and timbers, and two at the side, curved and stitched to the others. The seams had been made watertight by pads of moss, fixed by wedges and yew stitches.</p>

<p>The timbers that closed the recovered end of the boat had been removed in antiquity when it was abandoned, but much about its original shape could be deduced. There was also evidence for missing upper side planks. The boat was not a wreck, but had been deliberately discarded, dismantled and broken. Perhaps it had been ‘ritually killed’ at the end of its life, like other Bronze-Age objects.</p>

<p>With hindsight, it was significant that the boat was found and studied by mainstream archaeologists who naturally focused on its cultural context. At the time, ancient boats were often considered only from a narrower technological perspective, but news about the Dover boat reached a broad audience. In 2002, on the tenth anniversary of the discovery, the Dover Bronze-Age Boat Trust hosted a conference, where this meeting of different traditions became apparent. Alongside technical papers about the boat, other speakers explored its social and economic contexts, and the religious perceptions of boats in Bronze-Age societies. Many speakers came from overseas, and debate about cultural connections was renewed.</p>

<p>Within seven years of excavation, the Dover boat had been conserved and displayed, but it was apparent that there were issues that could not be resolved simply by studying the old wood. Experimental archaeology seemed to be the solution: a boat reconstruction, half-scale or full-sized, would permit assessment of the different hypotheses regarding its build and the missing end. The possibility of returning to Dover to search for the boat’s unexcavated northern end was explored, but practical and financial difficulties were insurmountable – and there was no guarantee that the timbers had survived the previous decade in the changed environment.</p>

<p>Detailed proposals to reconstruct the boat were drawn up in 2004. Archaeological evidence was beginning to suggest a Bronze-Age community straddling the Channel, brought together by the sea, rather than separated by it. In a region today divided by languages and borders, archaeologists had a duty to inform the general public about their common cultural heritage.</p>

<p>The boat project began in England but it was conceived from the start as a European collaboration. Reconstruction was only part of a scheme that would include a major exhibition and an extensive educational and outreach programme. Discussions began early in 2005 with archaeological bodies, universities and heritage organisations either side of the Channel. There was much enthusiasm and support, and an official launch of the project was held at an international seminar in France in 2007. Financial support was confirmed in 2008 and the project then named BOAT 1550BC got under way in June 2011.</p>

<p>A small team began to make the boat at the start of 2012 on the Roman Lawn outside Dover museum. A full-scale reconstruction of a mid-section had been made in 1996, primarily to see how Bronze-Age replica tools performed. In 2012, however, the hull shape was at the centre of the work, so modem power tools were used to carve the oak planks, before turning to prehistoric tools for finishing. It was decided to make the replica half-scale for reasons of cost and time, and synthetic materials were used for the stitching, owing to doubts about the seeding and tight timetable.</p>

<p>Meanwhile, the exhibition was being prepared ready for opening in July 2012 at the Castle Museum in Boulogne-sur-Mer. Entitled ‘Beyond the Horizon: Societies of the Channel & North Sea 3,500 years ago’, it brought together for the first time a remarkable collection of Bronze-Age objects, including many new discoveries for commercial archaeology and some of the great treasure of the past. The reconstructed boat, as a symbol of the maritime connections that bound together the communities either side of the Channel, was the centerpiece.</p>

<p><img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780814773/162d355c-184b-4f1b-b79d-c8d7690abf14_23da8f792d68ba13618201a4e907f384d38a8ad1.jpg" alt="Dover Bronze Age Boat" style="max-width:100%;height:auto;"></p>

</div>','',1,'Passage 1',40),
	 ('2026-08-06 17:31:40','user_56659',false,'2026-08-06 17:31:40','user_56659','','','<div>

<p><strong>The Flavour of Pleasure</strong></p>

<p>No matter how much we talk about tasting our favorite flavors, relishing them really depends on a combined input from our senses that we experience through mouth, tongue and nose. The taste, texture, and feel of food are what we tend to focus on, but most important are the slight puffs of air as we chew our food – what scientists call ‘retronasal smell’.</p>

<p>Certainly, our mouths and tongues have taste buds, which are receptors for the five basic flavors: sweet, salty, sour, bitter, and umami, or what is more commonly referred to as savory. But our tongues are inaccurate instruments as far as flavor is concerned. They evolved to recognise only a few basic tastes in order to quickly identify toxins, which in nature are often quite bitter or acidly sour.</p>

<p>All the complexity, nuance, and pleasure of flavor come from the sense of smell operating in the back of the nose. It is there that a kind of alchemy occurs when we breathe up and out the passing whiffs of our chewed food. Unlike a hound’s skull with its extra long nose, which evolved specifically to detect external smells, our noses have evolved to detect internal scents. Primates specialise in savoring the many millions of flavor combinations that they can create for their mouths.</p>

<p>Taste without retronasal smell is not much help in recognising flavor. Smell has been the most poorly understood of our senses, and only recently has neuroscience, led by Yale University’s Gordon Shepherd, begun to shed light on its workings. Shepherd has come up with the term ‘neurogastronomy’ to link the disciplines of food science, neurology, psychology, and anthropology with the savory elements of eating, one of the most enjoyed of human experiences.</p>

<p>In many ways, he is discovering that smell is rather like face recognition. The visual system detects patterns of light and dark and, building on experience, the brain creates a spatial map. It uses this to interpret the interrelationship of the patterns and draw conclusions that allow us to identify people and places. In the same way, we use patterns and ratios to detect both new and familiar flavors. As we eat, specialised receptors in the back of the nose detect the air molecules in our meals. From signals sent by the receptors, the brain understands smells as complex spatial patterns. Using these, as well as input from the other senses, it constructs the idea of specific flavors.</p>

<p>This ability to appreciate specific aromas turns out to be central to the pleasure we get from food, much as our ability to recognise individuals is central to the pleasures of social life. The process is so embedded in our brains that our sense of smell is critical to our enjoyment of life at large. Recent studies show that people who lose the ability to smell become socially insecure, and their overall level of happiness plummets.</p>

<p>Working out the role of smell in flavor interests food scientists, psychologists, and cooks alike. The relatively new discipline of molecular gastronomy, especially, relies on understanding the mechanics of aroma to manipulate flavor for maximum impact. In this discipline, chefs use their knowledge of the chemical changes that take place during cooking to produce eating pleasures that go beyond the ‘ordinary’.</p>

<p>However, whereas molecular gastronomy is concerned primarily with the food or ‘smell’ molecules, neurogastronomy is more focused on the receptor molecules and the brain’s spatial images for smell. Smell stimuli form what Shepherd terms ‘odor objects’, stored as memories, and these have a direct link with our emotions. The brain creates images of unfamiliar smells by relating them to other more familiar smells. Go back in history and this was part of our survival repertoire; like most animals, we drew on our sense of smell, when visual information was scarce, to single out prey.</p>

<p>Thus the brain’s flavor-recognition system is a highly complex perceptual mechanism that puts all five senses to work in various combinations. Visual and sound cues contribute, such as crunching, as does touch, including the texture and feel of food on our lips and in our mouths. Then there are the taste receptors, and finally, the smell, activated when we inhale. The engagement of our emotions can be readily illustrated when we picture some of the wide-ranging facial expressions that are elicited by various foods – many of them hard-wired into our brains at birth. Consider the response to the sharpness of a lemon and compare that with the face that is welcoming the smooth wonder of chocolate.</p>

<p>The flavor-sensing system, ever receptive to new combinations, helps to keep our brains active and flexible. It also has the power to shape our desires and ultimately our bodies. On the horizon we have the positive application of neurogastronomy: manipulating flavor to curb our appetites.</p>

<p><strong>Questions 1-5</strong></p>
<p><strong>Complete the sentences. Write <em>NO MORE THAN TWO WORDS</em> from the passage.</strong></p>

<p><strong>Questions 6-9</strong></p>
<p><strong>Complete the notes below. Write <em>NO MORE THAN TWO WORDS</em> from the passage.</strong></p>

<p><img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780821887/68593ba0-7eab-43cc-9a33-04c7d0f1a1e5_29c76969c4438ea59696cbe923671c4f03f9a0ad.jpg" alt="Notes Diagram" style="max-width:100%;height:auto;"></p>

<p><strong>Questions 10-13</strong></p>
<p><strong>Answer the questions below. Choose <em>NO MORE THAN ONE WORD</em> from the text for each answer.</strong></p>

</div>','',1,'Passage 1',41),
	 ('2026-08-07 17:31:40','user_56659',false,'2026-08-07 17:31:40','user_56659','','','<div>

<p><strong>Dawn of the robots</strong></p>

<p><strong>A</strong> At first sight it looked like a typical suburban road accident. A Land Rover approached a Chevy Tahoe estate car that had stopped at a kerb; the Land Rover pulled out and tried to pass the Tahoe just as it started off again. There was a crack of fenders and the sound of paintwork being scraped, the kind of minor mishap that occurs on roads thousands of times every day. Normally drivers get out, gesticulate, exchange insurance details and then drive off. But not on this occasion. No one got out of the cars for the simple reason that they had no humans inside them; the Tahoe and Land Rover were being controlled by computers competing in November’s DARPA (the U.S. Defence Advanced Research Projects Agency) Urban Challenge.</p>

<p><strong>B</strong> The idea that machines could perform to such standards is startling. Driving is a complex task that takes humans a long time to perfect. Yet here, each car had its on-board computer loaded with a digital map and route plans, and was instructed to negotiate busy roads; differentiate between pedestrians and stationary objects; determine whether other vehicles were parked or moving off; and handle various parking manoeuvres, which robots turn out to be unexpectedly adept at. Even more striking was the fact that the collision between the robot Land Rover, built by researchers at the Massachusetts Institute of Technology, and the Tahoe, fitted out by Cornell University Artificial Intelligence (AI) experts, was the only scrape in the entire competition. Yet only three years earlier, at DARPA’s previous driverless car race, every robot competitor – directed to navigate across a stretch of open desert – either crashed or seized up before getting near the finishing line.</p>

<p><strong>C</strong> It is a remarkable transition that has clear implications for the car of the future. More importantly, it demonstrates how robotics sciences and Artificial Intelligence have progressed in the past few years – a point stressed by Bill Gates, the Microsoft boss who is a convert to these causes. ‘The robotics industry is developing in much the same way the computer business did 30 years ago,’ he argues. As he points out, electronics companies make toys that mimic pets and children with increasing sophistication. ‘I can envision a future in which robotic devices will become a nearly ubiquitous part of our day-to-day lives,’ says Gates. ‘We may be on the verge of a new era, when the PC will get up off the desktop and allow us to see, hear, touch and manipulate objects in places where we are not physically present.’</p>

<p><strong>D</strong> What is the potential for robots and computers in the near future? The fact is we still have a way to go before real robots catch up with their science fiction counterparts, Gates says. So what are the stumbling blocks? One key difficulty is getting robots to know their place. This has nothing to do with class or etiquette, but concerns the simple issue of positioning. Humans orient themselves with other objects in a room very easily. Robots find the task almost impossible. ‘Even something as simple as telling the difference between an open door and a window can be tricky for a robot,’ says Gates. This has, until recently, reduced robots to fairly static and cumbersome roles.</p>

<p><strong>E</strong> For a long time, researchers tried to get round the problem by attempting to re-create the visual processing that goes on in the human cortex. However, that challenge has proved to be singularly exacting and complex. So scientists have turned to simpler alternatives: ‘We have become far more pragmatic in our work,’ says Nello Cristianini, Professor of Artificial Intelligence at the University of Bristol in England and associate editor of the Journal of Artificial Intelligence Research. ‘We are no longer trying to re-create human functions. Instead, we are looking for simpler solutions with basic electronic sensors, for example.’ This approach is exemplified by vacuuming robots such as the Electrolux Trilobite. The Trilobite scuttles around homes emitting ultrasound signals to create maps of rooms, which are remembered for future cleaning. Technology like this is now changing the face of robotics, says philosopher Ron Chrisley, director of the Centre for Research in Cognitive Science at the University of Sussex in England.</p>

<p><strong>F</strong> Last year, a new Hong Kong restaurant, Robot Kitchen, opened with a couple of sensor-laden humanoid machines directing customers to their seats. Each possesses a touch-screen on which orders can be keyed in. The robot then returns with the correct dishes. In Japan, University of Tokyo researchers recently unveiled a kitchen ‘android’ that could wash dishes, pour tea and make a few limited meals. The ultimate aim is to provide robot home helpers for the sick and the elderly, a key concern in a country like Japan where 22 per cent of the population is 65 or older. Over US$1 billion a year is spent on research into robots that will be able to care for the elderly. ‘Robots first learn basic competence – how to move around a house without bumping into things. Then we can think about teaching them how to interact with humans,’ Chrisley said. Machines such as these take researchers into the field of socialised robotics: how to make robots act in a way that does not scare or offend individuals. ‘We need to study how robots should approach people, how they should appear. That is going to be a key area for future research,’ adds Chrisley.</p>

<p><strong>Questions 14-19</strong></p>

<p><strong>The text on the following pages has six paragraphs, A-F. Choose the correct heading for each paragraph from the list of headings (i-ix) below.</strong></p>

<p><strong>List of headings</strong><br>
i&nbsp;&nbsp;Tackling the issue using a different approach<br>
ii&nbsp;&nbsp;A significant improvement on last time<br>
iii&nbsp;&nbsp;How robots can save human lives<br>
iv&nbsp;&nbsp;Examples of robots at work<br>
v&nbsp;&nbsp;Not what it seemed to be<br>
vi&nbsp;&nbsp;Why timescales are impossible to predict<br>
vii&nbsp;&nbsp;The reason why robots rarely move<br>
viii&nbsp;&nbsp;Following the pattern of an earlier development<br>
ix&nbsp;&nbsp;The ethical issues of robotics
</p>

<p><strong>Questions 20-23</strong></p>

<p><strong>Look at the following statements (Questions 20-23) and the list of people below.</strong></p>

<p><strong>Match each statement with the correct person, A, B or C.</strong><br>
NB You may use any letter more than once.</p>

<p>
<strong>A</strong> Bill Gates<br>
<strong>B</strong> Nello Cristianini<br>
<strong>C</strong> Ron Chrisley
</p>

<p><strong>Questions 24-26</strong></p>

<p><strong>Complete the notes below. Write <em>NO MORE THAN THREE WORDS</em> from the passage.</strong></p>

<p><strong>Robot features</strong><br>
DARPA race cars: (24) ____________________ provides maps and plans for route<br>
Electrolux Trilobite: builds an image of a room by sending out (25) ____________________<br>
Robot Kitchen humanoids: have a (26) ____________________ to take orders
</p>

</div>','',2,'Passage 2',41);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-08-08 17:31:40','user_56659',false,'2026-08-08 17:31:40','user_56659','','','<div>

<p><strong>It’s your choice – or is it really?</strong></p>

<p>We are constantly required to process a wide range of information to make decisions. Sometimes, these decisions are trivial, such as what marmalade to buy. At other times, the stakes are higher, such as deciding which symptoms to report to the doctor. However, the fact that we are accustomed to processing large amounts of information does not mean that we are better at it (Chabris &amp; Simons, 2009). Our sensory and cognitive systems have systematic ways of failing of which we are often, perhaps blissfully, unaware.</p>

<p>Imagine that you are taking a walk in your local city park when a tourist approaches you asking for directions. During the conversation, two men carrying a door pass between the two of you. If the person asking for directions had changed places with one of the people carrying the door, would you notice? Research suggests that you might not. Harvard psychologists Simons and Levin (1998) conducted a field study using this exact set-up and found that the change in identity went unnoticed by 7 (46.6%) of the 15 participants. This phenomenon has been termed ‘change blindness’ and refers to the difficulty that observers have in noticing changes to visual scenes (e.g. the person swap), when the changes are accompanied by some other visual disturbance (e.g. the passing of the door).</p>

<p>Over the past decade, the change blindness phenomenon has been replicated many times. Especially noteworthy is an experiment by Davies and Hine (2007) who studied whether change blindness affects eyewitness identification. Specifically, participants were presented with a video enactment of a burglary. In the video, a man entered a house, walking through the different rooms and putting valuables into a knapsack. However, the identity of the burglar changed after the first half of the film while the initial burglar was out of sight. Out of the 80 participants, 49 (61%) did not notice the change of the burglar’s identity, suggesting that change blindness may have serious implications for criminal proceedings.</p>

<p>To most of us, it seems bizarre that people could miss such obvious changes while they are paying active attention. However, to catch those changes, attention must be targeted to the changing feature. In the study described above, participants were likely not to have been expecting the change to happen, and so their attention may have been focused on the valuables the burglar was stealing, rather than the burglar.</p>

<p>Drawing from change blindness research, scientists have come to the conclusion that we perceive the world in much less detail than previously thought (Johansson, Hall, &amp; Sikstrom, 2008). Rather than monitoring all of the visual details that surround us, we seem to focus our attention only on those features that are currently meaningful or important, ignoring those that are irrelevant to our current needs and goals. Thus at any given time, our representation of the world surrounding us is crude and incomplete, making it possible for changes or manipulations to go undetected (Chabris &amp; Simons, 2010).</p>

<p>Given the difficulty people have in noticing changes to visual stimuli, one may wonder what would happen if these changes concerned the decisions people make. To examine choice blindness, Hall and colleagues (2010) invited supermarket customers to sample two different kinds of jams and teas. After participants had tasted or smelled both samples, they indicated which one they preferred. Subsequently, they were purportedly given another sample of their preferred choice. On half of the trials, however, these were samples of the non-chosen jam or tea. As expected, only about one-third of the participants detected this manipulation. Based on these findings, Hall and colleagues proposed that choice blindness is a phenomenon that occurs not only for choices involving visual material, but also for choices involving gustatory and olfactory information.</p>

<p>Recently, the phenomenon has also been replicated for choices involving auditory stimuli (Sauerland, Sagana, &amp; Otgaar, 2012). Specifically, participants had to listen to three pairs of voices and decide for each pair which voice they found more sympathetic or more criminal. The voice was then presented again; however, the outcome was manipulated for the second voice pair and participants were presented with the non-chosen voice. Replicating the findings by Hall and colleagues, only 29% of the participants detected this change.</p>

<p>Merckelbach, Jelicic, and Pieters (2011) investigated choice blindness for intensity ratings of one’s own psychological symptoms. Their participants had to rate the frequency with which they experienced 90 common symptoms (e.g. anxiety, lack of concentration, stress, headaches etc.) on a 5-point scale. Prior to a follow-up interview, the researchers inflated ratings for two symptoms by two points. For example, when participants had rated their feelings of shyness as 2 (i.e. occasionally), it was changed to 4 (i.e. all the time). This time, more than half (57%) of the 28 participants were blind to the symptom rating escalation and accepted it as their own symptom intensity rating. This demonstrates that blindness is not limited to recent preference selections, but can also occur for intensity and frequency.</p>

<p>Together, these studies suggest that choice blindness can occur in a wide variety of situations and can have serious implications for medical and judicial outcomes. Future research is needed to determine how, in those situations, choice blindness can be avoided.</p>

<p><strong>Questions 27-31</strong></p>
<p><strong>Do the following statements agree with the claims of the writer in the text?</strong></p>
<p><strong>YES</strong> if the statement agrees with the claims of the writer<br>
<strong>NO</strong> if the statement contradicts the claims of the writer<br>
<strong>NOT GIVEN</strong> if it is impossible to say what the writer thinks about this</p>

<p><strong>Questions 32-36</strong></p>
<p><strong>Complete the table below. Choose NO MORE THAN TWO WORDS from the text for each answer.</strong></p>
<table cellspacing="0" class="Table" style="border-collapse:collapse; margin-left:1px">
	<tbody>
		<tr>
			<td colspan="5" style="border-bottom:1px solid black; border-left:1px solid black; border-right:1px solid black; border-top:1px solid black; height:38px; width:602px">
			<p style="text-align:center"><strong><span style="color:black">Experiments in change blindness</span></strong></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:1px solid black; border-right:1px solid black; border-top:none; height:44px; width:122px">
			<p style="text-align:center"><strong><span style="color:black">Researchers</span></strong></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:44px; vertical-align:top; width:120px">
			<p style="text-align:center"><strong><span style="color:black">Purpose of<br>
			experiment</span></strong></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:44px; vertical-align:top; width:120px">
			<p style="text-align:center"><strong><span style="color:black">Situation for<br>
			participants</span></strong></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:44px; vertical-align:top; width:120px">
			<p style="text-align:center"><strong><span style="color:black">Focus of</span></strong></p>

			<p style="text-align:center"><strong><span style="color:black">participants''</span></strong></p>

			<p style="text-align:center"><strong><span style="color:black">attention</span></strong></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:44px; vertical-align:top; width:120px">
			<p style="text-align:center"><strong><span style="color:black">Percentage unaware of<br>
			identity change</span></strong></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:1px solid black; border-right:1px solid black; border-top:none; height:58px; width:122px">
			<p><span style="color:black">Simons &amp; Levi, 1998</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:58px; vertical-align:top; width:120px">
			<p style="margin-left:7px; margin-right:7px"><span style="color:black">To illustrate change blindness caused by a (32)&nbsp; such as an object</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:58px; width:120px">
			<p style="margin-left:7px"><span style="color:black">Giving (33) ............. to a</span></p>

			<p style="margin-left:7px"><span style="color:black">stranger</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:58px; width:120px">
			<p style="margin-left:6px"><span style="color:black">The movement of</span></p>

			<p style="margin-left:6px"><span style="color:black">(34)............ </span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:58px; width:120px">
			<p style="margin-left:8px"><span style="color:black">46.6%</span></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:1px solid black; border-right:1px solid black; border-top:none; height:73px; width:122px">
			<p><span style="color:black">Davies &amp; Hine, 2007</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:73px; vertical-align:top; width:120px">
			<p><span style="color:black">To&nbsp;assess&nbsp;the&nbsp; impact&nbsp;of change blindness on (35)............... by eyewitnesses</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:73px; width:120px">
			<p style="margin-left:7px"><span style="color:black">Watching a burglary</span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:73px; width:120px">
			<p style="margin-left:6px"><span style="color:black">The&nbsp;collection&nbsp;of</span></p>

			<p style="margin-left:6px"><span style="color:black">(36)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
			</td>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:73px; vertical-align:top; width:120px">
			<p style="margin-left:8px"><span style="color:black">61 %</span></p>
			</td>
		</tr>
	</tbody>
</table>
<p><strong>Questions 37-38</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO statements are true for both the supermarket and voice experiments?</strong></p>

<p>
A. The researchers focused on non-visual material.<br>
B. The participants were asked to explain their preferences.<br>
C. Some of the choices made by participants were altered.<br>
D. The participants were influenced by each other’s choices.<br>
E. Percentage results were surprisingly low.
</p>

<p><strong>Questions 39-40</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO statements are true for the psychology experiment conducted by Merckelbach, Jelicic, and Pieters?</strong></p>

<p>
A. The participants had to select their two most common symptoms.<br>
B. The participants gave each symptom a 1-5 rating.<br>
C. Shyness proved to be the most highly rated symptom.<br>
D. The participants changed their minds about some of their ratings.<br>
E. The researchers focused on the strength and regularity of symptoms.
</p>

</div>','',3,'',41),
	 ('2026-08-09 17:31:40','user_56659',false,'2026-08-09 17:31:40','user_56659','','','<div>

<p><strong>Secrets of the swarm</strong></p>

<p>Insects, birds and fish tend to be the creatures that humans feel furthest from. Unlike many mammals they do not engage in human-like behaviour. The way they swarm or flock together does not usually get good press coverage either: marching like worker ants might be a common simile for city commuters, but it’s a damning, not positive, image. Yet a new school of scientific theory suggests that these swarms might have a lot to teach us.</p>

<p>American author Peter Miller explains, ‘I used to think that individual ants knew where they were going, and what they were supposed to do when they got there. But Deborah Gordon, a biologist at Stanford University, showed me that nothing an ant does makes any sense except in terms of the whole colony. Which makes you wonder if, as individuals, we don’t serve a similar function for the companies where we work or the communities where we live.’ Ants are not intelligent by themselves. Yet as a colony, they make wise decisions. And as Gordon discovered during her research, there’s no one ant making decisions or giving orders.</p>

<p>Take food collecting, for example. No ant decides, ‘There’s lots of food around today; lots of ants should go out to collect it.’ Instead, some forager ants go out, and as soon as they find food, they pick it up and come back to the nest. At the entrance, they brush past reserve foragers, sending a ‘go out’ signal. The faster the foragers come back, the more food there is and the faster other foragers go out, until gradually the amount of food being brought back diminishes. An organic calculation has been made to answer the question, ‘How many foragers does the colony need today?’ And if something goes wrong – a hungry lizard prowling around for an ant snack, for instance – then a rush of ants returning without food sends waiting reserves a ‘Don’t go out’ signal.</p>

<p>But could such decentralised control work in a human organisation? Miller visited a Texas gas company that has successfully applied formulas based on ant colony behaviour to ‘optimise its factories and route its trucks’. He explains, ‘If ant colonies had worked out a reliable way to identify the best routes between their nest and food sources, the company managers figured, why not take advantage of that knowledge?’ So they came up with a computer model, based on the self-organising principles of an ant colony. Data is fed into the model about deliveries needing to be made the next day, as well as things like weather conditions, and it produces a simulation determining the best route for the delivery lorries to take.</p>

<p>Miller explains that he first really understood the impact that swarm behaviour could have on humans when he read a study of honeybees by Tom Seeley, a biologist at Cornell University. The honeybees choose as a group which new nest to move to. First, scouts fly off to investigate multiple sites. When they return they do a ‘waggle dance’ for their spot, and other scouts will then fly off and investigate it. Many bees go out, but none tries to compare all sites. Each reports back on just one. The more they liked their nest, the more vigorous and lengthy their waggle dance and the more bees will choose to visit it. Gradually the volume of bees builds up towards one site; it’s a system that ensures that support for the best site snowballs and the decision is made in the most democratic way.</p>

<p>Humans, too, can make clever decisions through diversity of knowledge and a little friendly competition. ‘The best example of shared decision-making that I witnessed during my research was a town meeting I attended in Vermont, where citizens met face-to-face to debate their annual budget,’ explains Miller. ‘For group decision-making to work well, you need a way to sort through the various options they propose; and you need a mechanism to narrow down these options.’ Citizens in Vermont control their municipal affairs by putting forward proposals, or backing up others’ suggestions, until a consensus is reached through a vote. As with the bees, the broad sampling of options before a decision is made will usually result in a compromise acceptable to all. The ‘wisdom of the crowd’ makes clever decisions for the good of the group – and leaves citizens feeling represented and respected.</p>

<p>The Internet is also an area where we are increasingly exhibiting swarm behaviour, without any physical contact. Miller compares a wiki website, for example, to a termite mound. Indirect collaboration is the key principle behind information-sharing web sites, just as it underlies the complex constructions that termites build. Termites do not have an architect’s blueprint or a grand construction scheme. They simply sense changes in their environment, as for example when the mound’s wall has been damaged, altering the circulation of air. They go to the site of the change and drop a grain of soil. When the next termite finds that grain, they drop theirs too. Slowly, without any kind of direct decision-making, a new wall is built. A termite mound, in this way, is rather like a wiki website. Rather than meeting up and talking about what we want to post online, we just add to what someone – maybe a stranger on the other side of the world – already wrote. This indirect knowledge and skill-sharing is now finding its way into the corridors of power.</p>

<p><strong>Questions 1-6</strong></p>

<p><strong>Do the following statements agree with the information in the text?</strong></p>

<p>
<strong>TRUE</strong> if the statement agrees with the information<br>
<strong>FALSE</strong> if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> if there is no information on this
</p>

<p><strong>Questions 7-9</strong></p>

<p><strong>Complete each sentence with the correct ending, A-F, below.</strong></p>

<p>
<strong>A</strong> provide support for each other’s ideas in order to reach the best outcome.<br>
<strong>B</strong> use detailed comments to create large and complicated systems.<br>
<strong>C</strong> use decision-making strategies based on insect communities to improve their service.<br>
<strong>D</strong> communicate with each other to decide who the leader will be.<br>
<strong>E</strong> contribute independently to the ideas of others they do not know.<br>
<strong>F</strong> repair structures they have built without directly communicating with each other.
</p>

<p><strong>Questions 10-13</strong></p>

<p><strong>Complete the flow-chart below. Choose <em>NO MORE THAN TWO WORDS</em> from the text for each answer.</strong></p>
<table cellspacing="0" class="Table" style="border-collapse:collapse">
	<tbody>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:1px solid black; height:30px; width:511px">
			<p style="text-align:center"><strong><span style="color:black">How honeybees choose a new nest</span></strong></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:30px; width:511px">
			<p style="text-align:center"><span style="color:black">Honeybee (10)................................................. explore possible net sites</span></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:29px; width:511px">
			<p style="text-align:center"><span style="color:black">They perform what is known as a (11).......................................... on their return</span></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:29px; width:511px">
			<p style="text-align:center"><span style="color:black">Other bees go out and report back</span></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:29px; width:511px">
			<p style="text-align:center"><span style="color:black">Enthusiasm and (12).......................................... increase for one particular site</span></p>
			</td>
		</tr>
		<tr>
			<td style="border-bottom:1px solid black; border-left:none; border-right:1px solid black; border-top:none; height:30px; width:511px">
			<p style="text-align:center"><span style="color:black">A final choice is reached using a (13).............................................. process</span></p>
			</td>
		</tr>
	</tbody>
</table>
</div>','',1,'Passage 1',42),
	 ('2026-08-10 17:31:40','user_56659',false,'2026-08-10 17:31:40','user_56659','','','<div>

<p><strong>High speed, high rise</strong></p>

<p><strong>A</strong> Zhang Yue is founder and chairman of Broad Sustainable Building (otherwise known as ‘Broad’) who, on 1 January, 2012, released a time-lapse video of its 30-story achievement. It shows construction workers buzzing around like gnats while a clock in the corner of the screen marks the time. In just 360 hours, a 100-metre-tall tower called the T30 rises from an empty site to overlook Hunan’s Xiang River. At the end of the video, the camera spirals around the building overhead as the Broad logo appears on the screen: a lowercase b that wraps around itself in an imitation of the @ symbol. The company is in the process of franchising its technology to partners in India, Brazil, and Russia. What it is selling is the world’s first standardized skyscraper and with it, Zhang aims to turn Broad into the McDonald’s of the sustainable building industry. When asked why he decided to start a construction company, Zhang replies, ‘It’s not a construction company. It’s a structural revolution.’</p>

<p><strong>B</strong> So far, Broad has built 16 structures in China, plus another in Cancun. They are fabricated at two factories in Hunan, roughly an hour’s drive from Broad Town, the sprawling headquarters. The floors and ceilings of the skyscrapers are built in sections, each measuring 15.6 by 3.9 meters with a depth of 45 centimeters. Pipes and ducts for electricity, water and waste are threaded through each floor module while it is still in the factory. The client’s choice of flooring is also pre-installed on top. Standardized truckloads carry two modules each to the site with the necessary columns, bolts and tools to connect them stacked on top of each other. Once they arrive at the location, each section is lifted by crane directly to the top of the building, which is assembled like toy Lego bricks. Workers use the materials on the module to quickly connect the pipes and wires. The unique column design has diagonal bracing at each end and tabs that bolt into the floors above and below. In the final step, heavily insulated exterior walls and windows are slotted in by crane. The result is far from pretty but the method is surprisingly safe – and phenomenally fast.</p>

<p><strong>C</strong> Zhang attributes his success to his creativity and to his outsider perspective on technology. He started out as an art student in the 1980s, but in 1988, Zhang left the art world to found Broad. The company started out as a maker of non-pressurized boilers. His senior vice-president, Juliet Jiang, says, ‘He made his fortune on boilers. He could have kept doing this business, but … he saw the need for nonelectric air-conditioning.’ Towards the end of the decade, China’s economy was expanding past the capacity of the nation’s electricity grid, she explains. Power shortages were becoming a serious obstacle to growth. Large air-conditioning (AC) units fueled by natural gas could help companies ease their electricity load, reduce overheads, and enjoy more reliable climate control into the bargain. Today, Broad has units operating in more than 70 countries, in some of the largest buildings and airports on the planet.</p>

<p><strong>D</strong> For two decades, Zhang’s AC business boomed. But a couple of events conspired to change his course. The first was that Zhang became an environmentalist. The second was the earthquake that hit China’s Sichuan Province in 2008, causing the collapse of poorly constructed buildings. Initially, he says, he tried to convince developers to refit existing buildings to make them both more stable and more sustainable, but he had little success. So Zhang drafted his own engineers and started researching how to build cheap, environmentally friendly structures that could also withstand an earthquake. Within six months of starting his research, Zhang had given up on traditional methods. He was frustrated by the cost of hiring designers and specialists for each new structure. The best way to cut costs, he decided, was to take building to the factory. But to create a factory-built skyscraper, Broad had to abandon the principles by which skyscrapers are typically designed. The whole load-bearing structure had to be different. To reduce the overall weight of the building, it used less concrete in the floors; that in turn enabled it to cut down on structural steel.</p>

<p><strong>E</strong> Around the world, prefabricated and modular buildings are gaining in popularity. But modular and prefabricated buildings elsewhere are, for the most part, low-rise. Broad is alone in applying these methods to skyscrapers. For Zhang, the environmental savings alone justify the effort. According to Broad’s numbers, a traditional high-rise will produce about 3,000 tons of construction waste, while a Broad building will produce only 25 tons. Traditional buildings also require 5,000 tons of water onsite to build, while Broad buildings use none. The building process is also less dangerous. Elevator systems – the base, rails, and machine room – can be installed at the factory, eliminating the risk of injury. And instead of shipping an elevator car to the site in pieces, Broad orders a finished car and drops it into the shaft by crane. In the future, elevator manufacturers are hoping to preinstall the doors, completely eliminating any chance that a worker might fall. ‘Traditional construction is chaotic,’ he says. ‘We took construction and moved it into the factory.’ According to Zhang, his buildings will help solve the many problems of the construction industry and what’s more, they will be quicker and cheaper to build.</p>

<p><strong>Questions 14-18</strong></p>

<p><strong>The text on the following pages has five paragraphs, A-E. Choose the correct heading for each paragraph from the list of headings below. Write the correct number, i-viii, in boxes 14-18 on your answer sheet.</strong></p>

<p><strong>List of Headings</strong><br>
i&nbsp;&nbsp;A joint business project<br>
ii&nbsp;&nbsp;Other engineering achievements<br>
iii&nbsp;&nbsp;Examining the overall benefits<br>
iv&nbsp;&nbsp;A building like no other<br>
v&nbsp;&nbsp;Some benefits of traditional methods<br>
vi&nbsp;&nbsp;A change of direction<br>
vii&nbsp;&nbsp;Examples of similar global brands<br>
viii&nbsp;&nbsp;From factory to building site
</p>

<p><strong>Questions 19-22</strong></p>

<p><strong>Label the diagram below. Choose ONE WORD ONLY from the text for each answer.</strong></p>

<p>
<img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780827766/c02e7bca-b60a-404e-8b2c-545f6b870a5f_0e68a777759aa361d0e0fdcb624095fe53bb7f38.jpg" alt="High speed high rise diagram" style="max-width:100%;height:auto;">
</p>

<p><strong>Questions 23-26</strong></p>

<p><strong>Complete the sentences below. Choose NO MORE THAN TWO WORDS from the text for each answer.</strong></p>

</div>','',2,'Passage 2',42),
	 ('2026-08-11 17:31:40','user_56659',false,'2026-08-11 17:31:40','user_56659','','','<div>

<p><strong>When conversations flow</strong></p>

<p>We spend a large part of our daily life talking with other people and, consequently, we are very accustomed to the art of conversing. But why do we feel comfortable in conversations that have flow, but get nervous and distressed when a conversation is interrupted by unexpected silences? To answer this question we will first look at some of the effects of conversational flow. Then we will explain how flow can serve different social needs.</p>

<p>The positive consequences of conversational flow show some similarities with the effects of ‘processing fluency’. Research has shown that processing fluency – the ease with which people process information – influences peoples’ judgments across a broad range of social dimensions. For instance, people feel that when something is easily processed, it is more true or accurate. Moreover, they have more confidence in their judgments regarding information that came to them fluently, and they like things that are easy to process more than things that are difficult to process. Research indicates that a speaker is judged to be more knowledgeable when they answer questions instantly; responding with disfluent speech markers such as ‘uh’ or ‘um’ or simply remaining silent for a moment too long can destroy that positive image.</p>

<p>One of the social needs addressed by conversational flow is the human need for ‘synchrony’ – to be ‘in sync’ or in harmony with one another. Many studies have shown how people attempt to synchronize with their partners, by coordinating their behavior. This interpersonal coordination underlies a wide array of human activities, ranging from more complicated ones like ballroom dancing to simply walking or talking with friends.</p>

<p>In conversations, interpersonal coordination is found when people adjust the duration of their utterances and their speech rate to one another so that they can enable turn-taking to occur, without talking over each other or experiencing awkward silences. Since people are very well-trained in having conversations, they are often able to take turns within milliseconds, resulting in a conversational flow of smoothly meshed behaviors. A lack of flow is characterized by interruptions, simultaneous speech or mutual silences. Avoiding these features is important for defining and maintaining interpersonal relationships.</p>

<p>The need to belong has been identified as one of the most basic of human motivations and plays a role in many human behaviors. That conversational flow is related to belonging may be most easily illustrated by the consequences of flow disruptions. What happens when the positive experience of flow is disrupted by, for instance, a brief silence? We all know that silences can be pretty awkward, and research shows that even short disruptions in conversational flow can lead to a sharp rise in distress levels. In movies, silences are often used to signal non-compliance or confrontation (Piazza, 2006). Some researchers even argue that ‘silencing someone’ is one of the most serious forms of exclusion. Group membership is of elementary importance to our wellbeing and because humans are very sensitive to signals of exclusion, a silence is generally taken as a sign of rejection. In this way, a lack of flow in a conversation may signal that our relationship is not as solid as we thought it was.</p>

<p>Another aspect of synchrony is that people often try to validate their opinions to those of others. That is, people like to see others as having similar ideas or worldviews as they have themselves, because this informs people that they are correct and their worldviews are justified. One way in which people can justify their worldviews is by assuming that, as long as their conversations run smoothly, their interaction partners probably agree with them. This idea was tested by researchers using video observations. Participants imagined being one out of three people in a video clip who had either a fluent conversation or a conversation in which flow was disrupted by a brief silence. Except for the silence, the videos were identical. After watching the video, participants were asked to what extent the people in the video agreed with each other. Participants who watched the fluent conversation rated agreement to be higher than participants watching the conversation that was disrupted by a silence, even though participants were not consciously aware of the disruption. It appears that the subjective feeling of being out of sync informs people of possible disagreements, regardless of the content of the conversation.</p>

<p>Because people are generally so well-trained in having smooth conversations, any disruption of this flow indicates that something is wrong, either interpersonally or within the group as a whole. Consequently, people who do not talk very easily may be incorrectly understood as being less agreeable than those who have no difficulty keeping up a conversation. On a societal level, one could even imagine that a lack of conversational flow may hamper the integration of immigrants who have not completely mastered the language of their new country yet. In a similar sense, the ever-increasing number of online conversations may be disrupted by misinterpretations and anxiety that are produced by insuperable delays in the Internet connection. Keeping in mind the effects of conversational flow for feelings of belonging and validation may help one to be prepared to avoid such misunderstandings in future conversations.</p>

<p><strong>Questions 27-32</strong></p>
<p><strong>Do the following statements agree with the claims of the writer in the text?</strong></p>
<p><strong>YES</strong> if the statement agrees with the claims of the writer<br>
<strong>NO</strong> if the statement contradicts the claims of the writer<br>
<strong>NOT GIVEN</strong> if it is impossible to say what the writer thinks about this</p>

<p><strong>Questions 33-40</strong></p>
<p><strong>Complete the summary below. Choose NO MORE THAN TWO WORDS from the text for each answer.</strong></p>

<p><strong>Synchrony</strong></p>

<p>
There is a human desire to co-ordinate (33)………………………. in an effort to be ‘in harmony’. This co-ordination can be seen in conversations when speakers alter the speed and extent of their speech in order to facilitate (34)……………………………. This is often achieved within milliseconds: only tiny pauses take place when a conversation flows; when it doesn’t, there are (35)…………………………….. and silences, or people talk at the same time. Our desire to (36)……………………………. is also an important element of conversation flow. According to research, our (37)…………………………………….. increase even if silences are brief. Humans have a basic need to be part of a group, and they experience a sense of (38)……………………………. if silences exclude them. People also attempt to co-ordinate their opinions in conversation. In an experiment, participants’ judgement of the overall (39)………………………………. among speakers was tested using videos of a fluent and a slightly disrupted conversation. The results showed that the (40)……………………………….. of the speakers’ discussion was less important than the perceived synchrony of the speakers.
</p>

</div>','',3,'Passage 3',42),
	 ('2026-08-12 17:31:40','user_56659',false,'2026-08-12 17:31:40','user_56659','','','<div>

<p><strong>South pole adventurer</strong></p>

<p>FOR a few weeks in January 1912, Antarctica was full of explorers. Norwegian Roald Amundsen had reached the South Pole on 14 December and was speeding back to the coast. On 17 January, Robert Scott and the men of the British Antarctic expedition had arrived at the pole to find they had been beaten to it. Just then, a third man arrived; Japanese explorer Nobu Shirase. However, his part in one of the greatest adventure stories of the 20th century is hardly known outside his own country, even by fellow explorers. Yet as Scott was nearing the pole and with the rest of the world still unaware of Amundsen’s triumph, Shirase and his team sailed into Antarctica’s Bay of Whales in the smallest ship ever to try its luck in these dangerous waters.</p>

<p>Since boyhood Shirase had dreamed of becoming a polar explorer. Like Amundsen, he initially set his sights on the North Pole. But after the American Robert Peary claimed to have reached it in 1909, both men hastily altered their plans. Instead they would aim for the last big prize: the South Pole. In January 1910, Shirase put his plans before Japanese government officials, promising to raise the flag at the South Pole within three years. For many of them, the question wasn’t could he do it but why would it be worth doing? 15 years earlier the International Geographical Congress had said that as the last unknown continent the Antarctic offered the chance to add to knowledge in almost every branch of science. So, like the British, Shirase presented his expedition as a search for knowledge: he would bring back fossils, make meteorological measurements and explore unknown parts of the continent.</p>

<p>The response from the government was cool, however, and Shirase struggled to raise funds. Fortunately, a few months later, Japan’s former prime minister Shigenobu Okuma came to Shirase’s rescue. With Okuma’s backing, Shirase got together just enough money to buy and equip a small ship. He eventually acquired a scientist, too, called Terutaro Takeda. At the end of November 1910, his ship the Kainan Maru finally left Tokyo with 27 men and 28 Siberian dogs on board. Before leaving, Shirase confidently outlined his plans to the media. He would sail to New Zealand, then reach Antarctica in February, during the southern summer, and then proceed to the pole the following spring. This was not to be, however. Bad weather delayed the expedition and they didn’t reach New Zealand until 8 February; Amundsen and Scott had already been in Antarctica for a month, preparing for winter.</p>

<p>In New Zealand local reporters were astonished: the ship was half the size of Amundsen’s ship. True, it was reinforced with iron plate and extra wood, but the ship had only the feeblest engine to help force its way through ice. Few doubted Shirase’s courage, but most reckoned the expedition to be ill-prepared as the Japanese had only lightweight sledges for transport across the ice, made of bamboo and wood.</p>

<p>But Shirase’s biggest challenge was time. Antarctica is only accessible by sea for a few weeks in summer and expeditions usually aimed to arrive in January or February. ‘Even with their determination and daring, our Japanese friends are running it rather fine,’ wrote local reporters. Nevertheless, on 11 February the Kainan Maru left New Zealand and sailed straight into the worst weather the captain had ever seen. Then, on 6 March, they approached the coastline of Antarctica’s Ross Sea, looking for a place to land. The ice began to close in, threatening to trap them for the winter, an experience no one was likely to survive. With a remarkable piece of seamanship, the captain steered the ship out of the ice and turned north. They would have to wait out the winter in a warmer climate.</p>

<p>A year later than planned, Shirase and six men finally reached Antarctica. Catching up with Scott or Amundsen was out of the question and he had said he would stick to science this time. Yet Shirase still felt the pull of the pole and eventually decided he would head southward to experience the thrills and hardships of polar exploration he had always dreamed of. With provisions for 20 days, he and four men would see how far they could get.</p>

<p>Shirase set off on 20 January 1912 with Takeda and two dog handlers, leaving two men at the edge of the ice shelf to make meteorological measurements. For a week they struggled through one blizzard after another, holing up in their tents during the worst of the weather. The temperature fell to -25°C, and frostbite claimed some of the dogs. On 26 January, Shirase estimated there were enough provisions to continue for two more days. Two days later, he announced it was time to turn back. Takeda calculated they had reached 80° 5'' south and had travelled 250 kilometres. The men hoisted the Japanese flag.</p>

<p>On 3 February, all the men were heading home. The ship reached Tokyo in June 1912 – and Shirase was greeted like a hero despite the fact that he never reached the pole. Nor did he contribute much to science – but then nor did Amundsen, whose only interest was in being first to the pole. Yet Shirase’s expedition was heroic. They travelled beyond 80° south, one of only four teams to have gone so far south at the time. Furthermore, they did it all without the advantages of the other teams and with no previous experience.</p>

<p><strong>Questions 1-8</strong></p>

<p><strong>Do the following statements agree with the information given in Reading Passage 1?</strong></p>

<p>
<strong>TRUE</strong> if the statement agrees with the information<br>
<strong>FALSE</strong> if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> if there is no information on this
</p>

</div>','',1,'Passage 1',43),
	 ('2026-08-13 17:31:40','user_56659',false,'2026-08-13 17:31:40','user_56659','','','<div>

<p><strong>The rise of agribots</strong></p>

<p>The next time you stand at the supermarket checkout, spare a thought for the farmers who helped fill your shopping basket as life is hard for them right now. This, in turn, inevitably means bigger grocery bills for consumers, and greater hardship for the millions in countries where food shortages are a matter of life and death. Worse, studies suggest that the world will need twice as much food by 2050. Yet while farmers must squeeze more out of the land, they must also address the necessity of reducing their impact on the soil, waterways and atmosphere. All this means rethinking how agriculture is practiced, and taking automation to a whole new level. On the new model farms of the future, precision will be key. Why dose a whole field with chemicals if you can spray only where they are needed? Each plant could get exactly the right amount of everything, no more or less, an approach that could slash chemical use and improve yields in one move. But this is easier said than done; the largest farms in Europe and the U.S. can cover thousands of acres. That’s why automation is key to precision farming. Specifically, say agricultural engineers, precision farming needs robot farmers.</p>

<p>One day, we might see fields with ‘agribots’ (agricultural robots) that can identify individual seedlings and encourage them along with drops of fertilizer. Other machines would distinguish problem weeds from crops and eliminate them with shots from high-power lasers or a microdot of pesticide. These machines will also be able to identify and harvest all kinds of vegetables. More than a century of mechanization has already turned farming into an industrial-scale activity in much of the world, with farms that grow cereals being the most heavily automated.</p>

<p>But a variety of other crops, including oranges and tomatoes destined to become processed foods, are also picked mechanically, albeit to a slightly lesser extent. Yet the next wave of autonomous farm machinery is already at work. You probably haven’t even noticed, for these robots are disguised as tractors. Many are self-steering, use GPS to cross a field, and can even ‘talk’ to their implements – a plough or sprayer, for example. And the implements can talk back, telling the tractor that it’s going too fast or needs to move to the left. This kind of communication is also being developed in other farm vehicles. A new system allows a combine harvester, say, to send a call over to a tractor-trailer so the driver can unload the grain as and when necessary.</p>

<p>However, when fully autonomous systems take to the field, they’ll look nothing like tractors. With their enormous size and weight, today’s farm machines have significant downsides: they compact the soil, reducing porosity and killing beneficial life, meaning crops don’t grow so well. Simon Blackmore, who researches agricultural technology at Harper Adams University College in England believes that fleets of lightweight autonomous robots have the potential to solve this problem and that replacing brute force with precision is key. ‘A seed only needs one cubic centimeter of soil to grow. If we cultivate just that we only put tiny amounts of energy in and the plants still grow nicely.’ There is another reason why automation may be the way forward according to Eldert van Henten, a robotics researcher at Wageningen University in the Netherlands. ‘While the population is growing and needs to be fed, a rapidly shrinking number of people are willing to work in agriculture,’ he points out. Other researchers such as Linda Calvin, an economist at the U.S. Department of Agriculture, and Philip Martin at the University of California, Davis, have studied trends in mechanization to predict how US farms might fare. Calvin and Martin have observed how rising employment costs have led to the adoption of labour-saving farm technology in the past, citing the raisin industry as an example. In 2000, a bumper harvest crashed prices and, with profits squeezed, farmers looked for a solution. With labour one of their biggest costs – 42 percent of production expenses on U.S. farms, on average – they started using a mechanical harvester adapted from a machine used by wine makers. By 2007, almost half of California’s raisins were mechanically harvested and a labour force once numbering 50,000 had shrunk to 30,000.</p>

<p>As well as having an impact on the job market, the widespread adoption of agribots might bring changes at the supermarket. Lewis Holloway, who studies agriculture at the University of Hull, UK, says that robotic milking is likely to influence the genetics of dairy herds as farmers opt for ‘robot-friendly’ cows, with udder shape, and even attitudes, suited to automated milking. Similarly, he says, it’s conceivable that agribots could influence what fruit or vegetable varieties get to the shops, since farmers may prefer to grow those with, say, leaf shapes that are easier for their robots to discriminate from weeds. Almost inevitably, these machines will eventually alter the landscape, too. The real tipping point for robot agriculture will come when farms are being designed with agribots in mind, says Salah Sukkarieh, a robotics researcher at the Australian Center for Field Robotics, Sydney. This could mean a return to smaller fields, with crops planted in grids rather than rows and fruit trees pruned into two-dimensional shapes to make harvesting easier. This alien terrain tended by robots is still a while away, he says ‘but it will happen.’</p>

<p><strong>Questions 14-17</strong></p>
<p><strong>Do the following statements agree with the claims of the writer in Reading Passage 2?</strong></p>
<p>
<strong>YES</strong> if the statement agrees with the claims of the writer<br>
<strong>NO</strong> if the statement contradicts the claims of the writer<br>
<strong>NOT GIVEN</strong> if it is impossible to say what the writer thinks about this
</p>

<p><strong>Questions 22-26</strong></p>
<p><strong>Look at the following researchers (Questions 22-26) and the list of statements below. Match each researcher with the correct statement, A-H.</strong></p>

<p><strong>List of Findings</strong></p>

<p>
A. The use of automation might impact on the development of particular animal and plant species.<br>
B. We need to consider the effect on employment that increased automation will have.<br>
C. We need machines of the future to be exact, not more powerful.<br>
D. As farming becomes more automated the appearance of farmland will change.<br>
E. New machinery may require more investment than certain farmers can afford.<br>
F. There is a shortage of employees in the farming industry.<br>
G. There are limits to the environmental benefits of automation.<br>
H. Economic factors are often the driving force behind the development of machinery.
</p>

</div>','',2,'Passage 2',43),
	 ('2026-08-14 17:31:40','user_56659',false,'2026-08-14 17:31:40','user_56659','','','<div>

<p><strong>Homer’s Literary Legacy</strong></p>

<p><strong>A</strong> Until the last tick of history’s clock, cultural transmission meant oral transmission and poetry, passed from mouth to ear, was the principal medium of moving information across space and from one generation to the next. Oral poetry was not simply a way of telling lovely or important stories, or of flexing the imagination. It was, argues the classicist Eric Havelock, a “massive repository of useful knowledge, a sort of encyclopedia of ethics, politics, history and technology which the effective citizen was required to learn as the core of his educational equipment”. The great oral works transmitted a shared cultural heritage, held in common not on bookshelves, but in brains. In India, an entire class of priests was charged with memorizing the Vedas with perfect fidelity. In pre-Islamic Arabia, people known as Rawis were often attached to poets as official memorizers. The Buddha’s teachings were passed down in an unbroken chain of oral tradition for four centuries until they were committed to writing in Sri Lanka in the first century B.C.</p>

<p><strong>B</strong> The most famous of the Western tradition’s oral works, and the first to have been systematically studied, were Homer’s Odyssey and Iliad. These two poems – possibly the first to have been written down in the Greek alphabet – had long been held up as literary archetypes. However, even as they were celebrated as the models to which all literature should aspire, Homer’s masterworks had also long been the source of scholarly unease. The earliest modern critics sensed that they were somehow qualitatively different from everything that came after – even a little strange. For one thing, both poems were oddly repetitive in the way they referred to characters. Odysseus was always “clever Odysseus”. Dawn was always “rosy-fingered”. Why would someone write that? Sometimes the epithets seemed completely off-key. Why call the murderer of Agamemnon “blameless Aegisthos”? Why refer to “swift-footed Achilles” even when he was sitting down? Or to “laughing Aphrodite” even when she was in tears? In terms of both structure and theme, the Odyssey and Iliad were also oddly formulaic, to the point of predictability. The same narrative units – gathering armies, heroic shields, challenges between rivals – pop up again and again, only with different characters and different circumstances. In the context of such finely spun, deliberate masterpieces, these quirks seemed hard to explain.</p>

<p><strong>C</strong> At the heart of the unease about these earliest works of literature were two fundamental questions: first, how could Greek literature have been born ex nihilo with two masterpieces? Surely a few less perfect stories must have come before, and yet these two were among the first on record. And second, who exactly was their author? Or was it authors? There were no historical records of Homer, and no trustworthy biography of the man exists beyond a few self-referential hints embedded in the texts themselves.</p>

<p><strong>D</strong> Jean-Jacques Rousseau was one of the first modern critics to suggest that Homer might not have been an author in the contemporary sense of a single person who sat down and wrote a story and then published it for others to read. In his 1781 Essay on the Origin of Languages, the Swiss philosopher suggested that the Odyssey and Iliad might have been “written only in men’s memories. Somewhat later they were laboriously collected in writing” – though that was about as far as his enquiry into the matter went.</p>

<p><strong>E</strong> In 1795, the German philologist Friedrich August Wolf argued for the first time that not only were Homer’s works not written down by Homer, but they weren’t even by Homer. They were, rather, a loose collection of songs transmitted by generations of Greek bards, and only redacted in their present form at some later date. In 1920, an eighteen-year-old scholar named Milman Parry took up the question of Homeric authorship as his Master’s thesis at the University of California, Berkeley. He suggested that the reason Homer’s epics seemed unlike other literature was because they were unlike other literature. Parry had discovered what Wood and Wolf had missed: the evidence that the poems had been transmitted orally was right there in the text itself. All those stylistic quirks, including the formulaic and recurring plot elements and the bizarrely repetitive epithets – “clever Odysseus” and “gray-eyed Athena” – that had always perplexed readers were actually like thumbprints left by a potter: material evidence of how the poems had been crafted. They were mnemonic aids that helped the bard(s) fit the meter and pattern of the line, and remember the essence of the poems.</p>

<p><strong>F</strong> The greatest author of antiquity was actually, Parry argued, just “one of a long tradition of oral poets that… composed wholly without the aid of writing”. Parry realised that if you were setting out to create memorable poems, the Odyssey and the Iliad were exactly the kind of poems you’d create. It’s said that clichés are the worst sin a writer can commit, but to an oral bard, they were essential. The very reason that clichés so easily seep into our speech and writing – their insidious memorability – is exactly why they played such an important role in oral storytelling. The principles that the oral bards discovered as they sharpened their stories through telling and retelling were the same mnemonic principles that psychologists rediscovered when they began conducting their first scientific experiments on memory around the turn of the twentieth century. Words that rhyme are much more memorable than words that don’t, and concrete nouns are easier to remember than abstract ones. Finding patterns and structure in information is how our brains extract meaning from the world, and putting words to music and rhyme is a way of adding extra levels of pattern and structure to language.</p>

<p><strong>Questions 27-32</strong></p>
<p><strong>Reading Passage 3 has six paragraphs, A-F.</strong></p>
<p><strong>Which paragraph contains the following information?</strong></p>
<p><em>NB: You may use each option more than once.</em></p>

<p><strong>Questions 33-34</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO of these points are made by the writer of the text about the Odyssey and the Iliad?</strong></p>

<p>
A. They are sometimes historically inaccurate.<br>
B. It is uncertain which century they were written in.<br>
C. Their content is very similar.<br>
D. Later writers referred to them as ideal examples of writing.<br>
E. There are stylistic differences between them.
</p>

<p><strong>Questions 35-36</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO of the following theories does the writer of the text refer to?</strong></p>

<p>
A. Homer wrote his work during a period of captivity.<br>
B. Neither the Odyssey nor the Iliad were written by Homer.<br>
C. Homer created the Odyssey and Iliad without writing them down.<br>
D. Homer may have suffered from a failing memory in later life.<br>
E. The oral and written versions of Homer’s work may not be identical.
</p>

<p><strong>Questions 37-40</strong></p>
<p><strong>Complete the summary below. Choose ONE WORD ONLY from the passage for each answer.</strong></p>

<p><strong>The importance of the spoken word and how words are remembered</strong></p>

<p>
Spoken poetry was once the means by which each (37) __________________ of a particular culture or community could pass on its knowledge. Indeed, it has been suggested that it was the duty of a (38) __________________ to know poetry so they would be informed about subjects such as politics and history.
</p>

<p>
Psychologists now know that when people are trying to remember information, they may find it difficult to remember words that express (39) __________________ ideas. It is easier to remember words which sound similar or go together with (40) __________________.
</p>

</div>','',3,'Passage 3',43),
	 ('2026-08-15 17:31:40','user_56659',false,'2026-08-15 17:31:40','user_56659','','','<div>

<p><strong>THE IMPORTANCE OF CHILDREN’S PLAY</strong></p>

<p>Brick by brick, six-year-old Alice is building a magical kingdom. Imagining fairy-tale turrets and fire-breathing dragons, wicked witches and gallant heroes, she’s creating an enchanting world. Although she isn’t aware of it, this fantasy is helping her take her first steps towards her capacity for creativity and so it will have important repercussions in her adult life.</p>

<p>Minutes later, Alice has abandoned the kingdom in favour of playing schools with her younger brother. When she bosses him around as his ‘teacher’, she’s practising how to regulate her emotions through pretence. Later on, when they tire of this and settle down with a board game, she’s learning about the need to follow rules and take turns with a partner.</p>

<p>‘Play in all its rich variety is one of the highest achievements of the human species,’ says Dr David Whitebread from the Faculty of Education at the University of Cambridge, UK. ‘It underpins how we develop as intellectual, problem-solving adults and is crucial to our success as a highly adaptable species.’</p>

<p>Recognizing the importance of play is not new: over two millennia ago, the Greek philosopher Plato extolled its virtues as a means of developing skills for adult life, and ideas about play-based learning have been developing since the 19th century.</p>

<p>But we live in changing times, and Whitebread is mindful of a worldwide decline in play, pointing out that over half the people in the world now live in cities. ‘The opportunities for free play, which I experienced almost every day of my childhood, are becoming increasingly scarce,’ he says. Outdoor play is curtailed by perceptions of risk to do with traffic, as well as parents’ increased wish to protect their children from being the victims of crime, and by the emphasis on ‘earlier is better’ which is leading to greater competition in academic learning and schools.</p>

<p>International bodies like the United Nations and the European Union have begun to develop policies concerned with children’s right to play, and to consider implications for leisure facilities and educational programmes. But what they often lack is the evidence to base policies on.</p>

<p>‘The type of play we are interested in is child-initiated, spontaneous and unpredictable – but, as soon as you ask a five-year-old “to play”, then you as the researcher have intervened,’ explains Dr Sara Baker. ‘And we want to know what the long-term impact of play is. It’s a real challenge.’</p>

<p>Dr Jenny Gibson agrees, pointing out that although some of the steps in the puzzle of how and why play is important have been looked at, there is very little data on the impact it has on the child’s later life.</p>

<p>Now, thanks to the university’s new Centre for Research on Play in Education, Development and Learning (PEDAL), Whitebread, Baker, Gibson and a team of researchers hope to provide evidence on the role played by play in how a child develops.</p>

<p>‘A strong possibility is that play supports the early development of children’s self-control,’ explains Baker. ‘This is our ability to develop awareness of our own thinking processes – it influences how effectively we go about undertaking challenging activities.’</p>

<p>In a study carried out by Baker with toddlers and young pre-schoolers, she found that children with greater self-control solved problems more quickly when exploring an unfamiliar set-up requiring scientific reasoning. ‘This sort of evidence makes us think that giving children the chance to play will make them more successful problem-solvers in the long run.’</p>

<p>If playful experiences do facilitate this aspect of development, say the researchers, it could be extremely significant for educational practices, because the ability to self-regulate has been shown to be a key predictor of academic performance.</p>

<p>Gibson adds: ‘Playful behavior is also an important indicator of healthy social and emotional development. In my previous research, I investigated how observing children at play can give us important clues about their well-being and can even be useful in the diagnosis of neurodevelopmental disorders like autism.’</p>

<p>Whitebread’s recent research has involved developing a play-based approach to supporting children’s writing. ‘Many primary school children find writing difficult, but we showed in a previous study that a playful stimulus was far more effective than an instructional one.’ Children wrote longer and better-structured stories when they first played with dolls representing characters in the story. In the latest study, children first created their story with Lego, with similar results. ‘Many teachers commented that they had always previously had children saying they didn’t know what to write about. With the Lego building, however, not a single child said this through the whole year of the project.’</p>

<p>Whitebread, who directs PEDAL, trained as a primary school teacher in the early 1970s, when, as he describes, ‘the teaching of young children was largely a quiet backwater, untroubled by any serious intellectual debate or controversy.’ Now, the landscape is very different, with hotly debated topics such as school starting age.</p>

<p>‘Somehow the importance of play has been lost in recent decades. It’s regarded as something trivial, or even as something negative that contrasts with “work”. Let’s not lose sight of its benefits, and the fundamental contributions it makes to human achievements in the arts, sciences and technology. Let’s make sure children have a rich diet of play experiences.’</p>

<p><strong>Questions 1-8</strong></p>
<p><strong>Complete the notes below.</strong></p>
<p><strong>Choose ONE WORD ONLY from the passage for each answer.</strong></p>

<p><strong>Children’s play</strong></p>

<p><strong>Uses of children’s play</strong></p>
<p>
• building a ‘magical kingdom’ may help develop <strong>1</strong> …………………………………<br>
• board games involve <strong>2</strong> ……………………………. and turn-taking
</p>

<p><strong>Recent changes affecting children’s play</strong></p>
<p>
• populations of <strong>3</strong> ……………………… have grown<br>
• opportunities for free play are limited due to
</p>

<p>
– fear of <strong>4</strong> ……………………………<br>
– fear of <strong>5</strong> ……………………………<br>
– increased <strong>6</strong> …………………………… in schools
</p>

<p><strong>International policies on children’s play</strong></p>

<p>
• it is difficult to find <strong>7</strong> …………………………… to support new policies<br>
• research needs to study the impact of play on the rest of the child’s <strong>8</strong> ……………………………..
</p>

<p><strong>Questions 9-13</strong></p>

<p><strong>Do the following statements agree with the information given in Reading Passage 1?</strong></p>

<p>
<strong>TRUE</strong> if the statement agrees with the information<br>
<strong>FALSE</strong> if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> if there is no information on this
</p>

</div>','',1,'Passage 1',44),
	 ('2026-08-16 17:31:40','user_56659',false,'2026-08-16 17:31:40','user_56659','','','<div>

<p><strong>The growth of bike-sharing schemes around the world</strong></p>

<p><em>How Dutch engineer Luud Schimmelpennink helped to devise urban bike-sharing schemes</em></p>

<p><strong>A</strong></p>

<p>The original idea for an urban bike-sharing scheme dates back to a summer’s day in Amsterdam in 1965. Provo, the organization that came up with the idea, was a group of Dutch activists who wanted to change society. They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism. In the centre of Amsterdam, they painted a small number of used bikes white. They also distributed leaflets describing the dangers of cars and inviting people to use the white bikes. The bikes were then left unlocked at various locations around the city, to be used by anyone in need of transport.</p>

<p><strong>B</strong></p>

<p>Luud Schimmelpennink, a Dutch industrial engineer who still lives and cycles in Amsterdam, was heavily involved in the original scheme. He recalls how the scheme succeeded in attracting a great deal of attention – particularly when it came to publicising Provo’s aims – but struggled to get off the ground. The police were opposed to Provo’s initiatives and almost as soon as the white bikes were distributed around the city, they removed them. However, for Schimmelpennink and for bike-sharing schemes in general, this was just the beginning. ‘The first Witte Fietsenplan was just a symbolic thing,’ he says. ‘We painted a few bikes white, that was all. Things got more serious when I became a member of the Amsterdam city council two years later.’</p>

<p><strong>C</strong></p>

<p>Schimmelpennink seized this opportunity to present a more elaborate Witte Fietsenplan to the city council. ‘My idea was that the municipality of Amsterdam would distribute 10,000 white bikes over the city, for everyone to use,’ he explains. ‘I made serious calculations. It turned out that a white bicycle – per person, per kilometer – would cost the municipality only 10% of what it contributed to public transport per person per kilometer.’ Nevertheless, the council unanimously rejected the plan. ‘They said that the bicycle belongs to the past. They saw a glorious future for the car,’ says Schimmelpennink. But he was not in the least discouraged.</p>

<p><strong>D</strong></p>

<p>Schimmelpennink never stopped believing in bike-sharing, and in the mid-90s, two Danes asked for his help to set up a system in Copenhagen. The result was the world’s first large-scale bike-share programme. It worked on a deposit: ‘You dropped a coin in the bike and when you returned it, you got your money back.’ After setting up the Danish system, Schimmelpennink decided to try his luck again in the Netherlands – and this time he succeeded in arousing the interest of the Dutch Ministry of Transport. ‘Times had changed,’ he recalls. ‘People had become more environmentally conscious, and the Danish experiment had proved that bike-sharing was a real possibility.’ A new Witte Fietsenplan was launched in 1999 in Amsterdam. However, riding a white bike was no longer free; it cost one guilder per trip and payment was made with a chip card developed by the Dutch bank Postbank. Schimmelpennink designed conspicuous, sturdy white bikes locked in special racks which could be opened with the chip card – the plan started with 250 bikes, distributed over five stations.</p>

<p><strong>E</strong></p>

<p>Theo Molenaar, who was a system designer for the project, worked alongside Schimmelpennink. ‘I remember when we were testing the bike racks, he announced that he had already designed better ones. But of course, we had to go through with the ones we had.’ The system, however, was prone to vandalism and theft. ‘After every weekend there would always be a couple of bikes missing,’ Molenaar says. ‘I really have no idea what people did with them, because they could instantly be recognised as white bikes.’ But the biggest blow came when Postbank decided to abolish the chip card, because it wasn’t profitable. ‘That chip card was pivotal to the system,’ Molenaar says. ‘To continue the project we would have needed to set up another system, but the business partner had lost interest.’</p>

<p><strong>F</strong></p>

<p>Schimmelpennink was disappointed, but – characteristically – not for long. In 2002 he got a call from the French advertising corporation JC Decaux, who wanted to set up his bike-sharing scheme in Vienna. ‘That went really well. After Vienna, they set up a system in Lyon. Then in 2007, Paris followed. That was a decisive moment in the history of bike-sharing.’ The huge and unexpected success of the Parisian bike-sharing programme, which now boasts more than 20,000 bicycles, inspired cities all over the world to set up their own schemes, all modelled on Schimmelpennink’s. ‘It’s wonderful that this happened,’ he says. ‘But financially I didn’t really benefit from it, because I never filed for a patent.’</p>

<p><strong>G</strong></p>

<p>In Amsterdam today, 38% of all trips are made by bike and, along with Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the world – but the city never got another Witte Fietsenplan. Molenaar believes this may be because everybody in Amsterdam already has a bike. Schimmelpennink, however, cannot see that this changes Amsterdam’s need for a bike-sharing scheme. ‘People who travel on the underground don’t carry their bikes around. But often they need additional transport to reach their final destination.’ Although he thinks it is strange that a city like Amsterdam does not have a successful bike-sharing scheme, he is optimistic about the future. ‘In the ‘60s we didn’t stand a chance because people were prepared to give their lives to keep cars in the city. But that mentality has totally changed. Today everybody longs for cities that are not dominated by cars.’</p>

<p><strong>Questions 14-18</strong></p>
<p><strong>Reading Passage 2 has seven paragraphs, A-G.</strong></p>
<p><strong>Which paragraph contains the following information?</strong></p>
<p><strong>Write the correct letter, A-G, in boxes 14-18 on your answer sheet.</strong></p>
<p><strong>NB You may use any letter more than once.</strong></p>

<p><strong>Questions 19-20</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO of the following statements are made in the text about the Amsterdam bike-sharing scheme of 1999?</strong></p>

<p>
A. It was initially opposed by a government department.<br>
B. It failed when a partner in the scheme withdrew support.<br>
C. It aimed to be more successful than the Copenhagen scheme.<br>
D. It was made possible by a change in people’s attitudes.<br>
E. It attracted interest from a range of bike designers.
</p>

<p><strong>Questions 21-22</strong></p>
<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO of the following statements are made in the text about Amsterdam today?</strong></p>

<p>
A. The majority of residents would like to prevent all cars from entering the city.<br>
B. There is little likelihood of the city having another bike-sharing scheme.<br>
C. More trips in the city are made by bike than by any other form of transport.<br>
D. A bike-sharing scheme would benefit residents who use public transport.<br>
E. The city has a reputation as a place that welcomes cyclists.
</p>

<p><strong>Questions 23-26</strong></p>
<p><strong>Complete the summary below.</strong></p>
<p><strong>Choose ONE WORD ONLY from the passage for each answer.</strong></p>

<p><strong>The first urban bike-sharing scheme</strong></p>

<p>
The first bike-sharing scheme was the idea of the Dutch group Provo. The people who belonged to this group were <strong>23</strong> ……………………….. They were concerned about damage to the environment and about <strong>24</strong> ……………………….., and believed that the bike-sharing scheme would draw attention to these issues. As well as painting some bikes white, they handed out <strong>25</strong> ……………………….. that condemned the use of cars.
</p>

<p>
However, the scheme was not a great success: almost as quickly as Provo left the bikes around the city, the <strong>26</strong> ………………………. took them away. According to Schimmelpennink, the scheme was intended to be symbolic. The idea was to get people thinking about the issues.
</p>

</div>','',2,'Passage 2',44),
	 ('2026-08-17 17:31:40','user_56659',false,'2026-08-17 17:31:40','user_56659','','','<div>

<p><strong>Motivational factors and the hospitality industry</strong></p>

<p>A critical ingredient in the success of hotels is developing and maintaining superior performance from their employees. How is that accomplished? What Human Resource Management (HRM) practices should organizations invest in to acquire and retain great employees?</p>

<p>Some hotels aim to provide superior working conditions for their employees. The idea originated from workplaces – usually in the non-service sector – that emphasized fun and enjoyment as part of work-life balance. By contrast, the service sector, and more specifically hotels, has traditionally not extended these practices to address basic employee needs, such as good working conditions.</p>

<p>Pfeffer (1994) emphasizes that in order to succeed in a global business environment, organizations must make investment in Human Resource Management (HRM) to allow them to acquire employees who possess better skills and capabilities than their competitors. This investment will be to their competitive advantage. Despite this recognition of the importance of employee development, the hospitality industry has historically been dominated by underdeveloped HR practices (Lucas, 2002).</p>

<p>Lucas also points out that ‘the substance of HRM practices does not appear to be designed to foster constructive relations with employees or to represent a managerial approach that enables developing and drawing out the full potential of people, even though employees may be broadly satisfied with many aspects of their work’ (Lucas, 2002). In addition, or maybe as a result, high employee turnover has been a recurring problem throughout the hospitality industry. Among the many cited reasons are low compensation, inadequate benefits, poor working conditions and compromised employee morale and attitudes (Maroudas et al., 2008).</p>

<p>Ng and Sorensen (2008) demonstrated that when managers provide recognition to employees, motivate employees to work together, and remove obstacles preventing effective performance, employees feel more obligated to stay with the company. This was succinctly summarized by Michel et al. (2013): ‘[P]roviding support to employees gives them the confidence to perform their jobs better and the motivation to stay with the organization.’ Hospitality organizations can therefore enhance employee motivation and retention through the development and improvement of their working conditions. These conditions are inherently linked to the working environment.</p>

<p>While it seems likely that employees’ reactions to their job characteristics could be affected by a predisposition to view their work environment negatively, no evidence exists to support this hypothesis (Spector et al., 2000). However, given the opportunity, many people will find something to complain about in relation to their workplace (Poulston, 2009). There is a strong link between the perceptions of employees and particular factors of their work environment that are separate from the work itself, including company policies, salary and vacations.</p>

<p>Such conditions are particularly troubling for the luxury hotel market, where high-quality service, requiring a sophisticated approach to HRM, is recognized as a critical source of competitive advantage (Maroudas et al., 2008). In a real sense, the services of hotel employees represent their industry (Schneider and Bowen, 1993). This representation has commonly been limited to guest experiences. This suggests that there has been a dichotomy between the guest environment provided in luxury hotels and the working conditions of their employees.</p>

<p>It is therefore essential for hotel management to develop HRM practices that enable them to inspire and retain competent employees. This requires an understanding of what motivates employees at different levels of management and different stages of their careers (Enz and Siguaw, 2000). This implies that it is beneficial for hotel managers to understand what practices are most favorable to increase employee satisfaction and retention.</p>

<p>Herzberg (1966) proposes that people have two major types of needs, the first being extrinsic motivation factors relating to the context in which work is performed, rather than the work itself. These include working conditions and job security. When these factors are unfavorable, job dissatisfaction may result. Significantly, though, just fulfilling these needs does not result in satisfaction, but only in the reduction of dissatisfaction (Maroudas et al., 2008).</p>

<p>Employees also have intrinsic motivation needs or motivators, which include such factors as achievement and recognition. Unlike extrinsic factors, motivator factors may ideally result in job satisfaction (Maroudas et al., 2008). Herzberg’s (1966) theory discusses the need for a ‘balance’ of these two types of needs.</p>

<p>The impact of fun as a motivating factor at work has also been explored. For example, Tews, Michel and Stafford (2013) conducted a study focusing on staff from a chain of themed restaurants in the United States. It was found that fun activities had a favorable impact on performance and manager support for fun had a favorable impact in reducing turnover. Their findings support the view that fun may indeed have a beneficial effect, but the framing of that fun must be carefully aligned with both organizational goals and employee characteristics. ‘Managers must learn how to achieve the delicate balance of allowing employees the freedom to enjoy themselves at work while simultaneously high levels of performance’ (Tews et al., 2013).</p>

<p>Deery (2008) has recommended several actions that can be adopted at the organizational level to retain good staff as well as assist in balancing work and family life. Those particularly appropriate to the hospitality industry include allowing adequate breaks during the working day, staff functions that involve families, and providing health and well-being opportunities.</p>

<p><strong>Questions 27-31</strong></p>

<p><strong>Look at the following statements (Questions 27-31) and the list of researchers below.</strong></p>

<p><strong>Match each statement with the correct researcher, A-F.</strong></p>

<p><strong>List of Researchers</strong></p>

<p>
A. Pfeffer<br>
B. Lucas<br>
C. Maroudas et al.<br>
D. Ng and Sorensen<br>
E. Enz and Siguaw<br>
F. Deery
</p>

<p><strong>Questions 32-35</strong></p>

<p><strong>Do the following statements agree with the claims of the writer in Reading Passage 3?</strong></p>

<p>
<strong>YES</strong> if the statement agrees with the claims of the writer<br>
<strong>NO</strong> if the statement contradicts the claims of the writer<br>
<strong>NOT GIVEN</strong> if it is impossible to say what the writer thinks about this
</p>

<p><strong>Questions 36-40</strong></p>

<p><strong>Complete the summary below.</strong></p>

<p><strong>Choose ONE WORD ONLY from the passage for each answer.</strong></p>

<p><strong>Fun at work</strong></p>

<p>
Tews, Michel and Stafford carried out research on staff in an American chain of <strong>36</strong> ……………………… . They discovered that activities designed for staff to have fun improved their <strong>37</strong> ……………………… , and that management involvement led to lower staff <strong>38</strong> ………………………….. . They also found that the activities needed to fit with both the company’s <strong>39</strong> ………………………….. and the <strong>40</strong> …………………………. of the staff. A balance was required between a degree of freedom and maintaining work standards.
</p>

</div>','',3,'Passage 3',44);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-08-18 17:31:40','user_05335',false,'2026-08-18 17:31:40','user_05335','','','<h1>Trees in Trouble</h1>

<p><strong>A</strong> Big trees are incredibly important ecologically. For a start, they sustain countless other species. They provide shelter for many animals, and their trunks and branches can become gardens, hung with green ferns, orchids and bromeliads, coated with mosses and draped with vines. With their tall canopies basking in the sun, they capture vast amounts of energy. This allows them to produce massive crops of fruit, flowers and foliage that sustain much of the animal life in the forest.</p>

<p><strong>B</strong> Only a small number of tree species have the genetic capacity to grow really big. The mightiest are native to North America, but big trees grow all over the globe, from the tropics to the boreal forests of the high latitudes. To achieve giant stature, a tree needs three things: the right place to establish its seedling, good growing conditions and lots of time with low adult mortality. Disrupt any of these, and you can lose your biggest trees.</p>

<p><strong>C</strong> In some parts of the world, populations of big trees are dwindling because their seedlings cannot survive or grow. In southern India, for instance, an aggressive non-native shrub, Lantana camara, is invading the floor of many forests. Lantana grows so thickly that young trees often fail to take root. With no young trees to replace them, it is only a matter of time before most of the big trees disappear. Across much of northern Australia, gamba grass from Africa is overrunning native savannah woodlands. The grass grows up to four metres tall and burns fiercely, creating super-hot fires that cause catastrophic tree mortality.</p>

<p><strong>D</strong> Without the right growing conditions trees cannot get really big, and there is some evidence to suggest tree growth could slow in a warmer world, particularly in environments that are already warm. Having worked for decades at La Selva Biological Station in Puerto Viejo de Sarapiqui, Costa Rica, David and Deborah Clark and colleagues have shown that tree growth there declines markedly in warmer years. “During the day, their photosynthesis shuts down when it gets too warm, and at night they consume more energy because their metabolic rate increases, much as a reptile’s would when it gets warmer,” explains David Clark. With less energy produced in warmer years and more being consumed just to survive, there is even less energy available for growth.</p>

<p><strong>E</strong> The Clarks’ hypothesis, if correct, means tropical forests would shrink over time. The largest, oldest trees would progressively die off and tend not to be replaced. According to the Clarks, this might trigger a destabilisation of the climate; as older trees die, forests would release some of their stored carbon into the atmosphere, prompting a vicious cycle of further warming, forest shrinkage and carbon emissions.</p>

<p><strong>F</strong> Big trees face threats from elsewhere. The most serious is increasing mortality, especially of mature trees. Across much of the planet, forests of slow-growing ancient trees have been cleared for human use. In western North America, most have been replaced by monocultures of fast-growing conifers. Siberia’s forests are being logged at an incredible rate. Logging in tropical forests is selective but the timber cutters usually prioritise the biggest and oldest trees. In the Amazon, my colleagues and I found the mortality rate for the biggest trees had tripled in small patches of rainforest surrounded by pasture land. This happens for two reasons. First, as they grow taller, big trees become thicker and less flexible: when winds blow across the surrounding cleared land, there is nothing to stop their acceleration. When they hit the trees, the impact can snap them in half. Second, rainforest fragments dry out when surrounded by dry, hot pastures and the resulting drought can have devastating consequences: one four-year study has shown that death rates will double for smaller trees but will increase 4.5 times for bigger trees.</p>

<p><strong>G</strong> Particular enemies to large trees are insects and disease. Across vast areas of western North America, increasingly mild winters are causing massive outbreaks of bark beetle. These tiny creatures can kill entire forests as they tunnel their way through the inside of trees. In both North America and Europe, fungus-causing diseases such as Dutch elm disease have killed off millions of stately trees that once gave beauty to forests and cities. As a result of human activity, such enemies reach even the remotest corners of the world, threatening to make the ancient giants a thing of the past.</p>

<h2>Questions 1–7</h2>

<p><strong>Reading Passage 1</strong> has seven paragraphs, A–G. Choose the correct heading for each paragraph from the list of headings below. Write the correct number, i–x, in boxes 1–7 on your answer sheet.</p>

<h3>List of Headings</h3>

<ol type="i">
    <li>How deforestation harms isolated trees</li>
    <li>How other plants can cause harm</li>
    <li>Which big trees support the most diverse species</li>
    <li>Impact of big tree loss on the wider environment</li>
    <li>Measures to prevent further decline in big tree populations</li>
    <li>How wildlife benefits from big trees</li>
    <li>Risk from pests and infection</li>
    <li>Ways in which industry uses big tree products</li>
    <li>How higher temperatures slow the rate of tree growth</li>
    <li>Factors that enable trees to grow to significant heights</li>
</ol>

<h2>Questions 8–13</h2>

<p>Complete the sentences below.</p>

<p><strong>Choose NO MORE THAN TWO WORDS</strong> from the passage for each answer.</p>','',1,'Passage 1',45),
	 ('2026-08-19 17:31:40','user_05335',false,'2026-08-19 17:31:40','user_05335','','','<h1>Whale Strandings</h1>

<p>
When the last stranded whale of a group eventually dies, the story does not end there.
A team of researchers begins to investigate, collecting skin samples for instance,
recording anything that could help them answer the crucial question: why?
Theories abound, some more convincing than others. In recent years, navy sonar has
been accused of causing certain whales to strand. It is known that noise pollution
from offshore industry, shipping and sonar can impair underwater communication,
but can it really drive whales onto our beaches?
</p>

<p>
In 1998, researchers at the Pelagos Cetacean Research Institute, a Greek non-profit
scientific group, linked whale strandings with low-frequency sonar tests being carried
out by the North Atlantic Treaty Organisation (NATO). They recorded the stranding of
12 Cuvier’s beaked whales over 38.2 kilometres of coastline. NATO later admitted it
had been testing new sonar technology in the same area at the time as the strandings
had occurred. ‘Mass’ whale strandings involve four or more animals. Typically they all
wash ashore together, but in mass atypical strandings (such as the one in Greece),
the whales don’t strand as a group; they are scattered over a larger area.
</p>

<p>
For humans, hearing a sudden loud noise might prove frightening, but it does not induce
mass fatality. For whales, on the other hand, there is a theory on how sonar can kill.
The noise can surprise the animal, causing it to swim too quickly to the surface.
The result is decompression sickness, a hazard human divers know all too well.
If a diver ascends too quickly from a high-pressure underwater environment to a
lower-pressure one, gases dissolved in blood and tissue expand and form bubbles.
The bubbles block the flow of blood to vital organs, and can ultimately lead to death.
</p>

<p>
Plausible as this seems, it is still a theory and based on our more comprehensive
knowledge of land-based animals. For this reason, some scientists are wary.
Whale expert Karen Evans is one such scientist. Another is Rosemary Gales,
a leading expert on whale strandings. She says sonar technology cannot always be blamed
for mass strandings. “It’s a case-by-case situation. Whales have been stranding for a
very long time – pre-sonar.” And when 80% of all Australian whale strandings occur
around Tasmania, Gales and her team must continue in the search for answers.
</p>

<p>
When animals beach next to each other at the same time, the most common cause has
nothing to do with humans at all. “They’re highly social creatures,” says Gales.
“When they mass strand – it’s complete panic and chaos. If one of the group strands
and sounds the alarm, others will try to swim to its aid, and become stuck themselves.”
</p>

<p>
Activities such as sonar testing can hint at when a stranding may occur, but if
conservationists are to reduce the number of strandings, or improve rescue operations,
they need information on where strandings are likely to occur as well. With this in mind,
Ralph James, physicist at the University of Western Australia in Perth, thinks he may
have discovered why whales turn up only on some beaches. In 1986 he went to Augusta,
Western Australia, where more than 100 false killer whales had beached.
“I found out from chatting to the locals that whales had been stranding there for decades.
So I asked myself, what is it about this beach?” From this question that James pondered
over 20 years ago, grew the university’s Whale Stranding Analysis Project.
</p>

<p>
Data has since revealed that all mass strandings around Australia occur on gently
sloping sandy beaches, some with inclines of less than 0.5%. For whale species that
depend on an echolocation system to navigate, this kind of beach spells disaster.
Usually, as they swim, they make clicking noises, and the resulting sound waves are
reflected in an echo and travel back to them. However, these just fade out on shallow
beaches, so the whale doesn’t hear an echo and it crashes onto the shore.
</p>

<p>
But that is not all. Physics, it appears, can help with the when as well as the where.
The ocean is full of bubbles. Larger ones rise quickly to the surface and disappear,
whilst smaller ones – called microbubbles – can last for days. It is these that absorb
whale ‘clicks’. “Rough weather generates more bubbles than usual,” James adds.
So, during and after a storm, echolocating whales are essentially swimming blind.
</p>

<p>
Last year was a bad one for strandings in Australia. Can we predict if this – or any
other year – will be any better? Some scientists believe we can. They have found trends
which could be used to forecast ‘bad years’ for strandings in the future. In 2005,
a survey by Klaus Vanselow and Klaus Ricklefs of sperm whale strandings in the North Sea
even found a correlation between these and the sunspot cycle, and suggested that changes
in the Earth’s magnetic field might be involved. But others are sceptical.
“Their study was interesting … but the analyses they used were flawed on a number of levels,”
says Evans. In the same year, she co-authored a study on Australian strandings that
uncovered a completely different trend. “We analysed data from 1920 to 2002 …
and observed a clear periodicity in the number of whales stranded each year that
coincides with a major climatic cycle.” To put it more simply, she says, in the years
when strong westerly and southerly winds bring cool water rich in nutrients closer to
the Australia coast, there is an increase in the number of fish. The whales follow.
</p>

<p>
So what causes mass strandings? “It’s probably many different components,” says James.
And he is probably right. But the point is we now know what many of those components are.
</p>

<h2>Questions 14–17</h2>

<p>
Answer the questions below. Choose <strong>NO MORE THAN TWO WORDS</strong>
from the passage for each answer.
</p>

<h2>Questions 18–21</h2>

<p>
Label the diagram below. Choose <strong>NO MORE THAN TWO WORDS</strong>
for each answer.
</p>
<img
    src="https://res.cloudinary.com/dilyyimrn/image/upload/v1780824447/6db756cb-ffe0-4807-a069-70637dc93830_127782c01d0b7cd34f63ff07745648823b57aa45.jpg"
    alt="Whale Strandings Diagram Questions 18-21"
    style="max-width:100%;height:auto;"
>
<h2>Questions 22–26</h2>

<p>
Do the following statements agree with the information given in Reading Passage 2?
</p>

<ul>
    <li><strong>TRUE</strong> — if the statement agrees with the information</li>
    <li><strong>FALSE</strong> — if the statement contradicts the information</li>
    <li><strong>NOT GIVEN</strong> — if there is no information on this</li>
</ul>','',2,'Passage 2',45),
	 ('2026-08-20 17:31:40','user_05335',false,'2026-08-20 17:31:40','user_05335','','','<h1>Science in Space</h1>

<p>
A premier, world-class laboratory in low Earth orbit. That was how the National Aeronautics and Space Administration agency (NASA) sold the International Space Station (ISS) to the US Congress in 2001. Today no one can doubt the agency’s technological ambition. The most complex engineering project ever attempted has created an enormous set of interlinked modules that orbits the planet at more than 27,000 kilometres per hour. It might be travelling fast but, say critics, as a lab it is going nowhere. So far, it has gone through $150 billion.
</p>

<p>
So where should its future priorities lie? This question was addressed at the recent 1st annual ISS research and development conference in Colorado. Among the presenters was Satoshi Iwase of Aichi Medical University in Japan who has spent several years developing an experiment that could help solve one of the key problems that humans will face in space: keeping our bodies healthy in weightlessness. One thing that physiologists have learned is that without gravity our bodies begin to lose strength, leaving astronauts with weakened bones, muscles and cardiovascular systems. To counter these effects on a long-duration mission to, say, Mars, astronauts will almost certainly need to create their own artificial gravity. This is where Iwase comes in. He leads a team designing a centrifuge for humans. In their preliminary design, an astronaut is strapped into the seat of a machine that resembles an exercise bike. Pedalling provides a workout for the astronaut’s muscles and cardiovascular system, but it also causes the seat to rotate vertically around a central axis so the rider experiences artificial gravity while exercising.
</p>

<p>
The centrifuge project highlights the station’s potential as a research lab. Similar machines have flown in space aboard NASA’s shuttles, but they couldn’t be tested for long enough to prove whether they were effective. It’s been calculated that to properly assess a centrifuge’s impact on human physiology, astronauts would have to ride it for 30 minutes a day for at least two months. The only way to test this is in weightlessness, and the only time we have to do that is on the space station,’ says Laurence Young, a space medicine expert at the Massachusetts Institute of Technology.
</p>

<p>
There are certainly plenty of ideas for other experiments, but many projects have yet to fly. Even if the centrifuge project gets the green light, it will have to wait another five years before the station’s crew can take a spin. Lengthy delays like this are one of the key challenges for NASA, according to an April 2011 report from the US National Academy of Sciences. Its authors said they were ‘deeply concerned’ about the state of NASA’s science research, and made a number of recommendations. Besides suggesting that the agency reduces the time between approving experiments and sending them into space, it also recommended setting clearer research priorities.
</p>

<p>
NASA has already begun to take action, hiring management consultants ProOrbis to develop a plan to cut through the bureaucracy. And Congress also directed NASA to hire an independent organisation, the Centre for the Advancement of Science in Space (CASIS), to help manage the station’s US lab facilities. One of CASIS’s roles is to convince public and private investors that science on the station is worth the spend because judged solely by the number of papers published, the ISS certainly seems poor value: research on the station has generated about 3,100 papers since 1998. The Hubble Space Telescope, meanwhile, has produced more than 11,300 papers in just over 20 years, yet it cost less than one-tenth of the price of the space station.
</p>

<p>
Yet Mark Uhran, assistant associate administrator for the ISS, refutes the criticism that the station hasn’t done any useful research. He points to progress made on a salmonella vaccine, for example. To get the ISS research back on track, CASIS has examined more than 100 previous microgravity experiments to identify promising research themes. From this, it has opted to focus on life science and medical research, and recently called for proposals for experiments on muscle wasting, osteoporosis and the immune system. The organisation also maintains that the ISS should be used to develop products with commercial application and to test those that are either close to or already on the market. Investment from outside organisations is vital, says Uhran, and a balance between academic and commercial research will help attract this.
</p>

<p>
The station needs to attract cutting-edge research, yet many scientists seem to have little idea what goes on aboard it. Jeanne DiFrancesco at ProOrbis conducted more than 200 interviews with people from organisations with potential interests in low gravity studies. Some were aware of the ISS but they didn’t know what’s going on up there, she says. ‘Others know there’s science, but they don’t know what kind.’
</p>

<p>
According to Alan Stern, planetary scientist, the biggest public relations boost for the ISS may come from the privately funded space flight industry. Companies like SpaceX could help NASA and its partners when it comes to resupplying the ISS, as it suggests it can reduce launch costs by two-thirds. Virgin Atlantic’s Space Ship Two or ZeroUnfinity’s high-altitude balloon could also boost the space station’s fortunes. They might not come close to the ISS’s orbit, yet Stern believes they will revolutionise the way we, the public, see space. Soon everyone will be dreaming of interplanetary travel again, he predicts. More importantly, scientists are already queuing for seats on these low-gravity space-flight services so they can collect data during a few minutes of weightlessness. This demand for low-cost space flight could eventually lead to a service running on a more frequent basis, giving researchers the chance to test their ideas before submitting a proposal for experiments on the ISS. Getting flight experience should help them win a slot on the station, says Stern.
</p>

<h2>Questions 31–35</h2>

<p>
Look at the following opinions (Questions 31–35) and the list of people below.
Match each opinion with the correct person, A, B, C or D.
Write the correct letter, A, B, C or D, in boxes 31–35 on your answer sheet.
</p>

<p><strong>NB:</strong> You may use any letter more than once.</p>

<h3>List of people</h3>

<ul>
    <li>A Laurence Young</li>
    <li>B Authors of the US National Academy of Sciences report</li>
    <li>C Mark Uhran</li>
    <li>D Jeanne DiFrancesco</li>
</ul>

<h2>Questions 36–39</h2>

<p>
Complete the summary using the lists of words, A–H, below.
Write the correct letter, A–H, in boxes 36–39 on your answer sheet.
</p>

<ul>
    <li>A safe</li>
    <li>B competitive</li>
    <li>C flexible</li>
    <li>D real</li>
    <li>E rapid</li>
    <li>F regular</li>
    <li>G suitable</li>
    <li>H economical</li>
</ul>

<h3>The influence of commercial space flight on the ISS</h3>

<p>
According to Alan Stern, private space companies could affect the future of the ISS.
He believes they could change its image; firstly because sending food and equipment
there would be more <strong>(36)</strong> ____________________ if a commercial craft were used,
and secondly, because commercial flights might make the whole idea of space exploration
seem <strong>(37)</strong> ____________________ to ordinary people.
Another point is that as the demand for space flights increases, there is a chance of them becoming more
<strong>(38)</strong> ____________________.
And by working on a commercial flight first, scientists would be more
<strong>(39)</strong> ____________________ if an ISS position came up.
</p>','',3,'Passage 3',45),
	 ('2026-08-21 17:31:40','user_05335',false,'2026-08-21 17:31:40','user_05335','','','<h1>Why Are Finland’s Schools Successful?</h1>

<h2>Reading Passage 1</h2>

<p><strong>A</strong> At Kirkkojarvi Comprehensive School in Espoo, a suburb west of Helsinki, Kari Louhivuori, the school’s principal, decided to try something extreme by Finnish standards. One of his sixth-grade students, a recent immigrant, was falling behind, resisting his teacher’s best efforts. So he decided to hold the boy back a year. Standards in the country have vastly improved in reading, math and science literacy over the past decade, in large part because its teachers are trusted to do whatever it takes to turn young lives around. ‘I took Besart on that year as my private student,’ explains Louhivuori. When he was not studying science, geography and math, Besart was seated next to Louhivuori’s desk, taking books from a tall stack, slowly reading one, then another, then devouring them by the dozens. By the end of the year, he had conquered his adopted country’s vowel-rich language and arrived at the realization that he could, in fact, learn.</p>

<p><strong>B</strong> This tale of a single rescued child hints at some of the reasons for Finland’s amazing record of education success. The transformation of its education system began some 40 years ago but teachers had little idea it had been so successful until 2000. In this year, the first results from the Programme for International Student Assessment (PISA), a standardized test given to 15-year-olds in more than 40 global venues, revealed Finnish youth to be the best at reading in the world. Three years later, they led in math. By 2006, Finland was first out of the 57 nations that participate in science. In the latest PISA scores, the nation came second in science, third in reading and sixth in math among nearly half a million students worldwide.</p>

<p><strong>C</strong> In the United States, government officials have attempted to improve standards by introducing marketplace competition into public schools. In recent years, a group of Wall Street financiers and philanthropists such as Bill Gates have put money behind private-sector ideas, such as charter schools, which have doubled in number in the past decade. President Obama, too, apparently thought competition was the answer. One policy invited states to compete for federal dollars using tests and other methods to measure teachers, a philosophy that would not be welcome in Finland. ‘I think, in fact, teachers would tear off their shirts,’ said Timo Heikkinen, a Helsinki principal with 24 years of teaching experience. ‘If you only measure the statistics, you miss the human aspect.’</p>

<p><strong>D</strong> There are no compulsory standardized tests in Finland, apart from one exam at the end of students’ senior year in high school. There is no competition between students, schools or regions. Finland’s schools are publicly funded. The people in the government agencies running them, from national officials to local authorities, are educators rather than business people or politicians. Every school has the same national goals and draws from the same pool of university-trained educators. The result is that a Finnish child has a good chance of getting the same quality education no matter whether he or she lives in a rural village or a university town.</p>

<p><strong>E</strong> It’s almost unheard of for a child to show up hungry to school. Finland provides three years of maternity leave and subsidized day care to parents, and preschool for all five-year-olds, where the emphasis is on socializing. In addition, the state subsidizes parents, paying them around 150 euros per month for every child until he or she turns 17. Schools provide food, counseling and taxi service if needed. Health care is even free for students taking degree courses.</p>

<p><strong>F</strong> Finland’s schools were not always a wonder. For the first half of the twentieth century, only the privileged got a quality education. But In 1963, the Finnish Parliament made the bold decision to choose public education as the best means of driving the economy forward and out of recession. Public schools were organized into one system of comprehensive schools for ages 7 through 16. Teachers from all over the nation contributed to a national curriculum that provided guidelines, not prescriptions, for them to refer to. Besides Finnish and Swedish (the country’s second official language), children started learning a third language (English is a favorite) usually beginning at age nine. The equal distribution of equipment was next, meaning that all teachers had their fair share of teaching resources to aid learning. As the comprehensive schools improved, so did the upper secondary schools (grades 10 through 12). The second critical decision came in 1979, when it was required that every teacher gain a fifth-year Master’s degree in theory and practice, paid for by the state. From then on, teachers were effectively granted equal status with doctors and lawyers. Applicants began flooding teaching programs, not because the salaries were so high but because autonomous decision making and respect made the job desirable. And as Louhivuori explains, ‘We have our own motivation to succeed because we love the work.’</p>

<hr>

<h2>Questions 1-6</h2>
<p>Reading Passage 1 has six paragraphs, A-F. Choose the correct heading for each paragraph from the list of headings below. Write the correct number, i-ix, in boxes 1-6 on your answer sheet.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>A business-model approach to education</li>
    <li>The reforms that improved education in Finland</li>
    <li>Educational challenges of the future</li>
    <li>Ways in which equality is maintained in the Finnish education system</li>
    <li>The benefits of the introduction of testing</li>
    <li>An approach that helped a young learner</li>
    <li>Statistical proof of education success</li>
    <li>Support for families working and living in Finland</li>
    <li>The impact of the education system on Finland’s economy</li>
</ol>

<p><strong>1.</strong> Paragraph A: ______</p>
<p><strong>2.</strong> Paragraph B: ______</p>
<p><strong>3.</strong> Paragraph C: ______</p>
<p><strong>4.</strong> Paragraph D: ______</p>
<p><strong>5.</strong> Paragraph E: ______</p>
<p><strong>6.</strong> Paragraph F: ______</p>

<hr>

<h2>Questions 7-13</h2>
<p>Complete the notes below. Choose NO MORE THAN TWO WORDS AND/OR A NUMBER from the passage for each answer.</p>

<h3>The school system in Finland</h3>

<p><strong>PISA tests</strong></p>
<ul>
    <li>In the most recent tests, Finland’s top subject was (7)………………………..</li>
</ul>

<p><strong>History 1963:</strong></p>
<ul>
    <li>A new school system was needed to improve Finland’s (8)…………………. </li>
    <li>Schools followed (9)……………………… that were created partly by teachers.</li>
    <li>Young pupils had to study an additional (10)…………………………</li>
    <li>All teachers were given the same (11)……………………….to use.</li>
</ul>

<p><strong>1979:</strong></p>
<ul>
    <li>Teachers had to get a (12)……………………………. but they did not have to pay for this.</li>
    <li>Applicants were attracted to the (13)……………………that teaching received.</li>
</ul>','',1,'Passage 1',46),
	 ('2026-08-22 17:31:40','user_05335',false,'2026-08-22 17:31:40','user_05335','','','<h1>The Magic of Kefir</h1>

<h2>Reading Passage 2</h2>

<p><strong>A</strong> The shepherds of the North Caucasus region of Europe were only trying to transport milk the best way they knew how – in leather pouches strapped to the side of donkeys – when they made a significant discovery. A fermentation process would sometimes inadvertently occur en route, and when the pouches were opened up on arrival they would no longer contain milk but rather a pungent, effervescent, low- alcoholic substance instead. This unexpected development was a blessing in disguise. The new drink – which acquired the name kefir – turned out to be health tonic, a naturally-preserved dairy product and a tasty addition to our culinary repertoire.</p>

<p><strong>B</strong> Although their exact origin remains a mystery, we do know that yeast-based kefir grains have always been at the root of the kefir phenomenon. These grains are capable of a remarkable feat: in contradistinction to most other items you might find in a grocery store, they actually expand and propagate with use. This is because the grains, which are granular to the touch and bear a slight resemblance to cauliflower rosettes, house active cultures that feed on lactose when added to milk. Consequently, a bigger problem for most kefir drinkers is not where to source new kefir grains, but what to do with the ones they already have!</p>

<p><strong>C</strong> The great thing about kefir is that it does not require a manufacturing line in order to be produced. Grains can be simply thrown in with a batch of milk for ripening to begin. The mixture then requires a cool, dark place to live and grow, with periodic unsettling to prevent clumping (Caucasus inhabitants began storing the concoction in animal-skin satchels on the back of doors – every time someone entered the room the mixture would get lightly shaken). After about 24 hours the yeast cultures in the grains have multiplied and devoured most of the milk sugars, and the final product is then ready for human consumption.</p>

<p><strong>D</strong> Nothing compares to a person’s first encounter with kefir. The smooth, uniform consistency rolls over the tongue in a manner akin to liquefied yogurt. The sharp, tart pungency of unsweetened yogurt is there too, but there is also a slight hint of effervescence, something most users will have previously associated only with mineral waters, soda or beer. Kefir also comes with a subtle aroma of yeast, and depending on the type of milk and ripening conditions, ethanol content can reach up to two or three percent – about on par with a decent lager – although you can expect around 0.8 to one per cent for a typical day-old preparation. This can bring out a tiny edge of alcohol in the kefir’s flavour.</p>

<p><strong>E</strong> Although it has prevailed largely as a fermented milk drink, over the years kefir has acquired a number of other uses. Many bakers use it instead of starter yeast in the preparation of sourdough, and the tangy flavour also makes kefir an ideal buttermilk substitute in pancakes. Kefir also accompanies sour cream as one of the main ingredients in cold beetroot soup and can be used in lieu of regular cow’s milk on granola or cereal. As a way to keep their digestive systems fine-tuned, athletes sometimes combine kefir with yoghurt in protein shakes.</p>

<p><strong>F</strong> Associated for centuries with pictures of Slavic babushkas clutching a shawl in one hand and a cup of kefir in the other, the unassuming beverage has become a minor celebrity of the nascent health food movement in the contemporary West. Every day, more studies pour out supporting the benefits of a diet high in probiotics . This trend toward consuming probiotics has engulfed the leisure classes in these countries to the point that it is poised to become, according to some commentators, “the next multivitamin”. These days the word kefir is consequently more likely to bring to mind glamorous, yoga mat-toting women from Los Angeles than austere visions of blustery Eastern Europe.</p>

<p><strong>G</strong> Kefir’s rise in popularity has encouraged producers to take short cuts or alter the production process. Some home users have omitted the ripening and culturation process while commercial dealers often add thickeners, stabilisers and sweeteners. But the beauty of kefir is that, at its healthiest and tastiest, it is a remarkably affordable, uncluttered process, as any accidental invention is bound to be. All that is necessary are some grains, milk and a little bit of patience. A return to the unadulterated kefir-making of old is in everyone’s interest.</p>

<hr>

<h2>Questions 14-20</h2>
<p>Reading passage 2 has seven paragraphs A-G. Choose the correct heading for each paragraph from the list of headings below.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>A unique sensory experience</li>
    <li>Getting back to basics</li>
    <li>The gift that keeps on giving</li>
    <li>Variations in alcohol content</li>
    <li>Old methods of transportation</li>
    <li>Culinary applications</li>
    <li>Making kefir</li>
    <li>A fortunate accident</li>
    <li>Kefir gets an image makeover</li>
    <li>Ways to improve taste</li>
</ol>

<p><strong>14.</strong> Paragraph A: ______</p>
<p><strong>15.</strong> Paragraph B: ______</p>
<p><strong>16.</strong> Paragraph C: ______</p>
<p><strong>17.</strong> Paragraph D: ______</p>
<p><strong>18.</strong> Paragraph E: ______</p>
<p><strong>19.</strong> Paragraph F: ______</p>
<p><strong>20.</strong> Paragraph G: ______</p>

<hr>

<h2>Questions 21-24</h2>
<p>Answer the questions below using <strong>NO MORE THAN TWO WORDS</strong> from the passage for each answer.</p>

<p><strong>21.</strong> What did shepherds use to transport milk? ________________</p>
<p><strong>22.</strong> What do kefir grains look like? ________________</p>
<p><strong>23.</strong> Where should the kefir mixture be stored during ripening? ________________</p>
<p><strong>24.</strong> What is the typical alcohol content of day-old kefir? ________________</p>

<hr>

<h2>Questions 25-26</h2>
<p>Choose <strong>TWO</strong> letters A-E.<br>
Which <strong>TWO</strong> products are <strong>NOT</strong> mentioned as things which kefir can replace?</p>

<ul>
    <li>A. Ordinary cow’s milk</li>
    <li>B. Buttermilk</li>
    <li>C. Sour cream</li>
    <li>D. Starter yeast</li>
    <li>E. Yoghurt</li>
</ul>','',2,'Passage 2',46),
	 ('2026-08-23 17:31:40','user_05335',false,'2026-08-23 17:31:40','user_05335','','','<h1>The Swiffer</h1>

<p>For a fascinating tale about creativity, look at a cleaning product called the Swiffer and how it came about, urges writer Jonah Lehrer. In the story of the Swiffer, he argues, we have the key elements in producing breakthrough ideas: frustration, moments of insight and sheer hard work. The story starts with a multinational company which had invented products for keeping homes spotless, and couldn’t come up with better ways to clean floors, so it hired designers to watch how people cleaned. Frustrated after hundreds of hours of observation, they one day noticed a woman do with a paper towel what people do all the time: wipe something up and throw it away. An idea popped into lead designer Harry West’s head: the solution to their problem was a floor mop with a disposable cleaning surface. Mountains of prototypes and years of teamwork later, they unveiled the Swiffer, which quickly became a commercial success.</p>

<p>Lehrer, the author of Imagine, a new book that seeks to explain how creativity works, says this study of the imagination started from a desire to understand what happens in the brain at the moment of sudden insight. ‘But the book definitely spiraled out of control,’ Lehrer says. ‘When you talk to creative people, they’ll tell you about the ‘eureka’* moment, but when you press them they also talk about the hard work that comes afterwards, so I realised I needed to write about that, too. And then I realised I couldn’t just look at creativity from the perspective of the brain, because it’s also about the culture and context, about the group and the team and the way we collaborate.’</p>

<p>When it comes to the mysterious process by which inspiration comes into your head as if from nowhere, Lehrer says modern neuroscience has produced a ‘first draft’ explanation of what is happening in the brain. He writes of how burnt-out American singer Bob Dylan decided to walk away from his musical career in 1965 and escape to a cabin in the woods, only to be overcome by a desire to write. Apparently ‘Like a Rolling Stone’ suddenly flowed from his pen. ‘It’s like a ghost is writing a song,’ Dylan has reportedly said. ‘It gives you the song and it goes away.’ But it’s no ghost, according to Lehrer.</p>

<p>Instead, the right hemisphere of the brain is assembling connections between past influences and making something entirely new. Neuroscientists have roughly charted this process by mapping the brains of people doing word puzzles solved by making sense of remotely connecting information. For instance, subjects are given three words – such as ‘age’, ‘mile’ and ‘sand’ – and asked to come up with a single word that can precede or follow each of them to form a compound word. (It happens to be ‘stone’.) Using brain-imaging equipment, researchers discovered that when people get the answer in an apparent flash of insight, a small fold of tissue called the anterior superior temporal gyrus suddenly lights up just beforehand. This stays silent when the word puzzle is solved through careful analysis. Lehrer says that this area of the brain lights up only after we’ve hit the wall on a problem. Then the brain starts hunting through the ‘filing cabinets of the right hemisphere’ to make the connections that produce the right answer.</p>

<p>Studies have demonstrated it’s possible to predict a moment of insight up to eight seconds before it arrives. The predictive signal is a steady rhythm of alpha waves emanating from the brain’s right hemisphere, which are closely associated with relaxing activities. ‘When our minds are at ease-when those alpha waves are rippling through the brain – we’re more likely to direct the spotlight of attention towards that stream of remote associations emanating from the right hemisphere,’ Lehrer writes. ‘In contrast, when we are diligently focused, our attention tends to be towards the details of the problems we are trying to solve.’ In other words, then we are less likely to make those vital associations. So, heading out for a walk or lying down are important phases of the creative process, and smart companies know this. Some now have a policy of encouraging staff to take time out during the day and spend time on things that at first glance are unproductive (like playing a PC game), but day-dreaming has been shown to be positively correlated with problem-solving. However, to be more imaginative, says Lehrer, it’s also crucial to collaborate with people from a wide range of backgrounds because if colleagues are too socially intimate, creativity is stifled.</p>

<p>Creativity, it seems, thrives on serendipity. American entrepreneur Steve Jobs believed so. Lehrer describes how at Pixar Animation, Jobs designed the entire workplace to maximise the chance of strangers bumping into each other, striking up conversations and learning from one another. He also points to a study of 766 business graduates who had gone on to own their own companies. Those with the greatest diversity of acquaintances enjoyed far more success. Lehrer says he has taken all this on board, and despite his inherent shyness, when he’s sitting next to strangers on a plane or at a conference, forces himself to initiate conversations. As for predictions that the rise of the Internet would make the need for shared working space obsolete, Lehrer says research shows the opposite has occurred; when people meet face-to-face, the level of creativity increases. This is why the kind of place we live in is so important to innovation. According to theoretical physicist Geoffrey West, when corporate institutions get bigger, they often become less receptive to change. Cities, however, allow our ingenuity to grow by pulling huge numbers of different people together, who then exchange ideas. Working from the comfort of our homes may be convenient, therefore, but it seems we need the company of others to achieve our finest ‘eureka’ moments.</p>

<hr>

<h2>Questions 31-34</h2>
<p>Complete each sentence with the correct ending, A-G, below.<br>
Write the correct letter, A-G, in boxes 31-34 on your answer sheet.</p>

<ol type="A">
    <li>when people are not too familiar with one another.</li>
    <li>because there is greater activity in the right side of the brain.</li>
    <li>if people are concentrating on the specifics of a problem.</li>
    <li>so they can increase the possibility of finding answers.</li>
    <li>when people lack the experience required for problem-solving.</li>
    <li>when the brain shows strong signs of distraction.</li>
    <li>when both hemispheres of the brain show activity.</li>
</ol>

<p><strong>31.</strong> A moment of insight is more likely to occur ________________</p>
<p><strong>32.</strong> The anterior superior temporal gyrus lights up ________________</p>
<p><strong>33.</strong> Alpha waves are associated with creativity ________________</p>
<p><strong>34.</strong> Creativity is increased ________________</p>

<hr>

<h2>Questions 35-39</h2>
<p>Complete the notes below. Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>How other people influence our creativity</h3>

<ul>
    <li><strong>Steve Jobs:</strong> made changes to the (35)……………………… to encourage interaction at Pixar.</li>
    <li><strong>Lehrer:</strong></li>
    <ul>
        <li>company owners must have a wide range of (36)………………………. to do well.</li>
        <li>it’s important to start (37)………………………. with new people</li>
        <li>the (38)………………………….. has not replaced the need for physical contact.</li>
    </ul>
    <li><strong>Geoffrey West:</strong> living in (39)……………………………….. encourages creativity.</li>
</ul>','',3,'Passage 3',46),
	 ('2026-08-24 17:31:40','user_05335',false,'2026-08-24 17:31:40','user_05335','','','<h1>The Hidden Histories of Exploration Exhibition</h1>

<h2>Reading Passage 1</h2>

<p><strong>A</strong> We have all heard tales of lone, heroic explorers, but what about the local individuals who guided and protected European explorers in many different parts of the globe? Or the go-betweens – including interpreters and traders – who translated the needs and demands of explorers into a language that locals could understand? Such questions have received surprisingly little attention in standard histories, where European explorers are usually the heroes, sometimes the villains. The Hidden Histories of Exploration exhibition at Britain’s Royal Geographical Society in London sets out to present an alternative view, in which exploration is a fundamentally collective experience of work, involving many different people. Many of the most famous examples of explorers said to have been ‘lone travellers’ – say, Mungo Park or David Livingstone in Africa – were anything but ‘alone’ on their travels. They depended on local support of various kinds – for food, shelter, protection, information, guidance and solace – as well as on other resources from elsewhere.</p>

<p><strong>B</strong> The Royal Geographical Society (RGS) seeks to record this story in its Hidden Histories project, using its astonishingly rich collections. The storage of geographical information was one of the main rationales for the foundation of the RGS in 1830, and the Society’s collections now contain more than two million individual items, including books, manuscripts, maps, photographs art-works, artefacts and film – a rich storehouse of material reflecting the wide geographical extent of British interest across the globe. In addition to their remarkable scope and range, these collections contain a striking visual record of exploration: the impulse to collect the world is reflected in a large and diverse image archive. For the researcher, this archive can yield many surprises: materials gathered for one purpose – say, maps relating to an international boundary dispute or photographs taken on a scientific expedition – may today be put to quite different uses.</p>

<p><strong>C</strong> In their published narratives, European explorers rarely portrayed themselves as vulnerable or dependent on others, despite the fact that without this support they were quite literally lost. Archival research confirms that Europeans were not merely dependent on the work of porters soldiers translators, cooks, pilots, guides, hunters and collectors: they also relied on local expertise. Such assistance was essential in identifying potential dangers poisonous species, unpredictable rivers, uncharted territories – which could mean the difference between life and death. The assistants themselves were usually in a strong bargaining position. In the Amazon, for example access to entire regions would depend on the willingness of local crew members and other assistants to enter areas inhabited by relatively powerful Amerindian groups. In an account of his journey across South America published in 1836, William Smyth thus complained of frequent desertion by his helpers: without them it was impossible to get on.</p>

<p><strong>D</strong> Those providing local support and information to explorers were themselves often not ‘locals’. For example, the history of African exploration in the nineteenth century is dominated by the use of Zanzibar as a recruiting station for porters, soldiers and guides who would then travel thousands of miles across the continent. In some accounts, the leading African members of expedition parties – the ‘officers’ or ‘foremen’ – are identified, and their portraits published alongside those of European explorers.</p>

<p><strong>E</strong> The information provided by locals and intermediaries was of potential importance to geographical science. How was this evidence judged? The formal procedures of scientific evaluation provided one framework. Alongside these were more ‘common sense’ notions of veracity and reliability, religiously-inspired judgments about the authenticity of testimony, and the routine procedures for cross-checking empirical observations developed in many professions.</p>

<p><strong>F</strong> Given explorers’ need for local information and support, it was in their interests to develop effective working partnerships with knowledgeable intermediaries who could act as brokers in their dealings with local inhabitants. Many of these people acquired far more experience of exploration than most Europeans could hope to attain. Some managed large groups of men and women, piloted the explorers’ river craft, or undertook mapping work. The tradition was continued with the Everest expeditions in the 1920s and 1930s, which regularly employed the Tibetan interpreter Karma Paul. In Europe, exploration was increasingly thought of as a career; the same might be said of the non-Europeans on whom their expeditions depended.</p>

<p><strong>G</strong> These individuals often forged close working relationships with European explorers. Such partnerships depended on mutual respect, though they were not always easy or intimate, as is particularly clear from the history of the Everest expeditions depicted in the Hidden Histories exhibition. The entire back wall is covered by an enlarged version of a single sheet of photographs of Sherpas taken during the 1936 Everest expedition. The document is a powerful reminder of the manpower on which European mountaineering expeditions depended, and also of the importance of local knowledge and assistance. Transformed from archive to wall display, it tells a powerful story through the medium of individual portraits – including Karma Paul, veteran of previous expeditions, and the young Tensing Norgay, 17 years before his successful 1953 ascent. This was a highly charged and transitional moment as the contribution of the Sherpas, depicted here with identity tags round their necks, was beginning to be much more widely recognised. These touching portraits encourage us to see them as agents rather than simply colonial subjects or paid employees. Here is a living history, which looks beyond what we already know about exploration: a larger history in which we come to recognise the contribution of everyone involved.</p>

<hr>

<h2>Questions 1-7</h2>
<p>Do the following statements agree with the information given in Reading Passage 1?<br>
In boxes 1-7 on your answer sheet, write</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>1.</strong> ________________</p>
<p><strong>2.</strong> ________________</p>
<p><strong>3.</strong> ________________</p>
<p><strong>4.</strong> ________________</p>
<p><strong>5.</strong> ________________</p>
<p><strong>6.</strong> ________________</p>
<p><strong>7.</strong> ________________</p>

<hr>

<h2>Questions 8-13</h2>
<p>Reading Passage 1 has seven paragraphs, A-G. Which paragraph contains the following information?</p>

<p><strong>8.</strong> ________________</p>
<p><strong>9.</strong> ________________</p>
<p><strong>10.</strong> ________________</p>
<p><strong>11.</strong> ________________</p>
<p><strong>12.</strong> ________________</p>
<p><strong>13.</strong> ________________</p>','',1,'Passage 1',47),
	 ('2026-08-25 17:31:40','user_05335',false,'2026-08-25 17:31:40','user_05335','','','<h1>Fatal Attraction</h1>

<p>Evolutionist Charles Darwin first marvelled at flesh-eating plants in the mid-19th century. Today, biologists, using 21st-century tools to study cells and DNA, are beginning to understand how these plants hunt, eat and digest – and how such bizarre adaptations arose in the first place.</p>

<h2>Reading Passage 2</h2>

<p><strong>A</strong> The leaves of the Venus flytrap plant are covered in hairs. When an insect brushes against them, this triggers a tiny electric charge, which travels down tunnels in the leaf and opens up pores in the leaf’s cell membranes. Water surges from the cells on the inside of the leaf to those on the outside, causing the leaf to rapidly flip in shape from convex to concave, like a soft contact lens. As the leaves flip, they snap together, trapping the insect in their sharp-toothed jaws.</p>

<p><strong>B</strong> The bladderwort has an equally sophisticated way of setting its underwater trap. It pumps water out of tiny bag-like bladders, making a vacuum inside. When small creatures swim past, they bend the hairs on the bladder, causing a flap to open. The low pressure sucks water in, carrying the animal along with it. In one five-hundredth of a second, the door swings shut again. The Drosera sundew, meanwhile, has a thick, sweet liquid oozing from its leaves, which first attracts insects, then holds them fast before the leaves snap shut. Pitcher plants use yet another strategy, growing long tube-shaped leaves to imprison their prey. Raffles’ pitcher plant, from the jungles of Borneo, produces nectar that both lures insects and forms a slick surface on which they can’t get a grip. Insects that land on the rim of the pitcher slide on the liquid and tumble in.</p>

<p><strong>C</strong> Many carnivorous plants secrete enzymes to penetrate the hard exoskeleton of insects so they can absorb nutrients from inside their prey. But the purple pitcher plant, which lives in bogs and infertile sandy soils in North America, enlists other organisms to process its food. It is home to an intricate food web of mosquito larvae, midges and bacteria, many of which can survive only in this unique habitat. These animals shred the prey that fall into the pitcher, and the smaller organisms feed on the debris. Finally, the plant absorbs the nutrients released.</p>

<p><strong>D</strong> While such plants clearly thrive on being carnivorous, the benefits of eating flesh are not the ones you might expect. Carnivorous animals such as ourselves use the carbon in protein and the fat in meat to build muscles and store energy. Carnivorous plants instead draw nitrogen, phosphorus, and other critical nutrients from their prey in order to build light-harvesting enzymes. Eating animals, in other words, lets carnivorous plants do what all plants do: carry out photosynthesis, that is, grow by harnessing energy directly from the sun.</p>

<p><strong>E</strong> Carnivorous plants are, in fact, very inefficient at converting sunlight into tissue. This is because of all the energy they expend to make the equipment to catch animals – the enzymes, the pumps, and so on. A pitcher or a flytrap cannot carry out much photosynthesis because, unlike plants with ordinary leaves, they do not have flat solar panels that can grab lots of sunlight. There are, however, some special conditions in which the benefits of being carnivorous do outweigh the costs. The poor soil of bogs, for example, offers little nitrogen and phosphorus, so carnivorous plants enjoy an advantage over plants that obtain these nutrients by more conventional means. Bogs are also flooded with sunshine, so even an inefficient carnivorous plant can photosynthesise enough light to survive.</p>

<p><strong>F</strong> Evolution has repeatedly made this trade-off. By comparing the DNA of carnivorous plants with other species, scientists have found that they evolved independently on at least six separate occasions. Some carnivorous plants that look nearly identical turn out to be only distantly related. The two kinds of pitcher plants – the tropical genus Nepenthes and the North American Sarracenia – have, surprisingly, evolved from different ancestors, although both grow deep pitchershaped leaves and employ the same strategy for capturing prey.</p>

<p><strong>G</strong> In several cases, scientists can see how complex carnivorous plants evolved from simpler ones. Venus flytraps, for example, share an ancestor with Portuguese sundews, which only catch prey passively, via ‘flypaper’ glands on their stems. They share a more recent ancestor with Drosera sundews, which can also curl their leaves over their prey. Venus flytraps appear to have evolved an even more elaborate version of this kind of trap, complete with jaw-like leaves.</p>

<p><strong>H</strong> Unfortunately, the adaptations that enable carnivorous plants to thrive in marginal habitats also make them exquisitely sensitive. Agricultural run-off and pollution from power plants are adding extra nitrogen to many bogs in North America. Carnivorous plants are so finely tuned to low levels of nitrogen that this extra fertilizer is overloading their systems, and they eventually burn themselves out and die.</p>

<p><strong>I</strong> Humans also threaten carnivorous plants in other ways. The black market trade in exotic carnivorous plants is so vigorous now that botanists are keeping the location of some rare species a secret. But even if the poaching of carnivorous plants can be halted, they will continue to suffer from other assaults. In the pine savannah of North Carolina, the increasing suppression of fires is allowing other plants to grow too quickly and outcompete the flytraps in their native environment. Good news, perhaps, for flies. But a loss for all who, like Darwin, delight in the sheer inventiveness of evolution.</p>

<hr>

<h2>Questions 14-18</h2>
<p>Complete the notes below. Choose <strong>NO MORE THAN TWO WORDS</strong> from the passage for each answer.</p>

<h3>How a Venus flytrap traps an insect</h3>
<ul>
    <li>Insect touches (14)…………………………….on leaf of plant</li>
    <li>Small (15)……………………………..passes through leaf</li>
    <li>(16)…………………………….in cell membrane open</li>
    <li>Outside cells of leaves fill with (17)……………………………. </li>
    <li>Leaves change so that they have a (18)………………………………..shape and snap shut</li>
</ul>

<hr>

<h2>Questions 19-22</h2>
<p>Look at the following statements (Questions 19-22) and the list of plants. Match each statement with the correct plant, A, B, C, D or E.<br>
Write the correct letter, A, B, C, D or E, in boxes 19-22 on your answer sheet.</p>

<h3>List of plants</h3>
<ul>
    <li><strong>A</strong> Venus flytrap</li>
    <li><strong>B</strong> bladderwort</li>
    <li><strong>C</strong> Drosera sundew</li>
    <li><strong>D</strong> Raffles’ pitcher plant</li>
    <li><strong>E</strong> purple pitcher plant</li>
</ul>

<p><strong>19.</strong> ________________</p>
<p><strong>20.</strong> ________________</p>
<p><strong>21.</strong> ________________</p>
<p><strong>22.</strong> ________________</p>

<hr>

<h2>Questions 23-26</h2>
<p>Reading Passage 2 has nine paragraphs, A-I. Which paragraph contains the following information?</p>

<p><strong>23.</strong> ________________</p>
<p><strong>24.</strong> ________________</p>
<p><strong>25.</strong> ________________</p>
<p><strong>26.</strong> ________________</p>','',2,'Passage 2',47),
	 ('2026-08-26 17:31:40','user_05335',false,'2026-08-26 17:31:40','user_05335','','','<h1>Want to be friends?</h1>

<h2>Reading Passage 3</h2>

<p><strong>A</strong> For many hundreds of thousands of people worldwide, online networking has become enmeshed in our daily lives. However, it is a decades-old insight from a study of traditional social networks that best illuminates one of the most important aspects of today’s online networking. In 1973 sociologist Mark Granovetter showed how the loose acquaintances, or ‘weak ties’, in our social network exert a disproportionate influence over our behaviour and choices. Granovetter’s research showed that a significant percentage of people get their jobs as a result of recommendations or advice provided by a weak tie. Today our number of weak-tie contacts has exploded via online social networking. ‘You couldn’t maintain all of those weak ties on your own,’ says Jennifer Golbeck of the University of Maryland. ‘Online sites, such as Facebook, give you a way of cataloguing them.’ The result? It’s now significantly easier for the schoolfriend you haven’t seen in years to pass you a tip that alters your behaviour, from recommendation of a low-cholesterol breakfast cereal to a party invite where you meet your future wife or husband.</p>

<p><strong>B</strong> The explosion of weak ties could have profound consequences for our social structures too, according to Judith Donath of the Berkman Center for Internet and Society at Harvard University. ‘We’re already seeing changes,’ she says. For example, many people now turn to their online social networks ahead of sources such as newspapers and television for trusted and relevant news or information. What they hear could well be inaccurate, but the change is happening nonetheless. If these huge ‘supernets’ – some of them numbering up to 5,000 people – continue to thrive and grow, they could fundamentally change the way we share information and transform our notions of relationships.</p>

<p><strong>C</strong> But are these vast networks really that relevant to us on a personal level? Robin Dunbar, an evolutionary anthropologist at the University of Oxford, believes that our primate brains place a cap on the number of genuine social relationships we can actually cope with: roughly 150. According to Dunbar, online social networking appears to be very good for ‘servicing’ relationships, but not for establishing them. He argues that our evolutionary roots mean we still depend heavily on physical and face-to-face contact to be able to create ties.</p>

<p><strong>D</strong> Nonetheless, there is evidence that online networking can transform our daily interactions. In an experiment at Cornell University, psychologist Jeff Hancock asked participants to try to encourage other participants to like them via instant messaging conversation. Beforehand, some members of the trial were allowed to view the Facebook profile of the person they were trying to win over. He found that those with Facebook access asked questions to which they already knew the answers or raised things they had in common, and as result were much more successful in their social relationships. Hancock concluded that people who use these sites to keep updated on the activities of their acquaintances are more likely to be liked in subsequent social interactions.</p>

<p><strong>E</strong> Online social networking may also have tangible effects on our well-being. Nicole Ellison of Michigan State University found that the frequency of networking site use correlates with greater selfesteem. Support and affirmation from the weak ties could be the explanation, says Ellison. ‘Asking your close friends for help or advice is nothing new, but we are seeing a lowering of barriers among acquaintances,’ she says. People are readily sharing personal feelings and experiences to a wider circle than they might once have done. Sandy Pentland at the Massachusetts Institute of Technology agrees. The ability to broadcast to our social group means we need never feel alone,’ he says. The things that befall us are often due to a lack of social support. There’s more of a safety net now.’</p>

<p><strong>F</strong> Henry Holzman, also at MIT, who studies the interface between online social networking and the real world, points out that increased visibility also means our various social spheres – family, work, friends – are merging, and so we will have to prepare for new societal norms. ‘Well have to learn how to live a more transparent life,’ he says. ‘We may have to give up some ability to show very limited glimpses of ourselves to others.’</p>

<p><strong>G</strong> Another way that online networking appears to be changing our social structures is through dominance. In one repeated experiment, Michael Kearns of the University of Pennsylvania asked 30 volunteers to quickly reach consensus in an online game over a choice between two colours. Each person was offered a cash reward if they succeeded in persuading the group to pick one or other colour. All participants could see the colour chosen by some of the other people, but certain participants had an extra advantage: the ability to see more of the participants’ chosen colours than others. Every time Kearns found that those who could see the choices of more participants (in other words, were better connected) persuaded the group to pick their colour, even when they had to persuade the vast majority to give up their financial incentive. While Kearns warns that the setting was artificial, he says it’s possible that greater persuasive power could lie with well-connected individuals in the everyday online world too.</p>

<hr>

<h2>Questions 27-32</h2>
<p>Reading Passage 3 has seven paragraphs, A-G.<br>
Choose the correct heading for paragraphs B-G from the list of headings below.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>A shift in our fact-finding habits</li>
    <li>How to be popular</li>
    <li>More personal information being known</li>
    <li>The origins of online social networks</li>
    <li>The link between knowledge and influence</li>
    <li>Information that could change how you live</li>
    <li>The emotional benefits of online networking</li>
    <li>A change in how we view our online friendships</li>
    <li>The future of networking</li>
    <li>Doubts about the value of online socializing</li>
</ol>

<p><strong>27.</strong> Paragraph B: ______</p>
<p><strong>28.</strong> Paragraph C: ______</p>
<p><strong>29.</strong> Paragraph D: ______</p>
<p><strong>30.</strong> Paragraph E: ______</p>
<p><strong>31.</strong> Paragraph F: ______</p>
<p><strong>32.</strong> Paragraph G: ______</p>

<hr>

<h2>Questions 33-36</h2>
<p>Look at the following findings (Questions 33-36) and the list of researchers below. Match each finding with the correct researcher A-F.<br>
Write the correct letter A-F in boxes 33-36 on your answer sheet.</p>

<h3>List of researchers</h3>
<ul>
    <li><strong>A</strong> Mark Granovetter</li>
    <li><strong>B</strong> Judith Donath</li>
    <li><strong>C</strong> Robin Dunbar</li>
    <li><strong>D</strong> Jeff Hancock</li>
    <li><strong>E</strong> Nicole Ellison</li>
    <li><strong>F</strong> Michael Kearns</li>
</ul>

<p><strong>33.</strong> ________________</p>
<p><strong>34.</strong> ________________</p>
<p><strong>35.</strong> ________________</p>
<p><strong>36.</strong> ________________</p>

<hr>

<h2>Questions 37-38</h2>
<p>Which <strong>TWO</strong> of these advantages of online social networking are mentioned in Reading Passage 3?</p>
<ul>
    <li>A. Social networking sites can be accessed on any day and at any time.</li>
    <li>B. Online socialising is an efficient way of keeping in touch with a lot of people.</li>
    <li>C. It is very easy to establish new friendships online.</li>
    <li>D. Online social networking can solve problems in real-world relationships.</li>
    <li>E. It can be reassuring to be part of an online social network.</li>
</ul>

<hr>

<h2>Questions 39-40</h2>
<p>Which <strong>TWO</strong> of these disadvantages of online social networking are mentioned in Reading Passage 3?</p>
<ul>
    <li>A. Information from online social contacts may be unreliable.</li>
    <li>B. We may become jealous of people who seem to have a wide circle of friends.</li>
    <li>C. We may lose the ability to relate to people face-to-face.</li>
    <li>D. It is easy to waste a lot of time on social networking sites.</li>
    <li>E. Using social networking sites may result in a lack of privacy.</li>
</ul>','',3,'Passage 3',47),
	 ('2026-08-27 17:31:40','user_05335',false,'2026-08-27 17:31:40','user_05335','','','<h1>The Phoenicians: an almost forgotten people</h1>

<p>The Phoenicians inhabited the region of modern Lebanon and Syria from about 3000 BC. They became the greatest traders of the pre-classical world, and were the first people to establish a large colonial network. Both of these activities were based on seafaring, an ability the Phoenicians developed from the example of their maritime predecessors, the Minoans of Crete.</p>

<p>An Egyptian narrative of about 1080 BC, the Story of Wen-Amen, provides an insight into the scale of their trading activity. One of the characters is Wereket-El, a Phoenician merchant living at Tanis in Egypt’s Nile delta. As many as 50 ships carry out his business, plying back and forth between the Nile and the Phoenician port of Sidon.</p>

<p>The most prosperous period for Phoenicia was the 10th century BC, when the surrounding region was stable. Hiram, the king of the Phoenician city of Tyre, was an ally and business partner of Solomon, King of Israel. For Solomon’s temple in Jerusalem, Hiram provided craftsmen with particular skills that were needed for this major construction project. He also supplied materials – particularly timber, including cedar from the forests of Lebanon. And the two kings went into trade in partnership. They sent out Phoenician vessels on long expeditions (of up to three years for the return trip) to bring back gold, sandalwood, ivory, monkeys and peacocks from Ophir. This is an unidentified place, probably on the east coast of Africa or the west coast of India.</p>

<p>Phoenicia was famous for its luxury goods. The cedar wood was not only exported as top-quality timber for architecture and shipbuilding. It was also carved by the Phoenicians, and the same skill was adapted to even more precious work in ivory. The rare and expensive dye for cloth, Tyrian purple, complemented another famous local product, fine linen. The metalworkers of the region, particularly those working in gold, were famous. Tyre and Sidon were also known for their glass.</p>

<p>These were the main products which the Phoenicians exported. In addition, as traders and middlemen, they took a commission on a much greater range of precious goods that they transported from elsewhere.</p>

<p>The extensive trade of Phoenicia required much book-keeping and correspondence, and it was in the field of writing that the Phoenicians made their most lasting contribution to world history. The scripts in use in the world up to the second millennium BC (in Egypt, Mesopotamia or China) all required the writer to learn a large number of separate characters – each of them expressing either a whole word or an element of its meaning. By contrast, the Phoenicians, in about 1500 BC, developed an entirely new approach to writing. The marks made (with a pointed tool called a stylus, on damp clay) now attempted to capture the sound of a word. This required an alphabet of individual letters.</p>

<p>The trading and seafaring skills of the Phoenicians resulted in a network of colonies, spreading westwards through the Mediterranean. The first was probably Citium, in Cyprus, established in the 9th century BC. But the main expansion came from the 8th century BC onwards, when pressure from Assyria to the east disrupted the patterns of trade on the Phoenician coast.</p>

<p>Trading colonies were developed on the string of islands in the centre of the Mediterranean – Crete, Sicily, Malta, Sardinia, Ibiza – and also on the coast of north Africa. The African colonies clustered in particular around the great promontory which, with Sicily opposite, forms the narrowest channel on the main Mediterranean sea route. This is the site of Carthage.</p>

<p>Carthage was the largest of the towns founded by the Phoenicians on the north African coast, and it rapidly assumed a leading position among the neighbouring colonies. The traditional date of its founding is 814 BC, but archaeological evidence suggests that it was probably settled a little over a century later.</p>

<p>The subsequent spread and growth of Phoenician colonies in the western Mediterranean, and even out to the Atlantic coasts of Africa and Spain, was as much the achievement of Carthage as of the original Phoenician trading cities such as Tyre and Sidon. But no doubt links were maintained with the homeland, and new colonists continued to travel west.</p>

<p>From the 8th century BC, many of the coastal cities of Phoenicia came under the control of a succession of imperial powers, each of them defeated and replaced in the region by the next: first the Assyrians, then the Babylonians, Persians and Macedonian Greeks. In 64 BC, the area of Phoenicia became part of the Roman province of Syria. The Phoenicians as an identifiable people then faded from history, merging into the populations of modern Lebanon and northern Syria.</p>

<hr>

<h2>Questions 1-8</h2>
<p>Complete the sentences below. Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>The Phoenician’s trading activities</h3>

<p><strong>1.</strong> ________________</p>
<p><strong>2.</strong> ________________</p>
<p><strong>3.</strong> ________________</p>
<p><strong>4.</strong> ________________</p>
<p><strong>5.</strong> ________________</p>
<p><strong>6.</strong> ________________</p>
<p><strong>7.</strong> ________________</p>
<p><strong>8.</strong> ________________</p>

<hr>

<h2>Questions 9-13</h2>
<p>Do the following statements agree with the information given in Reading Passage 1?</p>
<p>Write:</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>9.</strong> ________________</p>
<p><strong>10.</strong> ________________</p>
<p><strong>11.</strong> ________________</p>
<p><strong>12.</strong> ________________</p>
<p><strong>13.</strong> ________________</p>','',1,'Passage 1',48);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-08-28 17:31:40','user_05335',false,'2026-08-28 17:31:40','user_05335','','','<h1>The Hollywood Film Industry</h1>

<h2>Reading Passage 2</h2>

<p><strong>A</strong> This chapter examines the ‘Golden Age’ of the Hollywood film studio system and explores how a particular kind of filmmaking developed during this period in US film history. It also focuses on the two key elements which influenced the emergence of the classic Hollywood studio system: the advent of sound and the business ideal of vertical integration. In addition to its historical interest, inspecting the growth of the studio system may offer clues regarding the kinds of struggles that accompany the growth of any new medium. It might, in fact, be intriguing to examine which changes occurred during the growth of the Hollywood studio, and compare those changes to contemporary struggles in which production companies are trying to define and control emerging industries, such as online film and interactive television.</p>

<p><strong>B</strong> The shift of the industry away from ‘silent’ films began during the late 1920s. Warner Bros.’ 1927 film The Jazz Singer was the first to feature synchronized speech, and with it came a period of turmoil for the industry. Studios now had proof that ‘talkie’ films would make them money, but the financial investment this kind of filmmaking would require, from new camera equipment to new projection facilities, made the studios hesitant to invest at first. In the end, the power of cinematic sound to both move audiences and enhance the story persuaded studios that talkies were worth investing in. Overall, the use of sound in film was well-received by audiences, but there were still many technical factors to consider. Although full integration of sound into movies was complete by 1930, it would take somewhat longer for them to regain their stylistic elegance and dexterity. The camera now had to be encased in a big, clumsy, unmoveable soundproof box. In addition, actors struggled, having to direct their speech to awkwardly-hidden microphones in huge plants, telephones or even costumes.</p>

<p><strong>C</strong> Vertical integration is the other key component in the rise of the Hollywood studio system. The major studios realized they could increase their profits by handling each stage of a film’s life: production (making the film), distribution (getting the film out to people) and exhibition (owning the theaters in major cities where films were shown first). Five studios, ‘The Big Five’, worked to achieve vertical integration through the late 1940s, owning vast real estate on which to construct elaborate sets. In addition, these studios set the exact terms of films’ release dates and patterns. Warner Bros., Paramount, 20th Century Fox, MGM and RKO formed this exclusive club. ‘The Little Three’ studios – Universal, Columbia and United Artists – also made pictures, but each lacked one of the crucial elements of vertical integration. Together these eight companies operated as a mature oligopoly, essentially running the entire market.</p>

<p><strong>D</strong> During the Golden Age, the studios were remarkably consistent and stable enterprises, due in large part to long-term management heads – the infamous ‘movie moguls’ who ruled their kingdoms with iron fists. At MGM, Warner Bros, and Columbia, the same men ran their studios for decades. The rise of the studio system also hinges on the treatment of stars, who were constructed and exploited to suit a studio’s image and schedule. Actors were bound up in seven-year contracts to a single studio, and the studio boss generally held all the options. Stars could be loaned out to other production companies at any time. Studio bosses could also force bad roles on actors, and manipulate every single detail of stars’ images with their mammoth in-house publicity departments. Some have compared the Hollywood studio system to a factory, and it is useful to remember that studios were out to make money first and art second.</p>

<p><strong>E</strong> On the other hand, studios also had to cultivate flexibility, in addition to consistent factory output. Studio heads realized that they couldn’t make virtually the same film over and over again with the same cast of stars and still expect to keep turning a profit. They also had to create product differentiation. Examining how each production company tried to differentiate itself has led to loose characterizations of individual studios’ styles. MGM tended to put out a lot of all-star productions while Paramount excelled in comedy and Warner Bros, developed a reputation for gritty social realism. 20th Century Fox forged the musical and a great deal of prestige biographies, while Universal specialized in classic horror movies.</p>

<p><strong>F</strong> In 1948, struggling independent movie producers and exhibitors finally triumphed in their battle against the big studios’ monopolistic behavior. In the United States versus Paramount federal decree of that year, the studios were ordered to give up their theaters in what is commonly referred to as ‘divestiture’ – opening the market to smaller producers. This, coupled with the advent of television in the 1950s, seriously compromised the studio system’s influence and profits. Hence, 1930 and 1948 are generally considered bookends to Hollywood’s Golden Age.</p>

<hr>

<h2>Questions 14-19</h2>
<p>Reading Passage 2 has six paragraphs, A-F. Choose the correct heading for each paragraph from the list of headings below.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>The power within each studio</li>
    <li>The movie industry adapts to innovation</li>
    <li>Contrasts between cinema and other media of the time</li>
    <li>The value of studying Hollywood’s Golden Age</li>
    <li>Distinguishing themselves from the rest of the market</li>
    <li>A double attack on film studios’ power</li>
    <li>Gaining control of the industry</li>
    <li>The top movies of Hollywood’s Golden Age</li>
</ol>

<p><strong>14.</strong> Paragraph A: ______</p>
<p><strong>15.</strong> Paragraph B: ______</p>
<p><strong>16.</strong> Paragraph C: ______</p>
<p><strong>17.</strong> Paragraph D: ______</p>
<p><strong>18.</strong> Paragraph E: ______</p>
<p><strong>19.</strong> Paragraph F: ______</p>

<hr>

<h2>Questions 20-23</h2>
<p>Do the following statements agree with the information given in Reading Passage 2?<br>
Write:</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>20.</strong> ________________</p>
<p><strong>21.</strong> ________________</p>
<p><strong>22.</strong> ________________</p>
<p><strong>23.</strong> ________________</p>

<hr>

<h2>Questions 24-26</h2>
<p>Complete the summary below. Choose <strong>NO MORE THAN TWO WORDS</strong> from the passage for each answer.</p>

<h3>THE HOLLYWOOD STUDIOS</h3>
<p>Throughout its Golden Age, the Hollywood movie industry was controlled by a handful of studios. Using a system known as (24)……………………………… , the biggest studios not only made movies, but handled their distribution and then finally showed them in their own theaters. These studios were often run by autocratic bosses – men known as (25)………………………………… , who often remained at the head of organisations for decades. However, the domination of the industry by the leading studios came to an end in 1948, when they were forced to open the market to smaller producers – a process known as (26)…………………………</p>','',2,'Passage 2',48),
	 ('2026-08-29 17:31:40','user_05335',false,'2026-08-29 17:31:40','user_05335','','','<h1>Left or right?</h1>

<h2>Reading Passage 3</h2>

<p><strong>A</strong> Creatures across the animal kingdom have a preference for one foot, eye or even antenna. The cause of this trait, called lateralisation, is fairly simple: one side of the brain, which generally controls the opposite side of the body, is more dominant than the other when processing certain tasks. This does, on some occasions, let the animal down: such as when a toad fails to escape from a snake approaching from the right, just because its right eye is worse at spotting danger than its left. So why would animals evolve a characteristic that seems to endanger them?</p>

<p><strong>B</strong> For many years it was assumed that lateralisation was a uniquely human trait, but this notion rapidly fell apart as researchers started uncovering evidence of lateralisation in all sorts of animals. For example, in the 1970s, Lesley Rogers, now at the University of New England in Australia, was studying memory and learning in chicks. She had been injecting a chemical into chicks’ brains to stop them learning how to spot grains of food among distracting pebbles, and was surprised to observe that the chemical only worked when applied to the left hemisphere of the brain. That strongly suggested that the right side of the chicks brain played little or no role in the learning of such behaviours. Similar evidence appeared in songbirds and rats around the same time, and since then, researchers have built up an impressive catalogue of animal lateralisation.</p>

<p><strong>C</strong> In some animals, lateralisation is simply a preference for a single paw or foot, while in others it appears in more general patterns of behaviour. The left side of most vertebrate brains, for example, seems to process and control feeding. Since the left hemisphere processes input from the right side of the body, that means animals as diverse as fish, toads and birds are more likely to attack prey or food items viewed with their right eye. Even humpback whales prefer to use the right side of their jaws to scrape sand eels from the ocean floor.</p>

<p><strong>D</strong> Genetics plays a part in determining lateralisation, but environmental factors have an impact too. Rogers found that a chicks lateralisation depends on whether it is exposed to light before hatching from its egg – if it is kept in the dark during this period, neither hemisphere becomes dominant. In 2004, Rogers used this observation to test the advantages of brain bias in chicks faced with the challenge of multitasking. She hatched chicks with either strong or weak lateralisation, then presented the two groups with food hidden among small pebbles and the threatening shape of a fake predator flying overhead. As predicted, the birds incubated in the light looked for food mainly with their right eye, while using the other to check out the predator. The weakly-lateralised chicks, meanwhile, had difficulty performing these two activities simultaneously.</p>

<p><strong>E</strong> Similar results probably hold true for many other animals. In 2006, Angelo Bisazza at the University of Padua set out to observe the differences in feeding behaviour between strongly-lateralised and weakly-lateralised fish. He found that strongly-lateralised individuals were able to feed twice as fast as weakly-lateralised ones when there was a threat of a predator looming above them. Assigning different jobs to different brain halves may be especially advantageous for animals such as birds or fish, whose eyes are placed on the sides of their heads. This enables them to process input from each side separately, with different tasks in mind.</p>

<p><strong>F</strong> And what of those animals who favour a specific side for almost all tasks? In 2009, Maria Magat and Culum Brown at Macquarie University in Australia wanted to see if there was general cognitive advantage in lateralisation. To investigate, they turned to parrots, which can be either strongly right- or left-footed, or ambidextrous (without dominance). The parrots were given the intellectually demanding task of pulling a snack on a string up to their beaks, using a co-ordinated combination of claws and beak. The results showed that the parrots with the strongest foot preferences worked out the puzzle far more quickly than their ambidextrous peers.</p>

<p><strong>G</strong> A further puzzle is why are there always a few exceptions, like left-handed humans, who are wired differently from the majority of the population? Giorgio Vallortigara and Stefano Ghirlanda of Stockholm University seem to have found the answer via mathematical models. These have shown that a group of fish is likely to survive a shark attack with the fewest casualties if the majority turn together in one direction while a very small proportion of the group escape in the direction that the predator is not expecting.</p>

<p><strong>H</strong> This imbalance of lateralisation within populations may also have advantages for individuals. Whereas most co-operative interactions require participants to react similarly, there are some situations – such as aggressive interactions – where it can benefit an individual to launch an attack from an unexpected quarter. Perhaps this can partly explain the existence of left-handers in human societies. It has been suggested that when it comes to hand-to-hand fighting, left-handers may have the advantage over the right-handed majority. Where survival depends on the element of surprise, it may indeed pay to be different.</p>

<hr>

<h2>Questions 27-30</h2>
<p>Complete each sentence with the correct ending, A-F, below.</p>

<ol type="A">
    <li>lateralisation is more common in some species than in others.</li>
    <li>it benefits a population if some members have a different lateralisation than the majority.</li>
    <li>lateralisation helps animals do two things at the same time.</li>
    <li>lateralisation is not confined to human beings.</li>
    <li>the greater an animal’s lateralisation, the better it is at problem-solving.</li>
    <li>strong lateralisation may sometimes put groups of animals in danger.</li>
</ol>

<p><strong>27.</strong> Research in the 1970s first showed that ________________</p>
<p><strong>28.</strong> Rogers’ experiment in 2004 proved that ________________</p>
<p><strong>29.</strong> Bisazza’s experiment in 2006 showed that ________________</p>
<p><strong>30.</strong> Magat and Brown’s experiment in 2009 showed that ________________</p>

<hr>

<h2>Questions 31-35</h2>
<p>Complete the summary below. Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>Lesley Rogers’ 2004 Experiment</h3>
<p>Lateralisation is determined by both genetic and (31)………………………… influences. Rogers found that chicks whose eggs are given (32)……………………………. during the incubation period tend to have a stronger lateralisation. Her 2004 experiment set out to prove that these chicks were better at (33)………………………………than weakly lateralized chicks. As expected, the strongly lateralised birds in the experiment were more able to locate (34)……………………… using their right eye, while using their left eye to monitor an imitation (35)……………………………located above them.</p>

<hr>

<h2>Questions 36-40</h2>
<p>Reading Passage 3 has eight paragraphs, A-H.<br>
Which paragraph contains the following information?<br>
NB: You may use any letter more than once.</p>

<p><strong>36.</strong> ________________</p>
<p><strong>37.</strong> ________________</p>
<p><strong>38.</strong> ________________</p>
<p><strong>39.</strong> ________________</p>
<p><strong>40.</strong> ________________</p>','',3,'Passage 3',48),
	 ('2026-08-30 17:31:40','user_56659',false,'2026-08-30 17:31:40','user_56659','','','<div>

    <p><strong>Let’s Go Bats</strong></p>

    <p><strong>A</strong></p>

    <p>
        Bats have a problem: how to find their way around in the dark. They hunt at night, and
        cannot use light to help them find prey and avoid obstacles. You might say that this is a
        problem of their own making, one that they could avoid simply by changing their habits and
        hunting by day. But the daytime economy is already heavily exploited by other creatures such
        as birds. Given that there is a living to be made at night, and given that alternative
        daytime trades are thoroughly occupied, natural selection has favoured bats that make a go
        of the night-hunting trade. It is probable that the nocturnal trades go way back in the
        ancestry of all mammals. In the time when the dinosaurs dominated the daytime economy, our
        mammalian ancestors probably only managed to survive at all because they found ways of
        scraping a living at night. Only after the mysterious mass extinction of the dinosaurs about
        65 million years ago were our ancestors able to emerge into the daylight in any substantial
        numbers.
    </p>

    <p><strong>B</strong></p>

    <p>
        Bats have an engineering problem: how to find their way and find their prey in the absence
        of light. Bats are not the only creatures to face this difficulty today. Obviously the
        night-flying insects that they prey on must find their way about somehow. Deep-sea fish and
        whales have little or no light by day or by night. Fish and dolphins that live in extremely
        muddy water cannot see because, although there is light, it is obstructed and scattered by
        the dirt in the water. Plenty of other modern animals make their living in conditions where
        seeing is difficult or impossible.
    </p>

    <p><strong>C</strong></p>

    <p>
        Given the questions of how to manoeuvre in the dark, what solutions might an engineer
        consider? The first one that might occur to him is to manufacture light, to use a lantern
        or a searchlight. Fireflies and some fish (usually with the help of bacteria) have the power
        to manufacture their own light, but the process seems to consume a large amount of energy.
        Fireflies use their light for attracting mates. This doesn’t require a prohibitive amount of
        energy: a male’s tiny pinprick of light can be seen by a female from some distance on a dark
        night, since her eyes are exposed directly to the light source itself. However using light
        to find one’s own way around requires vastly more energy, since the eyes have to detect the
        tiny fraction of the light that bounces off each part of the scene. The light source must
        therefore be immensely brighter if it is to be used as a headlight to illuminate the path,
        than if it is to be used as a signal to others. In any event, whether or not the reason is
        the energy expense, it seems to be the case that, with the possible exception of some weird
        deep-sea fish, no animal apart from man uses manufactured light to find its way about.
    </p>

    <p><strong>D</strong></p>

    <p>
        What else might the engineer think of? Well, blind humans sometimes seem to have an uncanny
        sense of obstacles in their path. It has been given the name ‘facial vision’, because blind
        people have reported that it feels a bit like the sense of touch, on the face. One report
        tells of a totally blind boy who could ride his tricycle at good speed round the block near
        his home, using facial vision. Experiments showed that, in fact, facial vision is nothing
        to do with touch or the front of the face, although the sensation may be referred to the
        front of the face, like the referred pain in a phantom limb. The sensation of facial vision,
        it turns out, really goes in through the ears. Blind people, without even being aware of the
        fact, are actually using echoes of their own footsteps and of other sounds, to sense the
        presence of obstacles. Before this was discovered, engineers had already built instruments
        to exploit the principle, for example to measure the depth of the sea under a ship. After
        this technique had been invented, it was only a matter of time before weapons designers
        adapted it for the detection of submarines. Both sides in the Second World War relied heavily
        on these devices, under such codenames as Asdic (British) and Sonar (American), as well as
        Radar (American) or RDF (British), which uses radio echoes rather than sound echoes.
    </p>

    <p><strong>E</strong></p>

    <p>
        The Sonar and Radar pioneers didn’t know it then, but all the world now knows that bats, or
        rather natural selection working on bats, had perfected the system tens of millions of years
        earlier, and their radar achieves feats of detection and navigation that would strike an
        engineer dumb with admiration. It is technically incorrect to talk about bat ‘radar’, since
        they do not use radio waves. It is sonar but the underlying mathematical theories of radar
        and sonar are very similar and much of our scientific understanding of the details of what
        bats are doing has come from applying radar theory to them. The American zoologist Donald
        Griffin, who was largely responsible for the discovery of sonar in bats, coined the term
        ‘echolocation’ to cover both sonar and radar, whether used by animals or by human
        instruments.
    </p>

    <p><strong>Questions 1–5</strong></p>

    <p>
        <strong>
            Reading Passage 1 has five paragraphs, A–E. Which paragraph contains the following
            information?
        </strong>
    </p>

    <p>
        Write the correct letter, A–E, in boxes 1–5 on your answer sheet.
    </p>

    <p><em>NB You may use any letter more than once.</em></p>

    <p><strong>Questions 6–9</strong></p>

    <p><strong>Complete the summary below.</strong></p>

    <p><strong>Choose ONE WORD ONLY from the passage for each answer.</strong></p>

    <p><strong>Facial Vision</strong></p>

    <p>
        Blind people report that so-called ‘facial vision’ is comparable to the sensation of touch
        on the face. In fact, the sensation is more similar to the way in which pain from a
        (6) ................................ arm or leg might be felt. The ability actually comes
        from perceiving (7) ................................ through the ears.
    </p>

    <p>
        However, even before this was understood, the principle had been applied in the design of
        instruments which calculated the (8) ................................ of the seabed. This
        was followed by a wartime application in devices for finding
        (9) ................................ .
    </p>

    <p><strong>Questions 10–13</strong></p>

    <p><strong>Complete the sentences below.</strong></p>

    <p><strong>Choose NO MORE THAN TWO WORDS from the passage for each answer.</strong></p>

</div>','',1,'Passage 1',49),
	 ('2026-08-31 17:31:40','user_56659',false,'2026-08-31 17:31:40','user_56659','','','<h2>Making Every Drop Count</h2>

<h3>A</h3>
<p>
The history of human civilisation is entwined with the history of the ways we have learned to manipulate water resources.
As towns gradually expanded, water was brought from increasingly remote sources, leading to sophisticated engineering efforts
such as dams and aqueducts. At the height of the Roman Empire, nine major systems, with an innovative layout of pipes and
well-built sewers, supplied the occupants of Rome with as much water per person as is provided in many parts of the industrial
world today.
</p>

<h3>B</h3>
<p>
During the industrial revolution and population explosion of the 19th and 20th centuries, the demand for water rose dramatically.
Unprecedented construction of tens of thousands of monumental engineering projects designed to control floods, protect clean
water supplies, and provide water for irrigation and hydropower brought great benefits to hundreds of millions of people.
Food production has kept pace with soaring populations mainly because of the expansion of artificial irrigation systems that
make possible the growth of 40% of the world''s food. Nearly one fifth of all the electricity generated worldwide is produced
by turbines spun by the power of falling water.
</p>

<h3>C</h3>
<p>
Yet there is a dark side to this picture: despite our progress, half of the world''s population still suffers, with water
services inferior to those available to the ancient Greeks and Romans. As the United Nations report on access to water
reiterated in November 2001, more than one billion people lack access to clean drinking water; some two and a half billion
do not have adequate sanitation services. Preventable water-related diseases kill an estimated 10,000 to 20,000 children
every day, and the latest evidence suggests that we are falling behind in efforts to solve these problems.
</p>

<h3>D</h3>
<p>
The consequences of our water policies extend beyond jeopardising human health. Tens of millions of people have been forced
to move from their homes – often with little warning or compensation – to make way for the reservoirs behind dams. More than
20% of all freshwater fish species are now threatened or endangered because dams and water withdrawals have destroyed the
free-flowing river ecosystems where they thrive. Certain irrigation practices degrade soil quality and reduce agricultural
productivity. Groundwater aquifers are being pumped down faster than they are naturally replenished in parts of India, China,
the USA and elsewhere. And disputes over shared water resources have led to violence and continue to raise local, national
and even international tensions.
</p>

<h3>E</h3>
<p>
At the outset of the new millennium, however, the way resource planners think about water is beginning to change. The focus
is slowly shifting back to the provision of basic human and environmental needs as top priority – ensuring "some for all,"
instead of "more for some". Some water experts are now demanding that existing infrastructure be used in smarter ways rather
than building new facilities, which is increasingly considered the option of last, not first, resort. This shift in philosophy
has not been universally accepted, and it comes with strong opposition from some established water organisations. Nevertheless,
it may be the only way to address successfully the pressing problems of providing everyone with clean water to drink, adequate
water to grow food and a life free from preventable water-related illness.
</p>

<h3>F</h3>
<p>
Fortunately – and unexpectedly – the demand for water is not rising as rapidly as some predicted. As a result, the pressure
to build new water infrastructures has diminished over the past two decades. Although population, industrial output and economic
productivity have continued to soar in developed nations, the rate at which people withdraw water from aquifers, rivers and lakes
has slowed. And in a few parts of the world, demand has actually fallen.
</p>

<h3>G</h3>
<p>
What explains this remarkable turn of events? Two factors: people have figured out how to use water more efficiently, and
communities are rethinking their priorities for water use. Throughout the first three-quarters of the 20th century, the quantity
of freshwater consumed per person doubled on average; in the USA, water withdrawals increased tenfold while the population
quadrupled. But since 1980, the amount of water consumed per person has actually decreased, thanks to a range of new technologies
that help to conserve water in homes and industry. In 1965, for instance, Japan used approximately 13 million gallons of water
to produce $1 million of commercial output; by 1989 this had dropped to 3.5 million gallons (even accounting for inflation) –
almost a quadrupling of water productivity. In the USA, water withdrawals have fallen by more than 20% from their peak in 1980.
</p>

<h3>H</h3>
<p>
On the other hand, dams, aqueducts and other kinds of infrastructure will still have to be built, particularly in developing
countries where basic human needs have not been met. But such projects must be built to higher specifications and with more
accountability to local people and their environment than in the past. And even in regions where new projects seem warranted,
we must find ways to meet demands with fewer resources, respecting ecological criteria and to a smaller budget.
</p>

<hr>

<h3>Questions 14–20</h3>

<p>
<strong>Reading Passage 2 has seven paragraphs, A–H.</strong>
Choose the correct heading for paragraphs A and C–H from the list of headings below.
</p>

<p>
Write the correct number, <strong>i–xi</strong>, in boxes <strong>14–20</strong> on your answer sheet.
</p>

<p><strong>Example:</strong> Passage B – iii</p>

<h4>List of Headings</h4>

<ul style="list-style:none;padding-left:0;">
    <li>i&nbsp;&nbsp;Scientists’ call for revision of policy</li>
    <li>ii&nbsp;An explanation for reduced water use</li>
    <li>iii&nbsp;How a global challenge was met</li>
    <li>iv&nbsp;Irrigation systems fall into disuse</li>
    <li>v&nbsp;&nbsp;Environmental effects</li>
    <li>vi&nbsp;The financial cost of recent technological improvements</li>
    <li>vii&nbsp;The relevance to health</li>
    <li>viii&nbsp;Addressing the concern over increasing populations</li>
    <li>ix&nbsp;A surprising downward trend in demand for water</li>
    <li>x&nbsp;&nbsp;The need to raise standards</li>
    <li>xi&nbsp;A description of ancient water supplies</li>
</ul>

<hr>

<h3>Questions 21–26</h3>

<p>
Do the following statements agree with the information given in Reading Passage 2?
</p>

<p>
In boxes <strong>21–26</strong> on your answer sheet, write:
</p>

<ul style="list-style:none;padding-left:0;">
    <li><strong>YES</strong> — if the statement agrees with the claims of the writer</li>
    <li><strong>NO</strong> — if the statement contradicts the claims of the writer</li>
    <li><strong>NOT GIVEN</strong> — if it is impossible to say what the writer thinks about this</li>
</ul>','',2,'Passage 2',49),
	 ('2026-09-01 17:31:40','user_56659',false,'2026-09-01 17:31:40','user_56659','','','<h2>EDUCATING PSYCHE</h2>

<div class="box">
<p>
Educating Psyche by Bernie Neville is a book which looks at radical new approaches to learning, describing the effects of emotion, imagination and the unconscious on learning. One theory discussed in the book is that proposed by George Lozanov, which focuses on the power of suggestion.
</p>

<p>
Lozanov’s instructional technique is based on the evidence that the connections made in the brain through unconscious processing (which he calls non-specific mental reactivity) are more durable than those made through conscious processing. Besides the laboratory evidence for this, we know from our experience that we often remember what we have perceived peripherally, long after we have forgotten what we set out to learn. If we think of a book we studied months or years ago, we will find it easier to recall peripheral details – the colour, the binding, the typeface, the table at the library where we sat while studying it – than the content on which we were concentrating. If we think of a lecture we listened to with great concentration, we will recall the lecturer’s appearance and mannerisms, our place in the auditorium, the failure of the air-conditioning, much more easily than the ideas we went to learn.
</p>

<p>
This phenomenon can be partly attributed to the common counterproductive approach to study, but it also simply reflects the way the brain functions. Lozanov therefore made indirect instruction (suggestion) central to his teaching system. In suggestopedia, consciousness is shifted away from the curriculum to focus on something peripheral.
</p>

<p>
The suggestopedic approach to foreign language learning consists of reading vocabulary and text while listening to music. Students are passively exposed to material while classical and baroque music is played. Before the session, students are prepared psychologically and encouraged to believe that learning will be easy and effective.
</p>

<p>
Lozanov also emphasized that ritual and authority are important components of suggestion. Although controversial, his method suggests that large amounts of vocabulary can be acquired in a short time through relaxed exposure rather than conscious memorization.
</p>
</div>

<hr>

<h2>Questions 31–36</h2>

<ul>
    <li>TRUE if the statement agrees with the information</li>
    <li>FALSE if the statement contradicts the information</li>
    <li>NOT GIVEN if there is no information on this</li>
</ul>

<div class="question box">
<p>31. People tend to remember peripheral details more easily than core content when recalling past learning experiences.</p>
<p>32. Lozanov believed conscious repetition was the most effective way to learn vocabulary.</p>
<p>33. Suggestopedia involves students actively trying to memorize vocabulary during music sessions.</p>
<p>34. Students are told beforehand that learning will be easy and enjoyable.</p>
<p>35. Hypnosis is considered essential to Lozanov’s teaching method.</p>
<p>36. Most teachers using suggestopedia achieve the same results as Lozanov.</p>
</div>

<hr>

<h2>Questions 37–40</h2>

<div class="box">
<p>
Suggestopedia uses a less direct method of suggestion than other techniques such as hypnosis. However, Lozanov admits that a certain amount of (37) ______ is necessary in order to convince students, even if this is just a (38) ______. Furthermore, if the method is to succeed, teachers must follow a set procedure. Although Lozanov’s method has become quite (39) ______, the results of most other teachers using this method have been (40) ______.
</p>
</div>

<p><b>Word list:</b></p>
<ul>
    <li>A. spectacular</li>
    <li>B. teaching</li>
    <li>C. lesson</li>
    <li>D. authoritarian</li>
    <li>E. unpopular</li>
    <li>F. ritual</li>
    <li>G. unspectacular</li>
    <li>H. placebo</li>
    <li>I. involved</li>
    <li>J. appropriate</li>
    <li>K. well known</li>
</ul>','',3,'Passage 3',49),
	 ('2026-09-02 17:31:40','user_05335',false,'2026-09-02 17:31:40','user_05335','','','<h1>The Context, Meaning and Scope of Tourism</h1>

<h2>Reading Passage 1</h2>

<p><strong>A</strong> Travel has existed since the beginning of time, when primitive man set out, often traversing great distances in search of game, which provided the food and clothing necessary for his survival. Throughout the course of history, people have travelled for purposes of trade, religious conviction, economic gain, war, migration and other equally compelling motivations. In the Roman era, wealthy aristocrats and high government officials also travelled for pleasure. Seaside resorts located at Pompeii and Herculaneum afforded citizens the opportunity to escape to their vacation villas in order to avoid the summer heat of Rome. Travel, except during the Dark Ages, has continued to grow and, throughout recorded history, has played a vital role in the development of civilisations and their economies.</p>

<p><strong>B</strong> Tourism in the mass form as we know it today is a distinctly twentieth-century phenomenon. Historians suggest that the advent of mass tourism began in England during the industrial revolution with the rise of the middle class and the availability of relatively inexpensive transportation. The creation of the commercial airline industry following the Second World War and the subsequent development of the jet aircraft in the 1950s signalled the rapid growth and expansion of international travel. This growth led to the development of a major new industry: tourism. In turn, international tourism became the concern of a number of world governments since it not only provided new employment opportunities but also produced a means of earning foreign exchange.</p>

<p><strong>C</strong> Tourism today has grown significantly in both economic and social importance. In most industrialised countries over the past few years the fastest growth has been seen in the area of services. One of the largest segments of the service industry, although largely unrecognised as an entity in some of these countries, is travel and tourism. According to the World Travel and Tourism Council (1992), Travel and tourism is the largest industry in the world on virtually any economic measure including value-added capital investment, employment and tax contributions. In 1992, the industry’s gross output was estimated to be $3.5 trillion, over 12 per cent of all consumer spending. The travel and tourism industry is the world’s largest employer the almost 130 million jobs, or almost 7 per cent of all employees. This industry is the world’s leading industrial contributor, producing over 6 per cent of the world’s national product and accounting for capital investment in excess of $422 billion in direct indirect and personal taxes each year. Thus, tourism has a profound impact both on the world economy and, because of the educative effect of travel and the effects on employment, on society itself.</p>

<p><strong>D</strong> However, the major problems of the travel and tourism industry that have hidden, or obscured, its economic impact are the diversity and fragmentation of the industry itself. The travel industry includes: hotels, motels and other types of accommodation; restaurants and other food services; transportation services and facilities; amusements, attractions and other leisure facilities; gift shops and a large number of other enterprises. Since many of these businesses also serve local residents, the impact of spending by visitors can easily be overlooked or underestimated. In addition, Meis (1992) points out that the tourism industry involves concepts that have remained amorphous to both analysts and decision makers. Moreover, in all nations this problem has made it difficult for the industry to develop any type of reliable or credible tourism information base in order to estimate the contribution it makes to regional, national and global economies. However, the nature of this very diversity makes travel and tourism ideal vehicles for economic development in a wide variety of countries, regions or communities.</p>

<p><strong>E</strong> Once the exclusive province of the wealthy, travel and tourism have become an institutionalised way of life for most of the population. In fact, McIntosh and Goeldner (1990) suggest that tourism has become the largest commodity in international trade for many nations and, for a significant number of other countries, it ranks second or third. For example, tourism is the major source of income in Bermuda, Greece, Italy, Spain, Switzerland and most Caribbean countries. In addition, Hawkins and Ritchie, quoting from data published by the American Express Company, suggest that the travel and tourism industry is the number one ranked employer in the Bahamas, Brazil, Canada, France, (the former) West Germany, Hong Kong, Italy, Jamaica, Japan, Singapore, the United Kingdom and the United States. However, because of problems of definition, which directly affect statistical measurement, it is not possible with any degree of certainty to provide precise, valid or reliable data about the extent of world-wide tourism participation or its economic impact. In many cases, similar difficulties arise when attempts are made to measure domestic tourism.</p>

<hr>

<h2>Questions 1-4</h2>
<p>Reading Passage 1 has five paragraphs, A-E.<br>
Choose the correct heading for paragraphs B-E from the list of headings below.<br>
Write the correct number, i-vii, in boxes 1-4 on your answer sheet.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>Economic and social significance of tourism</li>
    <li>The development of mass tourism</li>
    <li>Travel for the wealthy</li>
    <li>Earning foreign exchange through tourism</li>
    <li>Difficulty in recognising the economic effects of tourism</li>
    <li>The contribution of air travel to tourism</li>
    <li>The world impact of tourism</li>
    <li>The history of travel</li>
</ol>

<p><strong>Example</strong> Paragraph A: <strong>viii</strong></p>

<p><strong>1.</strong> Paragraph B: ______</p>
<p><strong>2.</strong> Paragraph C: ______</p>
<p><strong>3.</strong> Paragraph D: ______</p>
<p><strong>4.</strong> Paragraph E: ______</p>

<hr>

<h2>Questions 5-10</h2>
<p>Do the following statements agree with the information given in Reading Passage 1?<br>
In boxes 5-10 on your answer sheet, write</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>5.</strong> ________________</p>
<p><strong>6.</strong> ________________</p>
<p><strong>7.</strong> ________________</p>
<p><strong>8.</strong> ________________</p>
<p><strong>9.</strong> ________________</p>
<p><strong>10.</strong> ________________</p>

<hr>

<h2>Questions 11-13</h2>
<p>Complete the sentences below.<br>
Choose <strong>NO MORE THAN THREE WORDS</strong> from the passage for each answer.<br>
Write your answers in boxes 11-13 on your answer sheet.</p>

<p><strong>11.</strong> ________________</p>
<p><strong>12.</strong> ________________</p>
<p><strong>13.</strong> ________________</p>','',1,'Passage 1',50),
	 ('2026-09-03 17:31:40','user_05335',false,'2026-09-03 17:31:40','user_05335','','','<h1>Autumn leaves</h1>

<p>Canadian writer Jay Ingram investigates the mystery of why leaves turn red in the fall</p>

<h2>Reading Passage 2</h2>

<p><strong>A</strong> One of the most captivating natural events of the year in many areas throughout North America is the turning of the leaves in the fall. The colours are magnificent, but the question of exactly why some trees turn yellow or orange, and others red or purple, is something which has long puzzled scientists.</p>

<p><strong>B</strong> Summer leaves are green because they are full of chlorophyll, the molecule that captures sunlight converts that energy into new building materials for the tree. As fall approaches in the northern hemisphere, the amount of solar energy available declines considerably. For many trees – evergreen conifers being an exception – the best strategy is to abandon photosynthesis* until the spring. So rather than maintaining the now redundant leaves throughout the winter, the tree saves its precious resources and discards them. But before letting its leaves go, the tree dismantles their chlorophyll molecules and ships their valuable nitrogen back into the twigs. As chlorophyll is depleted, other colours that have been dominated by it throughout the summer begin to be revealed. This unmasking explains the autumn colours of yellow and orange, but not the brilliant reds and purples of trees such as the maple or sumac.</p>

<p><strong>C</strong> The source of the red is widely known: it is created by anthocyanins, water-soluble plant pigments reflecting the red to blue range of the visible spectrum. They belong to a class of sugar-based chemical compounds also known as flavonoids. What’s puzzling is that anthocyanins are actually newly minted, made in the leaves at the same time as the tree is preparing to drop them. But it is hard to make sense of the manufacture of anthocyanins – why should a tree bother making new chemicals in its leaves when it’s already scrambling to withdraw and preserve the ones already there?</p>

<p><strong>D</strong> Some theories about anthocyanins have argued that they might act as a chemical defence against attacks by insects or fungi, or that they might attract fruit-eating birds or increase a leaf''s tolerance to freezing. However there are problems with each of these theories, including the fact that leaves are red for such a relatively short period that the expense of energy needed to manufacture the anthocyanins would outweigh any anti-fungal or anti-herbivore activity achieved.</p>

<p><strong>E</strong> It has also been proposed that trees may produce vivid red colours to convince herbivorous insects that they are healthy and robust and would be easily able to mount chemical defences against infestation. If insects paid attention to such advertisements, they might be prompted to lay their eggs on a duller, and presumably less resistant host. The flaw in this theory lies in the lack of proof to support it. No one has as yet ascertained whether more robust trees sport the brightest leaves, or whether insects make choices according to colour intensity.</p>

<p><strong>F</strong> Perhaps the most plausible suggestion as to why leaves would go to the trouble of making anthocyanins when they’re busy packing up for the winter is the theory known as the ‘light screen’ hypothesis. It sounds paradoxical, because the idea behind this hypothesis is that the red pigment is made in autumn leaves to protect chlorophyll, the light-absorbing chemical, from too much light. Why does chlorophyll need protection when it is the natural world’s supreme light absorber? Why protect chlorophyll at a time when the tree is breaking it down to salvage as much of it as possible?</p>

<p><strong>G</strong> Chlorophyll, although exquisitely evolved to capture the energy of sunlight, can sometimes be overwhelmed by it, especially in situations of drought, low temperatures, or nutrient deficiency. Moreover, the problem of oversensitivity to light is even more acute in the fall, when the leaf is busy preparing for winter by dismantling its internal machinery. The energy absorbed by the chlorophyll molecules of the unstable autumn leaf is not immediately channelled into useful products and processes, as it would be in an intact summer leaf. The weakened fall leaf then becomes vulnerable to the highly destructive effects of the oxygen created by the excited chlorophyll molecules.</p>

<p><strong>H</strong> Even if you had never suspected that this is what was going on when leaves turn red, there are clues out there. One is straightforward: on many trees, the leaves that are the reddest are those on the side of the tree which gets most sun. Not only that, but the red is brighter on the upper side of the leaf. It has also been recognised for decades that the best conditions for intense red colours are dry, sunny days and cool nights, conditions that nicely match those that make leaves susceptible to excess light. And finally, trees such as maples usually get much redder the more north you travel in the northern hemisphere. It’s colder there, they’re more stressed, their chlorophyll is more sensitive and it needs more sunblock.</p>

<p><strong>I</strong> What is still not fully understood, however, is why some trees resort to producing red pigments while others don’t bother, and simply reveal their orange or yellow hues. Do these trees have other means at their disposal to prevent overexposure to light in autumn? Their story, though not as spectacular to the eye, will surely turn out to be as subtle and as complex.</p>

<p><em>* photosynthesis: the production of new material from sunlight, water and carbon dioxide.</em></p>

<hr>

<h2>Questions 14-18</h2>
<p>Reading Passage 2 has nine paragraphs, A-I.<br>
Which paragraph contains the following information?<br>
Write the correct letter, A-I, in boxes 14-18 on your answer sheet.<br>
NB You may use any letter more than once.</p>

<p><strong>14.</strong> ________________</p>
<p><strong>15.</strong> ________________</p>
<p><strong>16.</strong> ________________</p>
<p><strong>17.</strong> ________________</p>
<p><strong>18.</strong> ________________</p>

<hr>

<h2>Questions 19-22</h2>
<p>Complete the notes below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>Why believe the ‘light screen’ hypothesis?</h3>
<ul>
    <li>The most vividly coloured red leaves are found on the side of the tree facing the <strong>19.</strong> …………….. .</li>
    <li>The <strong>20.</strong> …………… surfaces of leaves contain the most red pigment.</li>
    <li>Red leaves are most abundant when daytime weather conditions are <strong>21.</strong> ……………. and sunny.</li>
    <li>The intensity of the red colour of leaves increases as you go further <strong>22.</strong> ………….. .</li>
</ul>

<hr>

<h2>Questions 23-25</h2>
<p>Do the following statements agree with the information given in Reading Passage 2?<br>
In boxes 23-25 on your answer sheet, write</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>23.</strong> ________________</p>
<p><strong>24.</strong> ________________</p>
<p><strong>25.</strong> ________________</p>

<hr>

<h2>Question 26</h2>
<p>Choose the correct letter A, B, C or D.</p>

<p><strong>26.</strong> ________________</p>','',2,'Passage 2',50),
	 ('2026-09-04 17:31:40','user_05335',false,'2026-09-04 17:31:40','user_05335','','','<h1>Beyond the blue horizon</h1>

<p>Ancient voyagers who settled the far-flung islands of the Pacific Ocean</p>

<h2>Reading Passage 3</h2>

<p><strong>A</strong> An important archaeological discovery on the island of Efate in the Pacific archipelago of Vanuatu has revealed traces of an ancient seafaring people, the distant ancestors of today’s Polynesians. The site came to light only by chance. An agricultural worker, digging in the grounds of a derelict plantation, scraped open a grave – the first of dozens in a burial ground some 3,000 years old. It is the oldest cemetery ever found in the Pacific islands, and it harbors the remains of an ancient people archaeologists call the Lapita.</p>

<p><strong>B</strong> They were daring blue-water adventurers who used basic canoes to rove across the ocean. But they were not just explorers. They were also pioneers who carried with them everything they would need to build new lives – their livestock, taro seedlings and stone tools. Within the span of several centuries, the Lapita stretched the boundaries of their world from the jungle-clad volcanoes of Papua New Guinea to the loneliest coral outliers of Tonga.</p>

<p><strong>C</strong> The Lapita left precious few clues about themselves, but Efate expands the volume of data available to researchers dramatically. The remains of 62 individuals have been uncovered so far, and archaeologists were also thrilled to find six complete Lapita pots. Other items included a Lapita burial urn with modeled birds arranged on the rim as though peering down at the human remains sealed inside. ‘It’s an important discovery,’ says Matthew Spriggs, professor of archaeology at the Australian National University and head of the international team digging up the site, ‘for it conclusively identifies the remains as Lapita.’</p>

<p><strong>D</strong> DNA teased from these human remains may help answer one of the most puzzling questions in Pacific anthropology: did all Pacific islanders spring from one source or many? Was there only one outward migration from a single point in Asia, or several from different points? ‘This represents the best opportunity we’ve had yet,’ says Spriggs, ‘to find out who the Lapita actually were, where they came from, and who their closest descendants are today.’</p>

<p><strong>E</strong> There is one stubborn question for which archaeology has yet to provide any answers: how did the Lapita accomplish the ancient equivalent of a moon landing, many times over? No-one has found one of their canoes or any rigging, which could reveal how the canoes were sailed. Nor do the oral histories and traditions of later Polynesians offer any insights, for they turn into myths long before they reach as far back in time as the Lapita.</p>

<p><strong>F</strong> ‘All we can say for certain is that the Lapita had canoes that were capable of ocean voyages, and they had the ability to sail them,’ says Geoff Irwin, a professor of archaeology at the University of Auckland. Those sailing skills, he says, were developed and passed down over thousands of years by earlier mariners who worked their way through the archipelagoes of the western Pacific, making short crossings to nearby islands. The real adventure didn’t begin, however, until their Lapita descendants sailed out of sight of land, with empty horizons on every side. This must have been as difficult for them as landing on the moon is for us today. Certainly it distinguished them from their ancestors, but what gave them the courage to launch out on such risky voyages?</p>

<p><strong>G</strong> The Lapita''s thrust into the Pacific was eastward, against the prevailing trade winds, Irwin notes. Those nagging headwinds, he argues, may have been the key to their success. ‘They could sail out for days into the unknown and assess the area, secure in the knowledge that if they didn’t find anything, they could turn about and catch a swift ride back on the trade winds. This is what would have made the whole thing work.’ Once out there, skilled seafarers would have detected abundant leads to follow to land: seabirds, coconuts and twigs carried out to sea by the tides, and the afternoon pile-up of clouds on the horizon which often indicates an island in the distance.</p>

<p><strong>H</strong> For returning explorers, successful or not, the geography of their own archipelagoes would have provided a safety net. Without this to go by, overshooting their home ports, getting lost and sailing off into eternity would have been all too easy. Vanuatu, for example, stretches more than 500 miles in a northwest-southeast trend, its scores of intervisible islands forming a backstop for mariners riding the trade winds home.</p>

<p><strong>I</strong> All this presupposes one essential detail, says Atholl Anderson, professor of prehistory at the Australian National University: the Lapita had mastered the advanced art of sailing against the wind. ‘And there’s no proof they could do any such thing,’ Anderson says. ‘There has been this assumption they did, and people have built canoes to re-create those early voyages based on that assumption. But nobody has any idea what their canoes looked like or how they were rigged.’</p>

<p><strong>J</strong> Rather than give all the credit to human skill, Anderson invokes the winds of chance. El Nino, the same climate disruption that affects the Pacific today, may have helped scatter the Lapita, Anderson suggests. He points out that climate data obtained from slow-growing corals around the Pacific indicate a series of unusually frequent El Ninos around the time of the Lapita expansion. By reversing the regular east-to-west flow of the trade winds for weeks at a time, these super El Ninos might have taken the Lapita on long unplanned voyages.</p>

<p><strong>K</strong> However they did it, the Lapita spread themselves a third of the way across the Pacific, then called it quits for reasons known only to them. Ahead lay the vast emptiness of the central Pacific and perhaps they were too thinly stretched to venture farther. They probably never numbered more than a few thousand in total, and in their rapid migration eastward they encountered hundreds of islands – more than 300 in Fiji alone.</p>

<hr>

<h2>Questions 27-31</h2>
<p>Complete the summary using the list of words and phrases, A-J, below.<br>
Write the correct letter, A-J, in boxes 27-31 on your answer sheet.</p>

<h3>The Efate burial site</h3>
<p>A 3,000-year-old burial ground of a seafaring people called the Lapita has been found on an abandoned <strong>27.</strong> …………… on the Pacific island of Efate. The cemetery, which is a significant <strong>28.</strong> …………… , was uncovered accidentally by an agricultural worker.</p>
<p>The Lapita explored and colonised many Pacific islands over several centuries. They took many things with them on their voyages including <strong>29.</strong> …………… and tools.</p>
<p>The burial ground increases the amount of information about the Lapita available to scientists. A team of researchers, led by Matthew Spriggs from the Australian National University, are helping with the excavation of the site. Spriggs believes the <strong>30.</strong> …………… which was found at the site is very important since it confirms that the <strong>31.</strong> …………… found inside are Lapita.</p>

<h3>List of words and phrases</h3>
<ol type="A">
    <li>proof</li>
    <li>plantation</li>
    <li>harbour</li>
    <li>bones</li>
    <li>data</li>
    <li>archaeological discovery</li>
    <li>burial urn</li>
    <li>source</li>
    <li>animals</li>
    <li>maps</li>
</ol>

<hr>

<h2>Questions 32-35</h2>
<p>Choose the correct letter A, B, C or D.<br>
Write the correct letter in boxes 32-35 on your answer sheet.</p>

<p><strong>32.</strong> ________________</p>
<p><strong>33.</strong> ________________</p>
<p><strong>34.</strong> ________________</p>
<p><strong>35.</strong> ________________</p>

<hr>

<h2>Questions 36-40</h2>
<p>Do the following statements agree with the views of the writer in Reading Passage 3?<br>
In boxes 36-40 on your answer sheet, write</p>
<p><strong>YES</strong> — if the statement agrees with the views of the writer<br>
<strong>NO</strong> — if the statement contradicts the views of the writer<br>
<strong>NOT GIVEN</strong> — if it is impossible to say what the writer thinks about this</p>

<p><strong>36.</strong> ________________</p>
<p><strong>37.</strong> ________________</p>
<p><strong>38.</strong> ________________</p>
<p><strong>39.</strong> ________________</p>
<p><strong>40.</strong> ________________</p>','',3,'Passage 3',50),
	 ('2026-09-05 17:31:40','user_05335',false,'2026-09-05 17:31:40','user_05335','','','<h1>The story of silk</h1>
<p>The history of the world’s most luxurious fabric, from ancient China to the present day</p>

<h2>Reading Passage</h2>

<p>Silk is a fine, smooth material produced from the cocoons – soft protective shells – that are made by mulberry silkworms (insect larvae). Legend has it that it was Lei Tzu, wife of the Yellow Emperor, ruler of China in about 3000 BC, who discovered silkworms. One account of the story goes that as she was taking a walk in her husband’s gardens, she discovered that silkworms were responsible for the destruction of several mulberry trees. She collected a number of cocoons and sat down to have a rest. It just so happened that while she was sipping some tea, one of the cocoons that she had collected landed in the hot tea and started to unravel into a fine thread. Lei Tzu found that she could wind this thread around her fingers. Subsequently, she persuaded her husband to allow her to rear silkworms on a grove of mulberry trees. She also devised a special reel to draw the fibres from the cocoon into a single thread so that they would be strong enough to be woven into fabric. While it is unknown just how much of this is true, it is certainly known that silk cultivation has existed in China for several millennia.</p>

<p>Originally, silkworm farming was solely restricted to women, and it was they who were responsible for the growing, harvesting and weaving. Silk quickly grew into a symbol of status, and originally, only royalty were entitled to have clothes made of silk. The rules were gradually relaxed over the years until finally during the Qing Dynasty (1644—1911 AD), even peasants, the lowest caste, were also entitled to wear silk. Sometime during the Han Dynasty (206 BC-220 AD), silk was so prized that it was also used as a unit of currency. Government officials were paid their salary in silk, and farmers paid their taxes in grain and silk. Silk was also used as diplomatic gifts by the emperor. Fishing lines, bowstrings, musical instruments and paper were all made using silk. The earliest indication of silk paper being used was discovered in the tomb of a noble who is estimated to have died around 168 AD.</p>

<p>Demand for this exotic fabric eventually created the lucrative trade route now known as the Silk Road, taking silk westward and bringing gold, silver and wool to the East. It was named the Silk Road after its most precious commodity, which was considered to be worth more than gold. The Silk Road stretched over 6,000 kilometres from Eastern China to the Mediterranean Sea, following the Great Wall of China, climbing the Pamir mountain range, crossing modern-day Afghanistan and going on to the Middle East, with a major trading market in Damascus. From there, the merchandise was shipped across the Mediterranean Sea. Few merchants travelled the entire route; goods were handled mostly by a series of middlemen.</p>

<p>With the mulberry silkworm being native to China, the country was the world’s sole producer of silk for many hundreds of years. The secret of silk-making eventually reached the rest of the world via the Byzantine Empire, which ruled over the Mediterranean region of southern Europe, North Africa and the Middle East during the period 330—1453 AD. According to another legend, monks working for the Byzantine emperor Justinian smuggle silkworm eggs to Constantinople (Istanbul in modern-day Turkey) in 550 AD, concealed inside hollow bamboo walking canes. The Byzantines were as secretive as the Chinese, however, and for many centuries the weaving and trading of silk fabric was a strict imperial monopoly. Then in the seventh century, the Arabs conquered Persia, capturing their magnificent silks in the process.</p>

<p>Silk production thus spread through Africa, Sicily and Spain as the Arabs swept through these lands. Andalusia in southern Spain was Europe’s main silk-producing centre in the tenth century. By the thirteenth century, however, Italy had become Europe’s leader in silk production and export. Venetian merchants traded extensively in silk and encouraged silk growers to settle in Italy. Even now, silk processed in the province of Como in northern Italy enjoys an esteemed reputation.</p>

<p>The nineteenth century and industrialisation saw the downfall of the European silk industry. Cheaper Japanese silk, trade in which was greatly facilitated by the opening of the Suez Canal, was one of the many factors driving the trend. Then in the twentieth century, new manmade fibres, such as nylon, started to be used in what had traditionally been silk products, such as stockings and parachutes. The two world wars, which interrupted the supply of raw material from Japan, also stifled the European silk industry. After the Second World War, Japan’s silk production was restored, with improved production and quality of raw silk. Japan was to remain the world’s biggest producer of raw silk, and practically the only major exporter of raw silk, until the 1970s. However, in more recent decades, China has gradually recaptured its position as the world’s biggest producer and exporter of raw silk and silk yarn. Today, around 125,000 metric tons of silk are produced in the world, and almost two thirds of that production takes place in China.</p>

<hr>

<h2>Questions 1-9</h2>
<p>Complete the notes below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>THE STORY OF SILK</h3>

<h4>Early silk production in China</h4>
<ul>
    <li>Around 3000 BC, according to legend:<br>
    – silkworm cocoon fell into emperor’s wife’s (1)………………<br>
    – emperor’s wife invented a (2)……………. to pull out silk fibres</li>
    <li>Only (3)……………… were allowed to produce silk</li>
    <li>Only (4)………………. were allowed to wear silk</li>
    <li>Silk used as a form of (5)……………….<br>
    – e.g. farmers’ taxes consisted partly of silk</li>
    <li>Silk used for many purposes<br>
    – e.g. evidence found of (6)……………… made from silk around 168 AD</li>
</ul>

<h4>Silk reaches rest of world</h4>
<ul>
    <li>Merchants use Silk Road to take silk westward and bring back (7)…………….. and precious metals</li>
    <li>550 AD: (8)……………… hide silkworm eggs in canes and take them to Constantinople</li>
    <li>Silk production spreads across Middle East and Europe</li>
    <li>20th century: (9)……………… and other manmade fibres cause decline in silk production</li>
</ul>

<hr>

<h2>Questions 10-13</h2>
<p>Do the following statements agree with the information in Reading Passage?<br>
In boxes 10-13 on your answer sheet, write</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>10.</strong> ________________</p>
<p><strong>11.</strong> ________________</p>
<p><strong>12.</strong> ________________</p>
<p><strong>13.</strong> ________________</p>','',1,'Passage 1',51),
	 ('2026-09-06 17:31:40','user_05335',false,'2026-09-06 17:31:40','user_05335','','','<h1>Great Migrations</h1>

<p>Animal migration, however it is defined, is far more than just the movement of animals. It can loosely be described as travel that takes place at regular intervals – often in an annual cycle – that may involve many members of a species, and is rewarded only after a long journey. It suggests inherited instinct. The biologist Hugh Dingle has identified five characteristics that apply, in varying degrees and combinations, to all migrations. They are prolonged movements that carry animals outside familiar habitats; they tend to be linear, not zigzaggy; they involve special behaviours concerning preparation (such as overfeeding) and arrival; they demand special allocations of energy. And one more: migrating animals maintain an intense attentiveness to the greater mission, which keeps them undistracted by temptations and undeterred by challenges that would turn other animals aside.</p>

<p>An arctic tern, on its 20,000 km flight from the extreme south of South America to the Arctic circle, will take no notice of a nice smelly herring offered from a bird-watcher’s boat along the way. While local gulls will dive voraciously for such handouts, the tern flies on. Why? The arctic tern resists distraction because it is driven at that moment by an instinctive sense of something we humans find admirable: larger purpose. In other words, it is determined to reach its destination. The bird senses that it can eat, rest and mate later. Right now it is totally focused on the journey; its undivided intent is arrival.</p>

<p>Reaching some gravelly coastline in the Arctic, upon which other arctic terns have converged, will serve its larger purpose as shaped by evolution: finding a place, a time, and a set of circumstances in which it can successfully hatch and rear offspring.</p>

<p>But migration is a complex issue, and biologists define it differently, depending in part on what sorts of animals they study. Joel Berger, of the University of Montana, who works on the American pronghorn and other large terrestrial mammals, prefers what he calls a simple, practical definition suited to his beasts: ‘movements from a seasonal home area away to another home area and back again’. Generally the reason for such seasonal back-and-forth movement is to seek resources that aren’t available within a single area year-round.</p>

<p>But daily vertical movements by zooplankton in the ocean – upward by night to seek food, downward by day to escape predators – can also be considered migration. So can the movement of aphids when, having depleted the young leaves on one food plant, their offspring then fly onward to a different host plant, with no one aphid ever returning to where it started.</p>

<p>Dingle is an evolutionary biologist who studies insects. His definition is more intricate than Berger’s, citing those five features that distinguish migration from other forms of movement. They allow for the fact that, for example, aphids will become sensitive to blue light (from the sky) when it’s time for takeoff on their big journey, and sensitive to yellow light (reflected from tender young leaves) when it’s appropriate to land. Birds will fatten themselves with heavy feeding in advance of a long migrational flight. The value of his definition, Dingle argues, is that it focuses attention on what the phenomenon of wildebeest migration shares with the phenomenon of the aphids, and therefore helps guide researchers towards understanding how evolution has produced them all.</p>

<p>Human behaviour, however, is having a detrimental impact on animal migration. The pronghorn, which resembles an antelope, though they are unrelated, is the fastest land mammal of the New World. One population, which spends the summer in the mountainous Grand Teton National Park of the western USA, follows a narrow route from its summer range in the mountains, across a river, and down onto the plains. Here they wait out the frozen months, feeding mainly on sagebrush blown clear of snow. These pronghorn are notable for the invariance of their migration route and the severity of its constriction at three bottlenecks. If they can’t pass through each of the three during their spring migration, they can’t reach their bounty of summer grazing; if they can’t pass through again in autumn, escaping south onto those windblown plains, they are likely to die trying to overwinter in the deep snow. Pronghorn, dependent on distance vision and speed to keep safe from predators, traverse high, open shoulders of land, where they can see and run. At one of the bottlenecks, forested hills rise to form a V, leaving a corridor of open ground only about 150 metres wide, filled with private homes. Increasing development is leading toward a crisis for the pronghorn, threatening to choke off their passageway.</p>

<p>Conservation scientists, along with some biologists and land managers within the USA’s National Park Service and other agencies, are now working to preserve migrational behaviours, not just species and habitats. A National Forest has recognised the path of the pronghorn, much of which passes across its land, as a protected migration corridor. But neither the Forest Service nor the Park Service can control what happens on private land at a bottleneck. And with certain other migrating species, the challenge is complicated further – by vastly greater distances traversed, more jurisdictions, more borders, more dangers along the way. We will require wisdom and resoluteness to ensure that migrating species can continue their journeying a while longer.</p>

<hr>

<h2>Questions 14-18</h2>
<p>Do the following statements agree with the information given in Reading Passage 2?<br>
In boxes 14-18 on your answer sheet, write</p>
<p><strong>TRUE</strong> — if the statement agrees with the information<br>
<strong>FALSE</strong> — if the statement contradicts the information<br>
<strong>NOT GIVEN</strong> — if there is no information on this</p>

<p><strong>14.</strong> ________________</p>
<p><strong>15.</strong> ________________</p>
<p><strong>16.</strong> ________________</p>
<p><strong>17.</strong> ________________</p>
<p><strong>18.</strong> ________________</p>

<hr>

<h2>Questions 19-22</h2>
<p>Complete each sentence with the correct ending, A-G, below.<br>
Write the correct letter, A-G, in boxes 19-22 on your answer sheet.</p>

<ol type="A">
    <li>be discouraged by difficulties.</li>
    <li>travel on open land where they can look out for predators.</li>
    <li>eat more than they need for immediate purposes.</li>
    <li>be repeated daily.</li>
    <li>ignore distractions.</li>
    <li>be governed by the availability of water.</li>
    <li>follow a straight line.</li>
</ol>

<p><strong>19.</strong> Migrating animals are known to ________________</p>
<p><strong>20.</strong> During migration, animals are more likely to ________________</p>
<p><strong>21.</strong> Pronghorns are animals that ________________</p>
<p><strong>22.</strong> Migrating animals are known to ________________</p>

<hr>

<h2>Questions 23-26</h2>
<p>Complete the summary below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>The migration of pronghorns</h3>
<p>Pronghorns rely on their eyesight and (23)……………. to avoid predators. One particular population’s summer habitat is a national park, and their winter home is on the (24)……………… where they go to avoid the danger presented by the snow at that time of year. However, their route between these two areas contains three (25)……………… . One problem is the construction of new homes in a narrow (26)……………… of land on the pronghorns’ route.</p>','',2,'Passage 2',51);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-09-07 17:31:40','user_05335',false,'2026-09-07 17:31:40','user_05335','','','<h1>Preface to ‘How the other half thinks: Adventures in mathematical reasoning’</h1>

<h2>Reading Passage</h2>

<p><strong>A</strong> Occasionally, in some difficult musical compositions, there are beautiful, but easy parts – parts so simple a beginner could play them. So it is with mathematics as well. There are some discoveries in advanced mathematics that do not depend on specialized knowledge, not even on algebra, geometry, or trigonometry. Instead they may involve, at most, a little arithmetic, such as ‘the sum of two odd numbers is even’, and common sense. Each of the eight chapters in this book illustrates this phenomenon. Anyone can understand every step in the reasoning.<br>
The thinking in each chapter uses at most only elementary arithmetic, and sometimes not even that. Thus all readers will have the chance to participate in a mathematical experience, to appreciate the beauty of mathematics, and to become familiar with its logical, yet intuitive, style of thinking.</p>

<p><strong>B</strong> One of my purposes in writing this book is to give readers who haven’t had the opportunity to see and enjoy real mathematics the chance to appreciate the mathematical way of thinking. I want to reveal not only some of the fascinating discoveries, but, more importantly, the reasoning behind them.<br>
In that respect, this book differs from most books on mathematics written for the general public. Some present the lives of colorful mathematicians. Others describe important applications of mathematics. Yet others go into mathematical procedures, but assume that the reader is adept in using algebra.</p>

<p><strong>C</strong> I hope this book will help bridge that notorious gap that separates the two cultures: the humanities and the sciences, or should I say the right brain (intuitive) and the left brain (analytical, numerical). As the chapters will illustrate, mathematics is not restricted to the analytical and numerical; intuition plays a significant role. The alleged gap can be narrowed or completely overcome by anyone, in part because each of us is far from using the full capacity of either side of the brain. To illustrate our human potential, I cite a structural engineer who is an artist, an electrical engineer who is an opera singer, an opera singer who published mathematical research, and a mathematician who publishes short stories.</p>

<p><strong>D</strong> Other scientists have written books to explain their fields to non-scientists, but have necessarily had to omit the mathematics, although it provides the foundation of their theories. The reader must remain a tantalized spectator rather than an involved participant, since the appropriate language for describing the details in much of science is mathematics, whether the subject is expanding universe, subatomic particles, or chromosomes. Though the broad outline of a scientific theory can be sketched intuitively, when a part of the physical universe is finally understood, its description often looks like a page in a mathematics text.</p>

<p><strong>E</strong> Still, the non-mathematical reader can go far in understanding mathematical reasoning. This book presents the details that illustrate the mathematical style of thinking, which involves sustained, step-by-step analysis, experiments, and insights. You will turn these pages much more slowly than when reading a novel or a newspaper. It may help to have a pencil and paper ready to check claims and carry out experiments.</p>

<p><strong>F</strong> As I wrote, I kept in mind two types of readers: those who enjoyed mathematics until they were turned off by an unpleasant episode, usually around fifth grade, and mathematics aficionados, who will find much that is new throughout the book.<br>
This book also serves readers who simply want to sharpen their analytical skills. Many careers, such as law and medicine, require extended, precise analysis. Each chapter offers practice in following a sustained and closely argued line of thought. That mathematics can develop this skill is shown by these two testimonials:</p>

<p><strong>G</strong> A physician wrote, ‘The discipline of analytical thought processes [in mathematics] prepared me extremely well for medical school. In medicine one is faced with a problem which must be thoroughly analyzed before a solution can be found. The process is similar to doing mathematics.’<br>
A lawyer made the same point, “Although I had no background in law – not even one political science course — I did well at one of the best law schools. I attribute much of my success there to having learned, through the study of mathematics, and, in particular, theorems, how to analyze complicated principles. Lawyers who have studied mathematics can master the legal principles in a way that most others cannot.’<br>
I hope you will share my delight in watching as simple, even naive, questions lead to remarkable solutions and purely theoretical discoveries find unanticipated applications.</p>

<hr>

<h2>Questions 27-34</h2>
<p>Reading Passage has seven sections, A-G.<br>
Which section contains the following information?<br>
Write the correct letter, A-G, in boxes 27-34 on your answer sheet.<br>
NB You may use any letter more than once.</p>

<p><strong>27.</strong> ________________</p>
<p><strong>28.</strong> ________________</p>
<p><strong>29.</strong> ________________</p>
<p><strong>30.</strong> ________________</p>
<p><strong>31.</strong> ________________</p>
<p><strong>32.</strong> ________________</p>
<p><strong>33.</strong> ________________</p>
<p><strong>34.</strong> ________________</p>

<hr>

<h2>Questions 35-40</h2>
<p>Complete the sentences below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<p><strong>35.</strong> ________________</p>
<p><strong>36.</strong> ________________</p>
<p><strong>37.</strong> ________________</p>
<p><strong>38.</strong> ________________</p>
<p><strong>39.</strong> ________________</p>
<p><strong>40.</strong> ________________</p>','',3,'Passage 3',51),
	 ('2026-09-08 17:31:40','user_05335',false,'2026-09-08 17:31:40','user_05335','','','<h1>Flying tortoises</h1>
<p>An airborne reintroduction programme has helped conservationists take significant steps to protect the endangered Galápagos tortoise.</p>

<h2>Reading Passage 1</h2>

<p><strong>A</strong> Forests of spiny cacti cover much of the uneven lava plains that separate the interior of the Galápagos island of Isabela from the Pacific Ocean. With its five distinct volcanoes, the island resembles a lunar landscape. Only the thick vegetation at the skirt of the often cloud-covered peak of Sierra Negra offers respite from the barren terrain below. This inhospitable environment is home to the giant Galápagos tortoise. Some time after the Galápagos’s birth, around five million years ago, the islands were colonised by one or more tortoises from mainland South America. As these ancestral tortoises settled on the individual islands, the different populations adapted to their unique environments, giving rise to at least 14 different subspecies. Island life agreed with them. In the absence of significant predators, they grew to become the largest and longest-living tortoises on the planet, weighing more than 400 kilograms, occasionally exceeding 1.8 metres in length and living for more than a century.</p>

<p><strong>B</strong> Before human arrival, the archipelago’s tortoises numbered in the hundreds of thousands. From the 17th century onwards, pirates took a few on board for food, but the arrival of whaling ships in the 1790s saw this exploitation grow exponentially. Relatively immobile and capable of surviving for months without food or water, the tortoises were taken on board these ships to act as food supplies during long ocean passages. Sometimes, their bodies were processed into high-grade oil. In total, an estimated 200,000 animals were taken from the archipelago before the 20th century. This historical exploitation was then exacerbated when settlers came to the islands. They hunted the tortoises and destroyed their habitat to clear land for agriculture. They also introduced alien species – ranging from cattle, pigs, goats, rats and dogs to plants and ants – that either prey on the eggs and young tortoises or damage or destroy their habitat.</p>

<p><strong>C</strong> Today, only 11 of the original subspecies survive and of these, several are highly endangered. In 1989, work began on a tortoise-breeding centre just outside the town of Puerto Villamil on Isabela, dedicated to protecting the island’s tortoise populations. The centre’s captive-breeding programme proved to be extremely successful, and it eventually had to deal with an overpopulation problem.</p>

<p><strong>D</strong> The problem was also a pressing one. Captive-bred tortoises can’t be reintroduced into the wild until they’re at least five years old and weigh at least 4.5 kilograms, at which point their size and weight – and their hardened shells – are sufficient to protect them from predators. But if people wait too long after that point, the tortoises eventually become too large to transport.</p>

<p><strong>E</strong> For years, repatriation efforts were carried out in small numbers, with the tortoises carried on the backs of men over weeks of long, treacherous hikes along narrow trails. But in November 2010, the environmentalist and Galápagos National Park liaison officer Godfrey Merlin, a visiting private motor yacht captain and a helicopter pilot gathered around a table in a small café in Puerto Ayora on the island of Santa Cruz to work out more ambitious reintroduction. The aim was to use a helicopter to move 300 of the breeding centre’s tortoises to various locations close to Sierra Negra.</p>

<p><strong>F</strong> This unprecedented effort was made possible by the owners of the 67-metre yacht While Cloud, who provided the Galápagos National Park with free use of their helicopter and its experienced pilot, as well as the logistical support of the yacht, its captain and crew. Originally an air ambulance, the yacht’s helicopter has a rear double door and a large internal space that’s well suited for cargo, so a custom crate was designed to hold up to 33 tortoises with a total weight of about 150 kilograms. This weight, together with that of the fuel, pilot and four crew, approached the helicopter’s maximum payload, and there were times when it was clearly right on the edge of the helicopter’s capabilities. During a period of three days, a group of volunteers from the breeding centre worked around the clock to prepare the young tortoises for transport. Meanwhile, park wardens, dropped off ahead of time in remote locations, cleared landing sites within the thick brush, cacti and lava rocks.</p>

<p><strong>G</strong> Upon their release, the juvenile tortoises quickly spread out over their ancestral territory, investigating their new surroundings and feeding on the vegetation. Eventually, one tiny tortoise came across a fully grown giant who had been lumbering around the island for around a hundred years. The two stood side by side, a powerful symbol of the regeneration of an ancient species.</p>

<hr>

<h2>Questions 1-7</h2>
<p>Reading Passage 1 has seven paragraphs, A-G.<br>
Choose the correct heading for each paragraph from the list of headings below.<br>
Write the correct number, i-viii, in boxes 1-7 on your answer sheet.</p>

<h3>List of Headings</h3>
<ol type="i">
    <li>The importance of getting the timing right</li>
    <li>Young meets old</li>
    <li>Developments to the disadvantage of tortoise populations</li>
    <li>Planning a bigger idea</li>
    <li>Tortoises populate the islands</li>
    <li>Carrying out a carefully prepared operation</li>
    <li>Looking for a home for the islands’ tortoises</li>
    <li>The start of the conservation project</li>
</ol>

<p><strong>1.</strong> Paragraph A: ______</p>
<p><strong>2.</strong> Paragraph B: ______</p>
<p><strong>3.</strong> Paragraph C: ______</p>
<p><strong>4.</strong> Paragraph D: ______</p>
<p><strong>5.</strong> Paragraph E: ______</p>
<p><strong>6.</strong> Paragraph F: ______</p>
<p><strong>7.</strong> Paragraph G: ______</p>

<hr>

<h2>Questions 8-13</h2>
<p>Complete the notes below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<h3>The decline of the Galápagos tortoise</h3>
<ul>
    <li>Originally from mainland South America</li>
    <li>Numbers on Galápagos islands increased, due to lack of predators</li>
    <li>17th century: small numbers taken onto ships used by (8)…………………………..</li>
    <li>1790s: very large numbers taken onto whaling ships, kept for (9)……………………………….., and also used to produce (10)……………………………</li>
    <li>Hunted by (11)…………………………… on the islands</li>
    <li>Habitat destruction: for the establishment of agriculture and by various (12)………………………… not native to the islands, which also fed on baby tortoises and tortoises’ (13)…………………………..</li>
</ul>','',1,'Passage 1',52),
	 ('2026-09-09 17:31:40','user_05335',false,'2026-09-09 17:31:40','user_05335','','','<h1>The Intersection of Health Sciences and Geography</h1>

<h2>Reading Passage 2</h2>

<p><strong>A</strong> While many diseases that affect humans have been eradicated due to improvements in vaccinations and the availability of healthcare, there are still areas around the world where certain health issues are more prevalent. In a world that is far more globalised than ever before, people come into contact with one another through travel and living closer and closer to each other. As a result, super-viruses and other infections resistant to antibiotics are becoming more and more common.</p>

<p><strong>B</strong> Geography can often play a very large role in the health concerns of certain populations. For instance, depending on where you live, you will not have the same health concerns as someone who lives in a different geographical region. Perhaps one of the most obvious examples of this idea is malaria-prone areas, which are usually tropical regions that foster a warm and damp environment in which the mosquitos that can give people this disease can grow. Malaria is much less of a problem in high-altitude deserts, for instance.</p>

<p><strong>C</strong> In some countries, geographical factors influence the health and well-being of the population in very obvious ways. In many large cities, the wind is not strong enough to clear the air of the massive amounts of smog and pollution that cause asthma, lung problems, eyesight issues and more in the people who live there. Part of the problem is, of course, the massive number of cars being driven, in addition to factories that run on coal power. The rapid industrialisation of some countries in recent years has also led to the cutting down of forests to allow for the expansion of big cities, which makes it even harder to fight the pollution with the fresh air that is produced by plants.</p>

<p><strong>D</strong> It is in situations like these that the field of health geography comes into its own. It is an increasingly important area of study in a world where diseases like polio are re-emerging, respiratory diseases continue to spread, and malaria-prone areas are still fighting to find a better cure. Health geography is the combination of, on the one hand, knowledge regarding geography and methods used to analyse and interpret geographical information, and on the other, the study of health, diseases and healthcare practices around the world. The aim of this hybrid science is to create solutions for common geography-based health problems. While people will always be prone to illness, the study of how geography affects our health could lead to the eradication of certain illnesses, and the prevention of others in the future. By understanding why and how we get sick, we can change the way we treat illness and disease specific to certain geographical locations.</p>

<p><strong>E</strong> The geography of disease and ill health analyses the frequency with which certain diseases appear in different parts of the world, and overlays the data with the geography of the region, to see if there could be a correlation between the two. Health geographers also study factors that could make certain individuals or a population more likely to be taken ill with a specific health concern or disease, as compared with the population of another area. Health geographers in this field are usually trained as healthcare workers, and have an understanding of basic epidemiology as it relates to the spread of diseases among the population.</p>

<p><strong>F</strong> Researchers study the interactions between humans and their environment that could lead to illness (such as asthma in places with high levels of pollution) and work to create a clear way of categorizing illnesses, diseases and epidemics into local and global scales. Health geographers can map the spread of illnesses and attempt to identify the reasons behind an increase or decrease in illnesses, as they work to find a way to halt the further spread or re-emergence of diseases in vulnerable populations.</p>

<p><strong>G</strong> The second subcategory of health geography is the geography of healthcare provision. This group studies the availability (or lack thereof) of healthcare resources to individuals and populations around the world. In both developed and developing nations there is often a very large discrepancy between the options available to people in different social classes, income brackets, and levels of education. Individuals working in the area of the geography of healthcare provision attempt to assess the levels of healthcare in the area (for instance, it may be very difficult for people to get medical attention because there is a mountain between their village and the nearest hospital). These researchers are on the frontline of making recommendations regarding policy to international organisations, local government bodies and others.</p>

<p><strong>H</strong> The field of health geography is often overlooked, but it constitutes a huge area of need in the fields of geography and healthcare. If we can understand how geography affects our health no matter where in the world we are located, we can better treat disease, prevent illness, and keep people safe and well.</p>

<hr>

<h2>Questions 14-19</h2>
<p>Reading Passage 2 has eight sections, A-H.<br>
Which paragraph contains the following information?<br>
Write the correct letter, A-H, in boxes 14-19 on your answer sheet.<br>
NB You may use any letter more than once.</p>

<p><strong>14.</strong> ________________</p>
<p><strong>15.</strong> ________________</p>
<p><strong>16.</strong> ________________</p>
<p><strong>17.</strong> ________________</p>
<p><strong>18.</strong> ________________</p>
<p><strong>19.</strong> ________________</p>

<hr>

<h2>Questions 20-26</h2>
<p>Complete the sentences below.<br>
Choose <strong>ONE WORD ONLY</strong> from the passage for each answer.</p>

<p><strong>20.</strong> ________________</p>
<p><strong>21.</strong> ________________</p>
<p><strong>22.</strong> ________________</p>
<p><strong>23.</strong> ________________</p>
<p><strong>24.</strong> ________________</p>
<p><strong>25.</strong> ________________</p>
<p><strong>26.</strong> ________________</p>','',2,'Passage 2',52),
	 ('2026-09-10 17:31:40','user_05335',false,'2026-09-10 17:31:40','user_05335','','','<h1>Music and the emotions</h1>
<p>Neuroscientist Jonah Lehrer considers the emotional power of music</p>

<h2>Reading Passage</h2>

<p>Why does music make us feel? On the one hand, music is a purely abstract art form, devoid of language or explicit ideas. And yet, even though music says little, it still manages to touch us deeply. When listening to our favourite songs, our body betrays all the symptoms of emotional arousal. The pupils in our eyes dilate, our pulse and blood pressure rise, the electrical conductance of our skin is lowered, and the cerebellum, a brain region associated with bodily movement, becomes strangely active. Blood is even re-directed to the muscles in our legs. In other words, sound stirs us at our biological roots.</p>

<p>A recent paper in Nature Neuroscience by a research team in Montreal, Canada, marks an important step in revealing the precise underpinnings of the potent pleasurable stimulus that is music. Although the study involves plenty of fancy technology, including functional magnetic resonance imaging (fMRI) and ligand-based positron emission tomography (PET) scanning, the experiment itself was rather straightforward. After screening 217 individuals who responded to advertisements requesting people who experience ‘chills’ to instrumental music, the scientists narrowed down the subject pool to ten. They then asked the subjects to bring in their playlist of favourite songs – virtually every genre was represented, from techno to tango – and played them the music while their brain activity was monitored. Because the scientists were combining methodologies (PET and fMRI), they were able to obtain an impressively exact and detailed portrait of music in the brain. The first thing they discovered is that music triggers the production of dopamine – a chemical with a key role in setting people’s moods – by the neurons (nerve cells) in both the dorsal and ventral regions of the brain. As these two regions have long been linked with the experience of pleasure, this finding isn’t particularly surprising.</p>

<p>What is rather more significant is the finding that the dopamine neurons in the caudate – a region of the brain involved in learning stimulus-response associations, and in anticipating food and other ‘reward’ stimuli – were at their most active around 15 seconds before the participants’ favourite moments in the music. The researchers call this the ‘anticipatory phase’ and argue that the purpose of this activity is to help us predict the arrival of our favourite part. The question, of course, is what all these dopamine neurons are up to. Why are they so active in the period preceding the acoustic climax? After all, we typically associate surges of dopamine with pleasure, with the processing of actual rewards. And yet, this cluster of cells is most active when the ‘chills’ have yet to arrive, when the melodic pattern is still unresolved.</p>

<p>One way to answer the question is to look at the music and not the neurons. While music can often seem (at least to the outsider) like a labyrinth of intricate patterns, it turns out that the most important part of every song or symphony is when the patterns break down, when the sound becomes unpredictable. If the music is too obvious, it is annoyingly boring, like an alarm clock. Numerous studies, after all, have demonstrated that dopamine neurons quickly adapt to predictable rewards. If we know what’s going to happen next, then we don’t get excited. This is why composers often introduce a key note in the beginning of a song, spend most of the rest of the piece in the studious avoidance of the pattern, and then finally repeat it only at the end. The longer we are denied the pattern we expect, the greater the emotional release when the pattern returns, safe and sound.</p>

<p>To demonstrate this psychological principle, the musicologist Leonard Meyer, in his classic book Emotion and Meaning in Music (1956), analysed the 5th movement of Beethoven’s String Quartet in C-sharp minor, Op. 131. Meyer wanted to show how music is defined by its flirtation with – but not submission to – our expectations of order. Meyer dissected 50 measures (bars) of the masterpiece, showing how Beethoven begins with the clear statement of a rhythmic and harmonic pattern and then, in an ingenious tonal dance, carefully holds off repeating it. What Beethoven does instead is suggest variations of the pattern. He wants to preserve an element of uncertainty in his music, making our brains beg for the one chord he refuses to give us. Beethoven saves that chord for the end.</p>

<p>According to Meyer, it is the suspenseful tension of music, arising out of our unfulfilled expectations, that is the source of the music’s feeling. While earlier theories of music focused on the way a sound can refer to the real world of images and experiences – its ‘connotative’ meaning – Meyer argued that the emotions we find in music come from the unfolding events of the music itself. This ‘embodied meaning’ arises from the patterns the symphony invokes and then ignores. It is this uncertainty that triggers the surge of dopamine in the caudate, as we struggle to figure out what will happen next. We can predict some of the notes, but we can’t predict them all, and that is what keeps us listening, waiting expectantly for our reward, for the pattern to be completed.</p>

<hr>

<h2>Questions 27-31</h2>
<p>The Montreal Study</p>
<p>Participants, who were recruited for the study through advertisements, had their brain activity monitored while listening to their favourite music. It was noted that the music stimulated the brain’s neurons to release a substance called (27)…………………………. in two of the parts of the brain which are associated with feeling (28)…………………………..</p>
<p>Researchers also observed that the neurons in the area of the brain called the (29)……………………………. were particularly active just before the participants’ favourite moments in the music – the period known as the (30)…………………………. Activity in this part of the brain is associated with the expectation of ‘reward’ stimuli such as (31)………………………….</p>

<hr>

<h2>Questions 32-36</h2>
<p>Choose the correct letter, A, B, C or D.<br>
Write the correct letter in boxes 32-36 on your answer sheet.</p>

<p><strong>32.</strong> ________________</p>
<p><strong>33.</strong> ________________</p>
<p><strong>34.</strong> ________________</p>
<p><strong>35.</strong> ________________</p>
<p><strong>36.</strong> ________________</p>

<hr>

<h2>Questions 37-40</h2>
<p>Complete each sentence with the correct ending, A-F, below.<br>
Write the correct letter, A-F, in boxes 37-40 on your answer sheet.</p>

<ol type="A">
    <li>our response to music depends on our initial emotional state.</li>
    <li>neuron activity decreases if outcomes become predictable.</li>
    <li>emotive music can bring to mind actual pictures and events.</li>
    <li>experiences in our past can influence our emotional reaction to music.</li>
    <li>emotive music delays giving listeners what they expect to hear.</li>
    <li>neuron activity increases prior to key points in a musical piece.</li>
</ol>

<p><strong>37.</strong> ________________</p>
<p><strong>38.</strong> ________________</p>
<p><strong>39.</strong> ________________</p>
<p><strong>40.</strong> ________________</p>','',3,'Passage 3',52),
	 ('2026-09-11 17:31:40','truongdx18vtit',false,'2026-09-11 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781023823/fe4d4781-a63b-4b48-a850-79c13c4c1a94_sim_0401.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 600px; margin: 0 auto;">

  <div style="margin-bottom: 40px; border: 1px solid #cbd5e1; padding: 20px; background-color: #f8fafc; border-radius: 6px;">
    <h3 style="text-align: center; margin-top: 0; margin-bottom: 20px; color: #0f172a; text-transform: uppercase; font-size: 16px; letter-spacing: 0.5px;">Request for Commercial Lease</h3>
    
    <p><i>Complete the form below. Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer.</i></p>

    <div style="margin-top: 20px; display: grid; grid-template-columns: 1fr; gap: 12px;">
      <div><b>Name:</b> Mr R. Rich</div>
      <div><b>Company:</b> ICT Industries</div>
      
      <div>
        <b>Preferred location:</b> 
        <b>(1)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Near:</b> 
        <b>(2)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Size:</b> 
        <b>(3)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Number of staff:</b> 
        <b>(4)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Special needs:</b> 
        <b>(5)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> access, parking for mobility scooter
      </div>
      
      <div>
        <b>Moving date:</b> during month of 
        <b>(6)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div style="border: 1px solid #cbd5e1; padding: 20px; background-color: #f8fafc; border-radius: 6px;">
    <p style="margin-top: 0;"><i>Complete the notes below. Write <b>ONE WORD AND/OR A NUMBER</b> for each answer.</i></p>
    
    <p style="font-weight: bold; margin-top: 15px; color: #0f172a; font-size: 15px;">Requirements:</p>
    <ul style="margin-bottom: 0; padding-left: 20px; list-style-type: disc;">
      <li style="margin-bottom: 8px;">Good lift access</li>
      <li style="margin-bottom: 8px;">Large lobby</li>
      <li style="margin-bottom: 8px;">
        Removal of some 
        <b>(7)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
      <li style="margin-bottom: 8px;">
        <b>(8)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> too small � make bigger
      </li>
      <li style="margin-bottom: 8px;">Change office near entry to storeroom</li>
      <li style="margin-bottom: 8px;">
        New:
        <ul style="list-style-type: circle; padding-left: 20px; margin-top: 4px;">
          <li style="margin-bottom: 4px;">paintwork</li>
          <li style="margin-bottom: 4px;">lights</li>
          <li style="margin-bottom: 4px;">blinds</li>
          <li><b>(9)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
        </ul>
      </li>
      <li style="margin-top: 8px;">
        Minimum length of lease 
        <b>(10)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> (with right of renewal)
      </li>
    </ul>
  </div>','',1,'Part 1',53),
	 ('2026-09-29 17:31:40','truongdx18vtit',false,'2026-09-29 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015042/72563bf5-32e0-43c2-a321-d3118e0ee27a_08_ielts14-test1-audio3.m4a','','<p>
    What decision do the students make about each of the following parts of their presentation?
</p>

<p>
    Choose <strong>FIVE</strong> answers from the box and write the correct letter,
    <strong>A-G</strong>, next to Questions <strong>26-30</strong>.
</p>

<p><strong>Decisions</strong></p>

<p><strong>A</strong> &nbsp;&nbsp;&nbsp; use visuals</p>
<p><strong>B</strong> &nbsp;&nbsp;&nbsp; keep it short</p>
<p><strong>C</strong> &nbsp;&nbsp;&nbsp; involve other students</p>
<p><strong>D</strong> &nbsp;&nbsp;&nbsp; check the information is accurate</p>
<p><strong>E</strong> &nbsp;&nbsp;&nbsp; provide a handout</p>
<p><strong>F</strong> &nbsp;&nbsp;&nbsp; focus on one example</p>
<p><strong>G</strong> &nbsp;&nbsp;&nbsp; do online research</p>

<br>

<p><strong>Parts of the presentation</strong></p>','',3,'Part 3',57),
	 ('2026-09-12 17:31:40','truongdx18vtit',false,'2026-09-12 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781023848/e4e0105f-d70c-4694-bcc0-21167d95cc6e_sim_0402.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto;">

  <div style="margin-bottom: 40px;">
    <p><i>Complete the summary below.</i></p>
    <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer.</i></p>
    
    <div style="margin-top: 15px; border: 1px solid #cbd5e1; padding: 20px; background-color: #f8fafc; border-radius: 6px; text-align: justify;">
      After high school some people travel, find a(an) 
      <b>(11)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
      or take on temporary work to save money for further education. 
      If you decide to go straight on to more study, to start with you should think about your 
      <b>(12)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>. 
      You''ll also need to consider whether your 
      <b>(13)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
      will help you eventually get a good job. After course selection, you should decide on study goals: how many papers to take and what 
      <b>(14)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
      you want to achieve.
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><i>Where would you go for information or resources?</i></p>
    <p><i>Write the correct letter, <b>A, B, or C</b> next to questions <b>15-20</b>.</i></p>

    <div style="border: 1px solid #cbd5e1; padding: 15px; background-color: #f8fafc; border-radius: 6px; margin: 15px 0;">
      <div style="margin-bottom: 8px;"><b>A</b> &nbsp;from an Internet website</div>
      <div style="margin-bottom: 8px;"><b>B</b> &nbsp;in the form of personal advice or guidance</div>
      <div><b>C</b> &nbsp;on the availability of financial assistance</div>
    </div>

    <div style="margin-top: 20px; display: grid; grid-template-columns: 1fr; gap: 12px;">
      <div><b>15</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 15]</div>
      <div><b>16</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 16]</div>
      <div><b>17</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 17]</div>
      <div><b>18</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 18]</div>
      <div><b>19</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 19]</div>
      <div><b>20</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[N?i dung c�u h?i s? 20]</div>
    </div>
  </div>

</div>','',2,'Part 2',53),
	 ('2026-09-13 17:31:40','truongdx18vtit',false,'2026-09-13 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781023878/0af44ca5-53d9-4db7-b9dd-3f8dafb5a49c_sim_0403.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto;">

  <p><i>Complete the notes below.</i></p>
  <p><i>Write <b>NO MORE THAN THREE WORDS</b> for each answer.</i></p>

  <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">
    
    <p style="margin-top: 0; margin-bottom: 8px;"><b>? Research Topic</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li>Instant Messaging addiction in teenagers</li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? Demographics</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li>
        450 <b>(21)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        completed by random sample of middle school students, Jiangsu Province
      </li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? Scope</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li>Does IM addiction exist?</li>
      <li>What are the symptoms?</li>
      <li>Can it be predicted?</li>
      <li>Does it affect schoolwork?</li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? 4 Symptoms</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li style="margin-bottom: 6px;"><b>(22)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
      <li style="margin-bottom: 6px;"><b>(23)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
      <li style="margin-bottom: 6px;"><b>(24)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
      <li><b>(25)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? Predictors of IM addiction</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li style="margin-bottom: 6px;"><b>(26)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
      <li style="margin-bottom: 6px;"><b>(27)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
      <li>
        Note: high level users who are not addicts tend to use IM to chat with friends rather than 
        <b>(28)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? Conclusions</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px;">
      <li>
        Differences exist between high use and addiction but both have 
        <b>(29)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        effect on academic scores.
      </li>
    </ul>

    <p style="margin-bottom: 8px;"><b>? Recommendations</b></p>
    <ul style="list-style-type: dashed; margin-top: 4px; padding-left: 20px; margin-bottom: 0;">
      <li>
        Parents ought to take notice of teenagers'' IM usage and offer suitable 
        <b>(30)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        and control their use of IM.
      </li>
    </ul>

  </div>

</div>','',3,'Part 3',53),
	 ('2026-09-14 17:31:40','truongdx18vtit',false,'2026-09-14 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781023914/741ca6a5-566f-45e4-84ba-8f420ab951e1_sim_0404.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto;">

  <div style="margin-bottom: 35px;">
    <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer.</i></p>
    
    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr; gap: 12px;">
      <div>
        <b>31.</b> Where are the British Isles situated? <br />
        ? In the <b>eastern Atlantic</b> / <b>North Atlantic</b>
      </div>
      <div>
        <b>32.</b> The Venn diagram is being used to help students see the difference between geographic and what other regions? <br />
        ? <b>political</b>
      </div>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 25px 0;" />

  <div style="margin-bottom: 35px;">
    <p><b>Label the diagram below.</b></p>
    <p><i>Write <b>ONE WORD ONLY</b> for each answer.</i></p>
    
    <div style="margin-top: 15px; background-color: #f8fafc; border: 1px solid #cbd5e1; padding: 20px; border-radius: 6px;">
      <p style="margin-top: 0; font-weight: bold; color: #0f172a;">[Venn Diagram Labels - British Isles Relationships]:</p>
      <ul style="list-style-type: none; padding-left: 0; margin-bottom: 0;">
        <li style="margin-bottom: 8px;"><b>33.</b> <u><b>Scotland</b></u> (Khu v?c thu?c Great Britain b�n c?nh Wales v� England)</li>
        <li style="margin-bottom: 8px;"><b>34.</b> <u><b>Ireland</b></u> (T�n ??o ??a l� l?n th? hai ch?a Northern Ireland v� Republic)</li>
        <li style="margin-bottom: 8px;"><b>35.</b> <u><b>Republic</b></u> (Ch? Republic of Ireland thu?c t?p h?p ch�nh tr? n?m ngo�i UK)</li>
        <li><b>36.</b> <u><b>Man</b></u> (Isle of Man - ??o ph? thu?c V??ng quy?n n?m trong t?p h?p British Islands)</li>
      </ul>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 25px 0;" />

  <div>
    <p><b>Complete the sentences below.</b></p>
    <p><i>Write <b>ONE WORD ONLY</b> for each answer.</i></p>
    
    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr; gap: 12px;">
      <div><b>37.</b> There is <u><b>confusion</b></u> with language also when it comes to describing the British Isles.</div>
      <div><b>38.</b> The northernmost point of Ireland belongs to the Republican <u><b>County</b></u> of Donegal.</div>
      <div><b>39.</b> A Welshman will be upset if you call him <u><b>English</b></u>.</div>
      <div><b>40.</b> The former British Empire is now known as the Commonwealth of Nations to avoid recalling previous <u><b>colonial</b></u> relationships.</div>
    </div>
  </div>

</div>','',4,'Part 4',53),
	 ('2026-09-15 17:31:40','truongdx18vtit',false,'2026-09-15 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099746/c76d30e4-cfc5-469c-9b44-4c93592c0d4a_sim_0501.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto;">

  <div style="margin-bottom: 40px; border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px;">
    <h3 style="text-align: center; margin-top: 0; margin-bottom: 20px; color: #0f172a; text-transform: uppercase; font-size: 16px; letter-spacing: 0.5px;">Hotel Armitage Booking Form</h3>
    
    <p><i>Complete the form below. Write <b>NO MORE THAN ONE WORD AND/OR A NUMBER</b> for each answer.</i></p>

    <div style="margin-top: 20px; display: grid; grid-template-columns: 1fr; gap: 12px; font-size: 15px;">
      <div><b>Name:</b> Kelvin Jones</div>
      
      <div>
        <b>Booking #:</b> 
        <b>(1)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Vehicle Registration #:</b> 
        <b>(2)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div><b>Date of Arrival:</b> 21 May</div>
      <div><b>Room #:</b> 501</div>
      
      <div>
        <b>Type of room (Standard / Deluxe / Suite):</b> <br />
        <b>(3)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div>
        <b>Extra requirements:</b> 
        <b>(4)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
      
      <div><b>Identification:</b> Driver''s Licence</div>
      
      <div>
        <b>Length of stay:</b> 
        <b>(5)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </div>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><i>Complete the map below.</i></p>
    <p><i>Write <b>ONE WORD ONLY</b> for each answer for questions <b>6-10</b>.</i></p>
    
    <div style="text-align: center; margin: 20px 0;">
      <img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1781099406/8f51d8d8-5789-4051-b966-8108214f01d4_3a46e5421d54ab3f0cc0b75d7fa715d27c091e5e.jpg" alt="Hotel Facilities Map" style="max-width: 100%; height: auto; border: 1px solid #cbd5e1; border-radius: 4px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);" />
    </div>
  </div>

</div>','',1,'Part 1',54);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-09-16 17:31:40','truongdx18vtit',false,'2026-09-16 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099827/dcd3d37a-8e28-4502-abb0-ea27e5d53d50_sim_0502.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 850px; margin: 0 auto;">

  <p><i>Complete the table below.</i></p>
  <p><i>Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer for questions <b>14-20</b>.</i></p>

  <div style="margin-top: 25px; margin-bottom: 35px;">
    <p style="font-weight: bold; font-size: 15px; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px;">Savings Options</p>
    
    <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left;">
      <thead>
        <tr style="background-color: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #94a3b8;">
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Savings Account</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Minimum balance</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Interest Information</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Access</th>
        </tr>
      </thead>
      <tbody>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Internet Account</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">None</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Earn good rate from first dollar. Calculated daily and paid monthly</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Via Internet, TXT, telephone. No account or <b>(14)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> fees</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Stairs Saver</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">None � but higher rates for bigger balances</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">3 tiers plus <b>(15)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>. Calculated daily and paid monthly</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Unlimited withdrawals but better to limit to once a month</td>
        </tr>
        <tr style="border-bottom: 1px solid #cbd5e1;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;"><b>(16)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">None</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">One interest rate, calculated daily and paid on <b>(17)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Anytime � no penalty for withdrawals</td>
        </tr>
      </tbody>
    </table>
  </div>

  <div style="margin-bottom: 25px;">
    <p style="font-weight: bold; font-size: 15px; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 10px;">Investment Options</p>
    
    <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left;">
      <thead>
        <tr style="background-color: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #94a3b8;">
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Investment Account</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Minimum deposit</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Interest Information</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 25%;">Access</th>
        </tr>
      </thead>
      <tbody>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">
            Term Deposit <br />
            � safe and <b>(18)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>, low risk
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">$1,000</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Calculated daily and paid monthly, quarterly, or at maturity</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Only at maturity</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">
            <b>(19)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> <br />
            � longer term but better returns
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">$5,000</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Calculated daily and compounded or paid out quarterly</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Only at maturity</td>
        </tr>
        <tr style="border-bottom: 1px solid #cbd5e1;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Retirement Fund</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">
            a certain percentage of <br />
            <b>(20)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> before tax
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Different levels of risk and return</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">At 60</td>
        </tr>
      </tbody>
    </table>
  </div>

</div>','',2,'Part 2',54),
	 ('2026-09-17 17:31:40','truongdx18vtit',false,'2026-09-17 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099864/4f5660f5-15eb-41b7-bf1a-1f983d2d0d98_sim_0503.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto;">

  <p><i>Complete the notes below.</i></p>
  <p><i>Write <b>ONE WORD ONLY</b> for each answer for questions <b>24-30</b>.</i></p>

  <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">
    
    <p style="margin-top: 0; margin-bottom: 8px; font-weight: bold; color: #0f172a; font-size: 15px;">Procedure (dealt with by prof.)</p>
    <ul style="margin-top: 4px; padding-left: 20px; list-style-type: disc;">
      <li style="margin-bottom: 8px;">
        Identify topic of interest involving some 
        <b>(24)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
      <li style="margin-bottom: 8px;">Invite panellists</li>
      <li style="margin-bottom: 8px;">
        Select a 
        <b>(25)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
      <li>
        Decide on 
        <b>(26)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
    </ul>

    <p style="margin-top: 20px; margin-bottom: 8px; font-weight: bold; color: #0f172a; font-size: 15px;">Guidelines</p>
    <ul style="margin-top: 4px; padding-left: 20px; list-style-type: disc; margin-bottom: 0;">
      <li style="margin-bottom: 8px;">
        Introduction of topic & speakers � get 
        <b>(27)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        information from prof.
      </li>
      <li style="margin-bottom: 8px;">
        Each panellist speaks for 2 mins � make a hand 
        <b>(28)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        to show time is up
      </li>
      <li style="margin-bottom: 8px;">Primary function = panel discussion (about 40 mins)</li>
      <li style="margin-bottom: 8px;">
        Close discussion & give 
        <b>(29)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
      <li style="margin-bottom: 8px;">Secondary function = question time (about 15?20 mins)</li>
      <li>
        At end of question time, panel is thanked and audience shows appreciation by 
        <b>(30)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
    </ul>

  </div>

</div>','',3,'Part 3',54),
	 ('2026-09-18 17:31:40','truongdx18vtit',false,'2026-09-18 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099894/439f1979-63ac-4375-ab94-8162c79ed77d_sim_0504.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto; text-align: justify;">

  <div style="margin-bottom: 40px;">
    <p><i>Complete the notes below.</i></p>
    <p><i>Write <b>ONE WORD ONLY</b> for each answer for questions <b>31-35</b>.</i></p>

    <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">
      <p style="margin-top: 0; margin-bottom: 10px; font-weight: bold; color: #0f172a; font-size: 16px;">Hydropower</p>
      <ul style="margin-top: 5px; padding-left: 20px; list-style-type: disc;">
        <li style="margin-bottom: 8px;">
          Renewable � constant source of 
          <b>(31)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
          from natural hydrologic cycle
        </li>
        <li style="margin-bottom: 8px;">
          <b>(32)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
          � 90% of hydro energy ? electricity
        </li>
        <li style="margin-bottom: 8px;">
          Clean � no air or 
          <b>(33)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
          pollution
        </li>
        <li style="margin-bottom: 8px;">
          <b>(34)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
          & durable � simple to operate
        </li>
        <li>
          Flexible � can start & adapt quickly to meet demand ? leads to 
          <b>(35)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
          of power supply
        </li>
      </ul>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div style="margin-bottom: 40px;">
    <p><b>Label the diagram below.</b></p>
    <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer for questions <b>36-38</b>.</i></p>
    
    <div style="text-align: center; margin: 20px 0;">
      <img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1781100098/6a76c07f-815d-4ca9-b6b6-4c762a1b708c_8354636650f288d61f66fe5e9f44adbc1155279d.jpg" alt="Hydropower Plant Diagram" style="max-width: 100%; height: auto; border: 1px solid #cbd5e1; border-radius: 4px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);" />
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><b>Complete the sentences below.</b></p>
    <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer.</i></p>

</div>','',4,'Part 4',54),
	 ('2026-09-19 17:31:40','truongdx18vtit',false,'2026-09-19 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781101383/721556c1-688b-4199-ac70-d50441276a48_sim_0601.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 700px; margin: 0 auto; text-align: justify;">

  <div style="margin-bottom: 40px; border: 1px solid #cbd5e1; padding: 20px; background-color: #f8fafc; border-radius: 6px;">
    <p style="margin-top: 0; font-weight: bold; color: #0f172a; font-size: 15px;">Application for: Children''s Librarian � Volunteer</p>
    <p><i>Complete the form below. Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer.</i></p>

    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr; gap: 10px;">
      <div><b>Name:</b> Tessa Bridges</div>
      <div><b>Address:</b> 51, <b>(1)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> Drive</div>
      <div><b>Area:</b> Northwood</div>
      <div><b>Postcode:</b> <b>(2)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
      <div><b>Studying at:</b> Northwood Polytechnic</div>
      <div><b>Major:</b> <b>(3)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
      <div><b>Career choice:</b> Children''s author</div>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div style="margin-bottom: 40px;">
    <p style="font-weight: bold; font-size: 15px; color: #0f172a; margin-bottom: 5px;">Work History</p>
    <p><i>Complete the table below. Write <b>NO MORE THAN TWO WORDS</b> for each answer.</i></p>
    
    <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left; margin-top: 15px;">
      <thead>
        <tr style="background-color: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 2px solid #94a3b8;">
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 30%;">Length of service</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 35%;">Employer/Place</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 35%;">Position</th>
        </tr>
      </thead>
      <tbody>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">2 years</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;"><b>(4)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">babysitter</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">1 year</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Senior High School</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;"><b>(5)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">3 months</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Ace Sports Academy</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;"><b>(6)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></td>
        </tr>
        <tr style="border-bottom: 1px solid #cbd5e1;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">ongoing</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">Northwood Hospital</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px; vertical-align: top;">official visitor: Children''s ward</td>
        </tr>
      </tbody>
    </table>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><i>Is Tessa available for work at the times listed below?</i></p>
    <p><i>Write the correct letter, <b>A, B or C</b>, next to questions <b>7-10</b>.</i></p>

    <div style="border: 1px solid #cbd5e1; padding: 15px; background-color: #f8fafc; border-radius: 6px; margin: 15px 0;">
      <div style="margin-bottom: 6px;"><b>A</b> &nbsp;She is definitely available for work at these times</div>
      <div style="margin-bottom: 6px;"><b>B</b> &nbsp;She might be available for work at these times</div>
      <div><b>C</b> &nbsp;She is not available for work at these times</div>
    </div>

    <p style="font-weight: bold; margin-top: 20px; margin-bottom: 10px; color: #0f172a;">Times:</p>
    <div style="display: grid; grid-template-columns: 1fr; gap: 12px; padding-left: 5px;">
      <div><b>7</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[M?c th?i gian s? 7]</div>
      <div><b>8</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[M?c th?i gian s? 8]</div>
      <div><b>9</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[M?c th?i gian s? 9]</div>
      <div><b>10</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> &nbsp;[M?c th?i gian s? 10]</div>
    </div>
  </div>

</div>','',1,'Part 1',55),
	 ('2026-09-20 17:31:40','truongdx18vtit',false,'2026-09-20 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781101418/a4e3b42b-619e-4b87-88b4-1a9862d88dfd_sim_0602.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto; text-align: justify;">



  <div style="margin-bottom: 40px;">

    <p><i>Complete the notes below.</i></p>

    <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer for questions <b>11-17</b>.</i></p>



    <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">

      <p style="margin-top: 0; margin-bottom: 10px; font-weight: bold; color: #0f172a; font-size: 16px;">Be Well Online Programme</p>

      <p style="margin-top: 5px; margin-bottom: 15px;">

        = interactive website with resources to help reach health 

        <b>(11)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>

      </p>



      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Wellness Register:</p>

      <ul style="margin-top: 5px; margin-bottom: 15px; padding-left: 20px; list-style-type: disc;">

        <li style="margin-bottom: 6px;">easy online health check</li>

        <li style="margin-bottom: 6px;">keep a record of progress</li>

        <li>

          get <b>(12)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 

          on present health condition

        </li>

      </ul>



      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Active Health Agenda:</p>

      <p style="margin-top: 0; margin-bottom: 5px; font-style: italic; color: #475569;">8-week plans taking into account age & lifestyle</p>

      <ul style="margin-top: 5px; margin-bottom: 15px; padding-left: 20px; list-style-type: disc;">

        <li style="margin-bottom: 6px;">diet & workout</li>

        <li style="margin-bottom: 6px;">weight loss</li>

        <li style="margin-bottom: 6px;"><b>(13)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>

        <li style="margin-bottom: 6px;">healthy aging</li>

        <li>time-saver workouts</li>

      </ul>



      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Membership:</p>

      <ul style="margin-top: 5px; margin-bottom: 15px; padding-left: 20px; list-style-type: disc;">

        <li style="margin-bottom: 6px;">

          allow use of various tools and 

          <b>(14)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> online

        </li>

        <li>give access to articles, recipes, exercises</li>

      </ul>



      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Active Sport:</p>

      <p style="margin-top: 0; margin-bottom: 5px; font-style: italic; color: #475569;">Individual programmes in accordance with personal objective and <b>(15)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></p>

      <ul style="margin-top: 5px; margin-bottom: 15px; padding-left: 20px; list-style-type: disc;">

        <li>warm-up, workout, weekly training e.g. marathon, swimming, biking, running</li>

      </ul>



      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Active Care <span style="font-weight: normal; font-style: italic; color: #475569;">[for specific health requirements]</span>:</p>

      <ul style="margin-top: 5px; margin-bottom: 0; padding-left: 20px; list-style-type: disc;">

        <li style="margin-bottom: 6px;"><b>(16)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>

        <li style="margin-bottom: 6px;">Glucose Management</li>

        <li style="margin-bottom: 6px;">Heart Health</li>

        <li><b>(17)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>

      </ul>

    </div>

  </div>



  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />



  <div>

    <p><i>Complete the sentences below.</i></p>

    <p><i>Write <b>ONE WORD ONLY</b> for each answer for questions <b>18-20</b>.</i></p>

    

    <p style="font-weight: bold; margin-top: 15px; margin-bottom: 15px; color: #0f172a; font-size: 15px;">Be Well Coaching Course</p>

  </div>



</div>','',2,'Part 2',55),
	 ('2026-09-21 17:31:40','truongdx18vtit',false,'2026-09-21 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781101475/c74ca8f8-109f-4e47-83da-f3d2521f9fda_sim_0603.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto; text-align: justify;">

  <div style="margin-bottom: 40px;">
    <p><i>Write <b>NO MORE THAN THREE WORDS</b> for each answer for questions <b>26-27</b>.</i></p>
    
    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr; gap: 15px; padding-left: 5px;">
      <div><b>26</b> &nbsp;[N?i dung c�u h?i ng?n s? 26] <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
      <div><b>27</b> &nbsp;[N?i dung c�u h?i ng?n s? 27] <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><b>Label the flow chart below.</b></p>
    <p><i>Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer.</i></p>
    
    <div style="max-width: 550px; margin: 25px auto; text-align: center; font-size: 15px;">
      
      <div style="border: 1px solid #cbd5e1; padding: 12px 15px; background-color: #f8fafc; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); text-align: left;">
        <span style="font-weight: bold; color: #0284c7; margin-right: 8px;">Step 1</span> 
        Find ''Portal <b>(28)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>'' on campus on Open Day
      </div>
      
      <div style="font-size: 18px; color: #94a3b8; margin: 6px 0; font-weight: bold;">?</div>

      <div style="border: 1px solid #cbd5e1; padding: 12px 15px; background-color: #f8fafc; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); text-align: left;">
        <span style="font-weight: bold; color: #0284c7; margin-right: 8px;">Step 2</span> 
        Be photographed stepping through the Portal
      </div>
      
      <div style="font-size: 18px; color: #94a3b8; margin: 6px 0; font-weight: bold;">?</div>

      <div style="border: 1px solid #cbd5e1; padding: 12px 15px; background-color: #f8fafc; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); text-align: left;">
        <span style="font-weight: bold; color: #0284c7; margin-right: 8px;">Step 3</span> 
        Give contact <b>(29)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> (name & email address)
      </div>

      <div style="font-size: 18px; color: #94a3b8; margin: 6px 0; font-weight: bold;">?</div>

      <div style="border: 1px solid #cbd5e1; padding: 12px 15px; background-color: #f8fafc; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); text-align: left;">
        <span style="font-weight: bold; color: #0284c7; margin-right: 8px;">Step 4</span> 
        Visit the University Facebook page and vote
      </div>

      <div style="font-size: 18px; color: #94a3b8; margin: 6px 0; font-weight: bold;">?</div>

      <div style="border: 1px solid #cbd5e1; padding: 12px 15px; background-color: #f8fafc; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); text-align: left;">
        <span style="font-weight: bold; color: #0284c7; margin-right: 8px;">Step 5</span> 
        The picture with the most votes at 5 pm on <b>(30)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> wins
      </div>
      
    </div>
  </div>

</div>','',3,'Part 3',55),
	 ('2026-09-22 17:31:40','truongdx18vtit',false,'2026-09-22 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781101682/a4c3a34e-cd6c-4438-96a2-7fc58d4a8d25_sim_0604.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto; text-align: justify;">

  <p><i>Complete the notes below.</i></p>
  <p><i>Write <b>NO MORE THAN TWO WORDS</b> for each answer for questions <b>31-40</b>.</i></p>

  <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">
    <p style="margin-top: 0; margin-bottom: 10px; font-weight: bold; color: #0f172a; font-size: 16px;">Agriculture and Environment</p>
    
    <ul style="margin-top: 5px; padding-left: 20px; list-style-type: disc;">
      <li style="margin-bottom: 8px;">
        <b>(31)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
        production = biggest problem in today''s world
      </li>
      <li style="margin-bottom: 8px;">Agriculture is important for jobs, exports and foreign exchange</li>
      <li style="margin-bottom: 8px;">
        ''Agriculture'' means:
        <ul style="list-style-type: square; padding-left: 20px; margin-top: 4px;">
          <li style="margin-bottom: 4px;">growing crops</li>
          <li style="margin-bottom: 4px;">raising animals</li>
          <li style="margin-bottom: 4px;"><b>(32)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
          <li><b>(33)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></li>
        </ul>
      </li>
      <li style="margin-bottom: 8px;">
        Agriculture must be sustainable: old methods, & new, chemical methods are all unsustainable ? 
        <b>(34)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> of biodiversity
      </li>
      <li style="margin-bottom: 8px;">
        Biotechnology ? GM or GE ? bio-prospecting (bio-piracy) i.e. large companies steal samples of native plants to use the 
        <b>(35)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> for their own crop improvement
      </li>
      <li style="margin-bottom: 8px;">
        <b>(36)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> is responsible for less food and higher prices
      </li>
      <li style="margin-bottom: 8px;">
        Farmers need to be educated but governments also need to pay attention to 
        <b>(37)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> in order to protect the environment and re-nourish the soil
      </li>
      <li style="margin-bottom: 8px;">
        Experts from around the world could come together to form a 
        <b>(38)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> to observe farm systems aiming to prevent pollution and erosion and encourage safe procedures that are also 
        <b>(39)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
      </li>
      <li>
        Creating the project''s 
        <b>(40)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> would be very expensive and more money would be needed for the monitoring system but it could solve the problem of food shortages
      </li>
    </ul>
  </div>

</div>','',4,'Part 4',55),
	 ('2026-09-23 17:31:40','truongdx18vtit',false,'2026-09-23 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781103037/c36b9207-1d35-4f0a-8699-205db1ed9610_sim_0701.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 750px; margin: 0 auto;">

  <p><i>Complete the form below.</i></p>
  <p><i>Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer for questions <b>5-10</b>.</i></p>

  <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left; margin-top: 15px; border: 1px solid #cbd5e1;">
    <tbody>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold; width: 35%;">Passport #</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px; width: 65%;">
          <b>(5)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Nationality</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Spanish</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Postal address</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          1339 <b>(6)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br />
          Hollywell 1517
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Contact details</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Phone: 09-5577 5076</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Preferred contact person</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          Martha <b>(7)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br />
          (landlady) � contact number above
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Title</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          <b>(8)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Family name</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Farina</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">First given name</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Mafia</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Other given name(s)</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Rosa Ana</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Any other names</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          Mary = (<b>(9)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>)
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Date of birth</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          <b>(10)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> (dd/mm/yy)
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Gender</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Female</td>
      </tr>
      <tr>
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Name of spouse</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">N/A</td>
      </tr>
    </tbody>
  </table>

</div>','',1,'Part 1',56),
	 ('2026-09-24 17:31:40','truongdx18vtit',false,'2026-09-24 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781103124/7e6fb744-de42-4909-a227-5b6dfb943c33_sim_0702.mp3','','<div style="font-family: sans-serif; line-height: 1.8; max-width: 750px; margin: 0 auto;">

  <p><i>Complete the form below.</i></p>
  <p><i>Write <b>NO MORE THAN TWO WORDS AND/OR A NUMBER</b> for each answer for questions <b>5-10</b>.</i></p>

  <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left; margin-top: 15px; border: 1px solid #cbd5e1;">
    <tbody>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold; width: 35%;">Passport #</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px; width: 65%;">
          <b>(5)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Nationality</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Spanish</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Postal address</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          1339 <b>(6)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br />
          Hollywell 1517
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Contact details</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Phone: 09-5577 5076</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Preferred contact person</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          Martha <b>(7)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br />
          (landlady) � contact number above
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Title</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          <b>(8)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Family name</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Farina</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">First given name</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Mafia</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Other given name(s)</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Rosa Ana</td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Any other names</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          Mary = (<b>(9)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>)
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Date of birth</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">
          <b>(10)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> (dd/mm/yy)
        </td>
      </tr>
      <tr style="border-bottom: 1px solid #e2e8f0;">
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Gender</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">Female</td>
      </tr>
      <tr>
        <td style="border: 1px solid #cbd5e1; padding: 12px; background-color: #f8fafc; font-weight: bold;">Name of spouse</td>
        <td style="border: 1px solid #cbd5e1; padding: 12px;">N/A</td>
      </tr>
    </tbody>
  </table>

</div>','',2,'Part 2',56),
	 ('2026-09-25 17:31:40','truongdx18vtit',false,'2026-09-25 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781103152/884bec68-3009-4ce1-b113-7dca85fbb375_sim_0703.mp3','','D??i ?�y l� m� HTML ?� ???c c?u tr�c v� ??nh d?ng chu?n ch?nh cho hai ph?n b�i t?p (**Notes Completion** v� **S? ?? ?? th? / B?n ?? - Diagram Labeling**) ?i k�m v?i h�nh ?nh g?c ?? b?n d? d�ng l?u tr? v�o c? s? d? li?u v� hi?n th? ??ng b? tr�n h? th?ng UI:

```html
<div style="font-family: sans-serif; line-height: 1.8; max-width: 650px; margin: 0 auto; text-align: justify;">

  <div style="margin-bottom: 40px;">
    <p><i>Complete the notes below.</i></p>
    <p><i>Write <b>NO MORE THAN THREE WORDS</b> for each answer for questions <b>24-28</b>.</i></p>

    <div style="border: 1px solid #cbd5e1; padding: 25px; background-color: #f8fafc; border-radius: 6px; margin-top: 15px;">
      <p style="margin-top: 0; margin-bottom: 10px; font-weight: bold; color: #0f172a; font-size: 16px;">Department of Education Questionnaire</p>
      <p style="margin-bottom: 5px; font-weight: bold; color: #334155;">Reasons for Studying Abroad</p>
      <p style="margin-top: 0; margin-bottom: 8px; font-style: italic; color: #475569;">Study abroad...</p>
      
      <ul style="margin-top: 5px; padding-left: 20px; list-style-type: disc;">
        <li style="margin-bottom: 8px;">...is the best way to learn a language</li>
        <li style="margin-bottom: 8px;">
          ...provides a 
          <b>(24)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </li>
        <li style="margin-bottom: 8px;">...allows you to experience another culture first-hand</li>
        <li style="margin-bottom: 8px;">
          ...helps you 
          <b>(25)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </li>
        <li style="margin-bottom: 8px;">...gives you the opportunity to make new friends</li>
        <li style="margin-bottom: 8px;">
          ...helps you 
          <b>(26)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </li>
        <li style="margin-bottom: 8px;">
          ...enables you to 
          <b>(27)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </li>
        <li style="margin-bottom: 8px;">...increases the value of your degree</li>
        <li style="margin-bottom: 8px;">
          ...improves 
          <b>(28)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
        </li>
        <li>...expands your world view</li>
      </ul>
    </div>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><b>Label the diagram below.</b></p>
    <p><i>Choose your answers from the box below and write the letters <b>A-H</b> next to questions <b>29-30</b>.</i></p>

    <div style="border: 1px solid #cbd5e1; padding: 15px; background-color: #f8fafc; border-radius: 6px; margin: 15px 0;">
      <p style="margin-top: 0; margin-bottom: 10px; font-weight: bold; color: #0f172a;">Countries</p>
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; font-size: 14px;">
        <div><b>A.</b> Afghanistan</div>
        <div><b>B.</b> Saudi Arabia</div>
        <div><b>C.</b> Iraq</div>
        <div><b>D.</b> Japan</div>
        <div><b>E.</b> Mexico</div>
        <div><b>F.</b> Iran</div>
        <div><b>G.</b> Sweden</div>
        <div><b>H.</b> USA</div>
      </div>
    </div>

    <div style="text-align: center; margin: 20px 0;">
      <img src="https://res.cloudinary.com/dilyyimrn/image/upload/v1781103569/a66bc55d-c6a0-43b5-98ae-497a80652c15_8b33aa6cee24137a0182ecf55790137cb64ab72b.jpg" alt="Education Survey Diagram" style="max-width: 100%; height: auto; border: 1px solid #cbd5e1; border-radius: 4px; box-shadow: 0 2px 6px rgba(0,0,0,0.05);" />
    </div>

    <div style="margin-top: 20px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; padding-left: 5px;">
      <div><b>29</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
      <div><b>30</b> &nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u></div>
    </div>
  </div>

</div>

```','',3,'Part 3',56);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-09-26 17:31:40','truongdx18vtit',false,'2026-09-26 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781103218/0a288a0e-ec27-4ac3-82d5-9decfa8e6608_sim_0704.mp3','','D??i ?�y l� m� HTML ?� ???c c?u tr�c v� ??nh d?ng chu?n h�a cho to�n b? Section 4 (bao g?m b�i t?p **Table Completion** d?a tr�n h�nh ?nh b?n ?� cung c?p v� b�i t?p **Summary Completion**) ?? b?n l?u tr? v�o c? s? d? li?u v� hi?n th? ??ng b? tr�n h? th?ng UI:

```html
<div style="font-family: sans-serif; line-height: 1.8; max-width: 850px; margin: 0 auto; text-align: justify;">

  <div style="margin-bottom: 25px; font-size: 15px; color: #334155;">
    <h3 style="margin-top: 0; margin-bottom: 10px; color: #0f172a;">Charles Willson Peale</h3>
    <ul style="list-style-type: disc; padding-left: 20px; margin: 0;">
      <li>1741 � Born in Maryland, USA</li>
      <li>Became a saddler</li>
      <li>Began to paint</li>
      <li>1766 � London to study with B. West</li>
    </ul>
  </div>

  <div style="margin-bottom: 40px;">
    <p><i>Complete the table below.</i></p>
    <p><i>Write <b>NO MORE THAN TWO WORDS OR A NUMBER</b> for each answer for questions <b>31-36</b>.</i></p>
    
    <table style="width: 100%; border-collapse: collapse; font-size: 14px; text-align: left; margin-top: 15px; border: 1px solid #cbd5e1;">
      <thead>
        <tr style="background-color: #f1f5f9; border-bottom: 2px solid #94a3b8;">
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 10%;">Slide</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 28%;">Painting</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 15%;">Date</th>
          <th style="border: 1px solid #cbd5e1; padding: 10px; width: 47%;">Notes</th>
        </tr>
      </thead>
      <tbody>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">1</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">Pitt as a Roman Senator</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            <b>(31)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">elaborate, symbolical portrait of British parliamentarian</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">2</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">George Washington</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">1772</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            <b>(32)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> of many Washington portraits
          </td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">3</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">The Peale Family</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">1773</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            family portrait � shows exuberance & <br />
            <b>(33)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
          </td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">4</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            The <b>(34)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">1795</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">''trompe l''oeil'' [= ''fool the eye''] style � double portrait of sons � Raphaelle & Titian</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">5</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">Rachel Weeping</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">1772</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            wife and dead <b>(35)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> � macabre
          </td>
        </tr>
        <tr style="border-bottom: 1px solid #cbd5e1;">
          <td style="border: 1px solid #cbd5e1; padding: 10px; font-weight: bold; text-align: center;">6</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">�</td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">
            <b>(36)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>
          </td>
          <td style="border: 1px solid #cbd5e1; padding: 10px;">brother James � in darkness but face</td>
        </tr>
      </tbody>
    </table>
  </div>

  <hr style="border: 0; border-top: 1px dashed #cbd5e1; margin: 30px 0;" />

  <div>
    <p><i>Complete the summary below.</i></p>
    <p><i>Write <b>ONE WORD ONLY</b> for each answer for questions <b>37-40</b>.</i></p>
    
    <div style="margin-top: 15px; border: 1px solid #cbd5e1; padding: 20px; background-color: #f8fafc; border-radius: 6px; text-align: justify;">
      Primarily, Peale was a painter but he was also a politician, scientist and 
      <b>(37)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
      with many successful patents. He worked with Thomas Jefferson on the polygraph which was a desk that could be used for copying a 
      <b>(38)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>. 
      He wrote academic papers on different subjects and tried to make movies, spectacles and a velocipede (a kind of 
      <b>(39)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>). 
      Peale was also a naturalist and taxidermist and he helped unearth the skeleton of a mastodon which was the best 
      <b>(40)</b> <u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u> 
      in his museum.
    </div>
  </div>

</div>

```','',4,'Part 4',56),
	 ('2026-09-27 17:31:40','truongdx18vtit',false,'2026-09-27 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781014596/408156b6-2bfe-4548-90f3-ef4811f8a855_08_ielts14-test1-audio1.mp3','','<p>Complete the form below.</p>

<p>Write <strong>ONE WORD AND/OR A NUMBER</strong> for each answer.</p>

<p><strong>CRIME REPORT FORM</strong></p>

<table>
    <tr>
        <td><strong>Type of crime:</strong></td>
        <td>theft</td>
    </tr>

    <tr><td colspan="2"><br><strong>Personal information</strong></td></tr>

    <tr>
        <td><em>Example</em></td>
        <td></td>
    </tr>

    <tr>
        <td>Name</td>
        <td>Louise ...Taylor...</td>
    </tr>

    <tr>
        <td>Nationality</td>
        <td><strong>1</strong> ..................</td>
    </tr>

    <tr>
        <td>Date of birth</td>
        <td>14 December 1977</td>
    </tr>

    <tr>
        <td>Occupation</td>
        <td>interior designer</td>
    </tr>

    <tr>
        <td>Reason for visit</td>
        <td>business (to buy antique <strong>2</strong>................)</td>
    </tr>

    <tr>
        <td>Length of stay</td>
        <td>two months</td>
    </tr>

    <tr>
        <td>Current address</td>
        <td><strong>3</strong> ................ Apartments (No 15)</td>
    </tr>

    <tr><td colspan="2"><br><strong>Details of theft</strong></td></tr>

    <tr>
        <td>Items stolen</td>
        <td>– a wallet containing approximately <strong>4 £</strong> ..............</td>
    </tr>

    <tr>
        <td></td>
        <td>– a <strong>5</strong> ..............</td>
    </tr>

    <tr>
        <td>Date of theft</td>
        <td><strong>6</strong> ..............</td>
    </tr>

    <tr><td colspan="2"><br><strong>Possible time and place of theft</strong></td></tr>

    <tr>
        <td>Location</td>
        <td>outside the <strong>7</strong>.............. at about 4 pm</td>
    </tr>

    <tr>
        <td>Details of suspect</td>
        <td>– some boys asked for the <strong>8</strong>.............. then ran off</td>
    </tr>

    <tr>
        <td></td>
        <td>– one had a T-shirt with a picture of a tiger</td>
    </tr>

    <tr>
        <td></td>
        <td>– he was about 12, slim build with <strong>9</strong>.............. hair</td>
    </tr>

    <tr><td colspan="2"><br><strong>Crime reference number allocated</strong></td></tr>

    <tr>
        <td></td>
        <td><strong>10</strong> ..............</td>
    </tr>
</table>','',1,'Part 1',57),
	 ('2026-09-28 17:31:40','truongdx18vtit',false,'2026-09-28 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781014763/954cb52d-84fd-49f2-81bb-ee68301c1cfc_08_ielts14-test1-audio2.m4a','','<p><strong>Choose <u>TWO</u> letters, A-E.</strong></p>

<p>
    Which <strong>TWO</strong> pieces of advice for the first week of an apprenticeship
    does the manager give?
</p>

<p><strong>A</strong> &nbsp;&nbsp;&nbsp; get to know colleagues</p>
<p><strong>B</strong> &nbsp;&nbsp;&nbsp; learn from any mistakes</p>
<p><strong>C</strong> &nbsp;&nbsp;&nbsp; ask lots of questions</p>
<p><strong>D</strong> &nbsp;&nbsp;&nbsp; react positively to feedback</p>
<p><strong>E</strong> &nbsp;&nbsp;&nbsp; enjoy new challenges</p>

<br>

<p><strong>Choose <u>TWO</u> letters, A-E.</strong></p>

<p>
    Which <strong>TWO</strong> things does the manager say mentors can help with?
</p>

<p><strong>A</strong> &nbsp;&nbsp;&nbsp; confidence-building</p>
<p><strong>B</strong> &nbsp;&nbsp;&nbsp; making career plans</p>
<p><strong>C</strong> &nbsp;&nbsp;&nbsp; completing difficult tasks</p>
<p><strong>D</strong> &nbsp;&nbsp;&nbsp; making a weekly timetable</p>
<p><strong>E</strong> &nbsp;&nbsp;&nbsp; reviewing progress</p>

<br>

<p>
    What does the manager say about each of the following aspects of the company
    policy for apprentices?
</p>

<p>
    Write the correct letter, <strong>A</strong>, <strong>B</strong> or
    <strong>C</strong>, next to Questions <strong>15-20</strong>.
</p>

<p><strong>A</strong> &nbsp;&nbsp;&nbsp; It is encouraged.</p>
<p><strong>B</strong> &nbsp;&nbsp;&nbsp; There are some restrictions.</p>
<p><strong>C</strong> &nbsp;&nbsp;&nbsp; It is against the rules.</p>

<br>

<p><strong>Company policy for apprentices</strong></p>','',2,'Part 2',57),
	 ('2026-09-30 17:31:40','truongdx18vtit',false,'2026-09-30 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015253/d5424b61-2565-4918-9134-ab9d8ff305de_08_ielts14-test1-audio4.m4a','','<p><strong>Complete the notes below.</strong></p>

<p>Write <strong>ONE WORD ONLY</strong> for each answer.</p>

<p><strong>Marine renewable energy (ocean energy)</strong></p>

<p><strong>Introduction</strong></p>

<p>
    More energy required because of growth in population and
    <strong>31</strong> ......................
</p>

<p><strong>What''s needed:</strong></p>

<p>● &nbsp; renewable energy sources</p>
<p>● &nbsp; methods that won''t create pollution</p>

<br>

<p><strong>Wave energy</strong></p>

<p>
    Advantage: waves provide a <strong>32</strong> ...................... source of renewable energy
</p>

<p>Electricity can be generated using offshore or onshore systems</p>

<p>Onshore systems may use a reservoir</p>

<p><strong>Problems:</strong></p>

<p>
    ● &nbsp; waves can move in any <strong>33</strong> ......................
</p>

<p>
    ● &nbsp; movement of sand, etc. on the <strong>34</strong> ...................... of the ocean may be affected
</p>

<br>

<p><strong>Tidal energy</strong></p>

<p>
    Tides are more <strong>35</strong> ...................... than waves
</p>

<p><strong>Planned tidal lagoon in Wales:</strong></p>

<p>
    ● &nbsp; will be created in a <strong>36</strong> ...................... at Swansea
</p>

<p>
    ● &nbsp; breakwater (dam) containing 16 turbines
</p>

<p>
    ● &nbsp; rising tide forces water through turbines, generating electricity
</p>

<p>
    ● &nbsp; stored water is released through <strong>37</strong> ......................, driving the turbines in the reverse direction
</p>

<p><strong>Advantages:</strong></p>

<p>
    ● &nbsp; not dependent on weather
</p>

<p>
    ● &nbsp; no <strong>38</strong> ...................... is required to make it work
</p>

<p>
    ● &nbsp; likely to create a number of <strong>39</strong> ......................
</p>

<p><strong>Problem:</strong></p>

<p>
    ● &nbsp; may harm fish and birds, e.g. by affecting
    <strong>40</strong> ...................... and building up silt
</p>

<br>

<p><strong>Ocean thermal energy conversion</strong></p>

<p>
    Uses a difference in temperature between the surface and lower levels
</p>

<p>
    Water brought to the surface in a pipe
</p>','',4,'Part 4',57),
	 ('2026-10-01 17:31:40','truongdx18vtit',false,'2026-10-01 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015481/64225400-bb96-422b-a22b-2616f6ddfbef_08_ielts15_test1_audio1.m4a','','<p><strong>Complete the notes below.</strong></p>

<p>Write <strong>ONE WORD AND/OR A NUMBER</strong> for each answer.</p>

<p><strong>Bankside Recruitment Agency</strong></p>

<p>● &nbsp; Address of agency: 497 Eastside, Docklands</p>

<p>● &nbsp; Name of agent: Becky <strong>1</strong> ......................</p>

<p>● &nbsp; Phone number: 07866 510333</p>

<p>● &nbsp; Best to call her in the <strong>2</strong> ......................</p>

<br>

<p><strong>Typical jobs</strong></p>

<p>● &nbsp; Clerical and admin roles, mainly in the finance industry</p>

<p>● &nbsp; Must have good <strong>3</strong> ...................... skills</p>

<p>● &nbsp; Jobs are usually for at least one <strong>4</strong> ......................</p>

<p>● &nbsp; Pay is usually <strong>5</strong> £ ...................... per hour</p>

<br>

<p><strong>Registration process</strong></p>

<p>● &nbsp; Wear a <strong>6</strong> ...................... to the interview</p>

<p>● &nbsp; Must bring your <strong>7</strong> ...................... to the interview</p>

<p>● &nbsp; They will ask questions about each applicant''s <strong>8</strong> ......................</p>

<br>

<p><strong>Advantages of using an agency</strong></p>

<p>● &nbsp; The <strong>9</strong> ...................... you receive at interview will benefit you</p>

<p>● &nbsp; Will get access to vacancies which are not advertised</p>

<p>● &nbsp; Less <strong>10</strong> ...................... is involved in applying for jobs</p>','',1,'Part 1',58),
	 ('2026-10-02 17:31:40','truongdx18vtit',false,'2026-10-02 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015522/d3af0874-5af2-413e-b221-984ed91698e0_08_ielts15_test1_audio2.m4a','','<table style="border-collapse: collapse; width: 100%;">
    <tr>
        <td colspan="3" style="border: 1px solid #000; padding: 10px;">
            <strong>Timetable for Isle of Man holiday</strong>
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;"></td>
        <td style="border: 1px solid #000; padding: 10px;"><strong>Activity</strong></td>
        <td style="border: 1px solid #000; padding: 10px;"><strong>Notes</strong></td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 1</td>
        <td style="border: 1px solid #000; padding: 10px;">Arrive</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Introduction by manager<br><br>
            Hotel dining room has view of the <strong>15</strong> ............
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 2</td>
        <td style="border: 1px solid #000; padding: 10px;">Tynwald Exhibition and Peel</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Tynwald may have been founded in <strong>16</strong> ............ not 979.
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 3</td>
        <td style="border: 1px solid #000; padding: 10px;">Trip to Snaefell</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Travel along promenade in a tram; train to Laxey; train to the
            <strong>17</strong> ............ of Snaefell
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 4</td>
        <td style="border: 1px solid #000; padding: 10px;">Free day</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Company provides a <strong>18</strong> ............ for local transport and heritage sites.
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 5</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Take the <strong>19</strong> ............ railway train from Douglas to Port Erin
        </td>
        <td style="border: 1px solid #000; padding: 10px;">
            Free time, then coach to Castletown – former
            <strong>20</strong> ............ has old castle.
        </td>
    </tr>

    <tr>
        <td style="border: 1px solid #000; padding: 10px;">Day 6</td>
        <td style="border: 1px solid #000; padding: 10px;">Leave</td>
        <td style="border: 1px solid #000; padding: 10px;">
            Leave the island by ferry or plane
        </td>
    </tr>
</table>','',2,'Part 2',58),
	 ('2026-10-03 17:31:40','truongdx18vtit',false,'2026-10-03 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015568/c3cc9963-8d07-459d-bf23-19f3a34b6118_08_ielts15_test1_audio3.m4a','','<p><strong>Questions 21-26</strong></p>

<p>
    What did findings of previous research claim about the personality traits a child is likely to have because of their position in the family?
</p>

<p>
    Choose <strong>SIX</strong> answers from the box and write the correct letter,
    <strong>A-H</strong>, next to Questions <strong>21-26</strong>.
</p>

<p><strong>Personality Traits</strong></p>

<table border="1" cellspacing="0" cellpadding="8" width="100%">
    <tr>
        <td><strong>A</strong></td>
        <td>outgoing</td>
    </tr>
    <tr>
        <td><strong>B</strong></td>
        <td>selfish</td>
    </tr>
    <tr>
        <td><strong>C</strong></td>
        <td>independent</td>
    </tr>
    <tr>
        <td><strong>D</strong></td>
        <td>attention-seeking</td>
    </tr>
    <tr>
        <td><strong>E</strong></td>
        <td>introverted</td>
    </tr>
    <tr>
        <td><strong>F</strong></td>
        <td>co-operative</td>
    </tr>
    <tr>
        <td><strong>G</strong></td>
        <td>caring</td>
    </tr>
    <tr>
        <td><strong>H</strong></td>
        <td>competitive</td>
    </tr>
</table>

<p><strong>Position in family</strong></p>

<br>

<p><strong>Questions 29-30</strong></p>

<p><strong>Choose TWO letters, A-E.</strong></p>

<p>
    Which <strong>TWO</strong> experiences of sibling rivalry do the speakers agree has been valuable for them?
</p>

<p><strong>A</strong> learning to share</p>
<p><strong>B</strong> learning to stand up for oneself</p>
<p><strong>C</strong> learning to be a good loser</p>
<p><strong>D</strong> learning to be tolerant</p>
<p><strong>E</strong> learning to say sorry</p>','',3,'Part 3',58),
	 ('2026-10-04 17:31:40','truongdx18vtit',false,'2026-10-04 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781015797/75b094f9-6d46-4694-b1f4-5d2f98ec7614_08_ielts15_test1_audio4.m4a','','<p><strong>Complete the notes below.</strong></p>

<p>Write <strong>ONE WORD ONLY</strong> for each answer.</p>

<p><strong>The Eucalyptus Tree in Australia</strong></p>

<p><strong>Importance</strong></p>

<p>
    ● it provides <strong>31</strong> .................... and food for a wide range of species
</p>

<p>
    ● its leaves provide <strong>32</strong> .................... which is used to make a disinfectant
</p>

<br>

<p><strong>Reasons for present decline in number</strong></p>

<p><strong>A) Diseases</strong></p>

<p><strong>(i) ''Mundulla Yellows''</strong></p>

<p>
    ● Cause – lime used for making <strong>33</strong> .................... was absorbed
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – trees were unable to take in necessary iron through their roots
</p>

<br>

<p><strong>(ii) ''Bell-miner Associated Die-back''</strong></p>

<p>
    ● Cause – <strong>34</strong> .................... feed on eucalyptus leaves
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – they secrete a substance containing sugar
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – bell-miner birds are attracted by this and keep away other species
</p>

<br>

<p><strong>B) Bushfires</strong></p>

<p><strong>William Jackson''s theory:</strong></p>

<p>
    ● high-frequency bushfires have impact on vegetation, resulting in the growth of
    <strong>35</strong> ....................
</p>

<p>
    ● mid-frequency bushfires result in the growth of eucalyptus forests, because they:
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – make more <strong>36</strong> .................... available to the trees
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – maintain the quality of the <strong>37</strong> ....................
</p>

<p>
    ● low-frequency bushfires result in the growth of
    <strong>38</strong> ''.................... rainforest'', which is:
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – a <strong>39</strong> .................... ecosystem
</p>

<p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    – an ideal environment for the <strong>40</strong> .................... of the bell-miner
</p>','',4,'Part 4',58),
	 ('2026-10-05 17:31:40','truongdx18vtit',false,'2026-10-05 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_1.mp3','','<h3>Complete the notes below.</h3>

<p><strong>Write ONE WORD AND/OR A NUMBER for each answer.</strong></p>

<h4>Children’s Engineering Workshops</h4>

<h5>Tiny Engineers (ages 4-5)</h5>

<p><strong>Activities:</strong></p>

<p>☑️ Create a cover for an <strong>(1)</strong> .......................................... so they can drop it from a height without breaking it.</p>

<p>☑️ Take part in a competition to build the tallest <strong>(2)</strong> .......................................... .</p>

<p>☑️ Make a <strong>(3)</strong> .......................................... powered by a balloon.</p>

<h5>Junior Engineers (ages 6-8)</h5>

<p><strong>Activities:</strong></p>

<p>☑️ Build model cars, trucks and <strong>(4)</strong> .......................................... and learn how to program them so they can move.</p>

<p>☑️ Take part in a competition to build the longest <strong>(5)</strong> .......................................... using card and wood.</p>

<p>☑️ Create a short <strong>(6)</strong> .......................................... with special software.</p>

<p>☑️ Build, <strong>(7)</strong> .......................................... and program a humanoid robot.</p>

<p><strong>Cost for a five-week block:</strong> £50</p>

<p><strong>Held on</strong> <strong>(8)</strong> .......................................... from 10 am to 11 am</p>

<h5>Location</h5>

<p>☑️ Building 10A, <strong>(9)</strong> .......................................... Industrial Estate, Grasford</p>

<p>☑️ Plenty of <strong>(10)</strong> .......................................... is available.</p>','',1,'Part 1',59),
	 ('2026-10-06 17:31:40','truongdx18vtit',false,'2026-10-06 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_2.mp3','','<h3>Questions 15–20</h3>

<p><strong>Label the map below.</strong></p>

<p><strong>Write the correct letter, A–J, next to questions 15–20.</strong></p>

<p>
    <img 
        src="https://res.cloudinary.com/dilyyimrn/image/upload/v1781094258/510ad4dd-5032-474e-a086-955349ff72e3_3d46128fe68b2a7ed69bd2b4c43763408ec875cb.jpg" 
        alt="Map for Questions 15–20"
        style="max-width: 100%; height: auto;">
</p>','',2,'Part 2',59);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-10-07 17:31:40','truongdx18vtit',false,'2026-10-07 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_3.mp3','','<h3>Questions 21–22</h3>

<p><strong>Choose TWO letters, A–E.</strong></p>

<p><strong>Which TWO parts of the introductory stage to their art projects do Jess &amp; Tom agree were useful?</strong></p>

<p>A. the Bird Park visit</p>
<p>B. the workshop sessions</p>
<p>C. the Natural History Museum visit</p>
<p>D. the projects done in previous years</p>
<p>E. the handouts with research sources</p>

<hr>

<h3>Questions 23–24</h3>

<p><strong>Choose TWO letters, A–E.</strong></p>

<p><strong>In which TWO ways do both Jess &amp; Tom decide to change their proposals?</strong></p>

<p>A. by giving a rationale for their action plans</p>
<p>B. by being less specific about the outcome</p>
<p>C. by adding a video diary presentation</p>
<p>D. by providing a timeline and a mind map</p>
<p>E. by making their notes more evaluative</p>

<hr>

<h3>Questions 25–30</h3>

<p><strong>Which personal meaning do the students decide to give to each of the following pictures?</strong></p>

<p><strong>Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.</strong></p>

<p><strong>Personal meanings</strong></p>

<p>A. a childhood memory</p>
<p>B. hope for the future</p>
<p>C. fast movement</p>
<p>D. a potential threat</p>
<p>E. the power of colour</p>
<p>F. the continuity of life</p>
<p>G. protection of nature</p>
<p>H. a confused attitude to nature</p>','',3,'Part 3',59),
	 ('2026-10-08 17:31:40','truongdx18vtit',false,'2026-10-08 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_4.mp3','','<h3>Questions 31–40</h3>

<p><strong>Complete the notes below.</strong></p>

<p><strong>Write ONE WORD ONLY for each answer.</strong></p>

<h4>Stoicism</h4>

<p>Stoicism is still relevant today because of its <strong>(31)</strong> .......................................... appeal.</p>

<h5>Ancient Stoics</h5>

<p>☑️ Stoicism was founded over 200 years ago in Greece.</p>

<p>☑️ The Stoics’ ideas are surprisingly well known, despite not being intended for <strong>(32)</strong> .......................................... .</p>

<h5>Stoic principles</h5>

<p>☑️ Happiness could be achieved by leading a virtuous life.</p>

<p>☑️ Controlling emotions was essential.</p>

<p>☑️ Epictetus said that external events cannot be controlled but the <strong>(33)</strong> .......................................... people make in response can be controlled.</p>

<p>☑️ A Stoic is someone who has a different view on experiences which others would consider as <strong>(34)</strong> .......................................... .</p>

<h5>The influence of Stoicism</h5>

<p>☑️ George Washington organised a <strong>(35)</strong> .......................................... about Cato to motivate his men.</p>

<p>☑️ The French artist Delacroix was a Stoic.</p>

<p>☑️ Adam Smith’s ideas on <strong>(36)</strong> .......................................... were influenced by Stoicism.</p>

<p>☑️ Some of today’s political leaders are inspired by the Stoics.</p>

<p><strong>☑️ Cognitive Behaviour Therapy (CBT)</strong></p>

<p>&ndash; the treatment for <strong>(37)</strong> .......................................... is based on ideas from Stoicism</p>

<p>&ndash; people learn to base their thinking on <strong>(38)</strong> .......................................... .</p>

<p>☑️ In business, people benefit from Stoicism by identifying obstacles as <strong>(39)</strong> .......................................... .</p>

<h5>Relevance of Stoicism</h5>

<p>☑️ It requires a lot of <strong>(40)</strong> .......................................... but Stoicism can help people to lead a good life.</p>

<p>☑️ It teaches people that having a strong character is more important than anything else.</p>','',4,'Part 4',59),
	 ('2026-10-09 17:31:40','truongdx18vtit',false,'2026-10-09 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_1.mp3','','<h3>Complete the notes below.</h3>

<p><strong>Write ONE WORD AND/OR A NUMBER for each answer.</strong></p>

<h4>Children’s Engineering Workshops</h4>

<h5>Tiny Engineers (ages 4-5)</h5>

<p><strong>Activities:</strong></p>

<p>☑️ Create a cover for an <strong>(1)</strong> .......................................... so they can drop it from a height without breaking it.</p>

<p>☑️ Take part in a competition to build the tallest <strong>(2)</strong> .......................................... .</p>

<p>☑️ Make a <strong>(3)</strong> .......................................... powered by a balloon.</p>

<h5>Junior Engineers (ages 6-8)</h5>

<p><strong>Activities:</strong></p>

<p>☑️ Build model cars, trucks and <strong>(4)</strong> .......................................... and learn how to program them so they can move.</p>

<p>☑️ Take part in a competition to build the longest <strong>(5)</strong> .......................................... using card and wood.</p>

<p>☑️ Create a short <strong>(6)</strong> .......................................... with special software.</p>

<p>☑️ Build, <strong>(7)</strong> .......................................... and program a humanoid robot.</p>

<p><strong>Cost for a five-week block:</strong> £50</p>

<p><strong>Held on</strong> <strong>(8)</strong> .......................................... from 10 am to 11 am</p>

<h5>Location</h5>

<p>☑️ Building 10A, <strong>(9)</strong> .......................................... Industrial Estate, Grasford</p>

<p>☑️ Plenty of <strong>(10)</strong> .......................................... is available.</p>','',1,'Part 1',60),
	 ('2026-10-10 17:31:40','truongdx18vtit',false,'2026-10-10 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_2.mp3','','<h3>Questions 15–20</h3>

<p><strong>Label the map below.</strong></p>

<p><strong>Write the correct letter, A–J, next to questions 15–20.</strong></p>

<p>
    <img 
        src="https://res.cloudinary.com/dilyyimrn/image/upload/v1781094258/510ad4dd-5032-474e-a086-955349ff72e3_3d46128fe68b2a7ed69bd2b4c43763408ec875cb.jpg" 
        alt="Map for Questions 15–20"
        style="max-width: 100%; height: auto;">
</p>','',2,'Part 2',60),
	 ('2026-10-11 17:31:40','truongdx18vtit',false,'2026-10-11 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_3.mp3','','<h3>Questions 21–22</h3>

<p><strong>Choose TWO letters, A–E.</strong></p>

<p><strong>Which TWO parts of the introductory stage to their art projects do Jess &amp; Tom agree were useful?</strong></p>

<p>A. the Bird Park visit</p>
<p>B. the workshop sessions</p>
<p>C. the Natural History Museum visit</p>
<p>D. the projects done in previous years</p>
<p>E. the handouts with research sources</p>

<hr>

<h3>Questions 23–24</h3>

<p><strong>Choose TWO letters, A–E.</strong></p>

<p><strong>In which TWO ways do both Jess &amp; Tom decide to change their proposals?</strong></p>

<p>A. by giving a rationale for their action plans</p>
<p>B. by being less specific about the outcome</p>
<p>C. by adding a video diary presentation</p>
<p>D. by providing a timeline and a mind map</p>
<p>E. by making their notes more evaluative</p>

<hr>

<h3>Questions 25–30</h3>

<p><strong>Which personal meaning do the students decide to give to each of the following pictures?</strong></p>

<p><strong>Choose SIX answers from the box and write the correct letter, A–H, next to Questions 25–30.</strong></p>

<p><strong>Personal meanings</strong></p>

<p>A. a childhood memory</p>
<p>B. hope for the future</p>
<p>C. fast movement</p>
<p>D. a potential threat</p>
<p>E. the power of colour</p>
<p>F. the continuity of life</p>
<p>G. protection of nature</p>
<p>H. a confused attitude to nature</p>','',3,'Part 3',60),
	 ('2026-10-12 17:31:40','truongdx18vtit',false,'2026-10-12 17:31:40','truongdx18vtit','https://s4-media1.study4.com/media/ielts_cam16/Test_1_Part_4.mp3','','<h3>Questions 31–40</h3>

<p><strong>Complete the notes below.</strong></p>

<p><strong>Write ONE WORD ONLY for each answer.</strong></p>

<h4>Stoicism</h4>

<p>Stoicism is still relevant today because of its <strong>(31)</strong> .......................................... appeal.</p>

<h5>Ancient Stoics</h5>

<p>☑️ Stoicism was founded over 200 years ago in Greece.</p>

<p>☑️ The Stoics’ ideas are surprisingly well known, despite not being intended for <strong>(32)</strong> .......................................... .</p>

<h5>Stoic principles</h5>

<p>☑️ Happiness could be achieved by leading a virtuous life.</p>

<p>☑️ Controlling emotions was essential.</p>

<p>☑️ Epictetus said that external events cannot be controlled but the <strong>(33)</strong> .......................................... people make in response can be controlled.</p>

<p>☑️ A Stoic is someone who has a different view on experiences which others would consider as <strong>(34)</strong> .......................................... .</p>

<h5>The influence of Stoicism</h5>

<p>☑️ George Washington organised a <strong>(35)</strong> .......................................... about Cato to motivate his men.</p>

<p>☑️ The French artist Delacroix was a Stoic.</p>

<p>☑️ Adam Smith’s ideas on <strong>(36)</strong> .......................................... were influenced by Stoicism.</p>

<p>☑️ Some of today’s political leaders are inspired by the Stoics.</p>

<p><strong>☑️ Cognitive Behaviour Therapy (CBT)</strong></p>

<p>&ndash; the treatment for <strong>(37)</strong> .......................................... is based on ideas from Stoicism</p>

<p>&ndash; people learn to base their thinking on <strong>(38)</strong> .......................................... .</p>

<p>☑️ In business, people benefit from Stoicism by identifying obstacles as <strong>(39)</strong> .......................................... .</p>

<h5>Relevance of Stoicism</h5>

<p>☑️ It requires a lot of <strong>(40)</strong> .......................................... but Stoicism can help people to lead a good life.</p>

<p>☑️ It teaches people that having a strong character is more important than anything else.</p>','',4,'Part 4',60),
	 ('2026-10-13 17:31:40','truongdx18vtit',false,'2026-10-13 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781093794/a13b8f7a-b482-4cfe-bab9-3b12cf200ace_ELT_IELTS17_t1_audio1.mp3','','<h3>Complete the notes below.</h3>

<p><strong>Write ONE WORD AND/OR A NUMBER for each answer.</strong></p>

<h4>Buckworth Conservation Group</h4>

<h5>Regular activities</h5>

<p><strong>Beach</strong></p>
<ul>
    <li>making sure the beach does not have <strong>1. .........................................</strong> on it</li>
    <li>no <strong>2. .........................................</strong></li>
</ul>

<p><strong>Nature reserve</strong></p>
<ul>
    <li>maintaining paths</li>
    <li>nesting boxes for birds installed</li>
    <li>next task is taking action to attract <strong>3. .........................................</strong> to the place</li>
    <li>identifying types of <strong>4. .........................................</strong></li>
    <li>building a new <strong>5. .........................................</strong></li>
</ul>

<h5>Forthcoming events</h5>

<p><strong>Saturday</strong></p>
<ul>
    <li>meet at Dunsmore Beach car park</li>
    <li>walk across the sands and reach the <strong>6. .........................................</strong></li>
    <li>take a picnic</li>
    <li>wear appropriate <strong>7. .........................................</strong></li>
</ul>

<p><strong>Woodwork session</strong></p>
<ul>
    <li>suitable for <strong>8. .........................................</strong> to participate in</li>
    <li>making <strong>9. .........................................</strong> out of wood</li>
    <li>17th, from 10 a.m. to 3 p.m.</li>
    <li>cost of session (no camping): <strong>10. £.........................................</strong></li>
</ul>','',1,'Part 1',61),
	 ('2026-10-14 17:31:40','truongdx18vtit',false,'2026-10-14 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781093888/3332081d-0672-445c-8c3f-653e511c0c59_ELT_IELTS17_t1_audio2.mp3','','<h3>Questions 15–16</h3>

<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO features of the lighthouse does Lou mention?</strong></p>

<p>A. why it was built</p>
<p>B. who built it</p>
<p>C. how long it took to build</p>
<p>D. who staffed it</p>
<p>E. what it was built with</p>

<hr>

<h3>Questions 17–18</h3>

<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO types of creature might come close to the boat?</strong></p>

<p>A. sea eagles</p>
<p>B. fur seals</p>
<p>C. dolphins</p>
<p>D. whales</p>
<p>E. penguins</p>

<hr>

<h3>Questions 19–20</h3>

<p><strong>Choose TWO letters, A-E.</strong></p>

<p><strong>Which TWO points does Lou make about the caves?</strong></p>

<p>A. Only large tourist boats can visit them.</p>
<p>B. The entrances to them are often blocked.</p>
<p>C. It is too dangerous for individuals to go near them.</p>
<p>D. Someone will explain what is inside them.</p>
<p>E. They cannot be reached on foot.</p>','',2,'Part 2',61),
	 ('2026-10-15 17:31:40','truongdx18vtit',false,'2026-10-15 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781093929/c430a320-2fb7-4ee5-9bb8-d1b92d4d4212_ELT_IELTS17_t1_audio3.mp3','','<h3>Questions 29–30</h3>

<p><strong>What opinion do the students give about each of the following modules on their veterinary science course?</strong></p>

<p><strong>Choose FOUR answers from the box and write the correct letter, A–F, next to questions 27–30.</strong></p>

<p><strong>Opinions</strong></p>

<p>A. Tim found this easier than expected.</p>
<p>B. Tim thought this was not very clearly organised.</p>
<p>C. Diana may do some further study on this.</p>
<p>D. They both found the reading required for this was difficult.</p>
<p>E. Tim was shocked at something he learned on this module.</p>
<p>F. They were both surprised how little is known about some aspects of this.</p>

<p><strong>Modules on Veterinary Science course</strong></p>','',3,'Part 3',61),
	 ('2026-10-16 17:31:40','truongdx18vtit',false,'2026-10-16 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781094061/91c4200e-74c1-4aa4-9378-be938b0d0cf0_ELT_IELTS17_t1_audio4.mp3','','<h3>Questions 31–40</h3>

<p><strong>Complete the notes below.</strong></p>

<p><strong>Write ONE WORD ONLY for each answer.</strong></p>

<h4>Labyrinths</h4>

<p><strong>Definition</strong></p>
<ul>
    <li>a winding spiral path leading to a central area</li>
</ul>

<p><strong>Labyrinths compared with mazes</strong></p>
<ul>
    <li>Mazes are a type of <strong>31. ..........................................</strong></li>
    <li><strong>32. ..........................................</strong> is needed to navigate through a maze</li>
    <li>the word ‘maze’ is derived from a word meaning a feeling of <strong>33. ..........................................</strong></li>
    <li>Labyrinths represent a journey through life
        <ul>
            <li>they have frequently been used in <strong>34. ..........................................</strong> and prayer</li>
        </ul>
    </li>
</ul>

<p><strong>Early examples of the labyrinth spiral</strong></p>
<ul>
    <li>Ancient carvings on <strong>35. ..........................................</strong> have been found across many cultures</li>
    <li>The Pima, a Native American tribe, wove the symbol on baskets</li>
    <li>Ancient Greeks used the symbol on <strong>36. ..........................................</strong></li>
</ul>

<p><strong>Walking labyrinths</strong></p>
<ul>
    <li>The largest surviving example of a turf labyrinth once had a big <strong>37. ..........................................</strong> at its centre</li>
</ul>

<p><strong>Labyrinths nowadays</strong></p>
<ul>
    <li>Believed to have a beneficial impact on mental and physical health, e.g., walking a maze can reduce a person’s <strong>38. ..........................................</strong> rate</li>
    <li>Used in medical and health and fitness settings and also prisons</li>
    <li>Popular with patients, visitors and staff in hospitals
        <ul>
            <li>patients who can’t walk can use ‘finger labyrinths’ made from <strong>39. ..........................................</strong></li>
            <li>research has shown that Alzheimer’s sufferers experience less <strong>40. ..........................................</strong></li>
        </ul>
    </li>
</ul>','',4,'Part 4',61);
INSERT INTO public.test_sections (created_at,created_by,is_deleted,updated_at,updated_by,audio_url,cue_card,passage,sample_answer,section_number,title,test_id) VALUES
	 ('2026-10-17 17:31:40','truongdx18vtit',false,'2026-10-17 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099460/f407d14a-0696-4028-84a6-9149aad2318d_section1-part1.mp3','','<h3>Complete the notes below.</h3>

<p><strong>Write ONE WORD AND/OR A NUMBER for each answer.</strong></p>

<h4>Transport survey</h4>

<p><strong>Name:</strong> Sadie Jones</p>

<p><strong>Year of birth:</strong> 1991</p>

<p><strong>Postcode:</strong> <strong>(1)</strong> ..........................................</p>

<h5>Travelling by bus</h5>

<p><strong>Date of bus journey:</strong> <strong>(2)</strong> ..........................................</p>

<p><strong>Reason for trip:</strong> shopping and visit to the <strong>(3)</strong> ..........................................</p>

<p><strong>Travelled by bus because cost of</strong> <strong>(4)</strong> .......................................... <strong>too high</strong></p>

<p><strong>Got on bus at</strong> <strong>(5)</strong> .......................................... <strong>Street</strong></p>

<p><strong>Complaints about bus service:</strong></p>

<ul>
    <li>bus today was <strong>(6)</strong> ..........................................</li>
    <li>frequency of buses in the <strong>(7)</strong> ..........................................</li>
</ul>

<h5>Travelling by car</h5>

<ul>
    <li>Goes to the <strong>(8)</strong> .......................................... by car</li>
</ul>

<h5>Travelling by bicycle</h5>

<ul>
    <li>Dislikes travelling by bike in the city centre because of the <strong>(9)</strong> ..........................................</li>
    <li>Doesn’t own a bike because of a lack of <strong>(10)</strong> ..........................................</li>
</ul>','',1,'Part 1',62),
	 ('2026-10-18 17:31:40','truongdx18vtit',false,'2026-10-18 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099615/f4eafe0f-9c3f-4a9f-a014-07d6de6d4ba4_section1-part2.mp3','','<h3>Questions 11–13</h3>



<p><strong>Choose the correct letter, A, B or C.</strong></p>



<p><strong>Becoming a volunteer for ACE</strong></p>







<hr>



<h3>Questions 14–15</h3>



<p><strong>Choose TWO letters, A–E.</strong></p>



<p><strong>Which TWO issues does the speaker ask the audience to consider before they apply to be volunteers?</strong></p>



<p>A. their financial situation</p>

<p>B. their level of commitment</p>

<p>C. their work experience</p>

<p>D. their ambition</p>

<p>E. their availability</p>



<hr>



<h3>Questions 16–20</h3>



<p><strong>What does the speaker suggest would be helpful for each of the following areas of voluntary work?</strong></p>



<p><strong>Choose FIVE answers from the box and write the correct letter, A–G, next to Questions 16–20.</strong></p>



<p><strong>Helpful things volunteers might offer</strong></p>



<p>A. experience on stage</p>

<p>B. original, new ideas</p>

<p>C. parenting skills</p>

<p>D. an understanding of food and diet</p>

<p>E. retail experience</p>

<p>F. a good memory</p>

<p>G. a good level of fitness</p>



<p><strong>Area of voluntary work</strong></p>','',2,'Part 2',62),
	 ('2026-10-19 17:31:40','truongdx18vtit',false,'2026-10-19 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099751/016e6a9f-293e-49d6-bdab-386785e0c131_section1-part3.mp3','','<h3>Questions 21–26</h3>



<p><strong>Choose the correct letter, A, B or C.</strong></p>



<p><strong>Talk on jobs in fashion design</strong></p>







<hr>



<h3>Questions 27–28</h3>



<p><strong>Choose TWO letters, A–E.</strong></p>



<p><strong>Which TWO mistakes did the speaker admit she made in her first job?</strong></p>



<p>A. being dishonest to her employer</p>

<p>B. paying too much attention to how she looked</p>

<p>C. expecting to become well known</p>

<p>D. trying to earn a lot of money</p>

<p>E. openly disliking her client</p>



<hr>



<h3>Questions 29–30</h3>



<p><strong>Choose TWO letters, A–E.</strong></p>



<p><strong>Which TWO pieces of retail information do Hugo and Chantal agree would be useful?</strong></p>



<p>A. the reasons people return fashion items</p>



<p>B. how much time people have to shop for clothes</p>



<p>C. fashion designs people want but can’t find</p>



<p>D. the best time of year for fashion buying</p>



<p>E. the most popular fashion sizes</p>','',3,'Part 3',62),
	 ('2026-10-20 17:31:40','truongdx18vtit',false,'2026-10-20 17:31:40','truongdx18vtit','https://res.cloudinary.com/dilyyimrn/video/upload/v1781099821/2d6eb43c-fcc4-4731-b054-ae9fc0c45696_section1-part4.mp3','','<h3>Questions 31–40</h3>

<p><strong>Complete the notes below.</strong></p>

<p><strong>Write ONE WORD ONLY for each answer.</strong></p>

<h4>Elephant translocation</h4>

<h5>Reasons for overpopulation at Majete National Park</h5>

<ul>
    <li>strict enforcement of anti-poaching laws</li>
    <li>successful breeding</li>
</ul>

<h5>Problems caused by elephant overpopulation</h5>

<ul>
    <li>greater competition, causing hunger for elephants</li>
    <li>damage to <strong>(31)</strong> .......................................... in the park</li>
</ul>

<h5>The translocation process</h5>

<ul>
    <li>a suitable group of elephants from the same <strong>(32)</strong> .......................................... was selected</li>

    <li>vets and park staff made use of <strong>(33)</strong> .......................................... to help guide the elephants into an open plain</li>

    <li>elephants were immobilised with tranquilisers
        <ul>
            <li>this process had to be completed quickly to reduce <strong>(34)</strong> ..........................................</li>
            <li>elephants had to be turned <strong>ON</strong> their <strong>(35)</strong> .......................................... to avoid damage to their lungs</li>
            <li>elephants'' <strong>(36)</strong> .......................................... had to be monitored constantly</li>
            <li>tracking devices were fitted to the matriarchs</li>
            <li>data including the size of their tusks and <strong>(37)</strong> ..........................................</li>
        </ul>
    </li>

    <li>elephants were taken by truck to their new reserve</li>
</ul>

<h5>Advantages of translocation at Nkhotakota Wildlife Park</h5>

<ul>
    <li><strong>(38)</strong> .......................................... opportunities</li>

    <li>a reduction in the number of poachers and <strong>(39)</strong> ..........................................</li>

    <li>an example of conservation that other parks can follow</li>

    <li>an increase in <strong>(40)</strong> .......................................... as a contributor to GDP</li>
</ul>','',4,'Part 4',62);
