INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-05-30 17:31:40','',false,'2026-05-30 17:31:40','','',3600,'WRITING',false,'IELTS Practice Set 3 Writing test 4',NULL),
	 ('2026-05-31 17:31:40','',false,'2026-05-31 17:31:40','','',3600,'WRITING',false,'IELTS Practice Set 3 Writing test 5',NULL),
	 ('2026-06-01 17:31:40','',false,'2026-06-01 17:31:40','','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 6',NULL),
	 ('2026-06-02 17:31:40','',false,'2026-06-02 17:31:40','','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 7',NULL),
	 ('2026-06-03 17:31:40','',false,'2026-06-03 17:31:40','','',3600,'WRITING',true,'IELTS Practice Set 3 Writing test 8',NULL),
	 ('2026-06-04 17:31:40','user_56659',false,'2026-06-04 17:31:40','user_56659','',3600,'WRITING',false,'IELTS Practice Set 10 writing test 1',NULL),
	 ('2026-06-05 17:31:40','user_56659',false,'2026-06-05 17:31:40','user_56659','',3600,'WRITING',false,'IELTS Practice Set 11 writing test 1',NULL),
	 ('2026-06-06 17:31:40','user_56659',false,'2026-06-06 17:31:40','user_56659','',3600,'WRITING',false,'IELTS Practice Set 12 writing test 1 ',NULL),
	 ('2026-06-07 17:31:40','user_56659',false,'2026-06-07 17:31:40','user_56659','',3600,'WRITING',true,'IELTS Practice Set 13 writing test 1',NULL),
	 ('2026-06-08 17:31:40','user_56659',false,'2026-06-08 17:31:40','user_56659','',3600,'WRITING',true,'IELTS Practice Set 14 writing test 1',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-09 17:31:40','user_56659',false,'2026-06-09 17:31:40','user_56659','',3600,'WRITING',true,'IELTS Practice Set 15 writing test 1',NULL),
	 ('2026-06-10 17:31:40','user_56659',false,'2026-06-10 17:31:40','user_56659','',3600,'WRITING',true,'IELTS Practice Set 16 writing test 1',NULL),
	 ('2026-06-11 17:31:40','user_56659',false,'2026-06-11 17:31:40','user_56659','',3600,'WRITING',true,'IELTS Practice Set 17 writing test 1',NULL),
	 ('2026-06-12 17:31:40','user_56659',false,'2026-06-12 17:31:40','user_56659','',900,'SPEAKING',false,'IELTS Practice Set 3 Speaking test 4',NULL),
	 ('2026-06-13 17:31:40','user_56659',false,'2026-06-13 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 5',NULL),
	 ('2026-06-14 17:31:40','user_56659',false,'2026-06-14 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 6',NULL),
	 ('2026-06-15 17:31:40','user_56659',false,'2026-06-15 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 3 Speaking test 7',NULL),
	 ('2026-06-16 17:31:40','user_56659',false,'2026-06-16 17:31:40','user_56659','',900,'SPEAKING',false,'IELTS Practice Set 3 Speaking test 8',NULL),
	 ('2026-06-17 17:31:40','user_56659',false,'2026-06-17 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 10 speaking test 1',NULL),
	 ('2026-06-18 17:31:40','user_56659',false,'2026-06-18 17:31:40','user_56659','',900,'SPEAKING',false,'IELTS Practice Set 11 speaking test 1',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-19 17:31:40','user_56659',false,'2026-06-19 17:31:40','user_56659','',900,'SPEAKING',false,'IELTS Practice Set 12 speaking test 1',NULL),
	 ('2026-06-20 17:31:40','user_56659',false,'2026-06-20 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 13 speaking test 1',NULL),
	 ('2026-06-21 17:31:40','user_56659',false,'2026-06-21 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 14 speaking test 1',NULL),
	 ('2026-06-22 17:31:40','user_56659',false,'2026-06-22 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 15 speaking test 1',NULL),
	 ('2026-06-23 17:31:40','user_56659',false,'2026-06-23 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 16 speaking test 1',NULL),
	 ('2026-06-24 17:31:40','user_56659',false,'2026-06-24 17:31:40','user_56659','',900,'SPEAKING',true,'IELTS Practice Set 17 speaking test 1',NULL),
	 ('2026-06-25 17:31:40','user_56659',false,'2026-06-25 17:31:40','user_56659','',3600,'READING',false,'IELTS Practice Set 3 Reading test 1',NULL),
	 ('2026-06-26 17:31:40','user_56659',false,'2026-06-26 17:31:40','user_56659','',3600,'READING',false,'IELTS Practice Set 3 Reading test 2',NULL),
	 ('2026-06-27 17:31:40','user_56659',false,'2026-06-27 17:31:40','user_56659','',3600,'READING',true,'IELTS Practice Set 3 Reading test 3',NULL),
	 ('2026-06-28 17:31:40','user_56659',false,'2026-06-28 17:31:40','user_56659','',3600,'READING',true,'IELTS Practice Set 3 Reading test 4',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-06-29 17:31:40','user_56659',false,'2026-06-29 17:31:40','user_56659','',3600,'READING',true,'IELTS Practice Set 14 reading test 1',NULL),
	 ('2026-06-30 17:31:40','user_05335',false,'2026-06-30 17:31:40','user_05335','',3600,'READING',true,'IELTS Practice Set 3 Reading test 5',NULL),
	 ('2026-07-01 17:31:40','user_05335',false,'2026-07-01 17:31:40','user_05335','',3600,'READING',true,'IELTS Practice Set 3 Reading test 6',NULL),
	 ('2026-07-02 17:31:40','user_05335',false,'2026-07-02 17:31:40','user_05335','',3600,'READING',false,'IELTS Practice Set 3 Reading test 7',NULL),
	 ('2026-07-03 17:31:40','user_05335',false,'2026-07-03 17:31:40','user_05335','',3600,'READING',false,'IELTS Practice Set 3 Reading test 8',NULL),
	 ('2026-07-04 17:31:40','user_56659',false,'2026-07-04 17:31:40','user_56659','',3600,'READING',true,'IELTS Practice Set 7 reading test 1 ',NULL),
	 ('2026-07-05 17:31:40','user_05335',false,'2026-07-05 17:31:40','user_05335','',3600,'READING',true,'IELTS Practice Set 10 reading test 3',NULL),
	 ('2026-07-06 17:31:40','user_05335',false,'2026-07-06 17:31:40','user_05335','',3600,'READING',true,'IELTS Practice Set 11 reading test 3',NULL),
	 ('2026-07-07 17:31:40','user_05335',false,'2026-07-07 17:31:40','user_05335','',3600,'READING',true,'IELTS Practice Set 12 reading test 3',NULL),
	 ('2026-07-08 17:31:40','truongdx18vtit',false,'2026-07-08 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 4',NULL);
INSERT INTO public.tests (created_at,created_by,is_deleted,updated_at,updated_by,description,duration,exam_type,is_pro,title,parent_test_id) VALUES
	 ('2026-07-09 17:31:40','truongdx18vtit',false,'2026-07-09 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 5',NULL),
	 ('2026-07-10 17:31:40','truongdx18vtit',false,'2026-07-10 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 6',NULL),
	 ('2026-07-11 17:31:40','truongdx18vtit',false,'2026-07-11 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Simulation Listening test 7',NULL),
	 ('2026-07-12 17:31:40','truongdx18vtit',false,'2026-07-12 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 14 listening test 1 ',NULL),
	 ('2026-07-13 17:31:40','truongdx18vtit',false,'2026-07-13 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 15 listening test 1',NULL),
	 ('2026-07-14 17:31:40','truongdx18vtit',false,'2026-07-14 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 13 listening test 1',NULL),
	 ('2026-07-15 17:31:40','truongdx18vtit',false,'2026-07-15 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 16 listening test 1',NULL),
	 ('2026-07-16 17:31:40','truongdx18vtit',false,'2026-07-16 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 17 listening test 1',NULL),
	 ('2026-07-17 17:31:40','truongdx18vtit',false,'2026-07-17 17:31:40','truongdx18vtit','',2400,'LISTENING',false,'IELTS Practice Set 18 listening test 1',NULL);
